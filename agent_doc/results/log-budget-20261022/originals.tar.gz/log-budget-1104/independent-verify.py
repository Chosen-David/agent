import hashlib,itertools,json,math,platform,statistics,subprocess,sys,types,unittest
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];sys.path.insert(0,str(R))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((P/'manifest.json').read_text()); binding={name:sha(P/name)==digest for name,digest in m['files'].items()}
assert all(binding.values()),binding
assert sha(R/'agent_runtime/log_context.py')==m['candidate_source_sha256']
assert sha(R/'tests/test_log_context.py')==m['test_sha256']
base=subprocess.check_output(['git','show',m['base_revision']+':agent_runtime/log_context.py'],cwd=R)
assert base==(P/'baseline.py').read_bytes()
assert (P/'candidate.py').read_bytes()==(R/'agent_runtime/log_context.py').read_bytes()
vp=json.loads((P/'validation-plan.json').read_text());contract=json.loads((P/'contract.json').read_text());assert vp['scope']==contract['scope'];assert sha(P/'validation-plan.json')==contract['validation_plan']['sha256']
raw=json.loads((P/'raw.json').read_text()); assert len(raw)==42
stats={};seen=set()
for x in raw:
 key=(x['encoding'],x['phase'],x.get('pair'),x['source']);assert key not in seen;seen.add(key)
 assert x['input_sha256']==m['files']['job.log'];assert x['error']=='selected log exceeds budget; no silent truncation';assert math.isfinite(x['seconds']) and x['seconds']>=0
 assert x['traced']==('yes' if x['phase']=='traced-diagnostic' else 'no')
 assert (type(x['python_peak_bytes']) is int and x['python_peak_bytes']>0) if x['traced']=='yes' else x['python_peak_bytes'] is None
for enc in ('lines','chunks','runs'):
 measured=[x for x in raw if x['encoding']==enc and x['phase']=='measured'];assert len(measured)==10
 pair_improvements=[]
 for pair in range(5):
  rows=[x for x in measured if x['pair']==pair];assert [x['source'] for x in rows]==(['baseline.py','candidate.py'] if pair%2==0 else ['candidate.py','baseline.py'])
  d={x['source']:x['seconds'] for x in rows};pair_improvements.append(1-d['candidate.py']/d['baseline.py'])
 med={src:statistics.median(x['seconds'] for x in measured if x['source']==src) for src in ('baseline.py','candidate.py')}
 traced={x['source']:x['python_peak_bytes'] for x in raw if x['encoding']==enc and x['phase']=='traced-diagnostic'}
 s={'median_seconds':med,'pair_improvements':pair_improvements,'median_improvement':1-med['candidate.py']/med['baseline.py'],'peak_bytes':traced,'peak_improvement':1-traced['candidate.py']/traced['baseline.py']};s['thresholds_pass']=s['median_improvement']>=.1 and min(pair_improvements)>=.05 and s['peak_improvement']>=.2;stats[enc]=s
for opt,label in (([],'ordinary'),(['-O'],'optimized')):
 p=subprocess.run([sys.executable,*opt,'-m','unittest','tests.test_log_context','tests.test_log_chunks','tests.test_log_runs'],cwd=R,capture_output=True,text=True,timeout=30)
 (P/('independent-tests-'+label+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0
# Frozen baseline injection ensures the same new assertion actually fails without touching source.
import agent_runtime.log_context as live
module=types.ModuleType('agent_runtime.log_context');module.__package__='agent_runtime';exec(compile(base,'frozen-baseline.py','exec'),module.__dict__)
import tests.test_log_context as tests
original=tests.log_view;tests.log_view=module.log_view
from unittest.mock import patch
suite=unittest.TestSuite([tests.LogViewTests('test_impossible_line_budget_rejects_before_json_serialization')])
import io
stream=io.StringIO()
with patch.dict(sys.modules,{'agent_runtime.log_context':module}),patch('agent_runtime.log_context',module):
 result=unittest.TextTestRunner(stream=stream).run(suite)
tests.log_view=original
(P/'independent-baseline-failure.log').write_text(stream.getvalue());assert len(result.failures)==1 and not result.errors and 'AssertionError: oversized selection serialized' in result.failures[0][1]
def load(name):
 mo=types.ModuleType('agent_runtime._independent');mo.__package__='agent_runtime';exec(compile((P/name).read_bytes(),name,'exec'),mo.__dict__);return mo
old,new=load('baseline.py'),load('candidate.py');rows=[]
texts=['','x','x\n'*10,'a\r\nERROR\r\nlast','α\u2028ERROR\nβ\r','ERROR\n'*300,'x\n'*1100]
producer=json.loads((P/'controls.json').read_text());assert len(producer)==189
for index,(text,enc,budget,needles) in enumerate(itertools.product(texts,['lines','chunks','runs'],[700,1000,20000],[[],['ERROR'],['x','ERROR']])):
 path=P/'independent-control.log';path.write_bytes(text.encode());digest=sha(path)
 def call(mo):
  try:return {'ok':mo.log_view(P,path.name,digest,needles=needles,head=2,tail=2,context=1,max_chars=budget,encoding=enc)}
  except ValueError as exc:return {'error':str(exc)}
 a,b=call(old),call(new);assert a==b,(index,a,b)
 if 'ok'in a:a['ok']['source']['path']='control.log'
 row={'input_sha256':digest,'encoding':enc,'budget':budget,'needles':needles,'output_sha256':hashlib.sha256(json.dumps(a,sort_keys=True,ensure_ascii=False).encode()).hexdigest(),'status':'ok' if 'ok'in a else 'rejected'}
 assert row==producer[index],(index,row,producer[index]);rows.append(row)
(P/'independent-controls.json').write_text(json.dumps(rows,indent=2)+'\n')
reruns=[]
for enc in ('lines','chunks','runs'):
 for traced in ('no','yes'):
  for source in ('baseline.py','candidate.py'):
   p=subprocess.run([sys.executable,str(P/'measure.py'),'child',source,enc,traced],cwd=R,capture_output=True,text=True,timeout=30);assert p.returncode==0,p.stderr
   row=json.loads(p.stdout);assert row['error']=='selected log exceeds budget; no silent truncation' and row['input_sha256']==m['files']['job.log'];reruns.append(row)
(P/'independent-raw.json').write_text(json.dumps(reruns,indent=2)+'\n')
for enc in ('lines','chunks','runs'):
 d={x['source']:x for x in reruns if x['encoding']==enc and x['traced']=='no'};t={x['source']:x for x in reruns if x['encoding']==enc and x['traced']=='yes'}
 stats[enc]['independent_pair_improvement']=1-d['candidate.py']['seconds']/d['baseline.py']['seconds'];stats[enc]['independent_peak_improvement']=1-t['candidate.py']['python_peak_bytes']/t['baseline.py']['python_peak_bytes']
assert all(sha(P/name)==digest for name,digest in m['files'].items())
summary={'manifest_sha256':sha(P/'manifest.json'),'bindings':binding,'controls_count':len(rows),'controls_ok':sum(x['status']=='ok' for x in rows),'controls_rejected':sum(x['status']=='rejected' for x in rows),'producer_stats':stats,'environment':{'python':sys.version,'platform':platform.platform(),'machine':platform.machine()},'baseline_failure':'one intended AssertionError, no errors','frozen_hashes_unchanged_after_rerun':True}
(P/'independent-observations.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

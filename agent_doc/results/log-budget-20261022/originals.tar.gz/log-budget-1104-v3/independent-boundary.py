import hashlib,io,json,os,subprocess,sys,tempfile,tracemalloc,types,unittest
from pathlib import Path
from unittest.mock import patch
P=Path(__file__).resolve().parent;R=P.parents[1];sys.path.insert(0,str(R))
def load(name):
 m=types.ModuleType('agent_runtime._independent_bound');m.__package__='agent_runtime';exec(compile((P/name).read_bytes(),name,'exec'),m.__dict__);return m
old,new=load('baseline-observer.py'),load('candidate-observer.py')
# Actual old observer failure, keeping production modules untouched.
import tests.test_maintenance_observer as tests
original=tests.read_bound;tests.read_bound=old.read_bound
stream=io.StringIO();result=unittest.TextTestRunner(stream=stream).run(unittest.TestSuite([tests.ObserverTests('test_small_file_does_not_read_the_entire_budget')]))
tests.read_bound=original
assert len(result.failures)==1 and not result.errors and '[2097153] != [7]' in stream.getvalue()
(P/'independent-observer-failure.log').write_text(stream.getvalue())
rows=[]
with tempfile.TemporaryDirectory(prefix='independent-boundary-',dir=P) as d:
 root=Path(d);(root/'file').write_bytes(b'abcdef');(root/'dir').mkdir();(root/'link').symlink_to(root/'file');os.mkfifo(root/'fifo')
 for path in ('../file','/file','a//b','a\\b','C:file','missing','dir','link','fifo'):
  errors=[]
  for m in (old,new):
   try:m.read_bound(root,path,max_bytes=8)
   except (OSError,ValueError) as exc:errors.append((type(exc).__name__,str(exc)))
   else:raise AssertionError(('accepted path',path))
  assert errors[0]==errors[1],(path,errors);rows.append({'path':path,'errors':errors})
 for budget in (0,True,-1,32*1024*1024+1):
  for m in (old,new):
   try:m.read_bound(root,'file',max_bytes=budget)
   except ValueError as exc:assert str(exc)=='invalid read budget'
   else:raise AssertionError(budget)
 # fstat/actual byte changes, including size=0 sentinel, shrink, within/over cap.
 for observed,actual in ((0,0),(0,1),(0,64),(0,65),(2,6),(2,65),(64,0),(64,1),(64,64),(64,65)):
  (root/'file').write_bytes(b'x'*actual)
  for m in (old,new):
   with patch.object(m.os,'fstat',return_value=types.SimpleNamespace(st_size=observed,st_mode=0o100600)):
    try:value=m.read_bound(root,'file',max_bytes=64)
    except ValueError as exc:assert actual>64 and str(exc)=='source exceeds budget; no partial context'
    else:assert actual<=64 and value==b'x'*actual
  rows.append({'observed_size':observed,'actual_size':actual,'same_outcome':True})
(P/'independent-boundaries.json').write_text(json.dumps(rows,indent=2)+'\n')
# Verbose named compatibility cases for explicit evidence.
p=subprocess.run([sys.executable,'-m','unittest','-v','tests.test_maintenance_observer.ObserverTests.test_nonseekable_regular_adapter_retains_full_bounded_read','tests.test_maintenance_observer.ObserverTests.test_size_snapshot_growth_keeps_complete_read_and_bound','tests.test_maintenance_observer.ObserverTests.test_small_file_does_not_read_the_entire_budget'],cwd=R,capture_output=True,text=True,timeout=30)
(P/'independent-compatibility.log').write_text(p.stdout+p.stderr);assert p.returncode==0
rows=[]
for name,m in (('baseline-observer.py',old),('candidate-observer.py',new)):
 tracemalloc.start();payload=m.read_bound(P,'job.log',max_bytes=32*1024*1024);peak=tracemalloc.get_traced_memory()[1];tracemalloc.stop()
 rows.append({'source':name,'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),'python_peak_bytes':peak})
assert all(x['bytes']==300000 and x['sha256']=='b0ad3b8f8660c847ddb8e0de4a7fbd7e97a9ea3bce1006e544ed35d9e20506db' for x in rows)
assert 1-rows[1]['python_peak_bytes']/rows[0]['python_peak_bytes']>.2
(P/'independent-read-diagnostic.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))

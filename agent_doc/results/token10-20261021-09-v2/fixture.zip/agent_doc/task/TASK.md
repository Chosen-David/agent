# 项目任务

这是当前项目唯一日期任务索引，由主 AI 串行维护。
尚未填写已授权任务；收到用户目标后保留原始要求，按日期登记稳定 ID 与详情链接。
每项方法、验收、进度、证据与下一步由 AI 维护在 task_details/<ID>.md。
人类指南 agent_doc/guide/GUIDE.md 只读；建议 agent_doc/advice/ 须核验并记录取舍理由。
高频状态放 .agent-runs/<run_id>/，不另建活跃根 TASK.md。

# Tasks

## 2026-10-21

- [ ] [T0] Preserve blocker ([detail](task_details/T0.md))
- [ ] [T1] Preserve blocker ([detail](task_details/T1.md))
- [ ] [T2] Preserve blocker ([detail](task_details/T2.md))
- [ ] [T3] Preserve blocker ([detail](task_details/T3.md))
- [ ] [T4] Preserve blocker ([detail](task_details/T4.md))
- [ ] [T5] Preserve blocker ([detail](task_details/T5.md))
- [ ] [T6] Preserve blocker ([detail](task_details/T6.md))
- [ ] [T7] Preserve blocker ([detail](task_details/T7.md))
- [ ] [T8] Preserve blocker ([detail](task_details/T8.md))
- [ ] [T9] Preserve blocker ([detail](task_details/T9.md))
- [ ] [T10] Preserve blocker ([detail](task_details/T10.md))
- [ ] [T11] Preserve blocker ([detail](task_details/T11.md))

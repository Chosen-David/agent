import copy,hashlib,io,json,subprocess,sys,tempfile,types,unittest
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];sys.path.insert(0,str(R));h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((P/'manifest.json').read_text())
assert all(h(P/n)==v for n,v in m['files'].items());assert all(h(R/n)==v for n,v in m['sources'].items())
assert subprocess.check_output(['git','show',m['base_revision']+':agent_runtime/dispatch_context.py'],cwd=R)==(P/'baseline.py').read_bytes()
def load(name):
 mo=types.ModuleType('agent_runtime._independent_dispatch');mo.__package__='agent_runtime';exec(compile((P/name).read_bytes(),name,'exec'),mo.__dict__);return mo
old,new=load('baseline.py'),load('candidate.py')
for opt,name in (([],'ordinary'),(['-O'],'optimized')):
 cmd=[sys.executable,*opt,'-m','unittest','-v','tests.test_dispatch_context']
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=30);(P/('independent-tests-'+name+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0
import tests.test_dispatch_context as t
original=t.prepare_dispatch;t.prepare_dispatch=old.prepare_dispatch;stream=io.StringIO()
suite=unittest.TestSuite(t.DispatchContextTests(n) for n in ('test_scope_ancestors_cannot_include_reserved_outputs','test_scope_aliases_cannot_target_reserved_outputs','test_allowed_internal_alias_keeps_plan_and_native_settings'))
result=unittest.TextTestRunner(stream=stream).run(suite);t.prepare_dispatch=original
(P/'independent-baseline-failure.log').write_text(stream.getvalue());assert len(result.failures)==20 and len(result.errors)==1 and 'Symlink loop' in stream.getvalue()
rows=[]
with tempfile.TemporaryDirectory(prefix='independent-paths-',dir=P) as d:
 root=Path(d);(root/'outputs').mkdir();(root/'safe').symlink_to('outputs',target_is_directory=True);(root/'guide-alias').symlink_to('agent_doc/guide',target_is_directory=True);(root/'index-alias').symlink_to('agent_doc/task/TASK.md');(root/'root-alias').symlink_to('.',target_is_directory=True);(root/'outside-alias').symlink_to(root.parent,target_is_directory=True);(root/'loop').symlink_to('loop')
 request={'schema_version':'dispatch-context/v1','project_root':str(root),'task_id':'FIG8','parent':{'thread_id':'parent','last_turn_id':'done','cwd':str(root),'model':'same-model','reasoning_effort':'high','approval_policy':'never','sandbox':'read-only','config':{'features.apps':False}},'settings_complete':True,'needs_complete':False,'history_required':True,'guide_verified_human':False,'required_refs':[],'context_refs':[],'instruction':'read-only metadata check'}
 allowed=[None,[],['outputs'],['safe/new.txt'],['agent_doc/results/run'],['agent_doc/task/task_details/FIG8.md'],['TASK.md-other'],['agent_doc/task/TASK.md-extra'],['agent_doc/guidebook'],['doc/guidebook'],['doc-other/guide'],['agent_docs/guide']]
 for scope in allowed:
  q=copy.deepcopy(request)
  if scope is not None:q['write_scope']=scope
  before=copy.deepcopy(q)
  for inherit in (False,True):
   a,b=old.prepare_dispatch(root,q,force_inherit=inherit),new.prepare_dispatch(root,q,force_inherit=inherit);assert a==b and q==before;assert b['params']['sandbox']=='read-only' and b['params']['approvalPolicy']=='never'
  rows.append({'scope':scope,'outcome':'exact-original-plan-and-native-params'})
 bad=['.','agent_doc','doc','agent_doc/task','agent_doc/guide','doc/guide','AGENT_DOC/GUIDE/future.md','x/Agent_Doc/Guide/future.md','TASK.md/child','agent_doc/task/TASK.md/child','guide-alias/missing.md','index-alias','index-alias/child','root-alias','root-alias/agent_doc/task','outside-alias/file','loop/future','../escape','/absolute']
 for scope in bad:
  q=copy.deepcopy(request);q['write_scope']=[scope]
  for inherit in (False,True):
   try:new.prepare_dispatch(root,q,force_inherit=inherit)
   except ValueError as exc:message=str(exc)
   else:raise AssertionError(('accepted forbidden',scope))
  rows.append({'scope':scope,'outcome':'rejected','error':message})
 # Real CLI metadata-only errors and success, no fixture byte changes.
 cli=R/'scripts/dispatch_context.py'
 for scope,want in (('guide-alias/future.md',1),('loop/future',1),('safe/future',0)):
  q=copy.deepcopy(request);q['write_scope']=[scope];(root/'independent-request.json').write_text(json.dumps(q));before={p.name:p.read_bytes() for p in root.iterdir() if p.is_file() and not p.is_symlink()}
  p=subprocess.run([sys.executable,str(cli),'--root',str(root),'--request','independent-request.json'],capture_output=True,text=True,timeout=10);assert p.returncode==want,(scope,p.stderr,p.stdout);value=json.loads(p.stdout);assert ('error'in value)==bool(want);assert not p.stderr
  assert before=={p.name:p.read_bytes() for p in root.iterdir() if p.is_file() and not p.is_symlink()};rows.append({'cli_scope':scope,'exit':p.returncode,'json':value})
(P/'independent-probes.json').write_text(json.dumps(rows,indent=2)+'\n')
assert all(h(P/n)==v for n,v in m['files'].items());assert all(h(R/n)==v for n,v in m['sources'].items())
print('9 ordinary+9 optimized passed; frozen baseline20subtest failures+1looperror;34 extra probe records incl3CLI; immutable bindings unchanged.')

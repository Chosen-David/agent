"""Fresh independent all-fifty and frozen raw-byte/token/semantic verification.

Stored wire bytes are counted exactly. Reconstructed fixture comparisons replace
only the new temporary project_root display field with the recorded root; that
normalization is explicit and is not claimed as raw fresh-path byte reproducibility.
"""
from pathlib import Path, PurePosixPath
import copy,hashlib,json,os,re,subprocess,sys,tempfile,zipfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'.agent-runs/memory-index96-deps')];tempfile.tempdir=str(OUT)
os.environ['TIKTOKEN_CACHE_DIR']=str(ROOT/'.agent-runs/memory-index96-token-cache')
from agent_runtime.markdown_context import read_sections
from agent_runtime.validation_context import write_validation_context,restore_validation_context
from agent_runtime.handoff_basis import make_token_counter
from agent_runtime.result_validation import _snapshot
import tiktoken
GROUP=ROOT/'agent_doc/results/reflect50-20261021';FINAL=GROUP/'reflect50-final-20261021-v3'
contract=json.loads((FINAL/'contract.json').read_bytes());manifest,plan,proof=_snapshot(ROOT,contract)
assert manifest['run_id']=='reflect50-final-20261021-v3'
assert all(p['allow_not_applicable'] is False for p in plan['criteria'].values())
def sha(data):return hashlib.sha256(data).hexdigest()
def wire(value,newline=os.linesep):return (json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+newline).encode('utf-8')
for role,refs in manifest['artifacts'].items():
    for ref in refs:assert sha((ROOT/ref['path']).read_bytes())==ref['sha256'],(role,ref['path'])
protected=json.loads((ROOT/'.agent-runs/reflect50-20261021/baseline-protection.json').read_bytes())
for path,digest in protected.items():assert sha((ROOT/path).read_bytes())==digest,('protected file changed',path)
ledger=json.loads((GROUP/'iterations.json').read_bytes())
assert [r['id'] for r in ledger]==[f'R{i:02d}' for i in range(1,51)]
archives={}
for name in ('history.zip','history-delta.zip'):
    with zipfile.ZipFile(GROUP/name) as z:
        assert z.testzip() is None
        names=z.namelist();assert len(names)==len(set(names))
        assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts for n in names)
        archives[name]={n:z.read(n) for n in names}
assert len(archives['history.zip'])==114
gate_members=set()
for item in ledger:
    gate=item['group_gate'];data=archives[gate['archive']][gate['member']]
    assert sha(data)==gate['sha256'] and gate['actor']=='/root/reflect50_review'
    local=ROOT/'.agent-runs/reflect50-20261021'/gate['member']
    assert local.read_bytes()==data,'archived review differs from actual native reviewer artifact'
    accepted=json.loads(data);assert accepted['status']=='usable-with-scope'
    gate_members.add((gate['archive'],gate['member']))
for tag in ('g02','g03','g07'):
    assert json.loads(archives['history.zip']['reviewer/'+tag+'-inspect.json'])['status']=='invalid'
assert json.loads((OUT/'final-v1-stale-inspect.json').read_bytes())['status']=='invalid'
# Check all ten bounded before-source/ordered hash chains. Missing G10 nonruntime
# originals are reconstructed from a pinned Git blob with declared newline policy.
before_reconstructed=[]
for group in range(1,11):
    import io
    with zipfile.ZipFile(io.BytesIO(archives['history.zip'][f'before-g{group:02d}.zip'])) as z:expected={n:sha(z.read(n)) for n in z.namelist()}
    for item in ledger[(group-1)*5:group*5]:
        for path,version in item['changes'].items():
            if version['before'] is not None and path not in expected:
                raw=subprocess.check_output(['git','show','27195c7d791f21d491097249ff1154fe6a55da24:'+path],cwd=ROOT)
                mode='git-blob'
                if sha(raw)!=version['before']:raw=raw.replace(b'\n',b'\r\n');mode='git-blob-LF-to-CRLF'
                assert sha(raw)==version['before'];expected[path]=version['before'];before_reconstructed.append(dict(path=path,method=mode))
            assert version['before']==expected.get(path),(item['id'],path)
            expected[path]=version['after']
code_paths={r['path'] for r in manifest['artifacts']['code']}
assert {path for item in ledger for path in item['changes']}<=code_paths
observed=json.loads((FINAL/'observations.json').read_bytes())
assert observed['seed']==0 and observed['repeats']==1 and observed['tests_exit_code']==0
assert observed['tokenizer']=='o200k_base' and observed['tiktoken']==tiktoken.__version__=='0.12.0'
counter=make_token_counter('o200k_base');recount=[]
with zipfile.ZipFile(FINAL/'payloads.zip') as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==6
    payloads={n:z.read(n) for n in z.namelist()}
for item in observed['cases']:
    values={'case':item['case']}
    for side in ('before','after'):
        raw=payloads[item['case']+'-'+side+'.bin']
        values.update({side+'_bytes':len(raw),side+'_tokens':counter(raw.decode('utf-8')),side+'_sha256':sha(raw)})
        for key in ('bytes','tokens','sha256'):assert values[side+'_'+key]==item[side+'_'+key]
    recount.append(values)
assert recount[0]['after_tokens']<recount[0]['before_tokens'] and recount[1]['after_tokens']>recount[1]['before_tokens']
with tempfile.TemporaryDirectory(prefix='final-v3-') as tmp:
    root=Path(tmp)
    for name,text,selected,mandatory,blocks in (
        ('large-selection','# Global\nretain required global rule\n## Work\ncurrent literal source\n## Archive\n'+'historical unrelated record never used for this selected task.\n'*4000,['s2'],['s1'],['# Global\nretain required global rule\n','## Work\ncurrent literal source\n']),
        ('tiny-selection','# A\nx\n',['s1'],[],['# A\nx\n'])):
        before=json.loads(payloads[name+'-before.bin']);after=json.loads(payloads[name+'-after.bin'])
        assert before=={'source':{'path':'source.md','sha256':sha(text.encode())},'text':text}
        assert payloads[name+'-before.bin']==wire(before)
        assert after['requested']==selected and after['mandatory']==mandatory
        assert [n['text'] for n in after['sections']]==blocks
        (root/'source.md').write_bytes(text.encode());current=read_sections(root,before['source'],selected,mandatory=mandatory,max_chars=200000)
        current=copy.deepcopy(current);current['project_root']=after['project_root']
        assert current==after and wire(current)==payloads[name+'-after.bin']
    a=payloads['receipt-storage-before.bin'];b=payloads['receipt-storage-after.bin'];first=json.loads(a);second=json.loads(b)
    assert first==second and len(b)<len(a)
    result={'status':'pending','scope':'synthetic display only','errors':['current independent acceptance still required'],'next_action':'verify current source','proof':{'artifact_hashes':{'file%03d'%i:sha(str(i).encode()) for i in range(200)},'review_evidence':{},'limitations':['fixture only']}}
    assert first['result']==result
    for compact,name in ((False,'pretty'),(True,'compact')):
        display=write_validation_context(root,result,'agent_doc/results/'+name,compact_storage=compact)
        assert restore_validation_context(root,display['record_ref'])==result
        generated=json.loads((root/display['record_ref']['path']).read_bytes());generated['project_root']=first['project_root']
        data=(json.dumps(generated,ensure_ascii=False,indent=None if compact else 2,separators=(',',':') if compact else None,allow_nan=False)+'\n').encode()
        assert data==(b if compact else a)
metrics={m['name']:(m['value'],m['unit']) for m in manifest['metrics']}
assert metrics['implemented_iterations']==(50,'changes') and metrics['producer_exit_code']==(0,'exit-code')
for item in recount:
    for key in ('before_bytes','after_bytes','before_tokens','after_tokens'):
        assert metrics[item['case']+'.'+key]==(item[key],'bytes' if key.endswith('bytes') else 'o200k_base-tokens')
env=os.environ.copy();env.update(PYTHONPATH=str(ROOT/'.agent-runs/memory-index96-deps'),TEMP=str(OUT),TMP=str(OUT),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',TIKTOKEN_CACHE_DIR=os.environ['TIKTOKEN_CACHE_DIR'])
run=subprocess.run([sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_reflect50_g*.py','-v'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'final-v3-replay.txt').write_bytes(run.stdout);assert run.returncode==0
ids=re.findall(rb'^test_R(\d\d)_.*\.\.\. ok\r?$',run.stdout,re.M)
assert len(ids)==53 and {int(i) for i in ids}==set(range(1,51)) and b'skipped' not in run.stdout
assert len(re.findall(rb'^test_.*\.\.\. ok\r?$',run.stdout,re.M))==54
assert _snapshot(ROOT,contract)[2]==proof
# Preserve actual invalid/stale readback for v2 after the harness source changed.
from agent_runtime.result_validation import inspect_result
old_contract=json.loads((GROUP/'reflect50-final-20261021-v2/contract.json').read_bytes())
stale=inspect_result(ROOT,old_contract);assert stale['status']=='invalid'
(OUT/'final-v2-stale-inspect.json').write_text(json.dumps(stale,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')
# Independent actual harness refusal uses only an owned potential output target.
import uuid
name='final-v3-rejected-'+uuid.uuid4().hex
relative='agent_doc/results/../../.agent-runs/reflect50-20261021/reviewer/'+name
refusal=subprocess.run([sys.executable,'-X','utf8','-B',str(ROOT/'scripts/measure_reflect50.py'),'prepare','--out',relative],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert refusal.returncode!=0 and b'project result directory required' in refusal.stderr and not (OUT/name).exists()
output=dict(actor='/root/reflect50_review',producer_proof=proof,protected_original_files=len(protected),iterations=50,fresh_tests=54,skips=0,
    independent_recount=recount,raw_literal_semantics=True,compact_complete_values_equal=True,fixture_rebuilt=True,
    reproduction_normalization='Only project_root metadata replaced with recorded root before full wire comparison; raw artifact counts/SHA independently recomputed without normalization.',
    history_archives={name:dict(files=len(values),sha256=sha((GROUP/name).read_bytes())) for name,values in archives.items()},
    unique_historical_native_group_gates=len(gate_members),historical_failed_gates_preserved=True,final_v2_invalid_stale=True,harness_parent_escape_refused_without_creation=True,before_reconstruction=before_reconstructed,status='checks-pass')
(OUT/'final-v3-checks.json').write_text(json.dumps(output,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')
print(json.dumps(dict(status='checks-pass',fresh_tests=54,iterations=50,skips=0,raw_cases=recount)))

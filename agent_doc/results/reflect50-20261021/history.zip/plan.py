import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
titles=[
('project_docs.regular_bytes','close owned descriptor when fdopen construction/entry fails'),
('project_docs.atomic_write','close mkstemp descriptor on failed stream setup; preserve destination'),
('maintenance_observer.read_bound','close failed stream ownership and reject known oversized reads before allocation'),
('knowledge_index._connect','close SQLite connection on PRAGMA setup failure'),
('artifact_index._walk','stream artifact digests instead of retaining whole files'),
('project_docs.split_detail','ignore fenced Plan/Progress examples while binding real immutable boundary'),
('project_docs metadata consumers','ignore fenced identity/status fields across snapshot and navigation'),
('project_docs._plan_section','preserve fenced subsection examples without false heading stops'),
('project_docs.write_task_progress','allow fenced Progress examples but reject actual duplicate boundary'),
('knowledge_index.sections/project_docs','use physical Markdown line delimiters; Unicode separators stay literal'),
('project_docs.task_navigation','explicit task-ID selection with unknown-ID refusal'),
('project_docs.task_navigation','opt-in bounded summary with truncation/source identity metadata'),
('project_docs.task_navigation','snapshot-bound whole-task pagination and stale-cursor refusal'),
('project_docs.task_navigation','account for actual native CLI newline in whole-output character budget'),
('project_docs.snapshot_project_docs','avoid inventory body hash plus second reread of every task detail'),
('project_memory.index','construct content projections only for requested page; validate entire snapshot'),
('project_memory snapshot hashing','stream exact canonical JSON hash instead of full serialized copies'),
('project_memory.index cursor','find continuation position without a full extra ID-position dictionary'),
('project_memory.index budget','incremental exact packet sizing instead of serializing growing entries per candidate'),
('project_memory.index retention','release omitted full bodies before packet serialization; keep selection immutable'),
('result_store._timestamp','isolate UTC-normalization overflow so one record cannot crash search'),
('result_store._read','avoid maximum-ceiling allocation for tiny stable metadata; preserve growth checks'),
('result_store._check_ref','bounded small-file hashing chunks instead of 1MiB scratch for tiny references'),
('result_store.search lexical scoring','stream exact JSON casefold term matching without huge haystack copies'),
('result_store.search top results','retain only ordered top-k hits plus complete errors and partial flag'),
('result_validation.validate_result_plan','iterative ancestry supports valid thousand-node DAG'),
('result_validation.validate_result_plan','memoize ancestry per validation call instead of repeating per result producer'),
('result_validation._snapshot','verify identical path/hash declarations once within each fresh snapshot'),
('result_validation._snapshot artifacts','stream digest-only verification of ordinary declared artifacts'),
('result_validation metric finite check','handle mathematically finite large JSON integers without float overflow'),
('artifact_index directory','reject a symlinked starting directory before resolution'),
('artifact_index required paths','reject absolute/traversing/noncanonical required paths rather than report missing'),
('artifact_index required digests','reject malformed expected hashes rather than silently unbound comparisons'),
('artifact_index.diff','reject cross-project/directory comparisons without explicit rebasing'),
('artifact_index byte admission','optional cumulative actual-read byte budget before unbounded storage scans'),
('legacy_result_paths marker cache','bounded immutable content-keyed parsed/validated marker cache; reread source each call'),
('knowledge_index.build_index','reject nonboolean rebuild before opening or changing cache storage'),
('knowledge_index.indexed_search','one explicit read transaction keeps metadata and FTS rows on one index snapshot'),
('source_context parser admission','enforce small source byte ceiling before reading full verification ceiling'),
('project_docs._inventory','stream guide/advice inventory hashes while preserving every source byte'),
('markdown_context outline','new exact SHA-bound heading navigation for general project Markdown'),
('markdown_context sections','explicit literal section retrieval including full original selected bytes'),
('markdown_context outline paging','bounded whole-heading pages with exact source/cursor identity'),
('scripts/markdown_context.py','usable compact CLI for outline/read with complete refusal/status/exit behavior'),
('markdown_context mandatory sections','host-declared global section IDs included and verified alongside selected sections'),
('markdown_context token admission','optional actual-counter whole-response token cap including native newline'),
('validation_context record storage','opt-in compact physical JSON receipts; exact restoration and immutable IDs'),
('result_store record storage','opt-in compact physical registry JSON; unchanged complete values and acceptance gates'),
('storage_inventory runtime/CLI','bounded metadata-only storage overview before expensive content hashing; no deletion claims'),
('workflow adoption/reference sync','use proven compact interfaces in relevant installed workflow examples; synchronize mirrors')]
assert len(titles)==50
catalog={'schema_version':'reflection-iterations/v1','project_root':str(ROOT),'version':1,'iterations':[{'id':f'R{i:02d}','group':(i-1)//5+1,'source':p,'change':t,'status':'planned'} for i,(p,t) in enumerate(titles,1)],'counting':'Each ID is a separate code/behavior improvement, not a testcase variant or claimed new algorithm; negative/nonimproving optimizations require repair or substitution before completion.'}
(out/'catalog-v1.json').write_bytes((json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode())
p=ROOT/'agent_doc/task/task_details/REFLECT50-20261021.md';s=p.read_text(encoding='utf-8');s=s.replace('v0 / discovery.','v1 / EXECUTE pending independent plan review.');a=s.index('Next: inspect real call chains;');b=s.index('\n## Progress',a)
s=s[:a]+'''Execution: ten groups of five separately recorded code/behavior iterations; root
single writer. Exact 50 IDs/source changes in the frozen catalog. For each group:
freeze validation criteria/fixtures and before-source bytes; apply each change,
record before/after code hashes and actual per-ID oracle/refusal or bounded-cost
checks; one scoped independent six-domain node accepts all five IDs before any
consumer/conclusion. Final freshly validates all fifty on integrated source.
Native tools provide the reviewer identity, not stored JSON labels. Max two
bounded repairs per failed protocol; preserve failures and use fresh result IDs.

Allow compatible internal fixes and explicit opt-in navigation/storage features;
defaults preserve ordinary valid response values where feasible. New bounds,
metadata parsing and invalid-input refusals are deliberate documented corrections.
Do not alter scientific acceptance, permissions, private data or historical files.
No summary replaces memory evidence: navigation retains source hashes/partialness
and exact full retrieval. No cache holds result acceptance; relocation cache is
bounded immutable parsed metadata keyed by complete freshly read source bytes.
No unchecked stat/mtime-only trust. No physical deletes/VACUUM/active moves.

Independent reference: literal canonical JSON/physical-line/fence oracles, direct
SQLite/file fault injection, old source differential controls where appropriate,
real public CLI binary stdout with native newline. Deterministic bytes/tokens,
read/allocation/retained-memory metrics only with actual measured boundaries;
performance cases retain large/small/negative controls and all samples. No noisy
latency/QA/model/cash/global-token claim. Base-scope old failures stay historical.

One batch task/detail, one concise per-ID machine ledger, bounded shared fixtures
and one result per group/final; avoid fifty full code/fixture/report copies.
Frozen baseline source archives only cover affected files, no whole-repo evidence
mirroring. Source/trust proof is rechecked after all changes. Source plugin
workflow adoption is the last iteration, so installed-skill synchronization never
overwrites locally edited/uncommitted skills between preceding iterations.

Fresh source reading this execution: LongMemEval v2 §4.1-4.2/§5.1-5.3
(https://arxiv.org/html/2410.10813v2), value granularity versus detail loss and
reader-dependent budgets; use literal retrieval/navigation, transfer no QA scores.
Python3.12 sqlite3 context/transaction and functools.lru_cache official APIs;
bounded caches retain references and cache pure parsing only. GPU/ANN knowledge
cards do not match local file/SQLite premises. Standard library, no new packages.

Decision: compatible local repairs and opt-in features address user goal without
changing privacy, paid resources or interfaces requiring permission. No main
prompt/decision protocol rewrite. Readme/role workflow adoption preserves all
authority and independent-result contracts. Shared reference generator/checks and
appropriate final regressions follow; producer logs remain pending until review.
''' +s[b:]
p.write_bytes(s.encode())
print('v1:50 exact iterations; waiting for independent review')

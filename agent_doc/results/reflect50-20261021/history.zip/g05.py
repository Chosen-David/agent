from iterate import begin,end,ROOT
def edit(old,new):
    path=ROOT/'agent_runtime/result_store.py'; text=path.read_text(encoding='utf-8'); assert old in text,old[:80]; path.write_bytes(text.replace(old,new).encode())
begin(21)
edit('    return instant.astimezone(dt.timezone.utc)', "    try:\n        return instant.astimezone(dt.timezone.utc)\n    except (ValueError, OverflowError) as exc:\n        raise ResultStoreError('ISO8601 time outside UTC range') from exc")
end(21)
begin(22)
edit('            data = stream.read(limit + 1)', '''            if info.st_size < 65536 and stream.seekable():
                initial = info.st_size + 1
                data = stream.read(initial)
                if len(data) == initial:
                    del data
                    stream.seek(0)
                    data = stream.read(limit + 1)
            else:
                data = stream.read(limit + 1)''')
end(22)
begin(23)
edit('            while block := stream.read(1024 * 1024):', '            chunk_size = min(65536, max(1, info.st_size + 1))\n            while block := stream.read(chunk_size):')
end(23)
begin(24)
edit('def _timestamp(value):', '''def _lexical_score(value, tokens):
    """Exact full-JSON substring score using bounded cross-chunk tails."""
    found, tail = set(), ''
    overlap = max((len(token) for token in tokens), default=1) - 1
    for piece in json.JSONEncoder(ensure_ascii=False).iterencode(value):
        for offset in range(0, len(piece), 65536):
            window = tail + piece[offset:offset+65536].casefold()
            found.update(token for token in tokens if token in window)
            tail = window[-overlap:] if overlap else ''
    return len(found)


def _timestamp(value):''')
edit("                haystack = json.dumps({k: record.get(k) for k in\n                                      ('summary', 'run_id', 'result_id', 'producer_task_id', 'context')},\n                                     ensure_ascii=False).casefold()\n                score = sum(token in haystack for token in tokens)", "                searchable = {k: record.get(k) for k in\n                              ('summary', 'run_id', 'result_id', 'producer_task_id', 'context')}\n                score = (_lexical_score(searchable, tokens) if type(self) is ResultStore and 'show' not in self.__dict__\n                         else sum(token in json.dumps(searchable, ensure_ascii=False).casefold() for token in tokens))")
end(24)
begin(25)
edit('import math\n', 'import math\nfrom bisect import insort\n')
edit('        hits, errors = [], []','        hits, errors, hit_count = [], [], 0')
edit("                    hits.append({'run_id': name,", "                    hit_count += 1\n                    insort(hits, {'run_id': name,")
edit("                                 'applicability': 'unchecked'})", "                                 'applicability': 'unchecked'}, key=lambda hit: (-hit['score'], hit['run_id']))\n                    if len(hits) > limit:\n                        hits.pop()")
edit('partial or len(hits) > limit','partial or hit_count > limit')
end(25)

from iterate import begin,end,ROOT
def edit(name,old,new):
    path=ROOT/name; text=path.read_text(encoding='utf-8'); assert old in text,(name,old[:80]); path.write_bytes(text.replace(old,new).encode())
P='agent_runtime/project_docs.py'
begin(6)
edit(P,'def split_detail(text):', '''def outside_fences(text):
    """Yield literal line offsets outside CommonMark-style fenced examples."""
    offset, fence = 0, None
    for raw in text.splitlines(keepends=True):
        line = raw.rstrip('\\r\\n')
        marker = re.match(r'^ {0,3}(`{3,}|~{3,})(.*)$', line)
        if marker:
            token, tail = marker.groups()
            if fence is None and (token[0] != '`' or '`' not in tail):
                fence = token
            elif fence and token[0] == fence[0] and len(token) >= len(fence) and not tail.strip(' \\t'):
                fence = None
        elif fence is None:
            yield offset, offset + len(raw), line
        offset += len(raw)


def split_detail(text):''')
start="    boundaries = list(re.finditer(r'^## Progress(?:\\n|$)', text, re.M))"
edit(P,start,"    boundaries = [(a, b) for a, b, line in outside_fences(text) if line == '## Progress']")
edit(P,"    planning, progress = text[:boundary.start()], text[boundary.end():]\n    if len(re.findall(r'^## Plan$', planning, re.M)) != 1:","    planning, progress = text[:boundary[0]], text[boundary[1]:]\n    if sum(line == '## Plan' for _, _, line in outside_fences(planning)) != 1:")
end(6)
begin(7)
edit(P,"def _field_once(text, name):", "def _field_values(text, name):\n    prefix = name + ': '\n    return [line[len(prefix):] for _, _, line in outside_fences(text) if line.startswith(prefix)]\n\n\ndef _field_once(text, name):")
edit(P,"    matches = re.findall(r'^' + re.escape(name) + r': (.*)$', text, re.M)","    matches = _field_values(text, name)")
edit(P,"re.findall(r'^Task-ID: (.+)$', planning, re.M)","_field_values(planning, 'Task-ID')")
edit(P,"re.findall(r'^Date: (.+)$', planning, re.M)","_field_values(planning, 'Date')")
end(7)
begin(8)
path=ROOT/P; text=path.read_text(encoding='utf-8'); a=text.index('    header = re.compile',text.index('def _plan_section')); b=text.index('\n\ndef _progress_edges',a)
text=text[:a]+'''    start = None
    for a, b, line in outside_fences(text):
        if start is None:
            if line.rstrip(' \\t') == '### ' + name:
                start = b
        elif re.match(r'^#{2,3} ', line):
            return text[start:a].strip() or None
    return text[start:].strip() or None if start is not None else None
'''+text[b:]; path.write_bytes(text.encode())
end(8)
begin(9)
edit(P,"not isinstance(progress, str) or re.search(r'^## Progress$', progress, re.M)","not isinstance(progress, str) or any(line == '## Progress' for _, _, line in outside_fences(progress))")
end(9)
begin(10)
edit(P,'def outside_fences(text):', '''def physical_lines(text, *, keepends=False):
    """Markdown source lines end only at LF, CRLF or CR."""
    lines = [line for line in re.findall(r'[^\\r\\n]*(?:\\r\\n|\\r|\\n|$)', text) if line]
    return lines if keepends else [line.rstrip('\\r\\n') for line in lines]


def outside_fences(text):''')
edit(P,'text.splitlines(keepends=True)','physical_lines(text, keepends=True)')
edit(P,'text.splitlines()','physical_lines(text)')
edit(P,"regular_bytes(root, legacy).decode('utf-8').splitlines()","physical_lines(regular_bytes(root, legacy).decode('utf-8'))")
K='agent_runtime/knowledge_index.py'
edit(K,'import guard_write_path','import guard_write_path, physical_lines')
edit(K,"record['content'].splitlines(keepends=True)","physical_lines(record['content'], keepends=True)")
end(10)

from iterate import begin,end,ROOT
def edit(name,old,new):
    path=ROOT/name;text=path.read_text(encoding='utf-8');assert old in text,(name,old[:90]);path.write_bytes(text.replace(old,new).encode())
begin(46)
P='agent_runtime/markdown_context.py'
edit(P,'def _budget(value, max_chars):','def _budget(value, max_chars, max_tokens=None, token_counter=None):')
edit(P,'    return value\n\ndef outline', '''    if max_tokens is not None:
        if type(max_tokens) is not int or max_tokens < 1 or not callable(token_counter):
            raise ValueError('explicit positive token bound and trusted counter required')
        count = token_counter(rendered + os.linesep)
        if type(count) is not int or count < 0:
            raise ValueError('token counter must return a nonnegative integer')
        if count > max_tokens:
            raise ValueError('complete Markdown payload exceeds token budget')
    elif token_counter is not None:
        raise ValueError('token counter requires explicit token budget')
    return value

def outline''')
edit(P,'expected_snapshot=None):','expected_snapshot=None, max_tokens=None, token_counter=None):')
edit(P,'mandatory=()):','mandatory=(), max_tokens=None, token_counter=None):')
edit(P, '}, max_chars)', '}, max_chars, max_tokens, token_counter)')
edit(P,"    parser.add_argument('--max-chars', type=int, default=20000)", "    parser.add_argument('--max-chars', type=int, default=20000)\n    parser.add_argument('--max-tokens', type=int)\n    parser.add_argument('--tokenizer')")
edit(P,"        source = {'path': args.path, 'sha256': args.sha256}", "        if (args.max_tokens is None) != (args.tokenizer is None):\n            raise ValueError('max-tokens and explicit tokenizer must be supplied together')\n        counter = None\n        if args.tokenizer is not None:\n            from .handoff_basis import make_token_counter\n            counter = make_token_counter(args.tokenizer)\n        source = {'path': args.path, 'sha256': args.sha256}")
edit(P,'expected_snapshot=args.expected_snapshot)', 'expected_snapshot=args.expected_snapshot, max_tokens=args.max_tokens, token_counter=counter)')
edit(P,'mandatory=args.mandatory))','mandatory=args.mandatory, max_tokens=args.max_tokens, token_counter=counter))')
end(46)
begin(47)
P='agent_runtime/validation_context.py'
edit(P,'def write_validation_context(root, result, relative_directory):','def write_validation_context(root, result, relative_directory, *, compact_storage=False):')
edit(P,'    _shape(result)\n    supplied_root', "    _need(type(compact_storage) is bool, 'compact_storage must be boolean')\n    _shape(result)\n    supplied_root")
edit(P,'json.dumps(record, ensure_ascii=False, indent=2, allow_nan=False)',"json.dumps(record, ensure_ascii=False, indent=None if compact_storage else 2, separators=(',', ':') if compact_storage else None, allow_nan=False)")
P='scripts/validate_experiment_result.py'
edit(P,'    args = parser.parse_args()', "    parser.add_argument('--context-compact-storage', action='store_true')\n    args = parser.parse_args()\n    if args.context_compact_storage and not args.context_dir:\n        parser.error('context-compact-storage requires context-dir')")
edit(P,'write_validation_context(args.root, result, args.context_dir)','write_validation_context(args.root, result, args.context_dir, compact_storage=args.context_compact_storage)')
end(47)
begin(48)
P='agent_runtime/result_store.py'
edit(P,'    def __init__(self, root):','    def __init__(self, root, *, compact_storage=False):\n        _need(type(compact_storage) is bool, \'compact_storage must be boolean\')\n        self.compact_storage = compact_storage')
edit(P,'json.dumps(record, indent=2, ensure_ascii=False, allow_nan=False)', "json.dumps(record, indent=None if self.compact_storage else 2, separators=(',', ':') if self.compact_storage else None, ensure_ascii=False, allow_nan=False)")
edit('scripts/result_store.py',"    subs = parser.add_subparsers(dest='command', required=True)", "    parser.add_argument('--compact-storage', action='store_true', help='compact new immutable registry records; independent of stdout formatting')\n    subs = parser.add_subparsers(dest='command', required=True)")
edit('scripts/result_store.py','store = ResultStore(args.root)','store = ResultStore(args.root, compact_storage=args.compact_storage)')
end(48)
begin(49)
(ROOT/'agent_runtime/storage_inventory.py').write_text('''"""Bounded metadata-only disk inventory; no reads, reclamation or atomic snapshot."""
import argparse
from heapq import heappush, heapreplace
import json
import os
import sys
from pathlib import Path

def inventory(root, *, max_entries=10000, max_directories=1000, top=10):
    if not Path(root).is_absolute():
        raise ValueError('absolute PROJECT_ROOT required')
    supplied = Path(root).absolute()
    if any(p.is_symlink() or getattr(p, 'is_junction', lambda: False)() for p in (supplied, *supplied.parents)):
        raise ValueError('storage root must not traverse links')
    if not supplied.is_dir():
        raise ValueError('existing project directory required')
    root = supplied.resolve()
    for value, ceiling in ((max_entries, 1000000), (max_directories, 100000), (top, 100)):
        if type(value) is not int or not 1 <= value <= ceiling:
            raise ValueError('invalid storage inventory bound')
    pending, directories, entries, files, links, total = [root], 1, 0, 0, 0, 0
    groups, largest = {}, []
    while pending:
        directory = pending.pop()
        with os.scandir(directory) as children:
            for entry in children:
                entries += 1
                if entries > max_entries:
                    raise ValueError('storage inventory entry bound exceeded; narrow root')
                if entry.is_symlink() or getattr(entry, 'is_junction', lambda: False)():
                    links += 1
                    continue
                if entry.is_dir(follow_symlinks=False):
                    directories += 1
                    if directories > max_directories:
                        raise ValueError('storage directory bound exceeded; narrow root')
                    pending.append(Path(entry.path))
                elif entry.is_file(follow_symlinks=False):
                    size = entry.stat(follow_symlinks=False).st_size
                    rel = Path(entry.path).relative_to(root).as_posix()
                    group = ('private-memory' if rel.startswith('.agent-memory/') else
                             'runtime-cache' if rel.startswith(('.agent-runs/', '.cache/', '__pycache__/')) else
                             'results' if rel.startswith('agent_doc/results/') else
                             'markdown' if rel.lower().endswith('.md') else 'other')
                    values = groups.setdefault(group, {'files': 0, 'logical_bytes': 0})
                    values['files'] += 1; values['logical_bytes'] += size
                    files += 1; total += size
                    item = (size, rel)
                    if len(largest) < top:
                        heappush(largest, item)
                    elif item > largest[0]:
                        heapreplace(largest, item)
    return {'schema_version': 'storage-inventory/v1', 'project_root': str(root),
            'files': files, 'directories': directories, 'entries': entries, 'opaque_links': links,
            'logical_bytes': total, 'groups': dict(sorted(groups.items())),
            'largest': [{'path': name, 'logical_bytes': size} for size, name in sorted(largest, reverse=True)],
            'scope': 'metadata observation; concurrent changes are possible; logical sizes exclude link targets and do not measure allocated blocks or reclaimable space; no files read or deleted'}

def main(argv=None):
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--max-entries', type=int, default=10000)
    parser.add_argument('--max-directories', type=int, default=1000)
    parser.add_argument('--top', type=int, default=10)
    args = parser.parse_args(argv)
    try:
        result = inventory(args.root, max_entries=args.max_entries, max_directories=args.max_directories, top=args.top)
        print(json.dumps(result, ensure_ascii=False, separators=(',', ':'), allow_nan=False))
        return 0
    except (OSError, ValueError) as exc:
        print(json.dumps({'status': 'blocked', 'error': str(exc)}, ensure_ascii=False, separators=(',', ':')))
        return 2

if __name__ == '__main__':
    raise SystemExit(main())
''',encoding='utf-8')
(ROOT/'scripts/storage_inventory.py').write_text('''"""Observe project storage without reading file bodies."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from agent_runtime.storage_inventory import main
if __name__ == '__main__':
    raise SystemExit(main())
''',encoding='utf-8')
end(49)
begin(50)
path=ROOT/'workflows/project_memory_workflow.md'
with path.open('a',encoding='utf-8',newline='\n') as out:
    out.write('''

## 有界原文导航与存储格式

完整 checkout 中先显式筛选当前任务，长摘要按需展开：

```bash
python scripts/project_docs.py --root /absolute/project nav --task-id TASK_ID --summary-chars 240 --limit 5 --max-chars 12000
python scripts/markdown_context.py --root /absolute/project --path agent_doc/task/task_details/TASK_ID.md --sha256 EXACT_SHA256 outline --limit 20
python scripts/markdown_context.py --root /absolute/project --path agent_doc/task/task_details/TASK_ID.md --sha256 EXACT_SHA256 read --section SECTION_ID --mandatory GLOBAL_SECTION_ID
python scripts/storage_inventory.py --root /absolute/project --max-entries 10000 --top 10
```

任务页续读须带 `--after-id` 与 `--snapshot`；Markdown 页使用相同参数，源 SHA 同时绑定原文。任何源变化均重查首页。Markdown 章节是当前标题至下一标题的原始块，父标题不隐含其所有子块；preamble 自动保留，必要全局章节由调用者用 `--mandatory` 明确指定。预算不足拒绝整包，不裁剪原文。可选 `--max-tokens N --tokenizer ENCODING` 用指定 tokenizer 校验完整成功输出含原生换行；无 tokenizer 时不把字符当 token。摘要、目录及缓存均不取代 Plan/guide/依赖与当前证据门禁。

新增证据可显式使用 `validate_experiment_result.py --context-dir agent_doc/results/RUN --context-compact-storage` 或 `result_store.py --compact-storage register ...` 保存紧凑 JSON。完整字段保留；stdout 的 `--compact` 独立控制显示，默认存储格式不变。格式变化影响原始字节 SHA，须使用新记录身份并重绑证据，不改写旧的不可变记录；restore/当前独立验收继续执行。不要将所有历史 memory/Markdown 无差别重写成摘要或删除过期记录。

存储盘点只读元数据，含隐藏缓存与 memory/WAL/SHM 文件的可见逻辑大小；上界溢出拒绝，链接不跟随。它不提供原子磁盘快照、可回收字节数或删除授权。局部输出缩短不证明整轮 token、费用或任务质量改善；必要原文、全部页面及重试都计成本。纯 Skill 安装不含 runtime 时不得假称上述命令可用。
''')
import subprocess
subprocess.run([__import__('sys').executable,'-X','utf8','scripts/sync_plugin_references.py'],cwd=ROOT,check=True,capture_output=True)
end(50)

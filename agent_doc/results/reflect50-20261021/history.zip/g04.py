from iterate import begin,end,ROOT
def edit(old,new):
    path=ROOT/'agent_runtime/project_memory.py'; text=path.read_text(encoding='utf-8'); assert old in text,old[:80]; path.write_bytes(text.replace(old,new).encode())
begin(16)
edit('        projections = []\n        for entry in entries:', '        entry_hashes = []\n        for entry in entries:')
edit("            content = entry['content']\n            item = {key: value for key, value in entry.items() if key != 'content'}\n            item.update(content_sha256=hashlib.sha256(content.encode('utf-8')).hexdigest(),\n                        content_chars=len(content), entry_sha256=entry_hash)\n            projections.append(item)","            if not isinstance(entry['content'], str):\n                raise MemoryError('memory index content must be text')\n            entry_hashes.append(entry_hash)")
edit("        for item in projections[start:start + limit]:", "        for entry, entry_hash in zip(entries[start:start + limit], entry_hashes[start:start + limit]):\n            content = entry['content']\n            item = {key: value for key, value in entry.items() if key != 'content'}\n            item.update(content_sha256=hashlib.sha256(content.encode('utf-8')).hexdigest(),\n                        content_chars=len(content), entry_sha256=entry_hash)")
end(16)
begin(17)
edit('def _read_entry(db, entry_id, schema_state=None):', '''def _index_digest(value):
    """Same canonical identity without materializing the whole JSON encoding."""
    try:
        digest = hashlib.sha256()
        encoder = json.JSONEncoder(ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
        for piece in encoder.iterencode(value):
            for offset in range(0, len(piece), 65536):
                digest.update(piece[offset:offset+65536].encode('utf-8'))
        return digest.hexdigest()
    except (TypeError, ValueError, UnicodeError, RecursionError) as exc:
        raise MemoryError('memory index requires valid finite UTF-8 JSON') from exc


def _read_entry(db, entry_id, schema_state=None):''')
edit("hashlib.sha256(_index_json(entry).encode('utf-8')).hexdigest()","_index_digest(entry)")
end(17)
begin(18)
edit("            positions = {entry['id']: i for i, entry in enumerate(entries)}\n            if after_id not in positions:\n                raise MemoryError('index cursor is not in selected snapshot')\n            start = positions[after_id] + 1", "            position = next((i for i, entry in enumerate(entries) if entry['id'] == after_id), None)\n            if position is None:\n                raise MemoryError('index cursor is not in selected snapshot')\n            start = position + 1")
end(18)
begin(19)
edit('        for entry, entry_hash in zip(entries[start:start + limit], entry_hashes[start:start + limit]):','        entry_chars = 0\n        for entry, entry_hash in zip(entries[start:start + limit], entry_hashes[start:start + limit]):')
edit("            if len(_index_json(candidate)) + len(os.linesep) > max_chars:","            added_chars = len(_index_json(item)) + (1 if packet['entries'] else 0)\n            candidate_chars = len(_index_json(dict(candidate, entries=[]))) + entry_chars + added_chars\n            if candidate_chars + len(os.linesep) > max_chars:")
edit('            packet = candidate\n        if len(_index_json(packet))','            entry_chars += added_chars\n            packet = candidate\n        if len(_index_json(packet))')
end(19)
begin(20)
edit("        packet = {'schema_version': 'memory-index/v1', **binding, 'snapshot': snapshot,", "        total = len(entries)\n        page_entries = entries[start:start + limit]\n        page_hashes = entry_hashes[start:start + limit]\n        if entries:\n            del entry\n        del entries, entry_hashes\n        packet = {'schema_version': 'memory-index/v1', **binding, 'snapshot': snapshot,")
edit("'total_entries': len(entries), 'start': start, 'entries': [],", "'total_entries': total, 'start': start, 'entries': [],")
edit("'next_after_id': None, 'partial': start < len(entries),", "'next_after_id': None, 'partial': start < total,")
edit('zip(entries[start:start + limit], entry_hashes[start:start + limit])','zip(page_entries, page_hashes)')
edit("more = start + len(candidate['entries']) < len(entries)","more = start + len(candidate['entries']) < total")
end(20)

from pathlib import Path
import subprocess
ROOT=Path.cwd(); RUN=ROOT/'.agent-runs/reflect50-20261021'
name='agent_doc/task/TASK.md'
ours=(ROOT/name).read_bytes()
base=subprocess.check_output(['git','show','HEAD:'+name])
theirs=subprocess.check_output(['git','show','origin/main:'+name])
for label,data in (('ours',ours),('base',base),('theirs',theirs)):
    (RUN/('merge-'+label+'.md')).write_bytes(data)
merge=subprocess.run(['git','merge-file','-p',str(RUN/'merge-ours.md'),str(RUN/'merge-base.md'),str(RUN/'merge-theirs.md')],capture_output=True)
if merge.returncode:
    raise RuntimeError(merge.stdout.decode('utf-8',errors='replace'))
subprocess.run(['git','restore','--source=HEAD','--',name],check=True)
try:
    subprocess.run(['git','merge','--ff-only','origin/main'],check=True)
except BaseException:
    (ROOT/name).write_bytes(ours);raise
(ROOT/name).write_bytes(merge.stdout)
head=subprocess.check_output(['git','rev-parse','HEAD']).strip()
remote=subprocess.check_output(['git','rev-parse','origin/main']).strip()
assert head==remote
print(head.decode())

from iterate import begin,end,ROOT
def edit(old,new):
    path=ROOT/'agent_runtime/artifact_index.py';text=path.read_text(encoding='utf-8');assert old in text,old[:100];path.write_bytes(text.replace(old,new).encode())
begin(31)
edit('DocumentError, regular_digest','DocumentError, regular_digest, _relative')
edit('    path = (root / directory).resolve() if directory is not None else root.resolve()', "    path = _relative(root, directory if directory is not None else '.')\n    path = path.resolve()")
end(31)
begin(32)
edit('from pathlib import Path','from pathlib import Path, PurePosixPath\nimport re')
edit('def build_artifact_index(root,', '''def _canonical_path(value):
    if (type(value) is not str or not value or '\\\\' in value or ':' in value or
            PurePosixPath(value).is_absolute() or PurePosixPath(value).as_posix() != value or
            any(part in ('', '.', '..') for part in value.split('/'))):
        raise DocumentError('required path must be canonical and project-relative')
    return value


def build_artifact_index(root,''')
edit('{str(key): (val if isinstance(val, str) else None)', '{_canonical_path(key): (val if isinstance(val, str) else None)')
edit('{str(item): None for item in required}','{_canonical_path(item): None for item in required}')
edit("prefix = directory.rstrip('/') if directory is not None else ''", "prefix = (Path(directory).relative_to(root).as_posix() if Path(directory).is_absolute() else Path(directory).as_posix()) if directory is not None else ''\n        if prefix == '.':\n            prefix = ''")
end(32)
begin(33)
edit("            expected = {_canonical_path(key): (val if isinstance(val, str) else None) for key, val in required.items()}", "            if any(type(val) is not str or re.fullmatch('[0-9a-f]{64}', val) is None for val in required.values()):\n                raise DocumentError('required digest must be lowercase SHA256')\n            expected = {_canonical_path(key): val for key, val in required.items()}")
end(33)
begin(34)
edit("    current_files, previous_files = current.get('files', {}), previous.get('files', {})", "    if any(current.get(key) != previous.get(key) for key in ('root', 'directory')):\n        raise DocumentError('artifact diff requires the same root and directory')\n    current_files, previous_files = current.get('files', {}), previous.get('files', {})")
end(34)
begin(35)
edit('def _walk(root, directory, max_entries):','def _walk(root, directory, max_entries, max_total_bytes=None):')
edit('    files = {}\n    for parent,','    files, total = {}, 0\n    for parent,')
edit('digest, size = regular_digest(root, rel)', 'digest, size = regular_digest(root, rel, max_bytes=None if max_total_bytes is None else max_total_bytes-total)\n            total += size')
edit('required=None, max_entries=10000):','required=None, max_entries=10000, max_total_bytes=None):')
edit('    files = _walk(root, directory, max_entries)', "    if max_total_bytes is not None and (type(max_total_bytes) is not int or not 0 <= max_total_bytes <= 1024**3):\n        raise DocumentError('invalid total artifact byte budget')\n    files = _walk(root, directory, max_entries, max_total_bytes)")
end(35)

import json
from pathlib import Path
base=Path('.agent-runs/reflect50-20261021')
catalog=json.loads((base/'catalog-v2.json').read_text(encoding='utf-8'))
catalog['version']=3
catalog['iterations'][32]['change']='require lowercase SHA256 or explicit None for unbound mappings; reject other invalid/coerced digest values'
(base/'catalog-v3.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
path=Path('agent_doc/task/task_details/REFLECT50-20261021.md')
raw=path.read_bytes();(base/'plan-v2-source.md').write_bytes(raw)
text=raw.decode('utf-8').replace('Exact 50 IDs/source changes in catalog-v2.json.', 'Exact 50 IDs/source changes in catalog-v3.json. v3 adapts R33 to preserve the already tested explicit None/unbound mapping API; other invalid digest values must be rejected. V2 source is retained in plan-v2-source.md; historical gates bind their original plans.')
text=text.replace('v2 / EXECUTE pending narrow independent re-review','v3 / EXECUTE pending narrow independent re-review')
path.write_bytes(text.encode('utf-8'))
helper=base/'groups.py';t=helper.read_text(encoding='utf-8').replace("catalog-v2.json'","catalog-v3.json'");helper.write_bytes(t.encode())

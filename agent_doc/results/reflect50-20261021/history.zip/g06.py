from iterate import begin,end,ROOT
def edit(old,new):
    path=ROOT/'agent_runtime/result_validation.py'; text=path.read_text(encoding='utf-8'); assert old in text,old[:100]; path.write_bytes(text.replace(old,new).encode())
begin(26)
edit("    def ancestors(task_id, seen=None):\n        seen = set() if seen is None else seen\n        for dep in by_id[task_id].get('depends_on', []):\n            _need(dep in by_id, 'unknown result dependency')\n            if dep not in seen:\n                seen.add(dep)\n                ancestors(dep, seen)\n        return seen", "    def ancestors(task_id):\n        seen, pending = set(), list(by_id[task_id].get('depends_on', []))\n        while pending:\n            dep = pending.pop()\n            _need(dep in by_id, 'unknown result dependency')\n            if dep not in seen:\n                seen.add(dep)\n                pending.extend(by_id[dep].get('depends_on', []))\n        return seen")
end(26)
begin(27)
path=ROOT/'agent_runtime/result_validation.py'; text=path.read_text(encoding='utf-8');a=text.index('    def ancestors(task_id):');b=text.index('\n    for result_id, producer',a)
text=text[:a]+'''    # Per-validation bitsets share ancestry without recursive traversal or sets per producer.
    bits = {task_id: 1 << i for i, task_id in enumerate(by_id)}
    children = {task_id: [] for task_id in by_id}
    pending_counts, masks = {}, {}
    for task_id, task in by_id.items():
        deps = set(task.get('depends_on', []))
        _need(deps <= by_id.keys(), 'unknown result dependency')
        pending_counts[task_id] = len(deps)
        for dep in deps:
            children[dep].append(task_id)
    ready = [key for key, count in pending_counts.items() if count == 0]
    while ready:
        task_id = ready.pop()
        mask = 0
        for dep in by_id[task_id].get('depends_on', []):
            mask |= masks[dep] | bits[dep]
        masks[task_id] = mask
        for child in children[task_id]:
            pending_counts[child] -= 1
            if pending_counts[child] == 0:
                ready.append(child)
    _need(len(masks) == len(by_id), 'cyclic result dependency')
'''+text[b:]
text=text.replace("upstream = ancestors(task['task_id'])","upstream = masks[task['task_id']]").replace("producer['task_id'] in upstream", "bool(bits[producer['task_id']] & upstream)").replace("gate['task_id'] in upstream","bool(bits[gate['task_id']] & upstream)")
path.write_bytes(text.encode());end(27)
begin(28)
edit("            _bound(root, ref)\n            bindings[ref['path']] = ref['sha256']", "            if ref['path'] not in bindings:\n                _bound(root, ref)\n            bindings[ref['path']] = ref['sha256']")
end(28)
begin(29)
edit('from .legacy_result_paths import legacy_read_binding, check_relocated_digest','from .legacy_result_paths import legacy_read_binding, check_relocated_digest, relocated_digest_matches')
edit('def validate_contract(contract):', '''def _hash_bound(root, ref):
    """Fresh digest verification with bounded scratch; never acceptance caching."""
    _ref(ref)
    read_path, relocated_digest = legacy_read_binding(root, ref['path'])
    path = _path(root, read_path)
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NONBLOCK', 0) | getattr(os, 'O_NOFOLLOW', 0))
    try:
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            info = os.fstat(fd)
            _need(stat.S_ISREG(info.st_mode), 'artifact must be a regular file')
            _need(info.st_size <= LIMIT, 'artifact exceeds verification byte bound')
            digest, size = hashlib.sha256(), 0
            while block := stream.read(min(65536, LIMIT-size+1)):
                size += len(block)
                _need(size <= LIMIT, 'artifact grew beyond verification bound')
                digest.update(block)
    finally:
        os.close(fd)
    actual = digest.hexdigest()
    _need(actual == ref['sha256'], 'stale artifact: ' + ref['path'])
    _need(relocated_digest_matches(actual, relocated_digest), 'relocated historical result bytes changed')


def validate_contract(contract):''')
edit("            if ref['path'] not in bindings:\n                _bound(root, ref)", "            if ref['path'] not in bindings:\n                _hash_bound(root, ref)")
end(29)
begin(30)
edit("type(value) in (int, float) and math.isfinite(value)", "(type(value) is int or type(value) is float and math.isfinite(value))")
end(30)

"""Local batch driver: preserve exact changed inputs; never publish or delete."""
import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT / '.agent-runs/reflect50-20261021'
LEDGER = RUN / 'iterations.json'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def sources():
    return {p.relative_to(ROOT).as_posix(): sha(p.read_bytes())
            for folder in ('agent_runtime', 'scripts', 'workflows', 'tests')
            for p in (ROOT / folder).rglob('*') if p.is_file() and p.suffix in ('.py', '.md')
            and '__pycache__' not in p.parts and p.name not in ('json_context.py', 'test_json_context.py')}

def begin(number):
    subprocess.run(['git', 'fetch', 'origin', 'main'], cwd=ROOT, check=True, capture_output=True)
    local = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).strip()
    remote = subprocess.check_output(['git', 'rev-parse', 'origin/main'], cwd=ROOT).strip()
    if local != remote:
        raise RuntimeError('remote changed: reconcile before the next iteration')
    for args in ([], ['--check']):
        subprocess.run([sys.executable, '-X', 'utf8', 'scripts/setup_codex.py', *args], cwd=ROOT,
                       check=True, capture_output=True)
    state = sources()
    (RUN / 'before.json').write_text(json.dumps(state), encoding='utf-8')
    if (number - 1) % 5 == 0:
        group=(number-1)//5+1
        affected={2:['project_docs','knowledge_index'],3:['project_docs'],4:['project_memory'],5:['result_store'],6:['result_validation'],7:['artifact_index'],8:['legacy_result_paths','knowledge_index','source_context','result_validation','project_docs'],9:['markdown_context'],10:['markdown_context','validation_context','result_store','storage_inventory']}.get(group)
        with zipfile.ZipFile(RUN / ('before-g%02d.zip' % ((number - 1)//5+1)), 'w', zipfile.ZIP_DEFLATED) as archive:
            for name in state:
                if name.startswith('agent_runtime/') and (affected is None or Path(name).stem in affected):
                    archive.write(ROOT/name, name)

def end(number):
    before = json.loads((RUN / 'before.json').read_text(encoding='utf-8'))
    after = sources()
    changes = {name: {'before': before.get(name), 'after': after.get(name)}
               for name in sorted(before.keys() | after.keys()) if before.get(name) != after.get(name)}
    if not changes:
        raise RuntimeError('an iteration needs an actual source change')
    records = json.loads(LEDGER.read_text()) if LEDGER.exists() else []
    if len(records) != number - 1:
        raise RuntimeError('nonsequential iteration')
    records.append({'id': 'R%02d' % number, 'changes': changes, 'status': 'pending-independent-validation'})
    LEDGER.write_text(json.dumps(records, ensure_ascii=False, separators=(',', ':'))+'\n', encoding='utf-8')

if __name__ == '__main__':
    globals()[sys.argv[1]](int(sys.argv[2]))

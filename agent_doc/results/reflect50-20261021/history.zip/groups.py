import hashlib
import json
import platform
import subprocess
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from agent_runtime.result_validation import CHECKS, ARTIFACT_ROLES
OUT = ROOT/'agent_doc/results/reflect50-20261021'
SUFFIX = sys.argv[3] if len(sys.argv)>3 else ''
if SUFFIX and SUFFIX not in ('-r1','-r2','-final'):
    raise ValueError('bounded version suffix required')
def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, separators=(',', ':'))+'\n', encoding='utf-8')
def ref(path):
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
def freeze(group):
    directory = OUT/('g%02d'%group+SUFFIX)
    ids = ['R%02d'%n for n in range(group*5-4,group*5+1)]
    scope = 'Local synthetic behavior checks for '+','.join(ids)+'; no whole-agent token, latency, QA or bug-free claim'
    catalog = ROOT/'.agent-runs/reflect50-20261021/catalog-v3.json'
    procedures = {
      'implementation':'Inspect per-ID actual changed source; reproduce named literal/fault-injection behavior and negative controls.',
      'reference_boundary':'Compare selected original bytes/full JSON oracle; preserve errors, scope, fresh hashes and authorization boundaries.',
      'data_integrity':'Hash complete source, recipe, raw logs and environment; no partial or fabricated pass data.',
      'numerical_sanity':'Check exact sizes/counts/digests and finite metrics; compare semantic values independent of whitespace.',
      'measurement_validity':'Restrict observations to deterministic local fixture behavior; no general speed, QA or billed-token extrapolation.',
      'reproducibility':'Independently rerun group tests in this Windows/Python environment and inspect all five source deltas.'}
    plan = {'schema_version':'experiment-validation-plan/v1','scope':scope,'ids':ids,
            'criteria':{key:{'procedure':value,'acceptance':'All named checks pass with explicit scope and no unresolved blocking finding.', 'allow_not_applicable':False} for key,value in procedures.items()},
            'catalog':ref(catalog),'test_module':'tests/test_reflect50_g%02d.py'%group,
            'repairs':2,'recipe':'unittest literal fixtures; temp directories; deterministic UTF-8 text; no model calls'}
    write(directory/'plan.json',plan)
    write(directory/'contract.json',{'result_id':'reflect50-20261021-g%02d'%group+SUFFIX,'producer_task_id':'REFLECT50-20261021','producer_actor':'/root','manifest_path':(directory/'manifest.json').relative_to(ROOT).as_posix(),'scope':scope,'validation_plan':ref(directory/'plan.json')})
def produce(group):
    directory=OUT/('g%02d'%group+SUFFIX)
    contract=json.loads((directory/'contract.json').read_text(encoding='utf-8'))
    command=[sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_reflect50_g%02d.py'%group,'-v']
    run=subprocess.run(command,cwd=ROOT,capture_output=True)
    (directory/'raw.txt').write_bytes(run.stdout+run.stderr)
    write(directory/'environment.json',{'python':sys.version,'platform':platform.platform(),'returncode':run.returncode,'command':command})
    ledger=ROOT/'.agent-runs/reflect50-20261021/iterations.json'
    records=json.loads(ledger.read_text())[(group-1)*5:group*5]
    write(directory/'changes.json',records)
    code=sorted({p for record in records for p in record['changes']} | {'tests/test_reflect50_g%02d.py'%group})
    artifacts={'code':[ref(ROOT/p) for p in code], 'inputs':[ref(directory/'plan.json')], 'config':[ref(directory/'contract.json')], 'raw_data':[ref(directory/'raw.txt')], 'outputs':[ref(directory/'changes.json')], 'environment':[ref(directory/'environment.json')]}
    write(directory/'manifest.json',{'schema_version':'experiment-result/v1',**{k:contract[k] for k in ('result_id','producer_task_id','producer_actor','scope','validation_plan')},'run_id':'reflect50-g%02d'%group+SUFFIX,'code_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()+'+bound-working-sources','execution':{'command':command,'environment_description':platform.platform()+' / '+sys.version,'repeats':1,'seeds':[0]},'artifacts':artifacts,'metrics':[{'name':'producer_exit_code','value':run.returncode,'unit':'exit-code'},{'name':'iterations','value':len(records),'unit':'changes'}]})
    print(run.stdout.decode('utf-8',errors='replace')+run.stderr.decode('utf-8',errors='replace'))
    raise SystemExit(run.returncode)
if __name__=='__main__':
    globals()[sys.argv[1]](int(sys.argv[2]))

from iterate import begin, end, ROOT
def edit(name, old, new):
    path=ROOT/name
    text=path.read_bytes().decode('utf-8')
    assert old in text, (name,old[:70])
    path.write_bytes(text.replace(old,new).encode('utf-8'))
def own_stream(name, signature, next_signature, mode):
    path=ROOT/name
    text=path.read_text(encoding='utf-8')
    a=text.index(signature); b=text.index(next_signature,a)
    body=text[a:b]
    start=body.index('    with os.fdopen(fd, ')
    block=body[start:]
    block=block.replace("os.fdopen(fd, '"+mode+"')", "os.fdopen(fd, '"+mode+"', closefd=False)",1)
    # Leave trailing blank lines outside the ownership block.
    body=body[:start]+'    try:\n'+''.join('    '+line if line.strip() else line for line in block.rstrip().splitlines(True))+'\n    finally:\n        os.close(fd)\n\n\n'
    path.write_bytes((text[:a]+body+text[b:]).encode())
begin(1)
own_stream('agent_runtime/project_docs.py','def regular_bytes(', 'def parse_requirements(', 'rb')
end(1)
begin(2)
edit('agent_runtime/project_docs.py',"with os.fdopen(fd, 'wb') as stream:","with os.fdopen(fd, 'wb', closefd=False) as stream:")
edit('agent_runtime/project_docs.py',"        assert_ai_writable(root, path)\n        os.replace(temporary, path)\n    finally:\n        if os.path.exists(temporary):", "        os.close(fd)\n        fd = None\n        assert_ai_writable(root, path)\n        os.replace(temporary, path)\n    finally:\n        if fd is not None:\n            os.close(fd)\n        if os.path.exists(temporary):")
end(2)
begin(3)
own_stream('agent_runtime/maintenance_observer.py','def read_bound(', 'def maintenance_observer(', 'rb')
edit('agent_runtime/maintenance_observer.py',"            if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):", "            info = os.fstat(stream.fileno())\n            if info.st_size > max_bytes:\n                raise ValueError('source exceeds budget; no partial context')\n            if not stat.S_ISREG(info.st_mode):")
end(3)
begin(4)
edit('agent_runtime/knowledge_index.py',"    con.row_factory=sqlite3.Row\n    con.execute('PRAGMA trusted_schema=OFF')\n    return con", "    try:\n        con.row_factory=sqlite3.Row\n        con.execute('PRAGMA trusted_schema=OFF')\n        return con\n    except BaseException:\n        con.close()\n        raise")
end(4)
begin(5)
edit('agent_runtime/project_docs.py','def parse_requirements(text, *, canonical=False):', '''def regular_digest(root, path, *, max_bytes=None):
    """Hash exact regular-file bytes with bounded scratch space and growth checks."""
    path = _relative(root, path)
    if max_bytes is not None and (type(max_bytes) is not int or max_bytes < 0):
        raise DocumentError('document byte bound must be a nonnegative integer')
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0))
    try:
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            info = os.fstat(fd)
            if not stat.S_ISREG(info.st_mode):
                raise DocumentError('document must be a regular file')
            if max_bytes is not None and info.st_size > max_bytes:
                raise DocumentError('document exceeds byte bound')
            digest, size = hashlib.sha256(), 0
            while True:
                chunk = stream.read(65536 if max_bytes is None else min(65536, max_bytes-size+1))
                if not chunk:
                    return digest.hexdigest(), size
                size += len(chunk)
                if max_bytes is not None and size > max_bytes:
                    raise DocumentError('document exceeds byte bound')
                digest.update(chunk)
    finally:
        os.close(fd)


def parse_requirements(text, *, canonical=False):''')
edit('agent_runtime/artifact_index.py','DocumentError, regular_bytes','DocumentError, regular_digest')
edit('agent_runtime/artifact_index.py',"            files[rel] = {'sha256': hashlib.sha256(regular_bytes(root, rel)).hexdigest(),\n                          'size': item.stat().st_size,", "            digest, size = regular_digest(root, rel)\n            files[rel] = {'sha256': digest,\n                          'size': size,")
end(5)

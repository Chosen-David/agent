from iterate import begin,end,ROOT
def edit(name,old,new):
    path=ROOT/name;text=path.read_text(encoding='utf-8');assert old in text,(name,old[:80]);path.write_bytes(text.replace(old,new).encode())
begin(36)
P='agent_runtime/legacy_result_paths.py'
edit(P,'import hashlib','import hashlib\nfrom functools import lru_cache\nfrom types import MappingProxyType')
edit(P,'from .external_json import load_json','from .external_json import regular_bytes, strict_json')
path=ROOT/P;text=path.read_text(encoding='utf-8');a=text.index('    record = load_json(marker, max_bytes=LIMIT)');b=text.index("    if value not in record['files']:",a)
block=text[a:b].replace('    record = load_json(marker, max_bytes=LIMIT)','    record = strict_json(data)')
helper='@lru_cache(maxsize=4)\ndef _marker_files(data):\n    """Only immutable parsing is cached; current marker bytes are reread each call."""\n'+block+"    return MappingProxyType({key: tuple(value) if isinstance(value, list) else value for key, value in record['files'].items()})\n\n\n"
text=text[:a]+"    files = _marker_files(regular_bytes(marker, max_bytes=LIMIT))\n"+text[b:]
text=text.replace("value not in record['files']","value not in files").replace("expected = record['files'][value]","expected = files[value]")
text=text.replace('def legacy_read_binding(root, value):',helper+'def legacy_read_binding(root, value):');path.write_bytes(text.encode());end(36)
begin(37)
edit('agent_runtime/knowledge_index.py', '    con=_connect(path)\n    try:\n        _initialize(con)', "    _require(type(rebuild) is bool, 'rebuild must be boolean')\n    con=_connect(path)\n    try:\n        _initialize(con)")
end(37)
begin(38)
edit('agent_runtime/knowledge_index.py',"    con=_connect(path,readonly=True)\n    try:\n        meta=", "    con=_connect(path,readonly=True)\n    try:\n        con.execute('BEGIN')\n        meta=")
end(38)
begin(39)
P='agent_runtime/result_validation.py'
edit(P,'def _bytes(root, value):', "def _bytes(root, value, *, max_bytes=LIMIT):\n    _need(type(max_bytes) is int and 0 <= max_bytes <= LIMIT, 'invalid verification byte bound')")
edit(P,"_need(info.st_size <= LIMIT, 'artifact exceeds 16 MiB bound; use bounded shard manifests')", "_need(info.st_size <= max_bytes, 'artifact exceeds verification byte bound; use bounded shard manifests')")
edit(P,'data = stream.read(LIMIT + 1)','data = stream.read(max_bytes + 1)')
edit(P,"_need(len(data) <= LIMIT, 'artifact grew beyond verification bound')", "_need(len(data) <= max_bytes, 'artifact grew beyond verification bound')")
edit(P,'def _bound(root, ref):','def _bound(root, ref, *, max_bytes=LIMIT):')
edit(P,"    data = _bytes(root, ref['path'])","    data = _bytes(root, ref['path'], max_bytes=max_bytes)")
edit('agent_runtime/source_context.py','    raw = _bound(root, ref)','    raw = _bound(root, ref, max_bytes=262144)')
end(39)
begin(40)
edit('agent_runtime/project_docs.py',"hashlib.sha256(regular_bytes(root, item)).hexdigest() if hashes else None","regular_digest(root, item)[0] if hashes else None")
end(40)

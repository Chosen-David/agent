"""Independent small-graph oracle and fresh-stream validation controls."""
from pathlib import Path
import copy,hashlib,itertools,json,os,subprocess,sys,tempfile,types,zipfile
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));tempfile.tempdir=str(OUT)
from agent_runtime import result_validation as v
c=json.loads((ROOT/'agent_doc/results/reflect50-20261021/g06/contract.json').read_bytes());_,_,proof=v._snapshot(ROOT,c)
with zipfile.ZipFile(ROOT/'.agent-runs/reflect50-20261021/before-g06.zip') as z:
    assert z.namelist()==['agent_runtime/result_validation.py'];raw=z.read(z.namelist()[0]);last=hashlib.sha256(raw).hexdigest()
    old=types.ModuleType('agent_runtime._g06_old');old.__package__='agent_runtime';exec(compile(raw,'<before-g06>','exec'),old.__dict__)
for item in json.loads((ROOT/'agent_doc/results/reflect50-20261021/g06/changes.json').read_bytes()):
    item=item['changes']['agent_runtime/result_validation.py'];assert item['before']==last;last=item['after']
assert hashlib.sha256((ROOT/'agent_runtime/result_validation.py').read_bytes()).hexdigest()==last
contract=dict(result_id='r',producer_task_id='p',producer_actor='producer',manifest_path='manifest.json',scope='fixture',validation_plan={'path':'plan.json','sha256':'0'*64})
edges=[(i,j) for i in range(4) for j in range(i)];count=0
for edge_mask in range(1<<len(edges)):
    for refs in range(4):
        tasks=[dict(task_id=name,owner='other' if i==1 else 'producer',action='verify_experiment_result' if i==1 else 'work',depends_on=[]) for i,name in enumerate(('p','g','a','b'))]
        tasks[0]['experiment_result']=contract;tasks[1]['result_validation']=contract
        for bit,(i,j) in enumerate(edges):
            if edge_mask&(1<<bit):tasks[i]['depends_on'].append(tasks[j]['task_id'])
        for i in (2,3):
            if refs&(1<<(i-2)):tasks[i]['required_result_refs']=[contract]
        outputs=[]
        for mod in (old,v):
            try:outputs.append(bool(mod.validate_result_plan({'tasks':tasks})))
            except ValueError:outputs.append(False)
        assert outputs[0]==outputs[1],(edge_mask,refs,outputs);count+=1
deep=[dict(task_id='p',owner='producer',action='work',experiment_result=contract),dict(task_id='g',owner='other',action='verify_experiment_result',depends_on=['p'],result_validation=contract)]
for i in range(998):deep.append(dict(task_id='x'+str(i),owner='producer',action='work',depends_on=[deep[-1]['task_id']],required_result_refs=[contract]))
assert v.validate_result_plan({'tasks':deep})
try:old.validate_result_plan({'tasks':deep})
except RecursionError:pass
else:raise AssertionError('baseline deep recursion not reproduced')
cycle=copy.deepcopy(deep[:2]);cycle[0]['depends_on']=['g']
try:v.validate_result_plan({'tasks':cycle})
except v.ResultValidationError:pass
else:raise AssertionError('cycle admitted')
observations=[dict(name='small_dag_oracle',cases=count,deep_chain_tasks=len(deep),baseline_recursion_failure=True,cycle_refused=True)]
with tempfile.TemporaryDirectory(prefix='g06-') as tmp:
    root=Path(tmp)
    def put(name,data):
        (root/name).write_bytes(data);return dict(path=name,sha256=hashlib.sha256(data).hexdigest())
    plan=dict(schema_version='experiment-validation-plan/v1',scope='fixture',criteria={n:dict(procedure='literal',acceptance='exact',allow_not_applicable=False) for n in v.CHECKS})
    planref=put('plan.json',json.dumps(plan).encode());blob=put('blob',b'abc')
    bound=dict(contract,validation_plan=planref)
    manifest=dict(schema_version='experiment-result/v1',**bound,run_id='fixture',code_revision='fixture',execution=dict(command=['literal'],environment_description='local',repeats=1,seeds=[0]),artifacts={n:[blob] for n in v.ARTIFACT_ROLES},metrics=[dict(name='integer',value=10**1000,unit='count')])
    put('manifest.json',json.dumps(manifest).encode())
    with patch.object(v,'_hash_bound',wraps=v._hash_bound) as calls:
        v._snapshot(root,bound);assert calls.call_count==1
        v._snapshot(root,bound);assert calls.call_count==2
    (root/'blob').write_bytes(b'tamper')
    try:v._snapshot(root,bound)
    except v.ResultValidationError:pass
    else:raise AssertionError('stale fresh snapshot admitted')
    (root/'blob').write_bytes(b'abc');manifest['artifacts']['outputs']=[dict(blob,sha256='f'*64)];put('manifest.json',json.dumps(manifest).encode())
    try:v._snapshot(root,bound)
    except v.ResultValidationError:pass
    else:raise AssertionError('contradictory duplicate ref admitted')
    for bad in (True,float('inf'),float('nan')):
        manifest['artifacts']['outputs']=[blob];manifest['metrics'][0]['value']=bad;put('manifest.json',json.dumps(manifest).encode())
        try:v._snapshot(root,bound)
        except ValueError:pass
        else:raise AssertionError('non-numeric/nonfinite metric admitted')
    reads=[];real=os.fdopen
    def spy(fd,*args,**kw):
        stream=real(fd,*args,**kw)
        class Proxy:
            def __getattr__(self,key):return getattr(stream,key)
            def __enter__(self):stream.__enter__();return self
            def __exit__(self,*args):return stream.__exit__(*args)
            def read(self,size=-1):reads.append(size);return stream.read(size)
        return Proxy()
    data=b'z'*200000;large=put('large',data)
    with patch.object(v.os,'fdopen',spy):v._hash_bound(root,large)
    assert reads and min(reads)>0 and max(reads)<=65536
    with patch.object(v,'LIMIT',100):
        try:v._hash_bound(root,large)
        except v.ResultValidationError:pass
        else:raise AssertionError('oversize digest admitted')
    observations.append(dict(name='fresh_unique_hash_and_metrics',same_snapshot_once=True,next_snapshot_rehash=True,stale_and_contradictory_ref_refused=True,large_integer_exact=True,bool_nonfinite_refused=True,max_digest_read=max(reads)))
env=os.environ.copy();env.update(TEMP=str(OUT),TMP=str(OUT),PYTHONDONTWRITEBYTECODE='1')
run=subprocess.run([sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_reflect50_g06.py','-v'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'g06-replay.txt').write_bytes(run.stdout);assert run.returncode==0
assert v._snapshot(ROOT,c)[2]==proof
(OUT/'g06-checks.json').write_text(json.dumps(dict(actor='/root/reflect50_review',producer_proof=proof,observations=observations,replay_exit_code=0,status='checks-pass'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('256 DAG oracle cases, 1000-node chain, cycle/freshhash/metric/stream controls pass; five tests replay pass')

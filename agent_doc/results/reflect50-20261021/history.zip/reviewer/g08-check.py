"""Independent fresh-marker, WAL snapshot, parser admission and inventory checks."""
from contextlib import closing
from pathlib import Path
import hashlib,json,os,sqlite3,subprocess,sys,tempfile,types,zipfile
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));tempfile.tempdir=str(OUT)
from agent_runtime import legacy_result_paths as l,knowledge_index as k,source_context as s,project_docs as d,result_validation as v
c=json.loads((ROOT/'agent_doc/results/reflect50-20261021/g08/contract.json').read_bytes());_,_,proof=v._snapshot(ROOT,c)
with zipfile.ZipFile(ROOT/'.agent-runs/reflect50-20261021/before-g08.zip') as z:
    expected={name:hashlib.sha256(z.read(name)).hexdigest() for name in z.namelist()}
    old=types.ModuleType('agent_runtime._g08_old_index');old.__package__='agent_runtime';exec(compile(z.read('agent_runtime/knowledge_index.py'),'<before-g08>','exec'),old.__dict__)
for item in json.loads((ROOT/'agent_doc/results/reflect50-20261021/g08/changes.json').read_bytes()):
    for path,ver in item['changes'].items():assert ver['before']==expected[path];expected[path]=ver['after']
for path,digest in expected.items():assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest
observations=[]
with tempfile.TemporaryDirectory(prefix='g08-') as tmp:
    root=Path(tmp);marker=root/l.MARKER;marker.parent.mkdir(parents=True)
    l._marker_files.cache_clear();previous=None
    for i in range(6):
        digest=hashlib.sha256(str(i).encode()).hexdigest();raw=json.dumps(dict(schema_version='agent-doc-relocation/v1',files={'doc/results/a':[digest,'f'*64]})).encode();marker.write_bytes(raw)
        assert l.legacy_read_binding(root,'doc/results/a')==('agent_doc/results/a',(digest,'f'*64))
        if previous is not None:assert digest!=previous
        previous=digest
    cached=l._marker_files(raw)
    try:cached['doc/results/a']='bad'
    except TypeError:pass
    else:raise AssertionError('cached mapping mutable')
    assert isinstance(cached['doc/results/a'],tuple) and l._marker_files.cache_info().currsize==4
    marker.write_bytes(b'{}')
    try:l.legacy_read_binding(root,'doc/results/a')
    except ValueError:pass
    else:raise AssertionError('cached valid marker hides malformed current bytes')
    marker.write_bytes(raw);real=Path.is_symlink
    with patch.object(Path,'is_symlink',lambda p:p==root/'agent_doc/results/a' or real(p)):
        try:l.legacy_read_binding(root,'doc/results/a')
        except ValueError:pass
        else:raise AssertionError('cached marker skips current target link guard')
    observations.append(dict(name='marker_cache',entries=4,immutable_values=True,fresh_invalid_bytes_refused=True,current_target_safety_refused=True))
    corpus=root/'corpus';corpus.mkdir();record=dict(id='a',version=1,sha256='a'*64,title='A',content='# A\nmemory body',status='published',summary='s',aliases=[],domains=[],structures=[],assumptions=[],verification={})
    class Store:
        root=corpus;records={'a':record};snapshot='frozen'
        def ref(self,key):return {name:record[name] for name in ('id','version','sha256')}
        def get(self,key):return dict(record,knowledge_refs=[])
    store=Store()
    with patch.object(k,'_connect',side_effect=AssertionError('must not open')):
        for invalid in (None,0,1,'false',[]):
            try:k.build_index(store,root/'bad.sqlite',rebuild=invalid)
            except k.KnowledgeError:pass
            else:raise AssertionError('invalid rebuild admitted')
    assert not (root/'bad.sqlite').exists()
    lanes={}
    for label,module in (('before',old),('after',k)):
        path=root/(label+'.sqlite');module.build_index(store,path)
        with closing(sqlite3.connect(path)) as con:con.execute('PRAGMA journal_mode=WAL')
        connect=module._connect;changed=[]
        class Reader:
            def __init__(self,con):self.con=con
            def close(self):self.con.close()
            def execute(self,sql,*args):
                if 'bm25(docs' in sql and not changed:
                    with closing(sqlite3.connect(path)) as writer:
                        with writer:
                            writer.execute('DELETE FROM docs');writer.execute('DELETE FROM chunks');writer.execute("UPDATE meta SET value='changed' WHERE key='snapshot'")
                    changed.append(True)
                return self.con.execute(sql,*args)
        with patch.object(module,'_connect',lambda *args,**kw:Reader(connect(*args,**kw))):result=module.indexed_search(store,path,'memory')
        assert changed;lanes[label]=len(result['results'])
        try:module.indexed_search(store,path,'memory')
        except module.KnowledgeError:pass
        else:raise AssertionError('next query accepts changed snapshot')
    assert lanes=={'before':0,'after':1};observations.append(dict(name='real_WAL_concurrent_writer',results=lanes,next_call_stale_refused=True))
    source=root/'large.py';source.write_bytes(b'x'*262145);requests=[];realopen=v.os.fdopen
    def spy(fd,*args,**kw):
        stream=realopen(fd,*args,**kw)
        class Proxy:
            def __getattr__(self,key):return getattr(stream,key)
            def __enter__(self):stream.__enter__();return self
            def __exit__(self,*args):return stream.__exit__(*args)
            def read(self,size=-1):requests.append(size);return stream.read(size)
        return Proxy()
    request=dict(schema_version='source-context/v1',source={'path':'large.py','sha256':hashlib.sha256(source.read_bytes()).hexdigest()},symbols=['x'])
    with patch.object(v.os,'fdopen',spy):
        try:s.source_context(root,request)
        except ValueError:pass
        else:raise AssertionError('oversized parser source admitted')
    assert requests==[]
    directory=root/'agent_doc/advice';directory.mkdir()
    for name,data in (('empty',b''),('small',b'a'),('large',b'x'*100000)):(directory/name).write_bytes(data)
    expected={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in directory.iterdir()}
    with patch.object(d,'regular_bytes',side_effect=AssertionError('whole-read path')):assert d._inventory(root,'agent_doc/advice')==expected
    observations.append(dict(name='parser_and_inventory',oversize_read_requests=requests,inventory_literal_digests_equal=True))
env=os.environ.copy();env.update(TEMP=str(OUT),TMP=str(OUT),PYTHONDONTWRITEBYTECODE='1')
run=subprocess.run([sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_reflect50_g08.py','-v'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'g08-replay.txt').write_bytes(run.stdout);assert run.returncode==0
assert v._snapshot(ROOT,c)[2]==proof
(OUT/'g08-checks.json').write_text(json.dumps(dict(actor='/root/reflect50_review',producer_proof=proof,observations=observations,replay_exit_code=0,status='checks-pass'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Fresh immutable cache, invalid rebuild no-open, true WAL old/new, parser no-read and literal inventory pass; five tests replay pass')

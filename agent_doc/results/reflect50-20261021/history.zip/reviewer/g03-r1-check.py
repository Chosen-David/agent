"""Independent G03 literal pagination/selection/version and wire checks."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile,zipfile
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));tempfile.tempdir=str(OUT)
from agent_runtime import project_docs as d
from agent_runtime.result_validation import _snapshot
c=json.loads((ROOT/'agent_doc/results/reflect50-20261021/g03-r1/contract.json').read_bytes());_,_,proof=_snapshot(ROOT,c)
with zipfile.ZipFile(ROOT/'.agent-runs/reflect50-20261021/before-g03.zip') as z:
    assert z.namelist()==['agent_runtime/project_docs.py'];last=hashlib.sha256(z.read(z.namelist()[0])).hexdigest()
for item in json.loads((ROOT/'agent_doc/results/reflect50-20261021/g03/changes.json').read_bytes()):
    versions=item['changes']['agent_runtime/project_docs.py'];assert versions['before']==last;last=versions['after']
assert last=='9b91cbbec89e3b72ee9f054d210dae2754aada3335b791c67c0c087f302255ae' # Original result chain preserved; repair hash bound by fresh manifest.
observations=[]
with tempfile.TemporaryDirectory(prefix='g03-') as tmp:
    root=Path(tmp);details=root/'agent_doc/task/task_details';details.mkdir(parents=True);index=details.parent/'TASK.md'
    raw='## 2026-10-21\n'+''.join(f'- [ ] [{i}] Old title ([detail](task_details/{i}.md))\n' for i in ('A','B'))
    index.write_bytes(raw.encode())
    for i in ('A','B'):(details/(i+'.md')).write_bytes(f'Task-ID: {i}\nDate: 2026-10-21\n## Plan\n### 摘要\nRésumé\n## Progress\nlive'.encode())
    selected=d.task_navigation(root,task_ids=['A'],summary_chars=0)
    assert selected['tasks'][0]['summary']=='' and selected['tasks'][0]['summary_source']['chars']==6
    observations.append(dict(name='selection_checked_count',actual=selected['omitted_checked_tasks'],expected=0,fixed=selected['omitted_checked_tasks']==0))
    assert selected['omitted_checked_tasks']==0
    original=d.regular_bytes;calls=0
    def swapped(project,path,**kw):
        global calls
        if Path(path)==index:
            calls+=1
            value=original(project,path,**kw)
            if calls==1:index.write_bytes(raw.replace('Old title','New title').encode())
            return value
        return original(project,path,**kw)
    with patch.object(d,'regular_bytes',swapped):first=d.task_navigation(root,limit=1)
    try:d.task_navigation(root,limit=1,expected_snapshot=first['snapshot'])
    except d.DocumentError:pass
    else:raise AssertionError('changed title accepted under old snapshot')
    second=d.task_navigation(root,limit=1)
    assert calls==1 and first['tasks'][0]['title']!=second['tasks'][0]['title'] and first['snapshot']!=second['snapshot']
    observations.append(dict(name='index_snapshot_race',index_reads=calls,first_title=first['tasks'][0]['title'],second_title=second['tasks'][0]['title'],same_snapshot=False,old_snapshot_refused=True))
    base=[sys.executable,'-X','utf8','-B','scripts/project_docs.py','--root',str(root),'nav','--task-id','A']
    run=subprocess.run(base,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert run.returncode==0
    wire=run.stdout.decode('utf-8');packet=json.loads(wire)
    assert wire.endswith(os.linesep)
    exact=len(wire)
    yes=subprocess.run(base+['--max-chars',str(exact)],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    no=subprocess.run(base+['--max-chars',str(exact-1)],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert yes.returncode==0 and len(yes.stdout.decode('utf-8'))==exact and no.returncode==2
    observations.append(dict(name='native_cli_wire',chars=exact,native_newline=repr(os.linesep),exact_bound_accept=True,one_less_refuse=True))
env=os.environ.copy();env.update(TEMP=str(OUT),TMP=str(OUT),PYTHONDONTWRITEBYTECODE='1')
run=subprocess.run([sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_reflect50_g03.py','-v'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'g03-r1-replay.txt').write_bytes(run.stdout);assert run.returncode==0
assert _snapshot(ROOT,c)[2]==proof
(OUT/'g03-r1-checks.json').write_text(json.dumps(dict(actor='/root/reflect50_review',producer_proof=proof,observations=observations,replay_exit_code=0,status='checks-pass'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Both G03 repair oracles pass; actual CLI wire bound passes; six producer tests pass')

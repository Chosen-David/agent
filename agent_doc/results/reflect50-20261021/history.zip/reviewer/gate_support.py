"""Save a native review already performed; never authenticates stored labels.

Called explicitly by /root/reflect50_review after independent code/check work.
Producer data never selects this module or any callback.
"""
from pathlib import Path
import hashlib
import json
from agent_runtime.result_validation import _snapshot, inspect_result, CHECKS

def write_gate(root, group, tag, reasons, evidence_paths, limitations, fail=()):
    root=Path(root);out=root/'.agent-runs/reflect50-20261021/reviewer'
    contract=json.loads((root/f'agent_doc/results/reflect50-20261021/{group}/contract.json').read_bytes())
    _,_,proof=_snapshot(root,contract)
    def ref(path):return {'path':path,'sha256':hashlib.sha256((root/path).read_bytes()).hexdigest()}
    refs=[ref(p) for p in evidence_paths]
    review=dict(schema_version='experiment-validation/v1',
        **{k:proof[k] for k in ('manifest_sha256','artifact_hashes','validation_plan_sha256','scope')},
        verifier=dict(actor='/root/reflect50_review',independent=True,
            source='native independent collaboration actor with actual source inspection and executed independent checks',
            run_id='reflect50-'+tag+'-review-v1',method='actual source review, independently authored targeted checks and producer-test replay'),
        limitations=limitations,
        checks={n:dict(verdict='fail' if n in fail else 'pass',reason=reasons[n],evidence=refs) for n in CHECKS})
    review_path=out/(tag+'-review.json')
    review_path.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    result=inspect_result(root,contract,verifier=lambda *_:review)
    (out/(tag+'-inspect.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    expected='invalid' if fail else 'usable-with-scope'
    assert result['status']==expected,result
    return dict(status=result['status'],manifest_sha256=proof['manifest_sha256'],
        review_sha256=hashlib.sha256(review_path.read_bytes()).hexdigest())

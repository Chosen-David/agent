"""Independent narrow stream-wrapper and explicit None mapping compatibility."""
from pathlib import Path
import json,os,subprocess,sys,tempfile
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));tempfile.tempdir=str(OUT)
from agent_runtime import result_store as r,artifact_index as a,project_docs as d
from agent_runtime.result_validation import _snapshot
contracts={name:json.loads((ROOT/f'agent_doc/results/reflect50-20261021/{name}/contract.json').read_bytes()) for name in ('g05-r2','g07-r2')}
proofs={name:_snapshot(ROOT,c)[2] for name,c in contracts.items()}
with tempfile.TemporaryDirectory(prefix='compat-r2-') as tmp:
    root=Path(tmp);(root/'a').write_bytes(b'abc');real=r.os.fdopen;requests=[]
    def limited(fd,*args,**kw):
        stream=real(fd,*args,**kw)
        class Wrapper:
            def __enter__(self):stream.__enter__();return self
            def __exit__(self,*args):return stream.__exit__(*args)
            def fileno(self):return stream.fileno()
            def read(self,size):requests.append(size);return stream.read(size)
        return Wrapper()
    with patch.object(r.os,'fdopen',limited):assert r._read(root,'a')==b'abc'
    assert requests==[r.METADATA_LIMIT+1]
    result=a.build_artifact_index(root,required={'a':None,'missing':None})
    assert result['required']=={'a':{'path':'a','present':True},'missing':{'path':'missing','present':False}}
    for value in (False,0,[],b'x','X'*64):
        try:a.build_artifact_index(root,required={'a':value})
        except d.DocumentError:pass
        else:raise AssertionError('invalid digest admitted')
    try:a.build_artifact_index(root,directory='..')
    except d.DocumentError as exc:assert str(exc)=='index directory must live under the project root'
    else:raise AssertionError('outside root admitted')
env=os.environ.copy();env.update(TEMP=str(OUT),TMP=str(OUT),PYTHONDONTWRITEBYTECODE='1')
commands={
'g05-r2':[sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_reflect50_g05.py','-v'],
'g07-r2':[sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_reflect50_g07.py','-v'],
'compat-r2':[sys.executable,'-X','utf8','-B','-m','unittest','tests.test_result_store_fd','tests.test_artifact_index.ArtifactIndexTests.test_required_paths_report_present_missing_match_mismatch','tests.test_artifact_index.ArtifactIndexTests.test_directory_outside_root_and_missing_directory_are_rejected','-v']}
for name,command in commands.items():
    run=subprocess.run(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (OUT/(name+'-replay.txt')).write_bytes(run.stdout);assert run.returncode==0,run.stdout.decode(errors='replace')
for name,c in contracts.items():assert _snapshot(ROOT,c)[2]==proofs[name]
(OUT/'compat-r2-checks.json').write_text(json.dumps(dict(actor='/root/reflect50_review',producer_proofs=proofs,observations=dict(missing_seekable_wrapper_exact=True,read_requests=requests,None_presence_only=True,invalid_other_digests_refused=True,outside_error_preserved=True),status='checks-pass'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('G05-r2 six/G07-r2 five tests plus 11 compatibility tests pass (two existing platform skips); independent wrapper/None/error controls pass')

"""Narrow independent R24 custom-show serialization-side-effect repair check."""
from pathlib import Path
import json,os,subprocess,sys,tempfile
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));tempfile.tempdir=str(OUT)
from agent_runtime import result_store as r
from agent_runtime.result_validation import _snapshot
c=json.loads((ROOT/'agent_doc/results/reflect50-20261021/g05-r1/contract.json').read_bytes());m,_,proof=_snapshot(ROOT,c)
assert m['run_id']=='reflect50-g05-r1'
class Custom(r.ResultStore):
    def _directories(self,max_scan):return ['a','b'],False,2
    def show(self,name):
        return dict(record=dict(summary='alpha Straße beta',context={},origin='historical',validation_at_registration={'status':'unknown'}),record_ref=dict(path=name,sha256='0'*64))
original=r.json.dumps
with patch.object(r.json,'dumps',wraps=original) as dumps:
    actual=Custom(OUT).search('alpha strasse beta',limit=1)
assert dumps.call_count==2 and actual['results'][0]['score']==3 and actual['partial']
env=os.environ.copy();env.update(TEMP=str(OUT),TMP=str(OUT),PYTHONDONTWRITEBYTECODE='1')
run=subprocess.run([sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_reflect50_g05.py','-v'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'g05-r1-replay.txt').write_bytes(run.stdout);assert run.returncode==0
assert _snapshot(ROOT,c)[2]==proof
(OUT/'g05-r1-checks.json').write_text(json.dumps(dict(actor='/root/reflect50_review',producer_proof=proof,observations=dict(custom_records=2,tokens=3,json_serializations=2,score=3,partial=True),replay_exit_code=0,status='checks-pass'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Custom-show two records/three tokens serialize exactly twice; score/partial correct; six tests replay pass')

"""Independent artifact inventory path admission/default identity/growth checks."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile,types,zipfile
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));tempfile.tempdir=str(OUT)
from agent_runtime import artifact_index as a,project_docs as d
from agent_runtime.result_validation import _snapshot
c=json.loads((ROOT/'agent_doc/results/reflect50-20261021/g07/contract.json').read_bytes());_,_,proof=_snapshot(ROOT,c)
with zipfile.ZipFile(ROOT/'.agent-runs/reflect50-20261021/before-g07.zip') as z:
    assert z.namelist()==['agent_runtime/artifact_index.py'];raw=z.read(z.namelist()[0]);last=hashlib.sha256(raw).hexdigest()
    old=types.ModuleType('agent_runtime._g07_old');old.__package__='agent_runtime';exec(compile(raw,'<before-g07>','exec'),old.__dict__)
for item in json.loads((ROOT/'agent_doc/results/reflect50-20261021/g07/changes.json').read_bytes()):
    item=item['changes']['agent_runtime/artifact_index.py'];assert item['before']==last;last=item['after']
assert hashlib.sha256((ROOT/'agent_runtime/artifact_index.py').read_bytes()).hexdigest()==last
observations=[]
with tempfile.TemporaryDirectory(prefix='g07-') as tmp:
    root=Path(tmp);source=root/'file';source.write_bytes(b'abc')
    default=a.build_artifact_index(root)
    assert default==old.build_artifact_index(root)
    assert a.build_artifact_index(root,max_total_bytes=3)==default
    invalid=['/absolute','../escape','x//y','x/./y','C:/drive','x\\y']
    for path in invalid:
        try:a.build_artifact_index(root,required=[path])
        except d.DocumentError:pass
        else:raise AssertionError('unsafe required path admitted')
    nul=a.build_artifact_index(root,required=['bad\x00name'])
    assert nul['required']['bad\x00name']['present'] is False
    observations.append(dict(name='NUL_required_path',accepted_as_missing=True,blocking_defect=True))
    for key in ('root','directory'):
        other=dict(default);other[key]='other'
        try:a.diff_artifact_index(default,other)
        except d.DocumentError:pass
        else:raise AssertionError('foreign diff admitted')
    real=Path.is_symlink
    with patch.object(Path,'is_symlink',lambda p:p==root/'alias' or real(p)):
        try:a.build_artifact_index(root,directory='alias')
        except d.DocumentError as exc:assert 'symlink' in str(exc)
        else:raise AssertionError('starting alias not refused lexically')
    realopen=d.os.fdopen;requests=[]
    def growing(fd,*args,**kw):
        stream=realopen(fd,*args,**kw)
        class Proxy:
            first=True
            def __getattr__(self,k):return getattr(stream,k)
            def __enter__(self):stream.__enter__();return self
            def __exit__(self,*args):return stream.__exit__(*args)
            def read(self,size=-1):
                requests.append(size)
                if self.first:
                    self.first=False
                    with source.open('ab') as extra:extra.write(b'grown')
                return stream.read(size)
        return Proxy()
    with patch.object(d.os,'fdopen',growing):
        try:a.build_artifact_index(root,max_total_bytes=3)
        except d.DocumentError:pass
        else:raise AssertionError('growth beyond aggregate budget admitted')
    assert requests==[4]
    observations.append(dict(name='other_controls',default_old_new_equal=True,exact_budget_equal=True,noncanonical_refused=invalid,cross_scope_refused=True,mocked_symlink_refused=True,growth_refused=True,growth_read_requests=requests))
env=os.environ.copy();env.update(TEMP=str(OUT),TMP=str(OUT),PYTHONDONTWRITEBYTECODE='1')
run=subprocess.run([sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_reflect50_g07.py','-v'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'g07-replay.txt').write_bytes(run.stdout);assert run.returncode==0
assert _snapshot(ROOT,c)[2]==proof
(OUT/'g07-checks.json').write_text(json.dumps(dict(actor='/root/reflect50_review',producer_proof=proof,observations=observations,replay_exit_code=0,status='blocking-defect'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('NUL required path wrongly accepted as missing; other default/path/growth/diff controls and five tests pass')

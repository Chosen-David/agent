"""Independent focused G02 checks; fail if old v6 physical-line index is trusted."""
from pathlib import Path
import hashlib,json,os,sqlite3,subprocess,sys,tempfile,types,zipfile
from contextlib import closing
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));tempfile.tempdir=str(OUT)
from agent_runtime import project_docs as d,knowledge_index as k
from agent_runtime.result_validation import _snapshot
c=json.loads((ROOT/'agent_doc/results/reflect50-20261021/g02-r2/contract.json').read_bytes())
_,_,before=_snapshot(ROOT,c)
observations=[]
with zipfile.ZipFile(ROOT/'.agent-runs/reflect50-20261021/before-g02.zip') as z:
    assert set(z.namelist())=={'agent_runtime/project_docs.py','agent_runtime/knowledge_index.py'}
    old=types.ModuleType('agent_runtime._g02_old_index');old.__package__='agent_runtime'
    exec(compile(z.read('agent_runtime/knowledge_index.py'),'<g02-before-index>','exec'),old.__dict__)
    expected={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
changes=json.loads((ROOT/'agent_doc/results/reflect50-20261021/g02/changes.json').read_bytes())
for item in changes:
    for path,versions in item['changes'].items():
        assert expected[path]==versions['before'];expected[path]=versions['after']
for path,digest in expected.items():
    source=(ROOT/path).read_bytes()
    if path.endswith('knowledge_index.py'):
        source=source.replace(b'fts5-porter-physical-lines-v7',b'fts5-porter-alias-first-section-v6')
    assert hashlib.sha256(source).hexdigest()==digest
for newline in ('\n','\r\n','\r'):
    text=newline.join(['Task-ID: A','## Plan','~~~','## Plan','## Progress','~~~','actual','## Progress','live',''])
    plan,progress=d.split_detail(text)
    assert plan.endswith('actual'+newline) and progress=='live'+newline
    assert d._field_values('Task-ID: A'+newline+'```'+newline+'Task-ID: B'+newline+'```'+newline,'Task-ID')==['A']
observations.append('CR LF CRLF boundary and identity literal cases pass')
text='## Plan\n```\n``` trailing\n## Progress\n```\nactual\n## Progress\nlast\n'
assert d.split_detail(text)[1]=='last\n'
for token in ('~~~','````'):
    s='### Target\nbody\n'+token+'\n### fake\n'+token+'\ntail\n### End\nstop'
    assert d._plan_section(s,'Target')=='body\n'+token+'\n### fake\n'+token+'\ntail'
observations.append('invalid closer and subsection fence cases pass')
with tempfile.TemporaryDirectory(prefix='g02-') as tmp:
    root=Path(tmp);corpus=root/'corpus';corpus.mkdir()
    content='# Real\nvalue\u2028# Fake\nbody'
    record=dict(id='a',version=1,sha256=hashlib.sha256(content.encode()).hexdigest(),title='A',content=content,status='published',summary='s',aliases=[],domains=[],structures=[],assumptions=[],verification={})
    class Store:
        root=corpus;records={'a':record};snapshot='stable-snapshot'
        def ref(self,key):return {n:record[n] for n in ('id','version','sha256')}
        def get(self,key):return dict(record,knowledge_refs=[])
    store=Store();index=root/'cache.sqlite'
    old.build_index(store,index)
    try:k.indexed_search(store,index,'Fake')
    except k.KnowledgeError as exc:assert 'stale index engine' in str(exc)
    else:raise AssertionError('old engine accepted')
    result=k.build_index(store,index)
    with closing(sqlite3.connect(index)) as con:rows=con.execute('SELECT node,heading FROM chunks').fetchall()
    search=k.indexed_search(store,index,'Fake')
    assert len(rows)==len(k.sections(record))==1 and result['updated']==1 and result['engine_changed'] and search['results']
    observations.append(dict(name='old_index_invalidation',old_engine=old.ENGINE_VERSION,new_engine=k.ENGINE_VERSION,build=result,stored_sections=rows,current_section_count=1,old_search_refused=True,repaired_search_accepted=True))
env=os.environ.copy();env.update(TEMP=str(OUT),TMP=str(OUT),PYTHONDONTWRITEBYTECODE='1')
run=subprocess.run([sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_reflect50_g02.py','-v'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'g02-r2-replay.txt').write_bytes(run.stdout);assert run.returncode==0
_,_,after=_snapshot(ROOT,c);assert before==after
(OUT/'g02-r2-checks.json').write_text(json.dumps(dict(actor='/root/reflect50_review',producer_proof=before,observations=observations,producer_replay_exit_code=run.returncode,status='checks-pass'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('R10 old-index refusal/rebuild independently verified; six producer tests pass; source bindings unchanged')

"""Native reviewer checks, authored independently of producer test assertions.

Predeclared: exact bytes/hash equivalence; setup/entry/read/write failures must
release owned descriptors; known oversize must refuse before read; post-stat
growth must refuse; digest reads <=65536 bytes. Allocation observation is local
diagnostic only: three paired 4MiB samples plus tiny/empty controls, no latency.
"""
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import tracemalloc
import types
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from agent_runtime import project_docs as docs, maintenance_observer as observer
from agent_runtime import knowledge_index, artifact_index
from agent_runtime.result_validation import _snapshot

tempfile.tempdir = str(OUT)
contract = json.loads((ROOT/'agent_doc/results/reflect50-20261021/g01/contract.json').read_bytes())
manifest, plan, proof_before = _snapshot(ROOT, contract)
observations = []

def record(name, **values):
    observations.append(dict(name=name, **values))

def hashfile(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

with zipfile.ZipFile(ROOT/'.agent-runs/reflect50-20261021/before-g01.zip') as archive:
    baseline_sources = {name: archive.read(name) for name in (
        'agent_runtime/project_docs.py', 'agent_runtime/maintenance_observer.py',
        'agent_runtime/knowledge_index.py', 'agent_runtime/artifact_index.py')}
    record('baseline_archive', entries=len(archive.namelist()),
           sha256=hashfile(ROOT/'.agent-runs/reflect50-20261021/before-g01.zip'),
           selected_sha256={k:hashlib.sha256(v).hexdigest() for k,v in baseline_sources.items()})

def oldmodule(short):
    module=types.ModuleType('agent_runtime._review_old_'+short)
    module.__package__='agent_runtime'
    exec(compile(baseline_sources['agent_runtime/'+short+'.py'], '<review-baseline-'+short+'>', 'exec'),module.__dict__)
    return module

old_docs=oldmodule('project_docs')
old_observer=oldmodule('maintenance_observer')
old_index=oldmodule('knowledge_index')

changes=json.loads((ROOT/'agent_doc/results/reflect50-20261021/g01/changes.json').read_bytes())
last={}
for item in changes:
    for path, versions in item['changes'].items():
        expected=last.get(path,hashlib.sha256(baseline_sources[path]).hexdigest())
        assert versions['before']==expected,(item['id'],path,'before hash')
        last[path]=versions['after']
for path,digest in last.items():
    assert hashfile(ROOT/path)==digest,(path,'current hash')
record('iteration_chain', ids=[r['id'] for r in changes], final_sha256=last)

with tempfile.TemporaryDirectory(prefix='g01-') as tmp:
    root=Path(tmp)
    source=root/'case.bin'
    source.write_bytes(b'abc')

    def ownership(module, call, failure, expected_closed):
        opened=[]
        real_open=os.open
        def tracked(*args,**kwargs):
            fd=real_open(*args,**kwargs);opened.append(fd);return fd
        class Stream:
            def __init__(self,fd):self.fd=fd
            def __enter__(self):
                if failure=='enter':raise RuntimeError('review-enter')
                return self
            def __exit__(self,*args):return False
            def fileno(self):return self.fd
            def read(self,*args):raise RuntimeError('review-read')
            def write(self,*args):raise RuntimeError('review-write')
        def construct(fd,*args,**kwargs):
            if failure=='construct':raise RuntimeError('review-construct')
            return Stream(fd)
        caught=None
        with patch.object(module.os,'open',tracked),patch.object(module.os,'fdopen',construct):
            try:call()
            except Exception as exc:caught=type(exc).__name__
        assert caught is not None,'failure not observed'
        closed=[]
        for fd in opened:
            try:os.fstat(fd)
            except OSError:closed.append(True)
            else:
                closed.append(False)
                os.close(fd)
        assert opened and all(c==expected_closed for c in closed),(failure,closed)
        return dict(failure=failure,caught=caught,closed=closed)

    for label,module,call in (
        ('R01',docs,lambda:docs.regular_bytes(root,'case.bin')),
        ('R02',docs,lambda:docs.atomic_write(root,'case.bin',b'new')),
        ('R03',observer,lambda:observer.read_bound(root,'case.bin'))):
        values=[ownership(module,call,failure,True) for failure in ('construct','enter','io')]
        assert source.read_bytes()==b'abc','failed write changed destination'
        record(label+'_ownership',cases=values)

    for label,module,call in (
        ('R01',old_docs,lambda:old_docs.regular_bytes(root,'case.bin')),
        ('R03',old_observer,lambda:old_observer.read_bound(root,'case.bin'))):
        values=[ownership(module,call,failure,False) for failure in ('construct','enter')]
        record(label+'_baseline_negative',cases=values)
    # Baseline atomic-write setup cleanup may itself fail on Windows while its
    # handle remains open. Either exception exposes the ownership defect.
    record('R02_baseline_negative',case=ownership(old_docs,lambda:old_docs.atomic_write(root,'case.bin',b'new'),'construct',False))

    class Connection:
        closed=False
        def execute(self,*args):raise RuntimeError('review-pragma')
        def close(self):self.closed=True
    for label,module,want in (('before',old_index,False),('after',knowledge_index,True)):
        con=Connection()
        with patch.object(module.sqlite3,'connect',return_value=con):
            try:module._connect(root/'cache.sqlite')
            except RuntimeError:pass
            else:raise AssertionError('setup did not fail')
        assert con.closed is want
        record('R04_'+label,connection_closed=con.closed)

    real_fdopen=os.fdopen
    def read_spy(behavior,requests):
        def construct(fd,*args,**kwargs):
            underlying=real_fdopen(fd,*args,**kwargs)
            class Proxy:
                first=True
                def __enter__(self):underlying.__enter__();return self
                def __exit__(self,*args):return underlying.__exit__(*args)
                def fileno(self):return underlying.fileno()
                def read(self,size=-1):
                    requests.append(size)
                    if behavior=='never':raise AssertionError('oversize source was read')
                    if behavior=='grow' and self.first:
                        self.first=False
                        with source.open('ab') as extra:extra.write(b'growth')
                    return underlying.read(size)
            return Proxy()
        return construct

    for label,module,call in (
        ('R01',docs,lambda:docs.regular_bytes(root,'case.bin',max_bytes=2)),
        ('R03',observer,lambda:observer.read_bound(root,'case.bin',max_bytes=2)),
        ('R05',docs,lambda:docs.regular_digest(root,'case.bin',max_bytes=2))):
        requests=[]
        with patch.object(module.os,'fdopen',read_spy('never',requests)):
            try:call()
            except ValueError:pass
            else:raise AssertionError('oversize accepted')
        assert requests==[]
        record(label+'_preallocation_refusal',read_requests=requests)

    for label,module,call in (
        ('R01',docs,lambda:docs.regular_bytes(root,'case.bin',max_bytes=3)),
        ('R03',observer,lambda:observer.read_bound(root,'case.bin',max_bytes=3)),
        ('R05',docs,lambda:docs.regular_digest(root,'case.bin',max_bytes=3))):
        source.write_bytes(b'abc');requests=[]
        with patch.object(module.os,'fdopen',read_spy('grow',requests)):
            try:call()
            except ValueError:pass
            else:raise AssertionError('post-stat growth accepted')
        record(label+'_growth_refusal',read_requests=requests)

    for size in (0,3,4*1024*1024):
        data=(bytes(range(256))*((size+255)//256))[:size]
        source.write_bytes(data)
        expected=hashlib.sha256(data).hexdigest();del data
        requests=[]
        with patch.object(docs.os,'fdopen',read_spy('normal',requests)):
            assert docs.regular_digest(root,'case.bin')==(expected,size)
        assert requests and min(requests)>0 and max(requests)<=65536
        current=artifact_index.build_artifact_index(root)
        assert current['files']['case.bin']['sha256']==expected
        assert current['files']['case.bin']['size']==size
        peaks=[]
        for repeat in range(3):
            pair={}
            for name,operation in (
                ('before',lambda:hashlib.sha256(old_docs.regular_bytes(root,'case.bin')).hexdigest()),
                ('after',lambda:docs.regular_digest(root,'case.bin')[0])):
                tracemalloc.start()
                result=operation()
                _,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
                assert result==expected
                pair[name]=peak
            peaks.append(pair)
        if size>=4*1024*1024:
            assert all(p['after']<p['before']/2 for p in peaks),'large fixture allocation gain absent'
        record('R05_exact_streaming',size=size,max_read_request=max(requests),peak_python_bytes=peaks)

environment=os.environ.copy()
environment.update(TEMP=str(OUT),TMP=str(OUT),PYTHONDONTWRITEBYTECODE='1')
command=[sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_reflect50_g01.py','-v']
run=subprocess.run(command,cwd=ROOT,env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'g01-replay.txt').write_bytes(run.stdout)
assert run.returncode==0,run.stdout.decode(errors='replace')
_,_,proof_after=_snapshot(ROOT,contract)
assert proof_before==proof_after,'producer binding changed during review'
output=dict(schema_version='reviewer-checks/v1',actor='/root/reflect50_review',
    command=command,environment=dict(python=sys.version,platform=platform.platform()),
    producer_proof=proof_before,checks=observations,replay_returncode=run.returncode,
    limitations=['Local synthetic CPU/file fixtures only; no latency, QA, model or total-token claim.',
                 'Allocation samples cover Python tracemalloc peak for named digest operation only.',
                 'Baseline archive contains 52 runtime modules; only four affected modules were consumed.'])
(OUT/'g01-checks.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status='checks-pass',observations=len(observations),replay_returncode=run.returncode)))

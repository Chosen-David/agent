"""Independent exact old/new canonical memory packet controls."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile,types,zipfile,gc,weakref
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));tempfile.tempdir=str(OUT)
from agent_runtime import project_memory as m
from agent_runtime.result_validation import _snapshot
c=json.loads((ROOT/'agent_doc/results/reflect50-20261021/g04/contract.json').read_bytes());_,_,proof=_snapshot(ROOT,c)
with zipfile.ZipFile(ROOT/'.agent-runs/reflect50-20261021/before-g04.zip') as z:
    assert z.namelist()==['agent_runtime/project_memory.py'];raw=z.read(z.namelist()[0]);last=hashlib.sha256(raw).hexdigest()
    old=types.ModuleType('agent_runtime._g04_old');old.__package__='agent_runtime';exec(compile(raw,'<before-g04>','exec'),old.__dict__)
for item in json.loads((ROOT/'agent_doc/results/reflect50-20261021/g04/changes.json').read_bytes()):
    v=item['changes']['agent_runtime/project_memory.py'];assert v['before']==last;last=v['after']
assert hashlib.sha256((ROOT/'agent_runtime/project_memory.py').read_bytes()).hexdigest()==last
class Store:
    root=OUT
    def list(self,*args):return [dict(id=str(i),content=('😀ß\"\n\r\t\u2028'+str(i))*17,metadata=[i,None,True,{'z':'尾'}]) for i in range(7)]
s=Store();observations=[];cases=0
for limit in (1,3,7):
    first=old.MemoryLedger.index(s,limit=limit)
    exact=len(old._index_json(first))+len(os.linesep)
    for budget in (256,700,exact-1,exact,exact+1,20000):
        for after in (None,'0','6'):
            kw=dict(limit=limit,max_chars=budget)
            if after is not None:kw.update(after_id=after,expected_snapshot=first['snapshot'])
            results=[]
            for mod in (old,m):
                try:results.append(('value',mod.MemoryLedger.index(s,**kw)))
                except ValueError as exc:results.append(('error',str(exc)))
            assert results[0]==results[1],(kw,results);cases+=1
observations.append(dict(name='old_new_exact_packets_and_errors',cases=cases))
for value in (None,True,0,1.5,-0.0,1e-200,[],{},'😀ß\n\"\u2028',{'z':'x'*200000,'a':[1,2.0,None]}):
    encoded=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    assert m._index_digest(value)==hashlib.sha256(encoded).hexdigest()
observations.append('canonical SHA literal json.dumps oracle: scalar, Unicode, float, list, dict and long text pass')
class Bad(Store):
    def list(self,*args):return [dict(id='a',content='valid'),dict(id='b',content='\ud800')]
try:m.MemoryLedger.index(Bad(),limit=1)
except m.MemoryError:pass
else:raise AssertionError('omitted invalid body not validated')
first=m.MemoryLedger.index(s,limit=1)
class Changed(Store):
    def list(self,*args):
        values=super().list(*args);values[-1]['content']+='changed';return values
try:m.MemoryLedger.index(Changed(),limit=1,after_id='0',expected_snapshot=first['snapshot'])
except m.MemoryError:pass
else:raise AssertionError('omitted body mutation failed to stale cursor')
observations.append('omitted malformed Unicode rejects and omitted-body mutation invalidates cursor')
refs=[];counts=[];content_hashes=[]
class Body(str):pass
class Owned(Store):
    def list(self,*args):
        values=[Body('owned-body-'+str(i)) for i in range(40)];refs.extend(weakref.ref(v) for v in values)
        return [dict(id=str(i),content=v) for i,v in enumerate(values)]
original_json=m._index_json;original_sha=m.hashlib.sha256
def observe_json(value):
    if isinstance(value,dict) and value.get('schema_version')=='memory-index/v1':
        gc.collect();counts.append(sum(r() is not None for r in refs))
    return original_json(value)
def observe_sha(value=b''):
    if value.startswith(b'owned-body-'):content_hashes.append(value)
    return original_sha(value)
with patch.object(m,'_index_json',observe_json),patch.object(m.hashlib,'sha256',observe_sha):packet=m.MemoryLedger.index(Owned(),limit=1)
assert counts and max(counts)<=1 and content_hashes==[b'owned-body-0']
observations.append(dict(name='separate_projection_and_retention',content_sha_calls=len(content_hashes),live_body_counts_during_wire=counts))
env=os.environ.copy();env.update(TEMP=str(OUT),TMP=str(OUT),PYTHONDONTWRITEBYTECODE='1')
run=subprocess.run([sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_reflect50_g04.py','-v'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'g04-replay.txt').write_bytes(run.stdout);assert run.returncode==0
assert _snapshot(ROOT,c)[2]==proof
(OUT/'g04-checks.json').write_text(json.dumps(dict(actor='/root/reflect50_review',producer_proof=proof,observations=observations,replay_exit_code=0,status='checks-pass'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('54 differential packet/error cases, canonical SHA, omitted errors/staleness and separate projection/retention pass; five tests replay pass')

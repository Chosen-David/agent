"""Independent full-JSON/native-registry/bounded-stream controls for G05."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile,types,zipfile
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));tempfile.tempdir=str(OUT)
from agent_runtime import result_store as r
from agent_runtime.result_validation import _snapshot
c=json.loads((ROOT/'agent_doc/results/reflect50-20261021/g05/contract.json').read_bytes());_,_,proof=_snapshot(ROOT,c)
with zipfile.ZipFile(ROOT/'.agent-runs/reflect50-20261021/before-g05.zip') as z:
    assert z.namelist()==['agent_runtime/result_store.py'];raw=z.read(z.namelist()[0]);last=hashlib.sha256(raw).hexdigest()
    old=types.ModuleType('agent_runtime._g05_old');old.__package__='agent_runtime';exec(compile(raw,'<before-g05>','exec'),old.__dict__)
for item in json.loads((ROOT/'agent_doc/results/reflect50-20261021/g05/changes.json').read_bytes()):
    v=item['changes']['agent_runtime/result_store.py'];assert v['before']==last;last=v['after']
assert hashlib.sha256((ROOT/'agent_runtime/result_store.py').read_bytes()).hexdigest()==last
observations=[];score_cases=0
for length in (0,1,65520,65528,65534,65535,65536,65537,131071):
    data={'first':'x'*length+'StraßeİΣς中文😀','array':['a','b',None,True,1.2], 'escape':'"\\\n\t'}
    hay=json.dumps(data,ensure_ascii=False).casefold()
    tokens=['strasse','sse','i\u0307σ','σσ中','中文😀','a", "b','\\n','"array": [','missing']
    assert r._lexical_score(data,tokens)==sum(t in hay for t in tokens);score_cases+=1
observations.append(dict(name='streaming_json_oracle',cases=score_cases,unicode_casefold_and_serializer_boundaries=True))
with tempfile.TemporaryDirectory(prefix='g05-') as tmp:
    root=Path(tmp);home=root/'agent_doc/results';home.mkdir(parents=True)
    for i in range(9):
        name=f'r{i}';p=home/name;p.mkdir()
        record=dict(schema_version=r.SCHEMA,run_id=name,origin='historical-external-reference',summary='word '+('word2' if i%2 else ''),registered_at='2026-10-21T00:00:00+00:00',context={},validation_at_registration={'status':'unknown'},result_id=None,producer_task_id=None)
        if i==3:record['registered_at']='0001-01-01T00:00:00+01:00'
        (p/'record.json').write_text(json.dumps(record),encoding='utf-8')
    before=old.ResultStore(root)
    try:before.search('word',limit=2)
    except OverflowError:pass
    else:raise AssertionError('baseline UTC overflow not reproduced')
    actual=r.ResultStore(root).search('word',limit=2)
    assert [h['run_id'] for h in actual['results']]==['r0','r1'] and actual['partial'] and actual['errors'][0]['run_id']=='r3'
    # Repair only fixture metadata so old/new native path has a fair complete oracle.
    p=home/'r3/record.json';record=json.loads(p.read_bytes());record['registered_at']='2026-10-21T00:00:00+00:00';p.write_text(json.dumps(record),encoding='utf-8')
    for query in ('word','word2','missing'):
        for limit in (1,2,20):assert old.ResultStore(root).search(query,limit=limit)==r.ResultStore(root).search(query,limit=limit)
    observations.append('UTC overflow isolates one actual registry record; native old/new search rank, errors and partial agree across nine query/limit cases')
    source=root/'tiny';source.write_bytes(b'abc');real=os.fdopen
    def spy(grow,requests):
        def make(fd,*args,**kw):
            stream=real(fd,*args,**kw)
            class Proxy:
                first=True
                def __getattr__(self,key):return getattr(stream,key)
                def __enter__(self):stream.__enter__();return self
                def __exit__(self,*args):return stream.__exit__(*args)
                def read(self,size=-1):
                    requests.append(size)
                    if grow and self.first:
                        self.first=False
                        with source.open('ab') as extra:extra.write(b'growth-growth')
                    return stream.read(size)
            return Proxy()
        return make
    for which in ('read','hash'):
        source.write_bytes(b'abc');requests=[]
        with patch.object(r.os,'fdopen',spy(False,requests)):
            if which=='read':assert r._read(root,'tiny')==b'abc'
            else:r._check_ref(root,{'path':'tiny','sha256':hashlib.sha256(b'abc').hexdigest()})
        assert requests and max(requests)<=4
        observations.append(dict(name='tiny_'+which,read_requests=requests))
        source.write_bytes(b'abc');requests=[]
        with patch.object(r.os,'fdopen',spy(True,requests)),patch.object(r,'ARTIFACT_LIMIT',8):
            try:
                if which=='read':r._read(root,'tiny',3)
                else:r._check_ref(root,{'path':'tiny','sha256':hashlib.sha256(b'abc').hexdigest()})
            except r.ResultStoreError:pass
            else:raise AssertionError('growth admitted')
        observations.append(dict(name='growth_'+which,refused=True,requests=requests))
env=os.environ.copy();env.update(TEMP=str(OUT),TMP=str(OUT),PYTHONDONTWRITEBYTECODE='1')
run=subprocess.run([sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_reflect50_g05.py','-v'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'g05-replay.txt').write_bytes(run.stdout);assert run.returncode==0
assert _snapshot(ROOT,c)[2]==proof
(OUT/'g05-checks.json').write_text(json.dumps(dict(actor='/root/reflect50_review',producer_proof=proof,observations=observations,replay_exit_code=0,status='checks-pass'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Native registry UTC/rank/partial, nine full-JSON boundary cases, tiny read/hash and growth controls pass; five tests replay pass')

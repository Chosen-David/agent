"""Independent literal physical-block reconstruction/paging/staleness checks."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile,zipfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));tempfile.tempdir=str(OUT)
from agent_runtime import markdown_context as m
from agent_runtime.result_validation import _snapshot
c=json.loads((ROOT/'agent_doc/results/reflect50-20261021/g09/contract.json').read_bytes());_,_,proof=_snapshot(ROOT,c)
with zipfile.ZipFile(ROOT/'.agent-runs/reflect50-20261021/before-g09.zip') as z:assert z.namelist()==[]
last={}
for item in json.loads((ROOT/'agent_doc/results/reflect50-20261021/g09/changes.json').read_bytes()):
    for path,version in item['changes'].items():assert version['before']==last.get(path);last[path]=version['after']
for path,digest in last.items():assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest
observations=[]
with tempfile.TemporaryDirectory(prefix='g09-') as tmp:
    root=Path(tmp)
    for newline in ('\n','\r\n','\r'):
        pieces=['preface'+newline,'# Parent'+newline+'head'+newline+'```'+newline+'## fake'+newline+'``` trailing'+newline+'## still fake'+newline+'```'+newline,'## Child'+newline+'尾\u2028# literal'+newline,'### Grandchild'+newline+'value'+newline]
        raw=''.join(pieces).encode();source=root/'doc.md';source.write_bytes(raw);ref={'path':'doc.md','sha256':hashlib.sha256(raw).hexdigest()}
        outline=m.outline(root,ref)
        assert [n['title'] for n in outline['nodes']]==['doc.md','Parent','Child','Grandchild']
        all_sections=m.read_sections(root,ref,['s3','s2','s1'])
        assert ''.join(n['text'] for n in all_sections['sections']).encode()==raw
        selected=m.read_sections(root,ref,['s2'],mandatory=['s1'])
        assert [n['node'] for n in selected['sections']]==['intro','s1','s2']
        assert selected['sections'][1]['text']==pieces[1] and selected['sections'][2]['text']==pieces[2]
        page=m.outline(root,ref,limit=1);ids=[n['node'] for n in page['nodes']]
        while page['partial']:
            page=m.outline(root,ref,limit=1,after_id=page['next_after_id'],expected_snapshot=page['snapshot']);ids += [n['node'] for n in page['nodes']]
        assert ids==['intro','s1','s2','s3']
        size=len(json.dumps(selected,ensure_ascii=False,separators=(',',':'),allow_nan=False))+len(os.linesep)
        assert m.read_sections(root,ref,['s2'],mandatory=['s1'],max_chars=size)==selected
        try:m.read_sections(root,ref,['s2'],mandatory=['s1'],max_chars=size-1)
        except ValueError:pass
        else:raise AssertionError('partial mandatory payload silently admitted')
        old_snapshot=outline['snapshot'];source.write_bytes(raw+b'changed');newref=dict(ref,sha256=hashlib.sha256(source.read_bytes()).hexdigest())
        for candidate,kw in ((ref,{}),(newref,dict(expected_snapshot=old_snapshot))):
            try:m.outline(root,candidate,**kw)
            except ValueError:pass
            else:raise AssertionError('stale source or cursor accepted')
        observations.append(dict(name='physical_blocks',newline=repr(newline),exact_reconstruction=True,malformed_closer_hidden_headings=True,mandatory_literal=True,pages=ids,exact_budget=size,stale_refused=True))
    # Actual public binary CLI under CP936 defaults still emits UTF-8, with a
    # byte-derived success budget and preserved JSON refusal/exit code.
    raw='前言\r\n# H\r\n正文😀\r\n'.encode();(root/'doc.md').write_bytes(raw);digest=hashlib.sha256(raw).hexdigest()
    base=[sys.executable,'-B',str(ROOT/'scripts/markdown_context.py'),'--root',str(root),'--path','doc.md','--sha256',digest]
    env=os.environ.copy();env.update(PYTHONUTF8='0',PYTHONIOENCODING='cp936',TEMP=str(OUT),TMP=str(OUT),PYTHONDONTWRITEBYTECODE='1')
    first=subprocess.run(base+['read','--section','s1'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert first.returncode==0
    wire=first.stdout.decode('utf-8');assert wire.endswith(os.linesep) and json.loads(wire)['sections'][1]['text']=='# H\r\n正文😀\r\n'
    exact=subprocess.run(base+['--max-chars',str(len(wire)),'read','--section','s1'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    refused=subprocess.run(base+['--max-chars',str(len(wire)-1),'read','--section','s1'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert exact.returncode==0 and refused.returncode==2 and json.loads(refused.stdout)['status']=='blocked'
    observations.append(dict(name='native_cli',cp936_defaults_utf8_output=True,native_newline=repr(os.linesep),exact_characters=len(wire),one_less_refused=True))
env=os.environ.copy();env.update(TEMP=str(OUT),TMP=str(OUT),PYTHONDONTWRITEBYTECODE='1')
run=subprocess.run([sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_reflect50_g09.py','-v'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'g09-replay.txt').write_bytes(run.stdout);assert run.returncode==0
assert _snapshot(ROOT,c)[2]==proof
(OUT/'g09-checks.json').write_text(json.dumps(dict(actor='/root/reflect50_review',producer_proof=proof,observations=observations,replay_exit_code=0,status='checks-pass'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('CR/LF/CRLF literal reconstruction, malformed fences, mandatory selection/paging/stale and CP936 actual UTF8 wire controls pass; five tests replay pass')

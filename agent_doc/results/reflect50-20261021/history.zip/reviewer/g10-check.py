"""Independent real-token CLI, compact immutable storage and metadata-only checks."""
from pathlib import Path
import builtins,hashlib,json,os,subprocess,sys,tempfile,zipfile
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'.agent-runs/memory-index96-deps')];tempfile.tempdir=str(OUT)
os.environ['TIKTOKEN_CACHE_DIR']=str(ROOT/'.agent-runs/memory-index96-token-cache')
from agent_runtime import markdown_context as m,validation_context as vc,result_store as rs,storage_inventory as si
from agent_runtime.handoff_basis import make_token_counter
from agent_runtime.result_validation import _snapshot
import tiktoken
c=json.loads((ROOT/'agent_doc/results/reflect50-20261021/g10/contract.json').read_bytes());_,_,proof=_snapshot(ROOT,c)
with zipfile.ZipFile(ROOT/'.agent-runs/reflect50-20261021/before-g10.zip') as z:expected={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
reconstructed=[]
for item in json.loads((ROOT/'agent_doc/results/reflect50-20261021/g10/changes.json').read_bytes()):
    for path,version in item['changes'].items():
        if version['before'] is not None and path not in expected:
            blob=subprocess.check_output(['git','show','27195c7d791f21d491097249ff1154fe6a55da24:'+path],cwd=ROOT)
            if hashlib.sha256(blob).hexdigest()==version['before']:mode='git-blob'
            else:
                blob=blob.replace(b'\n',b'\r\n');assert hashlib.sha256(blob).hexdigest()==version['before'];mode='git-blob-LF-to-CRLF'
            expected[path]=version['before'];reconstructed.append(dict(path=path,sha256=version['before'],method=mode))
        assert version['before']==expected.get(path);expected[path]=version['after']
for path,digest in expected.items():assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest
observations=[dict(name='missing_zip_before_sources_reconstructed',sources=reconstructed)]
env=os.environ.copy();env.update(PYTHONPATH=str(ROOT/'.agent-runs/memory-index96-deps'),TIKTOKEN_CACHE_DIR=os.environ['TIKTOKEN_CACHE_DIR'],TEMP=str(OUT),TMP=str(OUT),PYTHONDONTWRITEBYTECODE='1')
with tempfile.TemporaryDirectory(prefix='g10-') as tmp:
    root=Path(tmp);raw='# Required\r\n中文😀 <|endoftext|>\r\n# Selected\r\nbody\r\n'.encode();(root/'doc.md').write_bytes(raw)
    base=[sys.executable,'-X','utf8','-B',str(ROOT/'scripts/markdown_context.py'),'--root',str(root),'--path','doc.md','--sha256',hashlib.sha256(raw).hexdigest()]
    read=['read','--section','s2','--mandatory','s1']
    first=subprocess.run(base+read,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert first.returncode==0
    wire=first.stdout.decode('utf-8');counter=make_token_counter('o200k_base');count=counter(wire)
    assert wire.endswith(os.linesep)
    yes=subprocess.run(base+['--max-tokens',str(count),'--tokenizer','o200k_base']+read,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    no=subprocess.run(base+['--max-tokens',str(count-1),'--tokenizer','o200k_base']+read,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert yes.returncode==0 and counter(yes.stdout.decode('utf-8'))==count
    assert no.returncode==2 and json.loads(no.stdout)['status']=='blocked'
    observations.append(dict(name='real_token_binary_CLI',encoding='o200k_base',version=tiktoken.__version__,complete_success_output_tokens=count,native_newline=repr(os.linesep),exact_accept=True,one_less_refuse=True))
    result=dict(status='pending',scope='literal',errors=['kept 中文'],next_action='verify',proof={'artifact_hashes':{'x':'a'*64},'review_evidence':{},'other':[True,1,None]})
    pretty=vc.write_validation_context(root,result,'agent_doc/results/receipt')
    compact=vc.write_validation_context(root,result,'agent_doc/results/receipt',compact_storage=True)
    a=(root/pretty['record_ref']['path']).read_bytes();b=(root/compact['record_ref']['path']).read_bytes()
    assert json.loads(a)==json.loads(b) and len(b)<len(a) and pretty['record_ref']!=compact['record_ref']
    assert vc.restore_validation_context(root,compact['record_ref'])==result
    assert vc.write_validation_context(root,result,'agent_doc/results/receipt',compact_storage=True)['record_ref']==compact['record_ref']
    (root/compact['record_ref']['path']).write_bytes(b+b' ')
    try:vc.restore_validation_context(root,compact['record_ref'])
    except ValueError:pass
    else:raise AssertionError('changed receipt hash accepted')
    store=rs.ResultStore(root);ref=dict(path='doc.md',sha256=hashlib.sha256(raw).hexdigest())
    record=store.register_history('pretty','literal',[ref])['record'];new=dict(record,run_id='compact')
    saved=rs.ResultStore(root,compact_storage=True)._save(new);original=(root/saved['record_ref']['path']).read_bytes()
    assert rs.ResultStore(root).show('compact')['record']==new and json.loads(original)==new
    try:rs.ResultStore(root)._save(dict(new,summary='changed'))
    except rs.ResultStoreError:pass
    else:raise AssertionError('same record identity overwritten')
    assert (root/saved['record_ref']['path']).read_bytes()==original
    observations.append(dict(name='compact_semantics',receipt_pretty_bytes=len(a),receipt_compact_bytes=len(b),same_full_values=True,distinct_byte_identity=True,exact_restore=True,receipt_tamper_refused=True,registry_immutable=True))
with tempfile.TemporaryDirectory(prefix='g10-meta-') as tmp:
    root=Path(tmp)
    for path,size in (('.agent-memory/memory.sqlite3',3),('.agent-memory/memory.sqlite3-wal',5),('.agent-memory/memory.sqlite3-shm',7),('.cache/x',11),('note.md',13)):
        target=root/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b'x'*size)
    with patch.object(builtins,'open',side_effect=AssertionError('body open')),patch.object(os,'open',side_effect=AssertionError('body descriptor')):
        inventory=si.inventory(root,top=2)
    assert inventory['files']==5 and inventory['logical_bytes']==39 and inventory['groups']['private-memory']['logical_bytes']==15 and len(inventory['largest'])==2
    scan=os.scandir
    class Entry:
        def __init__(self,inner):self.inner=inner
        def __getattr__(self,key):return getattr(self.inner,key)
        def is_symlink(self):return self.inner.name=='note.md' or self.inner.is_symlink()
    class Scan:
        def __init__(self,path):self.inner=scan(path)
        def __enter__(self):return (Entry(e) for e in self.inner.__enter__())
        def __exit__(self,*args):return self.inner.__exit__(*args)
    with patch.object(os,'scandir',Scan):opaque=si.inventory(root)
    assert opaque['opaque_links']==1 and opaque['files']==4 and opaque['logical_bytes']==26
    for kwargs in (dict(max_entries=1),dict(max_directories=1),dict(top=True)):
        try:si.inventory(root,**kwargs)
        except ValueError:pass
        else:raise AssertionError('inventory bound admitted')
    observations.append(dict(name='metadata_only_inventory',no_python_or_os_open=True,logical_bytes=39,private_memory_SQLite_WAL_SHM_bytes=15,mocked_opaque_link_excluded=True,entry_directory_type_bounds_refused=True))
sync=subprocess.run([sys.executable,'-X','utf8','-B',str(ROOT/'scripts/sync_plugin_references.py'),'--check'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'g10-sync.txt').write_bytes(sync.stdout);assert sync.returncode==0
run=subprocess.run([sys.executable,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_reflect50_g10.py','-v'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'g10-replay.txt').write_bytes(run.stdout);assert run.returncode==0 and b'skipped=' not in run.stdout
assert _snapshot(ROOT,c)[2]==proof
(OUT/'g10-checks.json').write_text(json.dumps(dict(actor='/root/reflect50_review',producer_proof=proof,observations=observations,generated_reference_check_exit=sync.returncode,replay_exit_code=0,status='checks-pass'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Real tokenizer binary CLI, compact restore/immutability, zero-body inventory and generated sync pass; five tests replay without skips')

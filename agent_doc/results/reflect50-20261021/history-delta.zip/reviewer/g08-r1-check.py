"""Narrow independent R39 runtime LIMIT/default-diagnostic compatibility gate."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));tempfile.tempdir=str(OUT)
from agent_runtime import result_validation as v
c=json.loads((ROOT/'agent_doc/results/reflect50-20261021/g08-r1/contract.json').read_bytes());_,_,proof=v._snapshot(ROOT,c)
with tempfile.TemporaryDirectory(prefix='g08-r1-') as tmp:
    root=Path(tmp);path=root/'a';path.write_bytes(b'abc');ref=dict(path='a',sha256=hashlib.sha256(b'abc').hexdigest())
    with patch.object(v,'LIMIT',3):
        assert v._bytes(root,'a')==b'abc' and v._bound(root,ref)==b'abc'
        try:v._bytes(root,'a',max_bytes=2)
        except v.ResultValidationError as exc:assert '2 byte bound' in str(exc)
        else:raise AssertionError('explicit bound admitted')
        path.write_bytes(b'abcd')
        try:v._bytes(root,'a')
        except v.ResultValidationError as exc:assert 'exceeds 16 MiB' in str(exc)
        else:raise AssertionError('dynamic default bound not enforced')
env=os.environ.copy();env.update(TEMP=str(OUT),TMP=str(OUT),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
run=subprocess.run([sys.executable,'-X','utf8','-B','-m','unittest','tests.test_reflect50_g08','tests.test_result_read_allocation','-v'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'g08-r1-replay.txt').write_bytes(run.stdout);assert run.returncode==0
assert v._snapshot(ROOT,c)[2]==proof
old=json.loads((ROOT/'agent_doc/results/reflect50-20261021/reflect50-final-20261021-v1/contract.json').read_bytes())
stale=v.inspect_result(ROOT,old)
assert stale['status']=='invalid'
(OUT/'final-v1-stale-inspect.json').write_text(json.dumps(stale,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')
(OUT/'g08-r1-checks.json').write_text(json.dumps(dict(actor='/root/reflect50_review',producer_proof=proof,observations=dict(runtime_LIMIT_rebound=True,bound_wrapper_rebound=True,explicit_bound_diagnostic=True,default_diagnostic_preserved=True),replay_exit_code=0,old_final_status=stale['status'],status='checks-pass'),ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')
print('Dynamic LIMIT/default diagnostic/explicit lower bound independently pass; nine tests replay; final-v1 invalid/stale')

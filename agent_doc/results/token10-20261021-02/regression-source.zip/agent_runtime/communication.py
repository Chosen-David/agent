"""Opt-in, local durable communication for trusted host adapters.

Routes are consumer-owned, immutable per run. This is an at-least-once inbox,
not an agent launcher, authentication boundary or semantic acceptance engine.
"""
from __future__ import annotations

import argparse
import hashlib
from contextlib import contextmanager
import json
from pathlib import Path
import sqlite3
import re

from scripts.validate_handoff import _consumer_contract, _load_json, validate
from .context_serialization import render_context
from .project_docs import guard_write_path


KINDS = {'artifact', 'question', 'review', 'blocker', 'correction'}


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False,
                      separators=(',', ':'))


def nonblank(value):
    return isinstance(value, str) and bool(value.strip())


def check_plan(plan):
    if not isinstance(plan, dict) or type(plan.get('schema_version')) is not int or plan['schema_version'] != 1:
        raise ValueError('unsupported communication plan')
    if any(not nonblank(plan.get(k)) for k in ('run_id', 'input_version')):
        raise ValueError('run_id and input_version required')
    routes = plan.get('routes')
    if not isinstance(routes, list) or not routes:
        raise ValueError('explicit consumer-owned routes required')
    seen = set()
    for route in routes:
        if not isinstance(route, dict) or any(not nonblank(route.get(k)) for k in ('sender', 'recipient', 'task_id', 'kind')):
            raise ValueError('route needs sender, recipient, task_id and kind')
        key = tuple(route[k] for k in ('sender', 'recipient', 'task_id', 'kind'))
        if route['kind'] not in KINDS or route['sender'] == route['recipient'] or key in seen:
            raise ValueError('invalid, self or duplicate route')
        seen.add(key)
    for key, default in (('max_message_bytes', 8192), ('max_events', 1000)):
        value = plan.get(key, default)
        if type(value) is not int or value < 1:
            raise ValueError(f'{key} must be a positive integer')
    if 'max_delivery_bytes' in plan:
        value = plan['max_delivery_bytes']
        if type(value) is not int or value < 1:
            raise ValueError('max_delivery_bytes must be a positive integer')


def prepare_event(plan, artifact_root, event):
    """Validate a publish envelope without opening or creating the mailbox."""
    check_plan(plan)
    if not isinstance(event, dict):
        raise ValueError('event must be an object')
    required = {'event_id', 'run_id', 'input_version', 'sender', 'task_id',
                'kind', 'summary', 'action', 'refs'}
    if set(event) != required or any(not nonblank(event.get(k)) for k in required - {'refs'}):
        raise ValueError('event needs exact envelope fields and a concrete action')
    if event['run_id'] != plan['run_id'] or event['input_version'] != plan['input_version']:
        raise ValueError('stale or cross-run event')
    recipients = sorted({r['recipient'] for r in plan['routes']
                         if all(r[k] == event[k] for k in ('sender', 'task_id', 'kind'))})
    if not recipients:
        raise ValueError('no approved consumer route')
    body = canonical(event)
    if len(body.encode('utf-8')) > plan.get('max_message_bytes', 8192):
        raise ValueError('message budget exceeded: put detail in referenced artifacts')
    refs = event['refs']
    if not isinstance(refs, list) or not refs:
        raise ValueError('reference the artifact, question, review or blocker record')
    errors = validate({'schema_version': 1, 'run_id': plan['run_id'],
                       'role': event['sender'], 'input_version': event['input_version'],
                       'status': 'partial', 'limitations': ['communication, not completion'],
                       'artifacts': refs, 'checks': [], 'tasks': []}, Path(artifact_root))
    if errors:
        raise ValueError('; '.join(errors))
    return body, recipients


def validate_receipt(plan, receipt):
    """Return a canonical receipt only after its complete wire contract passes."""
    check_plan(plan)
    if not isinstance(receipt, dict) or set(receipt) != {'status', 'reason'}:
        raise ValueError('receipt needs status and reason')
    if receipt['status'] not in ('consumed', 'rejected', 'needs_revision') or not nonblank(receipt['reason']):
        raise ValueError('invalid receipt')
    body = canonical(receipt)
    if len(body.encode('utf-8')) > plan.get('max_message_bytes', 8192):
        raise ValueError('receipt budget exceeded')
    return body


def validate_consumer_request(request):
    """Validate the independent consumer scope before mailbox persistence."""
    _version, _tasks, errors = _consumer_contract(request)
    if errors:
        raise ValueError('; '.join(errors))


def validate_known_context(known):
    """Validate cache hints structurally; they never authorize skipped checks."""
    if not isinstance(known, dict) or not set(known) <= {'knowledge_refs', 'memory_refs'}:
        raise ValueError('known context must contain only knowledge_refs and memory_refs')
    knowledge = known.get('knowledge_refs', [])
    memory = known.get('memory_refs', [])
    if not isinstance(knowledge, list):
        raise ValueError('known knowledge_refs must be a list')
    seen = set()
    for ref in knowledge:
        if (not isinstance(ref, dict) or set(ref) != {'id', 'version', 'sha256'}
                or not nonblank(ref.get('id')) or ref['id'] in seen
                or type(ref.get('version')) is not int or ref['version'] < 1
                or not isinstance(ref.get('sha256'), str)
                or re.fullmatch('[0-9a-f]{64}', ref['sha256']) is None):
            raise ValueError('known knowledge_refs contain an invalid pinned reference')
        seen.add(ref['id'])
    if (not isinstance(memory, list)
            or any(not isinstance(value, str)
                   or re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:-]*', value) is None
                   for value in memory)
            or len(set(memory)) != len(memory)):
        raise ValueError('known memory_refs must contain unique stable IDs')


class Mailbox:
    def __init__(self, db_path, plan, artifact_root):
        check_plan(plan)
        # Freeze caller data as well as the persisted plan.
        self.plan = json.loads(canonical(plan))
        self.run_id = self.plan['run_id']
        self.root = Path(artifact_root).resolve()
        self.path = guard_write_path(db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS communication_plans (
                    run_id TEXT PRIMARY KEY, body TEXT NOT NULL, root TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS communication_events (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL,
                    event_id TEXT NOT NULL, body TEXT NOT NULL,
                    UNIQUE(run_id,event_id));
                CREATE TABLE IF NOT EXISTS communication_deliveries (
                    seq INTEGER NOT NULL, recipient TEXT NOT NULL, receipt TEXT,
                    PRIMARY KEY(seq,recipient));
                CREATE TABLE IF NOT EXISTS communication_basis (
                    seq INTEGER NOT NULL, recipient TEXT NOT NULL,
                    record TEXT NOT NULL, request TEXT NOT NULL,
                    PRIMARY KEY(seq,recipient));
                CREATE INDEX IF NOT EXISTS communication_pending_recipient
                    ON communication_deliveries(recipient,seq)
                    WHERE receipt IS NULL;
            ''')
            db.execute('BEGIN IMMEDIATE')
            db.execute('INSERT OR IGNORE INTO communication_plans VALUES (?,?,?)',
                       (self.run_id, canonical(self.plan), str(self.root)))
            row = db.execute('SELECT body,root FROM communication_plans WHERE run_id=?', (self.run_id,)).fetchone()
            if tuple(row) != (canonical(self.plan), str(self.root)):
                raise ValueError('plan/root changed: create a new run and reconcile outstanding messages')
            self._init_usage(db)
            db.execute('INSERT OR IGNORE INTO communication_usage_v1 VALUES (?,0,0,0,0)',
                       (self.run_id,))

    @staticmethod
    def _init_usage(db):
        """Backfill once under the caller's IMMEDIATE transaction.

        The table is the migration marker: creation, backfill and triggers commit
        together. Do not use executescript here (it commits pending transactions).
        Triggers also account for append-only writes by older Mailbox processes.
        Direct SQL edits/deletes/replaces of historical events are unsupported.
        """
        if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='communication_usage_v1'").fetchone():
            return
        db.execute('''CREATE TABLE communication_usage_v1 (
            run_id TEXT PRIMARY KEY, events INTEGER NOT NULL,
            envelope_bytes INTEGER NOT NULL, deliveries INTEGER NOT NULL,
            delivery_bytes INTEGER NOT NULL)''')
        db.execute('''INSERT INTO communication_usage_v1
            SELECT run_id,COUNT(*),SUM(length(CAST(body AS BLOB))),0,0
            FROM communication_events GROUP BY run_id''')
        db.execute('''UPDATE communication_usage_v1 SET
            deliveries=(SELECT COUNT(*) FROM communication_events e
                JOIN communication_deliveries d ON e.seq=d.seq
                WHERE e.run_id=communication_usage_v1.run_id),
            delivery_bytes=(SELECT COALESCE(SUM(length(CAST(e.body AS BLOB))),0)
                FROM communication_events e JOIN communication_deliveries d ON e.seq=d.seq
                WHERE e.run_id=communication_usage_v1.run_id)''')
        db.execute('''CREATE TRIGGER communication_usage_event_v1
            AFTER INSERT ON communication_events BEGIN
                INSERT INTO communication_usage_v1 VALUES (
                    NEW.run_id,1,length(CAST(NEW.body AS BLOB)),0,0)
                ON CONFLICT(run_id) DO UPDATE SET
                    events=events+1,
                    envelope_bytes=envelope_bytes+length(CAST(NEW.body AS BLOB));
            END''')
        db.execute('''CREATE TRIGGER communication_usage_delivery_v1
            AFTER INSERT ON communication_deliveries BEGIN
                UPDATE communication_usage_v1 SET deliveries=deliveries+1,
                    delivery_bytes=delivery_bytes+(
                        SELECT length(CAST(body AS BLOB)) FROM communication_events WHERE seq=NEW.seq)
                WHERE run_id=(SELECT run_id FROM communication_events WHERE seq=NEW.seq);
            END''')

    @contextmanager
    def connect(self):
        guard_write_path(self.path)
        db = sqlite3.connect(self.path, timeout=30)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    def _prepare_publish(self, event):
        return prepare_event(self.plan, self.root, event)

    def _store_publish(self, db, event, body, recipients):
        old = db.execute('SELECT seq,body FROM communication_events WHERE run_id=? AND event_id=?',
                         (self.run_id, event['event_id'])).fetchone()
        if old:
            if old['body'] != body:
                raise ValueError('event_id reused with different content')
            return {'seq': old['seq'], 'recipients': recipients, 'duplicate': True}
        usage = db.execute('SELECT events,delivery_bytes FROM communication_usage_v1 WHERE run_id=?',
                           (self.run_id,)).fetchone()
        if usage['events'] >= self.plan.get('max_events', 1000):
            raise ValueError('run event budget exhausted; reconcile before extending the plan')
        if 'max_delivery_bytes' in self.plan:
            spent = usage['delivery_bytes']
            if spent + len(body.encode('utf-8')) * len(recipients) > self.plan['max_delivery_bytes']:
                raise ValueError('run delivery byte budget exhausted; no partial fan-out')
        seq = db.execute('INSERT INTO communication_events(run_id,event_id,body) VALUES (?,?,?)',
                         (self.run_id, event['event_id'], body)).lastrowid
        db.executemany('INSERT INTO communication_deliveries(seq,recipient) VALUES (?,?)',
                       [(seq, recipient) for recipient in recipients])
        return {'seq': seq, 'recipients': recipients, 'duplicate': False}

    def publish(self, event):
        body, recipients = self._prepare_publish(event)
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            return self._store_publish(db, event, body, recipients)

    def publish_many(self, events):
        """Publish 1..100 envelopes atomically, preserving input order.

        Every envelope, including a duplicate, gets the ordinary publish checks.
        Any error rolls back this batch's new events, fan-out and usage counters.
        The host opts into one bounded transaction; no connection is retained.
        """
        if not isinstance(events, list) or not 1 <= len(events) <= 100:
            raise ValueError('batch must be a list of 1..100 events')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            result = []
            for event in events:
                body, recipients = self._prepare_publish(event)
                result.append(self._store_publish(db, event, body, recipients))
            return result

    def inbox(self, recipient, *, limit=20, task_id=None, after_seq=0):
        """Read pending deliveries, optionally for one host-selected routed task.

        Task selection never filters kinds or acknowledges other deliveries.
        It is not a global-clearance check: the coordinator still reads the
        unscoped inbox for cross-task dependencies and outstanding issues.
        after_seq is navigation within this run/recipient/task, never an ACK.
        Pages are separate snapshots; poll again for newly appended corrections.
        """
        if type(after_seq) is not int or not 0 <= after_seq <= 2**63-1:
            raise ValueError('after_seq must be a nonnegative SQLite sequence')
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError('limit must be 1..100')
        if recipient not in {r['recipient'] for r in self.plan['routes']}:
            raise ValueError('unknown recipient')
        if task_id is not None and (not nonblank(task_id) or task_id not in {
                r['task_id'] for r in self.plan['routes'] if r['recipient'] == recipient}):
            raise ValueError('task_id must be an explicitly routed task for this recipient')
        # Filter before LIMIT, preserving order even after an unrelated backlog.
        scope_sql = " AND json_extract(e.body, '$.task_id')=?" if task_id is not None else ''
        params = (self.run_id, recipient, after_seq) + ((task_id,) if task_id is not None else ()) + (limit,)
        with self.connect() as db:
            # Exact ledger and inbox query share one read snapshot.
            db.execute('BEGIN')
            count = db.execute('SELECT events FROM communication_usage_v1 WHERE run_id=?',
                               (self.run_id,)).fetchone()['events']
            if count == 0:
                return []
            if count <= limit:
                rows = db.execute('''SELECT e.seq,e.body FROM communication_events e
                    WHERE e.run_id=? AND EXISTS (SELECT 1 FROM communication_deliveries d
                        WHERE d.seq=e.seq AND d.recipient=? AND d.receipt IS NULL) AND e.seq>?
                    ''' + scope_sql + ' ORDER BY e.seq LIMIT ?', params).fetchall()
                return [{'seq': r['seq'], 'event': json.loads(r['body'])} for r in rows]
            rows = db.execute('''SELECT e.seq,e.body FROM communication_events e
                JOIN communication_deliveries d ON e.seq=d.seq
                WHERE e.run_id=? AND d.recipient=? AND d.receipt IS NULL AND d.seq>?
                ''' + scope_sql + ' ORDER BY d.seq LIMIT ?', params).fetchall()
        return [{'seq': r['seq'], 'event': json.loads(r['body'])} for r in rows]

    def inbox_index(self, recipient, *, limit=20, task_id=None, max_chars=20000, after_seq=0):
        """Navigation only, from one pending-inbox snapshot; never auto ACK.

        Body versions permit read_pending() before semantic decisions. All kinds
        remain visible. has_more describes this selected page, not global closure.
        """
        if type(limit) is not int or not 1 <= limit <= 99:
            raise ValueError('index limit must be 1..99 (one lookahead required)')
        if type(max_chars) is not int or not 1 <= max_chars <= 1000000:
            raise ValueError('invalid index display budget')
        deliveries = self.inbox(recipient, limit=limit + 1, task_id=task_id, after_seq=after_seq)
        items = []
        for delivery in deliveries[:limit]:
            event = delivery['event']
            items.append({'seq': delivery['seq'], 'sender': event['sender'],
                          'task_id': event['task_id'], 'kind': event['kind'],
                          'body_sha256': hashlib.sha256(canonical(event).encode()).hexdigest()})
        result = {'schema_version': 'mailbox-index/v1', 'project_root': str(self.root.resolve()),
                  'run_id': self.run_id, 'input_version': self.plan['input_version'],
                  'recipient': recipient, 'task_id': task_id, 'has_more': len(deliveries) > limit,
                  'after_seq': after_seq, 'next_after_seq': items[-1]['seq'] if items else after_seq,
                  'items': items, 'scope': 'pending page navigation only; read exact bodies before decisions; no ACK or global clearance'}
        if len(canonical(result)) > max_chars:
            raise ValueError('index exceeds budget; request a smaller explicit page')
        return result

    def read_pending(self, recipient, seq, body_sha256):
        """Retrieve one version-bound currently pending routed delivery."""
        if (type(seq) is not int or seq <= 0 or type(body_sha256) is not str
                or re.fullmatch('[0-9a-f]{64}', body_sha256) is None):
            raise ValueError('positive seq and exact body SHA256 required')
        if recipient not in {r['recipient'] for r in self.plan['routes']}:
            raise ValueError('unknown recipient')
        with self.connect() as db:
            row = db.execute('''SELECT e.body FROM communication_events e
                JOIN communication_deliveries d ON e.seq=d.seq
                WHERE e.run_id=? AND d.recipient=? AND e.seq=? AND d.receipt IS NULL''',
                (self.run_id, recipient, seq)).fetchone()
        if row is None:
            raise ValueError('delivery missing or already handled; refresh pending index')
        event = json.loads(row['body'])
        if hashlib.sha256(canonical(event).encode()).hexdigest() != body_sha256:
            raise ValueError('body version changed')
        return {'seq': seq, 'event': event}

    def acknowledge(self, recipient, seq, receipt):
        # Receipt records handling, never task completion or scientific validity.
        if type(seq) is not int or seq <= 0:
            raise ValueError('receipt needs a positive sequence')
        body = validate_receipt(self.plan, receipt)
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('''SELECT d.receipt FROM communication_deliveries d
                JOIN communication_events e ON e.seq=d.seq
                WHERE e.run_id=? AND d.seq=? AND d.recipient=?''', (self.run_id, seq, recipient)).fetchone()
            if row is None:
                raise ValueError('delivery not found in this run')
            if row['receipt'] is not None and row['receipt'] != body:
                raise ValueError('receipt is immutable; publish a correction event')
            db.execute('UPDATE communication_deliveries SET receipt=? WHERE seq=? AND recipient=?',
                       (body, seq, recipient))

    def status(self):
        with self.connect() as db:
            rows = db.execute('''SELECT e.seq,d.recipient,d.receipt FROM communication_events e
                JOIN communication_deliveries d ON e.seq=d.seq WHERE e.run_id=?
                ORDER BY e.seq,d.recipient''', (self.run_id,)).fetchall()
        return [{'seq': r['seq'], 'recipient': r['recipient'],
                 'receipt': json.loads(r['receipt']) if r['receipt'] else None} for r in rows]

    def consume_handoff(self, recipient, seq, request, *, require_complete=True):
        """Re-read immutable references and validate against trusted consumer scope.

        Returns data without ACK: the host must separately read/verify semantics,
        perform an idempotent action, then acknowledge. A failed check stays pending.
        """
        validate_consumer_request(request)
        with self.connect() as db:
            row = db.execute('''SELECT e.body FROM communication_events e
                JOIN communication_deliveries d ON e.seq=d.seq
                WHERE e.run_id=? AND e.seq=? AND d.recipient=?''', (self.run_id, seq, recipient)).fetchone()
        if row is None:
            raise ValueError('delivery not found in this run')
        event = json.loads(row['body'])
        refs = event['refs']
        manifests = [r for r in refs if r['id'] == 'handoff']
        if len(manifests) != 1:
            raise ValueError('handoff reference required')
        ref = manifests[0]
        # Recheck all original references at consumption, including the manifest.
        errors = validate({'schema_version': 1, 'run_id': self.run_id,
                           'role': event['sender'], 'input_version': event['input_version'],
                           'status': 'partial', 'limitations': ['pending consumption'],
                           'artifacts': refs, 'checks': [], 'tasks': []}, self.root)
        if errors:
            raise ValueError('; '.join(errors))
        # Bind the parsed snapshot, not an earlier read of the same pathname.
        record = _load_json(self.root / ref['path'], expected_sha256=ref['sha256'])
        errors = validate(record, self.root, require_complete,
                          expected_input_version=self.plan['input_version'], consumer_request=request)
        if isinstance(record, dict) and (record.get('run_id') != self.run_id or record.get('role') != event['sender']):
            errors.append('handoff producer/run mismatch')
        if errors:
            raise ValueError('; '.join(errors))
        from .handoff_basis import check_handoff_basis
        check_handoff_basis(self.root, record, request)
        # Identity/dependency records only, never private memory contents or CoT.
        # An ACK remains independent. Keep the original consumer binding immutable.
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            stored = db.execute('SELECT record,request FROM communication_basis WHERE seq=? AND recipient=?',
                                (seq, recipient)).fetchone()
            value = (canonical(record), canonical(request))
            if stored is not None and tuple(stored) != value:
                raise ValueError('consumed basis/request changed: use a new event or run')
            db.execute('INSERT OR IGNORE INTO communication_basis VALUES (?,?,?,?)',
                       (seq, recipient, *value))
        return record

    def impact(self):
        """Return stale consumed evidence and actual affected recipients; no auto-ACK."""
        from .handoff_basis import basis_impact
        with self.connect() as db:
            rows = db.execute('''SELECT b.*,e.event_id,e.body FROM communication_basis b
                JOIN communication_events e ON b.seq=e.seq WHERE e.run_id=? ORDER BY b.seq,b.recipient''',
                              (self.run_id,)).fetchall()
        result = []
        for row in rows:
            record = json.loads(row['record'])
            impact = basis_impact(self.root, record, json.loads(row['request']))
            event = json.loads(row['body'])
            errors = validate({'schema_version': 1, 'run_id': self.run_id, 'role': event['sender'],
                               'input_version': event['input_version'], 'status': 'partial',
                               'limitations': ['basis audit'], 'artifacts': event['refs'],
                               'tasks': [], 'checks': []}, self.root)
            if errors:
                impact['stale'] = True
                impact['claim_ids'] = sorted(c['id'] for c in record.get('evidence_claims', []))
                impact['reasons'].extend(errors)
                impact['scope'] = 'shared envelope/manifest provenance changed; whole handoff affected'
            if impact['stale']:
                result.append({'seq': row['seq'], 'event_id': row['event_id'],
                               'recipient': row['recipient'], 'usage_stage': 'validated_handoff', **impact})
        return result

    def prepare_context(self, recipient, seq, request, **budget_and_cache):
        """Validate delivery, then build a budgeted evidence payload for the host."""
        from .handoff_basis import basis_context
        record = self.consume_handoff(recipient, seq, request)
        return basis_context(self.root, record, request, **budget_and_cache)

    def usage(self):
        """Exact envelope bytes including fan-out; deliberately no token estimate."""
        with self.connect() as db:
            row = db.execute('SELECT events,envelope_bytes,deliveries,delivery_bytes FROM communication_usage_v1 WHERE run_id=?',
                             (self.run_id,)).fetchone()
        return {'events': row['events'], 'envelope_bytes': row['envelope_bytes'],
                'deliveries': row['deliveries'], 'delivery_bytes': row['delivery_bytes'], 'tokens': None,
                'scope': 'stored envelopes only; excludes artifacts, model input/output and reasoning'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', required=True)
    parser.add_argument('--compact', action='store_true', help='preserve all JSON fields without formatting whitespace')
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--root', type=Path, required=True)
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('status')
    sub.add_parser('impact')
    sub.add_parser('usage')
    p = sub.add_parser('publish'); p.add_argument('event', type=Path)
    p = sub.add_parser('publish-many'); p.add_argument('events', type=Path)
    p = sub.add_parser('inbox'); p.add_argument('recipient'); p.add_argument('--limit', type=int, default=20)
    p.add_argument('--task-id', help='host-selected routed task; not global pending clearance')
    p.add_argument('--after-seq', type=int, default=0, help='continue after this sequence; not ACK or clearance')
    p = sub.add_parser('inbox-index'); p.add_argument('recipient'); p.add_argument('--limit', type=int, default=20)
    p.add_argument('--task-id'); p.add_argument('--max-chars', type=int, default=20000)
    p.add_argument('--after-seq', type=int, default=0, help='scope-bound pending-page cursor')
    p = sub.add_parser('read-pending'); p.add_argument('recipient'); p.add_argument('seq', type=int)
    p.add_argument('--body-sha256', required=True)
    p = sub.add_parser('ack'); p.add_argument('recipient'); p.add_argument('seq', type=int); p.add_argument('receipt', type=Path)
    p = sub.add_parser('consume'); p.add_argument('recipient'); p.add_argument('seq', type=int); p.add_argument('--request', type=Path, required=True)
    p = sub.add_parser('context'); p.add_argument('recipient'); p.add_argument('seq', type=int)
    p.add_argument('--request', type=Path, required=True); p.add_argument('--max-chars', type=int, default=20000)
    p.add_argument('--known', type=Path, help='trusted current-context refs; not producer input')
    p.add_argument('--encoding', help='explicit optional tiktoken encoding; no model inference')
    p.add_argument('--max-tokens', type=int)
    args = parser.parse_args()
    try:
        plan = _load_json(args.plan)
        check_plan(plan)
        payload = None
        known = None
        if args.command == 'publish':
            payload = _load_json(args.event)
            prepare_event(plan, args.root, payload)
        elif args.command == 'publish-many':
            payload = _load_json(args.events)
            if (not isinstance(payload, list) or not 1 <= len(payload) <= 100
                    or any(not isinstance(event, dict) for event in payload)):
                raise ValueError('batch must be a list of 1..100 event objects')
            for event in payload:
                prepare_event(plan, args.root, event)
        elif args.command == 'ack':
            payload = _load_json(args.receipt)
            if args.recipient not in {r['recipient'] for r in plan['routes']} or args.seq <= 0:
                raise ValueError('ack requires a routed recipient and positive sequence')
            validate_receipt(plan, payload)
        elif args.command in ('consume', 'context'):
            payload = _load_json(args.request)
            if args.recipient not in {r['recipient'] for r in plan['routes']} or args.seq <= 0:
                raise ValueError('consume requires a routed recipient and positive sequence')
            validate_consumer_request(payload)
            if args.command == 'context':
                known = _load_json(args.known) if args.known else {}
                validate_known_context(known)
        box = Mailbox(args.db, plan, args.root)
        if args.command == 'inbox-index':
            result = box.inbox_index(args.recipient, limit=args.limit, task_id=args.task_id, max_chars=args.max_chars, after_seq=args.after_seq)
        elif args.command == 'read-pending':
            result = box.read_pending(args.recipient, args.seq, args.body_sha256)
        elif args.command == 'publish':
            result = box.publish(payload)
        elif args.command == 'publish-many':
            result = box.publish_many(payload)
        elif args.command == 'inbox':
            result = box.inbox(args.recipient, limit=args.limit, task_id=args.task_id, after_seq=args.after_seq)
        elif args.command == 'ack':
            box.acknowledge(args.recipient, args.seq, payload); result = {'acknowledged': True}
        elif args.command == 'consume':
            result = box.consume_handoff(args.recipient, args.seq, payload)
        elif args.command == 'context':
            from .handoff_basis import make_token_counter
            result = box.prepare_context(args.recipient, args.seq, payload,
                                         max_chars=args.max_chars,
                                         max_tokens=args.max_tokens,
                                         token_counter=make_token_counter(args.encoding) if args.encoding else None,
                                         known_knowledge_refs=known.get('knowledge_refs', []),
                                         known_memory_ids=known.get('memory_refs', []))
        elif args.command == 'impact':
            result = box.impact()
        elif args.command == 'usage':
            result = box.usage()
        else:
            result = box.status()
    except (ValueError, OSError, sqlite3.Error) as exc:
        print(json.dumps({'error': str(exc)}, ensure_ascii=False)); return 1
    print((render_context(result, compact=True) if args.compact else json.dumps(result, ensure_ascii=False, indent=2))); return 0


if __name__ == '__main__':
    raise SystemExit(main())

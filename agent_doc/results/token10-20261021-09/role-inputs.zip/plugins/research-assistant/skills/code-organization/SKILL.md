---
name: code-organization
description: "管理项目文件并组织代码仓库。用于文件散落、跨 Agent 产物交接、输出目录规划、任务登记、CODEMAP维护，以及AI文档精简和AGENTS.md/CLAUDE.md整理。以项目 agent_doc/task/TASK.md 为唯一任务入口，协助主 AI 协调生产者与消费者，核对引用/版本/数据归属；保护运行中路径，不自动删除文件。"
---

# 文件管理与代码组织

整理AI文档、AGENTS.md或CLAUDE.md时，按需执行 [精简检查](references/concise_engineering.md)：单源规则、有效路径、明确作用域，不改历史证据或人类指南。

读取 [组织流程](references/workflow.md) 与 [执行与验收](references/execution.md)。沿用 `code-organization` 角色名，兼容既有调用；同时承担文件管理 Agent 职责。

先定位当前项目根目录，读取 `agent_doc/task/TASK.md`、已有 `CODEMAP.md` 和运行状态。主 AI 负责总清单唯一写入及调度；接收其他 Agent 的 task_refs、输出目录、产物清单和消费者信息。各 Agent 不另建总 agent_doc/task/TASK.md，不并发抢写同一文件。

在新任务开始前建议目录/命名和单一作者；交接/每项完成后登记产物、来源、数据类型、哈希和消费者；最终增量核对 CODEMAP、必要目录说明及待整理清单。默认遵循既有布局，新项目按源码/数据/结果/图表/报告/私有运行状态分开存放。

区分“计划生成”“实际存在”“验收通过”。文件管理检查不替代研究或代码验收；结果返回主 AI，说明对应哪项 TASK、数据和文件在哪里、还缺什么、谁继续处理。agent_doc/task/TASK.md 保留稳定需求与索引，高频状态记在 `.agent-runs/<run_id>/`，避免监督源哈希因反复勾选发生漂移。

保护原始数据、用户私人记录与运行中/状态未知的输出路径。移动前用 `rg` 查生产者、消费者、论文和任务引用；仅在已授权、可回滚且引用核对完成后执行。删除不自动执行。已授权的文档、目录规划与新产物登记直接完成，不为例行整理额外等用户批准。

跨轮次任务、意图纠正或证据复用时读取 [项目记忆与纠错](references/project_memory_workflow.md)，交接当前意图与 memory_refs；旧结论失效后先核对依赖，再复用或重算。

任务开始及接收交接时执行 [知识接入契约](references/knowledge_access_workflow.md)：定位实际语料/工具，按需检索并核对前提；传递真实 knowledge_refs，缺库或过期不可冒充已调用。

项目任务开始、交接与写文件前读取 [项目文档治理](references/project_document_workflow.md)：`agent_doc/task/TASK.md` 是唯一日期任务索引，`agent_doc/task/task_details/*.md` 由 AI 维护方法/进度/证据；已核实人类来源的 `agent_doc/guide/GUIDE.md` 为最高项目规划依据，AI 绝不创建、编辑、删除或移动 `agent_doc/guide/` 内任何文件。`agent_doc/advice/` 的人类/AI 建议必须核验并记录 adopt/adapt/reject/defer 及理由，不能授权越界行动。

生产或消费测试/实验数据时遵循 [结果独立验证](references/result_validation_workflow.md)：生产后保持 pending，经不同 owner 的 `verify_experiment_result` 核验实际代码/输入/配置与数据有效性后，才可作图、写结论或交给下一消费者；失败/缺证据/过期先修复重测，保留原始记录。仅可报告 usable-with-scope，不保证绝对无 bug。

项目新指令先按 [既有结果检索与复用](references/result_reuse_workflow.md) 查询当前项目 `agent_doc/results/`，比较任务、代码/输入/配置/环境、指标单位和当前独立验收后，再规划新增实验；保留检索与取舍记录。新数据存 `agent_doc/results/<run_id>/`，旧文件可按真实路径/哈希索引。复用不跳过独立代码/数据门禁、用户明确复现或新主张验收。

受管复杂项目的主控边界见 [双主 AI 计划审核](references/dual_main_workflow.md)：按已审核的准确任务/证据版本执行；新方案返回 planner-main 并由独立 review-main 复审，专业角色不能自批、越权或替代独立结果验收。简单独立任务保持原流程。

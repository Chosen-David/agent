from pathlib import Path
import json,csv,hashlib,platform
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image,ImageOps
from panel_a import draw as draw_a
from panel_b import draw as draw_b
OUT=Path(__file__).resolve().parent
CASE=OUT.parents[2]; ROOT=OUT.parents[4]
spec=json.loads((CASE/'inputs/architecture.json').read_text())
rows=list(csv.DictReader((CASE/'inputs/measurements.csv').open()))
plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none','pdf.fonttype':42,'font.size':9})
def save(fig,name):
    for ext in ('svg','png','pdf'): fig.savefig(OUT/f'{name}.{ext}',dpi=240,facecolor='white')
    plt.close(fig)
f=plt.figure(figsize=(5,3.5)); draw_a(f.add_axes([.04,.08,.92,.88]),spec); save(f,'panel_a')
f=plt.figure(figsize=(4.5,3.5)); draw_b(f.add_axes([.16,.27,.81,.49]),rows); save(f,'panel_b')
f=plt.figure(figsize=(9.5,3.6)); draw_a(f.add_axes([.025,.09,.47,.84]),spec); draw_b(f.add_axes([.58,.29,.40,.47]),rows); save(f,'figure')
im=Image.open(OUT/'figure.png').convert('RGB'); im.resize((950,360)).save(OUT/'figure_final_size.png'); ImageOps.grayscale(im).resize((950,360)).save(OUT/'figure_grayscale.png')
page=Image.new('RGB',(1100,1423),'white'); page.paste(im.resize((950,360)),(75,180)); page.save(OUT/'page_preview.png')
source_paths=['snapshot/config/role_registry.json','snapshot/workflows/agent_communication_workflow.md','snapshot/workflows/figure_workflow.md','snapshot/workflows/data_visualization_workflow.md','snapshot/workflows/diagram_workflow.md']
source_paths += ['snapshot/plugins/research-assistant/skills/research-figures/'+p for p in ['SKILL.md','references/execution.md','references/workflow.md','references/figure_shared.md','references/data_visualization_learning.md','references/paper_exemplar_learning.md']]
source_paths += [str(p.relative_to(ROOT)) for p in [CASE/'task.txt',CASE/'inputs/architecture.json',CASE/'inputs/measurements.csv']]
manifest={'run_id':ROOT.name,'case':CASE.name,'role':'research-figures','mode':'sequential staged execution by one agent, no independent specialist review','tools':{'matplotlib':matplotlib.__version__,'python':platform.python_version()},'loaded_sources':[{'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()} for p in source_paths], 'panels':[{'id':'A','route':'diagram','owner':'research-figures','evidence_type':'synthetic proposed specification','source':'inputs/architecture.json','editable_source':'panel_a.py','status':'rendered'},{'id':'B','route':'data_visualization','owner':'research-figures','evidence_type':'synthetic','source':'inputs/measurements.csv','editable_source':'panel_b.py','status':'rendered'}],'assembly_source':'build.py','input_rows':rows,'semantic_contract':spec}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
assert len(spec['nodes'])==6 and len(spec['edges'])==5
assert [(r['workload'],r['baseline_ms'],r['candidate_ms']) for r in rows]==[('small','100','80'),('medium','120','100'),('large','200','220'),('kernel','20','10')]
print('Rendered panels A/B and combined SVG/PNG/PDF; preserved six nodes, five edges and four data rows.')

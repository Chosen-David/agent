"""Build editable SVG from the exact input graph, then rasterize that actual SVG."""
from pathlib import Path
import json,hashlib,math,platform,xml.etree.ElementTree as ET
from xml.sax.saxutils import escape
import fitz
from PIL import Image,ImageOps
OUT=Path(__file__).resolve().parent; CASE=OUT.parents[2]; ROOT=OUT.parents[4]
spec=json.loads((CASE/'inputs/architecture.json').read_text())
pos={'a':(40,130,210,70),'b':(40,280,210,70),'sum':(330,205,200,70),'softmax':(610,205,240,70),'v':(330,365,200,70),'output':(610,365,240,70)}
coords={('a','sum'):((250,165),(330,240)),('b','sum'):((250,315),(330,240)),('sum','softmax'):((530,240),(610,240)),('softmax','output'):((730,275),(730,365)),('v','output'):((530,400),(610,400))}
parts=['<svg xmlns="http://www.w3.org/2000/svg" width="7.5in" height="4.333333in" viewBox="0 0 900 520">','<title>Proposed two-path logit combination</title>','<desc>Six nodes and exactly five directed data-flow edges from the supplied synthetic unimplemented specification.</desc>','<rect width="900" height="520" fill="white"/>','<g font-family="sans-serif" fill="#23354a">','<text x="40" y="48" font-size="24" font-weight="bold">'+escape(spec['title'])+'</text>','<text x="40" y="80" font-size="15" fill="#52677c">Proposed schematic · synthetic specification · not implemented</text>']
for n in spec['nodes']:
 x,y,w,h=pos[n['id']]
 parts += [f'<g id="node-{n["id"]}"><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="#edf1f5" stroke="#52677c" stroke-width="1.5"/>',f'<text x="{x+w/2}" y="{y+h/2+6}" font-size="17" text-anchor="middle">{escape(n["label"])}</text></g>']
for u,v in spec['edges']:
 (x,y),(xx,yy)=coords[(u,v)]; dx,dy=xx-x,yy-y; dist=math.hypot(dx,dy); ux,uy=dx/dist,dy/dist
 tip=(xx-3*ux,yy-3*uy); base=(tip[0]-10*ux,tip[1]-10*uy)
 pts=[tip,(base[0]-4*uy,base[1]+4*ux),(base[0]+4*uy,base[1]-4*ux)]
 points=' '.join(f'{a:.3f},{b:.3f}' for a,b in pts)
 parts += [f'<g id="edge-{u}-{v}" data-source="{u}" data-target="{v}" data-kind="data_flow"><path d="M {x} {y} L {base[0]:.3f} {base[1]:.3f}" fill="none" stroke="#52677c" stroke-width="2"/><polygon points="{points}" fill="#52677c"/></g>']
parts+=['<text x="40" y="483" font-size="15" fill="#52677c">Arrows: data flow. Fixed values V enter only the output.</text>','</g></svg>']
(OUT/'method.svg').write_text('\n'.join(parts))
tree=ET.parse(OUT/'method.svg'); elements=list(tree.iter()); ids=[e.attrib['id'] for e in elements if 'id' in e.attrib]
assert len(ids)==len(set(ids))==11
assert {i for i in ids if i.startswith('node-')}=={'node-'+n['id'] for n in spec['nodes']}
assert {(e.attrib['data-source'],e.attrib['data-target']) for e in elements if 'data-source' in e.attrib}==set(map(tuple,spec['edges']))
with fitz.open(OUT/'method.svg') as doc:
 page=doc[0]; pix=page.get_pixmap(matrix=fitz.Matrix(2.5,2.5));pix.save(OUT/'method.png')
im=Image.open(OUT/'method.png').convert('RGB');im.resize((900,520)).save(OUT/'final_size.png');ImageOps.grayscale(im).resize((900,520)).save(OUT/'grayscale.png')
page=Image.new('RGB',(1050,1359),'white');page.paste(im.resize((900,520)),(75,160));page.save(OUT/'page_preview.png')
contract={'status':spec['status'],'evidence_type':spec['evidence_type'],'source':'inputs/architecture.json','source_sha256':hashlib.sha256((CASE/'inputs/architecture.json').read_bytes()).hexdigest(),'nodes':[dict(n,type='input' if n['id'] in ['a','b','v'] else 'operation/output',source_pointer=f'/nodes/{i}',svg_id='node-'+n['id'],incoming=[u for u,v in spec['edges'] if v==n['id']],outgoing=[v for u,v in spec['edges'] if u==n['id']]) for i,n in enumerate(spec['nodes'])],'edges':[{'source':u,'target':v,'direction':u+' to '+v,'kind':spec['edge_kind'],'label':None,'source_pointer':f'/edges/{i}','svg_id':f'edge-{u}-{v}'} for i,(u,v) in enumerate(spec['edges'])],'groups':[],'invariants':spec['constraints'],'unknown':['tensor dimensions','training/inference distinction','hardware','measured performance','accuracy'],'label_changes':[]}
(OUT/'semantic_contract.json').write_text(json.dumps(contract,indent=2))
source_paths=['snapshot/config/role_registry.json','snapshot/workflows/agent_communication_workflow.md','snapshot/workflows/diagram_workflow.md']+['snapshot/plugins/research-assistant/skills/research-diagrams/'+p for p in ['SKILL.md','references/execution.md','references/workflow.md','references/figure_shared.md','references/paper_exemplar_learning.md']]+[str((CASE/p).relative_to(ROOT)) for p in ['task.txt','inputs/architecture.json']]
manifest={'run_id':ROOT.name,'case':CASE.name,'role':'research-diagrams','route':'diagram','loaded_sources':[{'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()} for p in source_paths],'loaded_sections':{'references/paper_exemplar_learning.md':'section 7 only'},'editable_master':'method.svg','generator':'render.py','actual_render':'PyMuPDF opens actual method.svg and renders pixels','tools':{'python':platform.python_version(),'PyMuPDF':fitz.VersionBind,'MuPDF':fitz.VersionFitz},'dimensions_inches':[7.5,4.333333],'semantic_assertions':'6 stable node IDs and exact 5 directed edge IDs equal supplied graph; no added groups'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Wrote and rasterized actual SVG; node/edge XML IDs verified against input.')

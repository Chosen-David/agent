# FIG-latency execution and visual QA

Status: ready for review as a faithful synthetic-data figure. Submission requirements unverified. Independent grading belongs to the main agent; this is author self-check.

Loaded source paths and SHA-256, exact CSV rows, actual plotted values, transformations and tool versions are in manifest.json. The registry and shared communication workflow were loaded earlier in the same assigned execution. Input is read-only. All edits and exports are under this case's attempts/0001/outputs. No external data, network, installation, subagents, new experiments or statistics.

Reproduction: `python /workspace/scratch/c12f3d9f92bd/revision-candidate-v3-roles-run/cases/research-data-visualization/attempts/0001/outputs/plot.py`. The source renders latency.svg/png/pdf. SVG has editable text and native vector marks. PNG dimensions are 1680 × 1104 (240 dpi); physical size is provisionally 7 × 4.6 inches. Actual PDF raster command: `pdftoppm -scale-to 1400 -png -singlefile latency.pdf pdf_render`. Font check: `pdffonts latency.pdf`, saved in font_report.txt. Both reported TrueType font subsets are embedded.

Actual image reading on 2026-10-07 with view_image: final_size.png (700 × 460), grayscale.png, pdf_render.png and page_preview.png all opened and inspected. A single local render was sufficient. PDF glyphs, legend, axes and eight value labels were checked separately from PNG. English-only figure retains input workload strings and correct units. No Chinese translation was requested. Approximate page preview checks placement; no real manuscript or physically calibrated print was available.

- Numerical preservation: pass. CSV has four unique workload rows, no missing values in used fields, eight finite positive values. Code checks actual scatter x offsets against the corresponding input values. Every source row appears in manifest and figure. No aggregate, synthetic uncertainty, speedup, fitted relationship or distribution is added.
- Scope and inference: pass. End-to-end and kernel-only are separate titled facets, with identical scales and method order. Large candidate regression at 220 vs 200 is clearly retained. Caption disclaims empirical validation and scope transfer.
- Comparison/hierarchy: pass. Scope titles organize the rows; exact values are primary, pale grid secondary. No lines imply measured values between categories.
- Typography/final size: pass at provisional inspected screen size. Exact labels fit beside markers, the 220 label is inside the canvas, and ticks/legend/axis unit are readable.
- Encoding/accessibility: pass for circle/square and top/bottom position in viewed grayscale. No reliance on hue alone. Color-vision simulation remains unverified.
- Layout/legend/whitespace: pass. Facets have an explicit gap, labels do not collide, and shared legend occupies the bottom margin below the axis label. Same 0–250 axis prevents scope-facet scale exaggeration.
- Technical/reproduction: SVG XML parsed successfully; source and input hashes recorded. PDF and PNG actually rendered; final PDF opened as pixels, and embedded fonts checked. Another-machine execution unverified.

External exemplar learning: not run (local-only standalone synthetic task; no supplied papers). Target venue and font constraints unknown, so no publication-format certification. Repeat units, repeat count, uncertainty and hardware/configuration are unavailable; this prevents statistical or general system-performance conclusions but does not prevent honest display of provided values.

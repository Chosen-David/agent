import csv, json, sys
with open(sys.argv[1], newline="") as f:
    rows=list(csv.DictReader(f))
output=[]
for row in rows:
    b=float(row["baseline_ms"]); c=float(row["candidate_ms"])
    output.append({**row,"speedup_baseline_over_candidate":b/c if c>0 else None,"latency_reduction_percent":100*(b-c)/b if b>0 else None})
print(json.dumps(output, indent=2))

# 本轮结论与范围

EXECUTE：完成现有 v2 数据分析、结果段落、图和依赖重排。建议保留 baseline，不将 candidate 作为普遍更优的实现；后续优化仅值得围绕 large 回退开展有界诊断。现有数据不足以批准替换，也不足以证明进一步优化必有收益。未运行新实验或独立专业 Agent，未启动服务或监督器。

## 输入版本更新影响

| 原工作 | 本轮处理 | 理由与证据 |
|---|---|---|
| collect@v1 | 保留历史采集记录；使用给定 measurements.csv@v2，不重新采集 | project.json 已声明更新，当前文件有 4 行、单位 ms；未提供 v1 原始字节，不能比较两版改动 |
| figure@v1 | stale；已由 figure_v2.png/svg 替代供本轮使用 | 图依赖 measurements.csv@v1；旧图文件未提供，不能宣称已审阅 |
| write（todo） | 停止依赖 v1 的旧安排，绑定 v2 分析与图，已产出本轮段落 | 写作显式依赖旧图与旧数据 |
| background@v1 | 保留项目中的历史完成状态；未受 measurements 变化影响 | 唯一声明输入为 concept.txt@v1，内容与延迟数据独立；原 background 文件未提供，保留不等于本轮验收 |

本轮另建 RES-KEEP 适用性检查，记录以上独立性结论。下游依赖这个实际记录，不依赖 skipped 的历史执行任务。concept.txt 可复用，但无需重做其量化教学题；如最终文稿需要 background 原文，须取得原文件后核验。

## 数值分析

speedup = baseline_ms / candidate_ms；延迟降低率 = (baseline_ms − candidate_ms) / baseline_ms。small 为 1.25×、20.00%；medium 为 1.20×、16.67%；large 为 0.9091×、−10.00%；kernel_only 为 2.00×、50.00%。端到端与 kernel_only 分开，不混合求平均。无每种工作负载的生产权重，不给总体收益；无重复次数、误差或计时环境，不能给显著性、置信区间或因果解释。

## 结果段落

给定的合成 v2 数据中，candidate 在 small 与 medium 工作负载上的端到端延迟由 100、120 ms 降至 80、100 ms，分别为 1.25× 和 1.20× 加速；large 从 200 ms 升至 220 ms，延迟增加 10%。独立 kernel 记录从 20 ms 降至 10 ms，为 2.00× 加速，但该计时范围不能代表端到端收益。因此，这些数据支持收益随工作负载变化，不支持普遍加速。由于缺少重复测量、运行配置与正确性记录，尚不能判断统计稳定性、退化原因或生产适用性。

图：figure_v2.png / figure_v2.svg。图中分开 end_to_end 与 kernel_only，纵轴从零开始，未编造误差棒；已实际查看 PNG，标签完整可读，4 对柱高与原数据一致。

## 可执行后续与验收

本轮已完成 RES-KEEP → 无依赖保留检查；RES-INGEST → RES-ANALYZE → FIG-T-2 → WRITE-2，WRITE-2 同时依赖 RES-KEEP。结构化节点见 task_chain.json。所有 done 仅为本地工作及自检完成，交主 AI 独立验收，不代表模型效果评测通过。

CODE-DIAG（blocked）：仅当另行提供同配置日志、正确性结果、large 路径或实现后，复核额外开销/访问行为；恢复条件为相关材料具备且属于授权范围。不得从四个耗时猜出机制。若诊断需新实验，单独固定 CPU 预算、重复规则、正确性门槛和停止标准后再授权；当前不运行。最终采用条件应覆盖全部必要工作负载及正确性；工作负载权重、噪声容忍阈值尚未定义。

本轮停止条件已到达：现有数据能做的重算、图、段落、影响分析完成；不为获取正结果扩预算。未接入持久 inbox；handoff_event.json 是手工交接 envelope，尚无消费回执，未以回执关闭科学问题。根 TASK 与最终验收由主 AI 管理。

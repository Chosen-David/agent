# 通用工作稿：选择性执行

本稿仅改写给定合成材料，不代表真实论文或新增实验。

## 中文结果段落

在给定合成测量中，替换选定内核后，小型与中型工作负载的端到端延迟分别由 100 ms 降至 80 ms、由 120 ms 降至 100 ms，相对基线降低 20.0% 和 16.7%，对应加速比分别为 1.25× 和 1.20×。大型工作负载则由 200 ms 增至 220 ms，延迟增加 10.0%，加速比为 0.91×，说明收益依赖于工作负载，现有结果不支持“所有工作负载均获得 2× 端到端加速且没有退化”的原摘要表述。独立计时的内核延迟由 20 ms 降至 10 ms，即内核级加速比为 2.00×、延迟降低 50.0%；该内核已包含在端到端路径中，不能将两种计时相加，也不能将内核级收益作为端到端收益。所有记录使用相同 CPU 进程与输入配置，每个数值仅来自一次运行，没有独立重复，故不能据此判断统计显著性或估计方差。材料未测量质量或 GPU 性能，也未提供大型工作负载退化的机制证据；以上结论仅描述给定 CPU 合成记录，不表明质量保持、GPU 收益或普遍性能优势。

## English abstract

We examine selective kernel replacement using supplied synthetic CPU timing records. Under the same CPU process and input configuration, end-to-end latency decreases from 100 to 80 ms for the small workload and from 120 to 100 ms for the medium workload, corresponding to speedups of 1.25× and 1.20× and latency reductions of 20.0% and 16.7%, respectively. The large workload regresses from 200 to 220 ms, a 10.0% latency increase and a speedup of 0.91×. Independently timed kernel latency decreases from 20 to 10 ms, yielding a 2.00× kernel-only speedup. Because the kernel is already included in the end-to-end paths, these timings must not be added, and the kernel-only speedup does not establish a 2× end-to-end improvement. Each value represents a single run without independent repeats; variance, statistical significance, output quality, and GPU performance remain unassessed. These records therefore indicate workload-dependent CPU timing changes, including a regression, rather than uniform end-to-end gains. The cause of the regression is not established by the supplied evidence.

## 主张证据表

计时单位均为 ms；加速比 = 基线 / 候选；延迟变化 = (候选 − 基线) / 基线。证据文件版本与 SHA-256 见 execution_record.json，逐行计算见 calculation_checks.json。

| 主张 ID | 主张与强度 | 证据 ID / 位置 | 指标与范围 | 限制或反证 | 正文位置 |
|---|---|---|---|---|---|
| WRITE-C001 | 小型记录加速 1.25×，延迟降低 20.0%（有限支持） | E1：measurements.csv 第 2 行 | 100→80，end_to_end | 单次 CPU 合成记录，不代表统计显著 | 结果与摘要 |
| WRITE-C002 | 中型记录加速 1.20×，延迟降低 16.7%（有限支持） | E2：measurements.csv 第 3 行 | 120→100，end_to_end | 单次运行，不可推广 | 结果与摘要 |
| WRITE-C003 | 大型记录延迟增加 10.0%，加速比 0.91×（有限支持） | E3：measurements.csv 第 4 行；manuscript.md Appendix A | 200→220，end_to_end | 退化原因未知，保留负结果 | 结果与摘要 |
| WRITE-C004 | 内核级加速 2.00×、延迟降低 50.0%（有限支持） | E4：measurements.csv 第 5 行 | 20→10，kernel_only | 不能扩展到端到端或 GPU | 结果；摘要给出倍数 |
| WRITE-C005 | 内核计时已包含在端到端路径，不应相加（材料支持） | E5：manuscript.md Results | 独立计时口径 | 不推断其他开销、占比或机制 | 结果与摘要 |
| WRITE-C006 | 每值一次运行，无独立重复；质量、方差与 GPU 未测量（材料支持） | E6：manuscript.md Method、Results、Appendix A | 本材料的实验范围 | 无法作显著性、质量保持、GPU 收益结论 | 结果与摘要 |
| WRITE-C007 | 原摘要“所有负载端到端 2× 且无退化”（不支持，已替换） | E1–E4；manuscript.md Abstract | 泛化主张 | 三个端到端加速比均非 2×；大型出现退化 | 原摘要的纠正记录 |

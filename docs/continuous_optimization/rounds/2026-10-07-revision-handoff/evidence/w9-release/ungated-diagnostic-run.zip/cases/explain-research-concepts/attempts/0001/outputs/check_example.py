import math,json
from pathlib import Path

def softmax(z):
    e=[math.exp(v-max(z)) for v in z]
    return [v/sum(e) for v in e]
def f(z):
    p=softmax(z)
    return 10*p[1]
z=[0.,0.]; changed=[0.,math.log(3)]
h=1e-5
fd=[(f([z[j]+(h if i==j else 0) for j in range(2)])-f([z[j]-(h if i==j else 0) for j in range(2)]))/(2*h) for i in range(2)]
assert abs(f(z)-5)<1e-12
assert abs(f(changed)-7.5)<1e-12
assert all(abs(a-b)<1e-8 for a,b in zip(fd,[-2.5,2.5]))
assert abs(f([2.,2.])-f(z))<1e-12
assert abs(f([1.-1.,-3.+3.])-f(z))<1e-12
record={'initial_probabilities':softmax(z),'changed_probabilities':softmax(changed),'initial_y':f(z),'changed_y':f(changed),'exact_delta_y':f(changed)-f(z),'jacobian_at_initial':[-2.5,2.5],'central_difference_jacobian':fd,'finite_difference_step':h,'linear_delta_prediction':2.5*math.log(3),'constant_shift_delta':f([2.,2.])-f(z),'opposite_path_errors_delta':f([0.,0.])-f(z),'checks':'passed; numerical teaching checks, not real-model experiments'}
print(json.dumps(record,indent=2))
Path(__file__).with_name('calculation_checks.json').write_text(json.dumps(record,indent=2)+'\n')

# EXPL-001：独立打分不等于输出误差独立

**不能仅凭两路分别打分或分别检查非零量化误差，就保证输出不变。** 两路先相加，再共同经过 softmax；输出取决于合并误差及固定的值矩阵。这里讨论的是 concept.txt 给定的教学模型，不是论文实测。

给定 \(a=b=(0,0)\)、\(V=(0,10)^T\)，初始权重为 \((1/2,1/2)\)，所以 \(y=5\)。保持 \(a,V\) 不变，仅令 \(b'=(0,\log 3)\)，则

\[
\operatorname{softmax}(a+b')=(1/4,3/4),\qquad y'=7.5,\qquad \Delta y=2.5.
\]

第一路完全没有误差，输出仍发生变化；“独立打分”不能推出“误差对输出独立”。当然，分别检查能发现第二路发生了变化，但它本身并不给出输出不变的保证。

**局部推导。** 为明确形状，将 logits 写成列向量 \(z=a+b\in\mathbb R^n\)，\(p=\operatorname{softmax}(z)\in\mathbb R^n\)，固定 \(V\in\mathbb R^{n\times d}\)，将输出转为列向量 \(y=V^Tp\in\mathbb R^d\)；这与题中行向量写法等价。logits 无量纲，输出与 \(V\) 同单位。

\[
p_i=\frac{e^{z_i}}{\sum_k e^{z_k}},\qquad
\frac{\partial p_i}{\partial z_j}=p_i(\delta_{ij}-p_j),\qquad
S=\operatorname{diag}(p)-pp^T.
\]

因此 \(J_z=V^TS\in\mathbb R^{d\times n}\)，且

\[
J_a=J_b=J_z,\quad J_{(a,b)}=[J_z\;J_z],\qquad
\Delta y=J_z(\Delta a+\Delta b)+O(\|\Delta a+\Delta b\|^2).
\]

每列可写成 \(\partial y/\partial z_j=p_j(V_{j,:}^{T}-y)\)：敏感度取决于合并 logits 产生的权重以及值矩阵，不由每一路孤立决定。在本例初始点，

\[
S=\begin{pmatrix}1/4&-1/4\\-1/4&1/4\end{pmatrix},\quad
J_z=(-2.5,2.5),\quad J_{(a,b)}=(-2.5,2.5,-2.5,2.5).
\]

线性预测为 \(\Delta y\approx2.5\log 3\approx2.7465\)，而精确值为 \(2.5\)。两者不同说明局部 Jacobian 只给小扰动的一阶近似，不能充当有限扰动下输出不变的证明。脚本已用中心差分核验初始 Jacobian。

**边界与反例。** 非零误差也不一定改变输出：若 \(\Delta a+\Delta b=c\mathbf1\)，softmax 对共同平移严格不变；两路误差完全抵消是其中 \(c=0\) 的情况。若 \(V\) 的所有行相同，任何权重变化都不改变输出。一般的精确条件是 \(V^T(p'-p)=0\)；只满足初始点的一阶零变化并不足以保证有限变化严格为零。独立的误差上界可以结合联合敏感度分析来限制输出误差，但“小”不等于“零”。

回到 concept.txt 第 2–4 行，应把它理解为“两个 logits 路径在共同归一化前合并”。这个反例否定的是无条件的不变保证；它不能说明真实模型的量化误差分布、准确率变化、任何具体量化方案优劣或硬件性能，也不说明所有非零量化误差都会改变输出。真实模型未在本任务中运行。

| Experiment | Conclusion | Script | Data | Result | Citation |
|---|---|---|---|---|---|
| HIST-0 | unknown | archived/missing.py | unknown | unknown | unknown |
| ALPHA | inconclusive (fixture declaration, not verified experiment) | experiments/alpha.py | synthetic-x (label only; file absent) | results/alpha.json | script comment L1 and result JSON; provenance unknown |
| BETA | rejected (fixture declaration, not verified experiment) | experiments/beta.py | synthetic-y (label only; file absent) | results/beta.json (running output: protect) | script comment L1 and result JSON; provenance unknown |
| UNKNOWN-NOTE | provenance unknown; protected | unknown | unknown | notes/orphan.txt | active_tasks.json protected_files; not a scientific citation |
| UNKNOWN-STATE | active/protected path declarations | experiments/alpha.py; experiments/beta.py | unknown | active_tasks.json | local runtime declaration; actual processes unverified |

This is an output-only incremental draft for the supplied organization root. Historical header and HIST-0 row remain byte-for-byte in original order. Input files are unchanged. Task identifiers ALPHA/BETA come from supplied experiment declarations, not a newly invented project TASK.

| Task/anchor | Producer | Consumer | Data kind | Existence/verification |
|---|---|---|---|---|
| HIST-0 | unknown | unknown | unknown | archived/missing.py absent; preserve history, unresolved |
| ALPHA | experiments/alpha.py is declared script; executing actor unknown | unknown | synthetic fixture, not measured data | script/result exist and mutually name each other; no execution proof |
| BETA | experiments/beta.py is declared script; executing actor unknown | unknown | synthetic fixture, not measured data | script/result exist and mutually name each other; output declared running |
| UNKNOWN-NOTE | unknown | unknown | historical text, provenance unknown | exists; protected by active_tasks.json |
| UNKNOWN-STATE | producer unknown | this inventory; other consumers unknown | supplied state declaration | exists; not OS process telemetry |

Exact source SHA-256 values and path inventory are in inventory.json. No paper citations or raw data files are supplied. Existing unknown citations stay unknown. Current input results are snapshots only; running beta may change in a real project. No acceptance status is inferred from file existence.

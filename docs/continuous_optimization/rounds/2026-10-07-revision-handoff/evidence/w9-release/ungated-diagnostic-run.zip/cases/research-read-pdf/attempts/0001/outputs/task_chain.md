# Reader task chain

- READ-T001 verify, depends on []: Read pages 1–3 at current hash; distinguish changed output from defined error amplification; ask whether a theorem with assumptions or appropriate empirical evidence exists, without presuming it.
- READ-T002 resolve, depends on ['READ-T001']: Choose supported scope correction; preserve toy arithmetic; regenerate PDF and record new hash.
- READ-T003 recheck, depends on ['READ-T002']: Actually render and reopen pages 1–3 of new PDF, checking claim and Appendix consistency.

import math,json
Q=2.0;delta=.03;eta=Q*delta
checks={'eta':eta,'conservative_threshold':2*eta,'joint_l2_threshold':math.sqrt(2)*eta,'gap_015_certified':.15>math.sqrt(2)*eta,'gap_008_certified':.08>math.sqrt(2)*eta}
# One-dimensional q, two key columns: spectral norm of 1x2 E is its Euclidean norm.
q=2.0;K=[.04,0.0];E=[-.021,.021]
original=[q*x for x in K];approx=[q*(x+e) for x,e in zip(K,E)]
checks['counterexample']={'q':q,'K':K,'Khat_minus_K':E,'operator_error':math.hypot(*E),'score_error_l2':math.hypot(*[q*e for e in E]),'original_scores':original,'approx_scores':approx,'original_top1':max(range(2),key=original.__getitem__),'approx_top1':max(range(2),key=approx.__getitem__)}
assert math.hypot(*E)<=delta
assert checks['counterexample']['original_top1']!=checks['counterexample']['approx_top1']
# Zero error is also admissible and preserves top1 for the .08 case.
checks['preserving_example']={'error':0.0,'scores':original,'top1_preserved':True}
checks['equality_example']={'original_gap':math.sqrt(2)*eta,'errors':[-eta/math.sqrt(2),eta/math.sqrt(2)],'remaining_gap':0.0,'possible_tie':True}
checks['machine_example']={'work_units':2.0,'speeds':[1.0,2.0],'completion_times':[2.0/1.0,2.0/2.0],'same_objective':False}
assert checks['gap_015_certified'] and not checks['gap_008_certified']
assert checks['machine_example']['completion_times'][0]!=checks['machine_example']['completion_times'][1]
checks['status']='all deterministic arithmetic assertions passed; no benchmark or formal proof'
print(json.dumps(checks,indent=2))

# CODE-READ-001 — run to final scores

Scope: frozen synthetic_selector.py only, source SHA-256 `6fc687e85d2c169c5dc88d7dc126b970036f22b822c00c9f8f0d8b628a6e8ea1`. No repository commit was supplied for this standalone input; SHA identifies the exact source. All conclusions below are source facts/static inferences. No target import, execution, tests, profiling or dynamic trace occurred; no runtime options are known. No independent reviewer was launched. No AGENTS.md, .agents/skills, logs or tests are present in the supplied input file inventory.

Module claims (lines 1–2) conflict with reachable expressions:

| Narrative | Source-grounded correction |
|---|---|
| near is forced | select L19 defines near boundary; forced is a separate trailing interval at L20. Near candidates are ranked then quota-truncated at L24–25. |
| skip means no scoring | skip_far suppresses only far sorting/selection (L23); query/key representations and reduced scores still run for all keys (L21–22), near sorting still runs (L24), final scoring still runs (run L30). |
| projector is query-trained | represent has no training/update. Default extracts coordinates 0 and 2 (L7–8). Optional externally supplied basis takes dot products with each column (L9). Its provenance/training is unknown; no query-derived learning exists in this file. |
| final scoring uses reduced keys | full_score consumes original query and keys indexed by selected positions (L12–13); run passes them directly at L30. Reduced scores choose positions only. |

Call edges (syntactic_call and statically resolved local definitions; none observed_call): run→select L29, select→represent(query) L21, select→represent(each key) L22, run→full_score L30. run resolves ordinary module globals; these edges assume no external monkey-patching. No dynamic backend/registration occurs in this slice.

Data edges: query vector and basis→represent→qsmall (L6–9,21); each original key and same basis→reduced key→dot(qsmall,reduced key)→scores list, one scalar per key (L22); n and near_len→boundary (L18–19); reduced scores + positional ranges→far/near rankings (L23–24); forced_len→forced positions (L20); budget−len(forced)−len(far)→near slice length (L25); concatenation→positions→original keys[i] and original query→final score list (L29–30,12–13). Return is (positions, final scores), in matching concatenation order, not globally score sorted.

| Option | Default | Definition/consumer | Static effect |
|---|---:|---|---|
| near_len | 4 | select L16,19,24 | Range boundary max(0,n−4); near candidate range ends before n−forced_len. It is a range, not a guaranteed quota. |
| forced_len | 1 | L16,20,24–25 | Last min(n,1) positions by default; forced appended unconditionally. |
| budget | 3 | L16,25 | Only caps near allocation after far and forced; not a validated global hard cap. |
| far_budget | 1 | L16,23 | At most one far candidate by default if available and skip_far false. |
| skip_far | False | L17,23 | True makes far=[]; no reduced/final scoring bypass. |
| basis | None | L17,21–22→L6–9 | None selects [0,2]; otherwise returns one dot product per supplied column. |

run accepts overrides through **options at L28–29. No file/env/CLI override or actual run log is supplied. A vector needs at least three entries for default representation; for optional basis, zip truncates to shorter lengths. The code does not validate dimensions, dtype, basis orthogonality, normalization, finiteness or configuration ranges. Reduced length is 2 by default, or len(basis) if it is reusable; generic iterators could be exhausted across calls, which is not constrained by an interface contract. full_score likewise uses zip and thus uses all paired original coordinates only when lengths agree—not necessarily a validated full-D inner product.

For nonnegative sane lengths and forced_len≤near_len, forced is trailing indices [max(0,n−forced_len),n), far is [0,boundary), near is [boundary,max(boundary,n−forced_len)). These are positional ranges; no attention masks, values, normalization, softmax or output aggregation appear. Sorting key is −score, so larger scores rank first; Python stable sort preserves ascending position order on ordinary equal scores. Far picks precede near picks, followed by forced ascending positions. No deduplication occurs.

Counterexamples inferred statically (not run): with n=6 defaults, boundary=2, forced=[5], far selects one of [0,1], near ranks [2,3,4] and selects one, so only one of the near candidates is retained. With budget=0, a nonempty forced set remains; far can also remain, so total can exceed budget. With n=6, near_len=1, forced_len=3, far range [0,5) overlaps forced [3,4,5]; if far chooses 3 or 4, returned positions duplicate it and full_score computes it again. Negative far_budget uses Python negative slicing rather than a valid count. Short/empty key pools may reduce output, but even n=0 still represents query L21 and can raise for a query shorter than 3.

Unknowns: intended dimensional/parameter validation policy, provenance and shape guarantees of external basis, actual query/key types and inputs/options, performance and quality relative to any baseline, consumers outside this file, and broader models/entrypoints. This source establishes the listed synthetic mechanism only. Future implementation work could validate dimensions/counts and clarify hard-budget and deduplication semantics, but no modifications are authorized here.

Self-check: reread entire 30-line source against each claim, separating defaults/options, ranking/final scoring, ranges/quotas, and static/observed evidence. No target runtime checks were attempted.

# 核验 → 处理 → 复查

- REV-T001 (REV-F001, verify): Recompute each paired row and preserve scope; cross-check Appendix A. 依赖：[]。
- REV-T002 (REV-F001, resolve): Use confirmed evidence to select minimal resolution; rejected means no edit. Missing data remains blocked. 依赖：['REV-T001']。
- REV-T003 (REV-F001, recheck): Read revised artifact at new hash and assess original acceptance conditions. 依赖：['REV-T002']。
- REV-T004 (REV-F002, verify): Determine intended generalization and correctness requirement; recover paired raw timing logs if they exist. 依赖：[]。
- REV-T005 (REV-F002, resolve): Use confirmed evidence to select minimal resolution; rejected means no edit. Missing data remains blocked. 依赖：['REV-T004']。
- REV-T006 (REV-F002, recheck): Read revised artifact at new hash and assess original acceptance conditions. 依赖：['REV-T005']。

REV-F003 已由附录反证撤销，不要求改稿。未执行任何修订或新实验。

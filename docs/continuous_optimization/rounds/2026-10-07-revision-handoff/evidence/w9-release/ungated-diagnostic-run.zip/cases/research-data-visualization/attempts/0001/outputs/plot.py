from pathlib import Path
import csv,json,hashlib,platform,xml.etree.ElementTree as ET
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image,ImageOps
OUT=Path(__file__).resolve().parent; CASE=OUT.parents[2]; ROOT=OUT.parents[4]
rows=list(csv.DictReader((CASE/'inputs/measurements.csv').open()))
assert len(rows)==4 and len({r['workload'] for r in rows})==4
assert all(r[k] and float(r[k])>0 for r in rows for k in ['baseline_ms','candidate_ms'])
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none','pdf.fonttype':42})
fig=plt.figure(figsize=(7,4.6)); axs=[fig.add_axes([.16,.49,.78,.34]),fig.add_axes([.16,.17,.78,.13])]
fig.text(.045,.94,'Latency by workload and timing scope',fontsize=11,weight='bold',color='#23354a')
fig.text(.045,.889,'Synthetic values • repeat counts and uncertainty not supplied',fontsize=8,color='#52677c')
actual=[]; handles=[]
for ax,scope,title in zip(axs,['end_to_end','kernel_only'],['End-to-end','Kernel only']):
    subset=[r for r in rows if r['scope']==scope]; ys=np.arange(len(subset))
    for key,label,color,marker,offset in [('baseline_ms','Baseline','#41647e','o',-.16),('candidate_ms','Candidate','#b86c24','s',.16)]:
        vals=np.array([float(r[key]) for r in subset]); col=ax.scatter(vals,ys+offset,s=30,color=color,marker=marker,label=label,zorder=3)
        if scope=='end_to_end': handles.append(col)
        assert np.array_equal(np.array(col.get_offsets())[:,0],vals)
        for r,x,y in zip(subset,vals,ys+offset):
            ax.annotate(f'{x:g}',(x,y),xytext=(7,0),textcoords='offset points',va='center',fontsize=9)
            actual.append({'workload':r['workload'],'scope':scope,'method':label,'latency_ms':x})
    ax.set_yticks(ys,[r['workload'] for r in subset]); ax.set_ylim(len(subset)-.5,-.5)
    ax.set_xlim(0,250); ax.set_xticks([0,50,100,150,200,250]);ax.grid(axis='x',color='#e7ebef');ax.set_axisbelow(True)
    ax.set_title(title,loc='left',fontsize=9,weight='bold',pad=9)
    ax.tick_params(length=0,pad=7)
    for side in ['top','left','right']:ax.spines[side].set_visible(False)
    ax.spines['bottom'].set_color('#98a6b2')
axs[1].set_xlabel('Latency (ms; lower is better)',labelpad=9)
fig.legend(handles=handles,loc='lower right',bbox_to_anchor=(.95,.007),frameon=False,ncol=2,fontsize=9)
for ext in ['svg','png','pdf']:fig.savefig(OUT/f'latency.{ext}',dpi=240,facecolor='white')
plt.close(fig)
im=Image.open(OUT/'latency.png').convert('RGB'); im.resize((700,460)).save(OUT/'final_size.png'); ImageOps.grayscale(im).resize((700,460)).save(OUT/'grayscale.png')
page=Image.new('RGB',(850,1100),'white');page.paste(im.resize((700,460)),(75,160));page.save(OUT/'page_preview.png')
source_paths=['snapshot/config/role_registry.json','snapshot/workflows/agent_communication_workflow.md','snapshot/workflows/data_visualization_workflow.md']+['snapshot/plugins/research-assistant/skills/research-data-visualization/'+p for p in ['SKILL.md','references/execution.md','references/workflow.md','references/figure_shared.md','references/data_visualization_learning.md']]+[str((CASE/p).relative_to(ROOT)) for p in ['task.txt','inputs/measurements.csv']]
manifest={'run_id':ROOT.name,'case':CASE.name,'owner':'research-data-visualization','route':'data_visualization','evidence_type':'synthetic','loaded_sources':[{'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()} for p in source_paths], 'tools':{'python':platform.python_version(),'matplotlib':matplotlib.__version__},'data_transforms':['parse numeric strings as float for plotting','facet by provided scope, keeping original row order within scope','no filtering, aggregation, smoothing, normalization or statistical inference'],'raw_rows':rows,'plotted_values':actual,'uncertainty':{'available':False,'shown':False,'sampling_unit':'not supplied','repeat_count':'not supplied'},'editable_source':'plot.py','dimensions_inches':[7,4.6]}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)); ET.parse(OUT/'latency.svg')
print('Rendered all 8 supplied values; verified scatter x offsets against CSV values.')

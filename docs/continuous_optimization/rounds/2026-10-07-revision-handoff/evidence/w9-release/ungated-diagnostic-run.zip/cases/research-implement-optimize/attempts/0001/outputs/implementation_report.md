# CODE-T001 — moving_average repair

The candidate keeps moving_average(values, window), slice-sum arithmetic and list output. Full-window start positions include len(values)-window, fixing the missing final result. Positive integer-like windows are validated with operator.index; zero/negative raise ValueError and noninteger/bool raise TypeError. The original docstring specifies positive integers but not exception classes; these are now explicit. Inputs are never assigned to.

Minimal reproduction: moving_average([1,2,3],2) previously returned [1.5], expected [1.5,2.5]. Root cause: exclusive range bound omitted +1. Original baseline failures are preserved in baseline_check.json. Independent checks build means by endpoints and exact Fraction accumulation, unlike candidate slice sums. All 117 candidate checks passed, covering empty/single/full/oversized windows, window 1, signed and fractional values, large integers, tuple input, invalid windows, seeded random inputs and nonmutation. This verifies the tested contract, not every numeric type.

Performance: supplied CSV is external evidence, not timings generated here and not linked to this patch. Speedup = baseline/candidate; latency reduction = (baseline-candidate)/baseline.

| Workload | Scope | Speedup | Latency reduction |
|---|---|---:|---:|
| small | end_to_end | 1.25× | 20% |
| medium | end_to_end | 1.20× | 16.67% |
| large | end_to_end | 0.9091× | −10% (regression) |
| kernel | kernel_only | 2.00× | 50% |

No uniform end-to-end gain is supported. Kernel-only gain does not establish system gain. No repetitions, hardware/configurations, raw sessions, dispersion, workload weights, correctness linkage or timing protocol are supplied; no CI, significance, noise attribution or generalizable improvement can be inferred. If one execution of each end-to-end workload were deliberately the target mixture, sum ratio would be 420/400=1.05× and reduction 4.76%; that conditional calculation is not a supported deployment aggregate. No CPU performance benchmark, GPU execution, install, network, external runtime or profiler was run.

Candidate/landscape/optimization decision (offline_fallback): direct slice sum is selected as the minimal semantic repair, O((n-w+1)w) time for w≤n, O(w) temporary space plus O(n-w+1) output. Sliding running sum gives O(n) time/O(1) auxiliary space but changes floating cancellation and nonfinite recovery behavior; prefix sums require O(n) auxiliary memory and also change numerical behavior. Neither alternative was implemented or measured. No claim of fastest/current best. Budget: one initial candidate, no feedback revision. Baseline is invalid for correctness and cannot support fair patch speed comparisons.

Reproduce from the run root: python -B cases/research-implement-optimize/attempts/0001/outputs/check_correctness.py cases/research-implement-optimize/attempts/0001/outputs/buggy.py. CSV calculations: python -B cases/research-implement-optimize/attempts/0001/outputs/analyze_measurements.py cases/research-implement-optimize/inputs/measurements.csv.

No further check is required for the requested bounded repair. Before making any future performance claim, pin workload/configuration/code identity, establish correctness for both sides, predefine repeat/session design and timing boundaries, and collect paired raw timings. Main owns integration and grading.

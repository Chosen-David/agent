import csv,json,hashlib,pathlib
R=pathlib.Path.cwd(); O=R/'cases/research-review/attempts/0001/outputs'; S=R/'cases/research-review/inputs/manuscript.md'; H=hashlib.sha256(S.read_bytes()).hexdigest()
rows=list(csv.DictReader((R/'cases/research-review/inputs/measurements.csv').open()))
for r in rows:
 b,c=float(r['baseline_ms']),float(r['candidate_ms']);r.update(speedup=b/c,latency_change_percent=100*(c/b-1))
(O/'recomputed.json').write_text(json.dumps(rows,indent=2))
def finding(i,cat,typ,sev,loc,evidence,impact,verify,repair,accept,status='confirmed'):
 return dict(finding_id=f'REV-F{i:03}',snapshot_id=H,category=cat,severity=sev,confidence='high',assertion_type=typ,status=status,location=dict(physical_page=None,printed_page=None,anchor=loc),evidence=evidence,why_it_matters=impact,verification=verify,resolution_options=repair,acceptance=accept,related_findings=[])
f=[finding(1,'correctness','confirmed_error','major','manuscript.md Abstract line 4; measurements.csv lines 2–5',['Abstract: 2x end-to-end speedup on every workload without any regression.','Recomputed baseline/candidate: small 1.25x, medium 1.20x, large 0.90909x; large latency increases 10%. Only kernel-only is 2x.'],'Core summary contradicts all three end-to-end observations.','Recompute each paired row and preserve scope; cross-check Appendix A.',['Replace universal 2x/no-regression claim with scoped observed values, including large regression.'],['Abstract, Results and Appendix agree with scope and all three end-to-end ratios.']),finding(2,'evidence','reporting_gap','major','Results line 8; Appendix A line 10',['One run per value; no independent repeats. Variance and quality unmeasured, explicitly stated.'],'Observed differences do not establish repeatable improvements or quality preservation. This is insufficient evidence, not evidence the observations are noise.','Determine intended generalization and correctness requirement; recover paired raw timing logs if they exist.',['Limit to one-run descriptive CPU observations.','If retaining repeatability claims, predefine independent sessions, interleaved/randomized matched pairs, timing scope, warmup and fixed stopping/precision plan using independent pilot variance; retain failures and all workloads. Test correctness/quality at a prespecified tolerance only if such a claim is retained.'],['Scope explicitly remains descriptive, or new independently collected evidence and precommitted analysis justify the revised claim without fabricated CI.']),finding(3,'reporting','suspected_error','minor','Appendix A line 10',['Appendix explicitly says large workload regresses from 200 ms to 220 ms.'],'Prevents false claim that authors hid or omitted regression. Abstract inconsistency remains REV-F001.','Read Appendix A against CSV large row.',['No repair for alleged missing disclosure; retain Appendix A.'],['Existing appendix and CSV directly refute missing-disclosure suspicion.'],status='rejected')]
(O/'findings.yaml').write_text(json.dumps(dict(schema_version='1.0',snapshot_id=H,findings=f),ensure_ascii=False,indent=2))
tasks=[]
for x in f:
 if x['status']=='rejected': continue
 prev=None
 for stage in ['verify','resolve','recheck']:
  n=f'REV-T{len(tasks)+1:03}';tasks.append(dict(task_id=n,finding_ids=[x['finding_id']],stage=stage,depends_on=[] if prev is None else [prev],owner='research-review' if stage=='recheck' else 'main_ai',preconditions=['Matching snapshot and evidence available' if stage=='verify' else 'Predecessor record available'],action={'verify':x['verification'],'resolve':'Use confirmed evidence to select minimal resolution; rejected means no edit. Missing data remains blocked.','recheck':'Read revised artifact at new hash and assess original acceptance conditions.'}[stage],outputs=[f'{stage}/{x["finding_id"]}.md'],done_when=x['acceptance'] if stage=='recheck' else ['Evidence and decision recorded'],on_missing_input='blocked; identify missing input, preserve finding',status='todo'));prev=n
(O/'task_chain.yaml').write_text(json.dumps(dict(tasks=tasks),ensure_ascii=False,indent=2))
(O/'task_chain.md').write_text('# 核验 → 处理 → 复查\n\n'+ '\n'.join(f'- {t["task_id"]} ({t["finding_ids"][0]}, {t["stage"]}): {t["action"]} 依赖：{t["depends_on"]}。' for t in tasks)+'\n\nREV-F003 已由附录反证撤销，不要求改稿。未执行任何修订或新实验。\n')
(O/'review_report.md').write_text('''# 材料内科学审阅

范围：完整 manuscript.md（含 Appendix A）及 measurements.csv；synthetic fixture，非公开论文。采用 provisional rubric：正确性、证据、可复现性及清晰度。无 venue/year/track；不评分、不预测录用。未修改输入，未联网、安装或启动新实验。

中性总结：作者替换一个内核，在相同 CPU 进程及输入配置下报告三个端到端计时和一个独立内核计时。每值仅一次运行。数据所支持的贡献是特定设置下 small/medium 观测延迟下降，large 观测延迟上升；内核独立计时减半。

优点：明确区分 kernel-only 与 end-to-end，说明前者包含于后者、不可相加；披露单次测量限制、未测 GPU、未测质量/方差，以及 large 退化。没有把 GPU 或其他硬件测量当作已执行。

| 工作负载 | baseline/candidate | 延迟变化 | 范围 |
|---|---:|---:|---|
| small | 1.25x | −20% | end-to-end |
| medium | 1.20x | −16.67% | end-to-end |
| large | 0.9091x | +10% | end-to-end |
| kernel | 2.00x | −50% | kernel-only |

主要问题：REV-F001 是已证实的摘要与数据矛盾。内核的 2x 不能推广到每个端到端工作负载；无需新增实验即可纠正。REV-F002 是超出单次描述性观察的证据边界，不代表数据虚假，也不意味着必须跑任意固定次数。若作者缩小范围，合理披露即可；若坚持可重复普遍收益，需有独立单位、前瞻精度/停止计划和公平配对的补测。

撤销疑点 REV-F003：原先检查“large 退化是否未报告”，完整阅读 Appendix A 后已反证，不保留该指控。摘要的错误仍独立成立。

可回答问题：摘要是否本意仅指 kernel-only？研究要声称固定 CPU 设置一次观察，还是跨 session 的可重复效果？是否希望主张功能/质量保持？答案决定 REV-F001/F002 的最小补救。质量没有测量不能变成“质量已下降”；未提供实现，不能判定实现错误。

贡献边界：替换内核的局部可行性只有合成材料内计时描述；最强可比替代是现有 baseline。无代码、配置细节或外部文献，创新性、维护成本及历史/当前领域地位均未核验。日期 2026-10-07；投稿截止和首发日期未知；按任务要求未进行最新检索（offline_fallback），不作“已被已有工作支配”的判断。

优先级：先核验并纠正 REV-F001，再决定 REV-F002 的主张范围或补证。全部修订、补实验与新快照复查尚未执行，交 main_ai；见 findings.yaml 与 task_chain.yaml。
''')
paths=['snapshot/config/role_registry.json','snapshot/workflows/agent_communication_workflow.md','snapshot/plugins/research-assistant/skills/research-review/SKILL.md','snapshot/plugins/research-assistant/skills/research-review/references/execution.md','snapshot/workflows/reviewer_workflow.md','snapshot/plugins/research-assistant/skills/research-review/references/workflow.md','snapshot/plugins/research-assistant/skills/research-review/references/measurement_evidence_contract.md','cases/research-review/task.txt','cases/research-review/inputs/manuscript.md','cases/research-review/inputs/measurements.csv']
(O/'provenance.json').write_text(json.dumps(dict(run_id=R.name,attempt='0001',mode='offline_fallback',loaded_files=[dict(path=p,sha256=hashlib.sha256((R/p).read_bytes()).hexdigest(),coverage='first 38 lines' if p.endswith('/references/workflow.md') else 'full; initial workflow truncation recovered relevant omitted section in subsequent reads' if p=='snapshot/workflows/reviewer_workflow.md' else 'full') for p in paths],tool_trace=['57ffc4: read skill/execution/workflow (workflow response truncated)','6b86ba: manuscript and CSV full; measurement contract full; workflow sections 4.2–4.3.1 and reference first 38 lines','8299ea: workflow section 4.3.2 remainder','build_review.py: deterministic per-row arithmetic; no CI or test fabricated'],limits=['No external novelty verification','No implementation audit','No independent performance trials','No durable inbox configured: file handoff to main_ai']),indent=2))

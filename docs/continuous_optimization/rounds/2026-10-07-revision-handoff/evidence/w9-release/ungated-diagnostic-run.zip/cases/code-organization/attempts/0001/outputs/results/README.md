# Results
alpha.json declares ALPHA/inconclusive; beta.json declares BETA/rejected.
These synthetic fixture declarations are not measured scientific evidence.
Each JSON names a script and input label; raw data and run provenance are absent.
active_tasks.json declares beta.json a running output; protect its path.
Do not move, delete or rewrite either result while lifecycle/consumers are unknown.
See CODEMAP.md and inventory.json in this delivery for exact source versions.

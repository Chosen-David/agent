"""Independent contract checks: endpoint-built windows + exact rational oracle."""
import copy
from fractions import Fraction
import importlib.util
import json
from pathlib import Path
import random
import sys

def load(path):
    spec = importlib.util.spec_from_file_location("tested", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.moving_average

def oracle(values, window):
    result = []
    for end in range(window, len(values) + 1):
        total = Fraction(0)
        for offset in range(window):
            total += Fraction(values[end - 1 - offset])
        result.append(float(total / window))
    return result

def check(fn):
    failures = []; checks = 0
    def case(values, window):
        nonlocal checks
        before = copy.deepcopy(values); expected = oracle(values, window)
        checks += 1
        try:
            actual = fn(values, window)
            assert actual == expected, (actual, expected)
            assert values == before, "input mutated"
        except Exception as e:
            failures.append({"values": repr(before), "window": window, "error": repr(e)})
    for values, window in [([1,2,3],2), ([7],1), ([1,2,3],3),([],1),([1],2),([1,2,3],1),([-4,-2,0,2],2),([0.5,1.5,2.5],2),((1,2,3),2),([10**20,1,-10**20],3)]:
        case(values, window)
    rng=random.Random(317)
    for _ in range(100):
        values=[rng.randint(-100,100) for _ in range(rng.randrange(20))]
        case(values, rng.randint(1,22))
    for window, exc in [(0,ValueError),(-1,ValueError),(1.5,TypeError),("2",TypeError),(None,TypeError),(True,TypeError),(False,TypeError)]:
        checks += 1
        values=[1,2,3]; before=values.copy()
        try:
            fn(values,window)
        except exc:
            if values != before: failures.append({"invalid":repr(window),"error":"input mutated"})
        except Exception as e:
            failures.append({"invalid":repr(window),"error":repr(e),"expected":exc.__name__})
        else:
            failures.append({"invalid":repr(window),"error":"missing error","expected":exc.__name__})
    return {"checks":checks,"failures":failures,"passed":not failures}

if __name__ == "__main__":
    result=check(load(Path(sys.argv[1])))
    print(json.dumps(result,indent=2))
    sys.exit(0 if result["passed"] else 1)

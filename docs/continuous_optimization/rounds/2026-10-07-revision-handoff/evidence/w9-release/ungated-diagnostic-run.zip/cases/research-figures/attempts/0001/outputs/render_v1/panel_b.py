"""Editable performance panel. Values are synthetic supplied observations."""
import numpy as np

def draw(ax,rows):
    names=[r['workload'] for r in rows]; ys=np.arange(len(rows))
    baseline=[float(r['baseline_ms']) for r in rows]; candidate=[float(r['candidate_ms']) for r in rows]
    ax.barh(ys-.17,baseline,height=.3,color='#657a8c',label='Baseline')
    ax.barh(ys+.17,candidate,height=.3,color='#d79446',hatch='///',label='Candidate')
    for i,(b,c) in enumerate(zip(baseline,candidate)):
        ax.text(b+3,i-.17,f'{b:g}',va='center',fontsize=8)
        ax.text(c+3,i+.17,f'{c:g}',va='center',fontsize=8)
    ax.set_yticks(ys,names); ax.invert_yaxis(); ax.set_xlim(0,250)
    ax.axhline(2.5,color='#84919d',lw=.8,ls='--')
    ax.set_xlabel('Latency (ms; lower is better)',fontsize=8.5)
    ax.set_title('B  Supplied performance values',loc='left',fontsize=11,weight='bold',pad=36)
    ax.text(0,1.075,'Synthetic • no repeat / uncertainty information',transform=ax.transAxes,fontsize=8,color='#52677c')
    ax.text(.99,.275,'End-to-end above / kernel-only below',transform=ax.transAxes,ha='right',fontsize=7.5,color='#52677c')
    ax.legend(loc='lower right',bbox_to_anchor=(1,-.39),frameon=False,ncol=2,fontsize=8)
    ax.tick_params(labelsize=8,length=0); ax.xaxis.grid(True,color='#e7ebef'); ax.set_axisbelow(True)
    for side in ('top','right','left'): ax.spines[side].set_visible(False)
    ax.spines['bottom'].set_color('#9ba7b2')

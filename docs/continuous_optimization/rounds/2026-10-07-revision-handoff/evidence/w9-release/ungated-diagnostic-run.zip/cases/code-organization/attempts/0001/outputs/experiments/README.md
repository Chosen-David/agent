# Experiments
Read-only documentation fixtures: alpha.py and beta.py.
Both are declared active in active_tasks.json; do not execute or move.
Comments name synthetic-x/y labels and results/alpha.json or beta.json.
Actual data, execution history and owning people are unknown.
See CODEMAP.md and inventory.json in this delivery for mapping and hashes.

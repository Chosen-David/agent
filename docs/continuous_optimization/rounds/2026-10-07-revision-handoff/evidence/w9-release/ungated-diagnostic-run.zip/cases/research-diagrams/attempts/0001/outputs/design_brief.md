# FIG-method design brief

Purpose: show that two parallel logits merge before softmax while fixed values bypass it and join only at output. The source is a proposed synthetic specification, not an implementation.

Use a single SVG panel with a three-column left-to-right upper data path and a lower V bypass. A/B have matching size and horizontal alignment; no connector between them. The merge and softmax sit at the same height; the softmax arrow descends into the output, and V approaches output from the left. This exposes all five edges without line crossings. No boundary boxes imply hardware or privacy partitions. Uniform pale blue nodes and dark slate arrows; text and spatial identity carry meaning, not color. Use stable node/edge IDs, editable text and vector paths, DejaVu Sans 17 px labels, 24 px title, 15 px status/legend. Canvas 900 × 520, provisional 7.5 × 4.333 inches; no venue supplied.

Source IDs and original labels map one-to-one to SVG group IDs. No extra module, timing annotation, accuracy claim or model execution. Alternative long horizontal chain rejected because it would misstate A/B parallelism. No external exemplars provided; network prohibited; external exemplar learning not run. Only author self-review, no independent reader/delegation.

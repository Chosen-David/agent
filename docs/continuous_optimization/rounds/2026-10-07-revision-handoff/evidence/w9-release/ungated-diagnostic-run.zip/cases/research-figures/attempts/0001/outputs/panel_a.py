"""Editable method panel; all five edges come from architecture.json."""
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

def draw(ax, spec):
    ax.set(xlim=(0,10),ylim=(0,7)); ax.axis('off')
    pos={'a':(1.8,5.0),'b':(1.8,3.2),'sum':(5.0,4.1),'softmax':(8.15,4.1),'v':(5.0,1.5),'output':(8.15,1.5)}
    w,h=2.6,.88
    for node in spec['nodes']:
        x,y=pos[node['id']]
        box=FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=0.02,rounding_size=0.1',facecolor='#edf1f5',edgecolor='#52677c',lw=.85)
        box.set_gid('node-'+node['id']); ax.add_patch(box)
        ax.text(x,y,node['label'],ha='center',va='center',fontsize=8.5,color='#23354a')
    for u,v in spec['edges']:
        x,y=pos[u]; xx,yy=pos[v]
        if x==xx: start=(x,y-h/2); end=(xx,yy+h/2)
        else: start=(x+w/2,y); end=(xx-w/2,yy)
        arr=FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=10,lw=1,color='#52677c',shrinkA=3,shrinkB=3)
        arr.set_gid('edge-'+u+'-'+v); ax.add_patch(arr)
    ax.text(0,6.55,'A  Two-path logit combination',fontsize=11,weight='bold',color='#23354a')
    ax.text(0,6.0,'Proposed schematic • not implemented',fontsize=8,color='#52677c')
    ax.text(0,.18,'Arrows: data flow. V enters only the output.',fontsize=8,color='#52677c')

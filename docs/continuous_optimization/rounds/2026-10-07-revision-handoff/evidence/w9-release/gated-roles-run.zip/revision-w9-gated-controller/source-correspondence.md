# Independent material source correspondence

All observations belong to the fresh pre-dispatch gated-run material review, not an evaluation of old or future worker outputs. Exact task/rubric copies and source evidence are saved alongside. Only supplied data and frozen corpus were used; no network or installation.

## research-assistant
project.json states collect and figure done at measurements v1; write is todo and depends on figure; background is done using concept v1. Change is measurements v2. Invalidate dependent v1 figure use, revalidate current data, regenerate affected figure and update pending write's input. Background stays valid. The rubric's reference to dependent write outputs is a scope dependency, not evidence that a write artifact already exists. Historical collect/v1 records remain; no invented new execution. CPU-only bounded analysis and acyclic dependency/acceptance plan are coherent task requirements.

## code-reading
The actual source is static-only and was read in full, never imported or executed. represent returns dimensions0,2 by default; optional basis is passed data, not trained. select computes reduced scores for every key before skip_far can suppress far candidate selection. near_len defines boundary/candidate interval; forced suffix is separately computed and can exceed intended budget in unchecked inputs. near sorts range(boundary,max(boundary,n-forced_len)); selection concatenates far, bounded near and forced. run then calls full_score with original query/keys/positions. full_score uses zip, so full-vector meaning presumes compatible dimensions; mismatched lengths truncate silently. Negative/oversized parameters are not validated. These qualifications should not be penalized as contradiction of default/scoped criteria.

## code-reading boundaries
Static caller/data edges are run→select→represent and run→full_score, with input options controlling branches. The docstring is a deliberately misleading claim, not the oracle. No target execution, latency or quality result is supported.

## code-organization
alpha.py comments identify ALPHA/synthetic-x/results/alpha.json, whose JSON points back to experiments/alpha.py and inconclusive. beta.py similarly identifies BETA/synthetic-y/results/beta.json with rejected. active_tasks marks both scripts active, beta.json a running output, and orphan.txt protected. orphan.txt explicitly lacks provenance. HIST-0 stays as the first historical CODEMAP row with missing/unknown qualifiers; archived/missing.py is a declared historical anchor, not a file found to exist. No duplicate is established by the fixture. The requirement to propose safe duplicate/orphan handling cannot demand invented duplicates or actual moves. README limit and incremental order are explicit task instructions.

## scientific fixtures
Measurements: small100→80, medium120→100, large200→220ms end-to-end; kernel20→10ms kernel-only. The manuscript Results says kernel time is already included in end-to-end and each value is one run; Appendix A discloses large regression and unmeasured quality/variance. The Abstract remains false. CSV-only figure roles still cannot invent error bars or statistical reliability because no repeats/error data are provided.

Architecture JSON declares six nodes and five exact edges; V bypasses softmax. Status proposed and synthetic/not-implemented disallow empirical claims. Mixed panel task requires no independent subagents; explicit integration ownership is consistent with the shared figure contract.

## mathematical scopes
Softmax Jacobian is local and fixed-V; exact finite example separately yields5→7.5. Independent path assessment cannot ignore joint normalized weights. Common equal shift leaves softmax unchanged. No RoPE-specific evidence exists in concept or PDF.

For knowledge task, frozen bundled topk-margin plus cauchy-schwarz yields per-score≤.06 and conservative sufficient gap>.12; these are sufficient rather than sharp. The .08 case is not settled: zero perturbation preserves, an explicitly computed rank-one matrix perturbation with operator norm.03 reverses two scores. Symmetry requires objective/constraints invariant; one job10 work units on speeds10 versus1 takes1 versus10. Merely swapping assignments is not full relabeling of all machine attributes.

## calibration
No criterion requires a particular prose format beyond requested artifacts, a unique travel itinerary, fabricated grading scores, invented layout defects, independent model agents prohibited by task, or empirical results not present. No future-produced artifact has been read. Source inspection/retrieval and numerical oracles support materials; they do not satisfy workers' later execution obligations.

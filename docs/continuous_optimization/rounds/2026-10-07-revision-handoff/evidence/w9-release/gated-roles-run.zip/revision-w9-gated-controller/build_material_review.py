"""Serialize the independent review's explicitly assessed criterion correspondences."""
from pathlib import Path
import json, hashlib, importlib.util, shutil, sys
from datetime import datetime, timezone
sys.dont_write_bytecode=True
RUN=Path('/workspace/scratch/c12f3d9f92bd/revision-w9-gated-roles-run')
OUT=Path(__file__).resolve().parent
REPO=Path('/workspace/scratch/c12f3d9f92bd/agent')
spec=importlib.util.spec_from_file_location('pipeline',REPO/'scripts/agent_eval_pipeline.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
manifest,errors=p.verify_run(RUN)
assert not errors and manifest['require_material_review'] is True
assert not list(RUN.glob('cases/*/attempts/*')), 'Review must finish before dispatch'
assert p.digest((RUN/'manifest.json').read_bytes())=='c29e266184accafab5e8271e74fa5e6cda00276797a3e482c7bbdd1a2fd36056'
tasks=p.read(RUN/'tasks.json');rubric=p.read(RUN/'rubric.json')['criteria']
# Independent controller evidence copies stay outside the worker run.
for name in ('manifest.json','tasks.json','rubric.json'):
 (OUT/('frozen-'+name)).write_bytes((RUN/name).read_bytes())
for case in tasks['cases']:
 cid=case['id'];dest=OUT/'sources'/cid;dest.mkdir(parents=True,exist_ok=True)
 (dest/'task.txt').write_bytes((RUN/'cases'/cid/'task.txt').read_bytes())
 for src in (RUN/'cases'/cid/'inputs').rglob('*'):
  if src.is_file():
   dst=dest/'inputs'/src.relative_to(RUN/'cases'/cid/'inputs');dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
for rel in ['workflows/figure_shared.md','plugins/research-assistant/skills/model-with-knowledge/SKILL.md']:
 src=RUN/'snapshot'/rel;dest=OUT/'sources/snapshot'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes())

def ref(rel,location):
 f=OUT/rel
 return {'path':f'revision-w9-gated-controller/{rel}','sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'location':location}
def task(cid):return ref(f'sources/{cid}/task.txt','full exact frozen task prompt')
def inp(cid,n,loc):return ref(f'sources/{cid}/inputs/{n}',loc)
def oracle(loc):return ref('oracle-results.json',loc)
def srcnotes(loc):return ref('source-correspondence.md',loc)
def row(kind,verification,reason,*evidence):return {'kind':kind,'status':'supported','verification':verification,'reason':reason,'evidence':list(evidence)}
F=lambda reason,*ev:row('factual','source_review',reason,*ev)
N=lambda reason,*ev:row('factual','executable_oracle',reason,*ev)
B=lambda reason,*ev:row('behavioral','task_requirement',reason,*ev)
rows={}
cid='research-assistant'
rows[cid]=[
 F('project.json changes measurements v1→v2; figure depends on collect and consumes v1, while pending write depends on figure and consumes v1. Background consumes unchanged concept v1. Invalidate stale dependent use and plan v2 figure/write; do not invent an already-produced write artifact (write is todo).',inp(cid,'project.json','state[collect,figure,write,background], change'),srcnotes('research-assistant')),
 B('Task requires executable dependencies and acceptance using only available analysis; fixture budget is CPU only/no service or GPU. An acyclic bounded plan and no completed descendant of blocked/skipped work are coherent acceptance constraints, without requiring fictional new runs.',task(cid),inp(cid,'project.json','goal,budget,state')),
 B('The task explicitly prohibits invented experiments; delivery status and proposed roles must stay distinct from executed work.',task(cid))]
cid='research-explore'
rows[cid]=[
 N('CSV yields kernel-only 20/10=2, versus end-to-end 1.25,1.2,10/11; manuscript says kernel timing is included in end-to-end paths, so adding it is wrong.',oracle('measurement_rows'),inp(cid,'manuscript.md','Results'),inp(cid,'measurements.csv','all four rows')),
 B('Task explicitly asks mechanism, strongest alternative explanation, minimal discriminating experiment, primary metric and resource bound. Criterion does not prescribe a hidden rival or require unperformed experiments.',task(cid)),
 B('Task asks stopping/resources and forbids novelty claims on synthetic local materials; conditional go/pivot/stop is an appropriate decision form.',task(cid))]
cid='research-implement-optimize'
rows[cid]=[
 N('Supplied docstring requires every full consecutive window and no mutation; independent specification yields [1.5,2.5], full-window [2], empty/oversize []; invalid nonpositive/noninteger windows violate the contract. Do not require one exact exception class or boolean policy beyond stated rubric.',oracle('moving_average_specification_cases,moving_boundary'),inp(cid,'buggy.py','docstring and range(len(values)-window) implementation')),
 B('Task explicitly requires independent correctness checks actually run and unchanged input. The oracle here supports expected facts, not the future worker execution requirement.',task(cid)),
 N('CSV large row is 200→220 ms, +10% latency; task explicitly prohibits GPU or invented performance experiments.',oracle('measurement_rows[2]'),task(cid),inp(cid,'measurements.csv','large row'))]
cid='research-figures'
rows[cid]=[
 B('Task specifies method+result mixed panels, routing and whole-image QA, prohibits independent subagents. Shared figure contract has a single final integration owner; do not claim uninvoked producers.',task(cid),ref('sources/snapshot/workflows/figure_shared.md','§2 图与panel交接契约: route,owner,panels')),
 N('Two scopes are explicit in four measurement rows; architecture has exactly a,b,sum,softmax,v,output and five declared directed edges. Panels A/B must preserve these independent inputs.',oracle('measurement_rows,architecture'),inp(cid,'architecture.json','nodes,edges,constraints'),task(cid)),
 B('Task requests editable panel and whole-figure sources, SVG/PNG, caption, and actual final-image opening; these are observable deliverable/action requirements, not claims already satisfied.',task(cid))]
cid='research-write'
rows[cid]=[
 N('Only independently timed kernel is 2x; end-to-end small/medium improve less and large regresses. Abstract all-workload 2x claim contradicts exact rows.',oracle('measurement_rows'),inp(cid,'manuscript.md','Abstract,Results')),
 N('Large workload 200→220 ms explicitly appears in CSV and Appendix A and must remain in results/abstract discussion.',oracle('measurement_rows[2]'),inp(cid,'manuscript.md','Appendix A')),
 F('Task requests a claim-evidence table; manuscript Results states one run/no repeats and Appendix A states no quality or variance measurement. Scope is paragraph+abstract, not a full new paper/PDF.',task(cid),inp(cid,'manuscript.md','Results and Appendix A'))]
cid='research-review'
rows[cid]=[
 N('The abstract universal no-regression 2x end-to-end assertion conflicts with 1.25x/1.2x/10÷11x end-to-end and separately timed kernel 2x.',oracle('measurement_rows'),inp(cid,'manuscript.md','Abstract')),
 F('Appendix A literally discloses 200→220 ms large regression, so accusing omission is factually unsupported even though Abstract remains wrong.',inp(cid,'manuscript.md','Appendix A')),
 B('Task asks located evidence and verification tasks, permits withdrawing answered suspicions, prohibits unsupported acceptance probability. No mandatory finding count or numerical score is imposed.',task(cid))]
cid='research-read-pdf'
rows[cid]=[
 F('Actual final PDF contains three physical pages. Reviewer rendered and personally viewed all three; worker must still perform its own requested page opening/read.',ref('pdf-inspection.json','page_count and visual_observations'),task(cid)),
 F('Physical page 3 is Appendix; physical labels differ from printed i/1/A1. Exact PDF hash is frozen and coverage should bind that hash and physical indices.',ref('pdf-inspection.json','pdf_sha256,page_labels'),task(cid)),
 F('Physical page 2 asserts universal RoPE error amplification; page 3 states invented teaching example/no RoPE experiment, so overgeneralization is real. Viewed pages are legible with no observed overlap; do not demand or invent a layout defect.',ref('pdf-inspection.json','visual_observations pages 2 and 3'),ref('pdf-page-2.png','entire physical page 2'),ref('pdf-page-3.png','entire physical page 3'))]
cid='paper-reading-companion'
rows[cid]=[
 N('Original physical page 2 values yield weights .5/.5→.25/.75 and output 5→7.5; page 3 denies any RoPE-specific empirical evidence. Exact toy arithmetic cannot establish universality.',oracle('softmax'),ref('pdf-inspection.json','physical page 2/3 text and observations')),
 B('User specifically requests physical page 2 and saving current position/notes; bind these to the actual PDF hash, not printed page 1 or a different file.',task(cid),ref('pdf-inspection.json','pdf_sha256,page_labels')),
 B('Task requests offline two-column reading HTML and does not authorize backend installation. Require an actual artifact and honest offline scope; no whole-paper review required.',task(cid))]
cid='explain-research-concepts'
rows[cid]=[
 N('Given b changes to (0,log3), exp logits normalize 1:3; independently computed weights and weighted outputs exactly match criterion.',oracle('softmax'),inp(cid,'concept.txt','example')),
 N('For fixed V and z=a+b, dp=(diag(p)-pp^T)dz and dy=V^T dp; baseline Jacobian [[1/4,-1/4],[-1/4,1/4]] gives derivative [-2.5,2.5]. Scope is local first-order and excludes varying V; finite example computed exactly.',oracle('softmax.jacobian_at_before,dy_dz_at_before,fixed_V_local_derivative'),inp(cid,'concept.txt','fixed value matrix teaching model')),
 F('Input explicitly says teaching model, not a paper; no RoPE model/data appear. A common shift leaves softmax unchanged, also excluding universal amplification from this setup.',inp(cid,'concept.txt','opening and question'),oracle('softmax.common_shift_output'))]
cid='travel-planner'
rows[cid]=[
 N('Independent feasible witnesses satisfy availability 11–18, 60-minute lunch entirely within 10:30–14:30 and before last order, and fixed 16–17 photo for both 20/35-minute legs. These witness times are not a required unique itinerary.',oracle('travel.schedules'),inp(cid,'travel.json','available,lunch,photo,amendment')),
 N('Witnesses allocate an uninterrupted 75-minute hotel rest separate from travel, with explicit hotel→lunch→hotel→photo→hotel legs in both plans; revised rest ends14:25 before15:25 departure.',oracle('travel.schedules'),inp(cid,'travel.json','rest,commute,amendment')),
 N('Two-person meals160–200 plus one group photo300 plus four one-vehicle fares60–100 total520–600 for that route; duration amendment supplies no price change. Other valid routes may have correctly counted different legs. User-confirmed appointment is a fixture fact, not assistant-made booking.',oracle('travel.four_leg_two_person_budget,travel.assumption'),inp(cid,'travel.json','people and price/unit fields; amendment'),task(cid))]
cid='research-data-visualization'
rows[cid]=[
 N('All four rows and two timing scopes exist; large end-to-end200→220ms is a regression. Do not merge kernel with end-to-end or omit unfavorable row.',oracle('measurement_rows'),inp(cid,'measurements.csv','rows 1–4')),
 F('Only one value per method/workload is supplied, with no replicates, error columns or distribution. The task forbids new statistical analysis; no uncertainty or reliability is established by these inputs.',inp(cid,'measurements.csv','header and all rows'),task(cid)),
 B('Task explicitly requests editable source, SVG/PNG, caption and actual final-figure opening with numerical/visual checks.',task(cid))]
cid='research-diagrams'
rows[cid]=[
 N('Independent JSON check finds six stable node IDs and exactly edges a→sum,b→sum,sum→softmax,softmax→output,v→output. V never enters softmax.',oracle('architecture.nodes,architecture.edges'),inp(cid,'architecture.json','nodes,edges,constraints')),
 F('Input status is proposed and evidence_type says synthetic/not implemented; neither performance nor model accuracy is provided.',inp(cid,'architecture.json','status,evidence_type,constraints')),
 B('Task requests editable SVG, PNG, caption, node/edge contract and actual rendering/opening. No model execution or online lookup is required.',task(cid))]
cid='code-reading'
rows[cid]=[
 F('Module narrative asserts forced near, no scoring when skipped, query-trained projection and reduced final scoring. Functions contradict each claim; require source lines rather than treating docstring as authority.',inp(cid,'synthetic_selector.py','module lines1–3 versus represent6–9,full_score12–13,select16–25,run28–30'),srcnotes('code-reading')),
 F('represent default returns vector[0],vector[2]; optional basis is caller supplied, no learning routine. run passes original query/keys into full_score, which dots full zipped vectors at selected positions.',inp(cid,'synthetic_selector.py','represent6–9;full_score12–13;run28–30')),
 F('boundary=n-near_len clipped0 partitions candidate ranges; forced suffix separately uses forced_len. skip_far empties far but scores already computed for every key, near still sorted and full_score still called.',inp(cid,'synthetic_selector.py','select19–25;run28–30')),
 B('Task demands conditional call/data edges, line evidence and read-only static analysis; prohibits executing target or labeling static inference performance measurement.',task(cid),srcnotes('code-reading boundaries'))]
cid='code-organization'
rows[cid]=[
 F('ALPHA/BETA script comments and result JSON explicitly cross-reference each other. HIST-0 contains an archived/missing.py path anchor but unknown evidence and must stay unknown; orphan declares no provenance. Do not pretend missing.py exists or assign orphan to an experiment.',inp(cid,'organization/CODEMAP.md','HIST-0 row'),inp(cid,'organization/results/alpha.json','script,input,result'),inp(cid,'organization/results/beta.json','script,input,result'),inp(cid,'organization/notes/orphan.txt','full text'),srcnotes('code-organization')),
 B('Task explicitly limits each necessary directory README to at most10 lines; does not require README for every possible folder.',task(cid)),
 F('active_tasks lists both scripts, running results/beta.json and protected notes/orphan.txt. Task allows proposal only/no moves or deletion; no duplicate fixture is established, so valid no-duplicate finding should pass rather than invent one.',inp(cid,'organization/active_tasks.json','all fields'),task(cid),srcnotes('code-organization')),
 B('Task expressly requests incremental CODEMAP retaining historical row order and an inspectable proposal. Preserve HIST-0 first; append grounded mappings without claiming nonexistent history.',task(cid),inp(cid,'organization/CODEMAP.md','existing table and HIST-0 row'))]
cid='model-with-knowledge'
rows[cid]=[
 F('Actual offline searches of frozen bundled corpus return topk-margin and symmetry-quotient; show topk includes prerequisite cauchy-schwarz and content-pinned closure refs. Source interface is executable and available. Future worker must perform own retrieval, not copy this review.',ref('knowledge-source-read.json','two actual searches and three show responses'),ref('sources/snapshot/plugins/research-assistant/skills/model-with-knowledge/SKILL.md','按需读取 items1–4'),task(cid)),
 N('||E^Tq||∞≤||E||2||q||2≤.03×2=.06; per-item bound gives conservative sufficient gap>.12. .15 qualifies. .08 can preserve for E=0 or flip under the recorded rank-one E with spectral norm.03, so it is undecided, not necessarily failure. Stronger valid bounds may also be discussed.',oracle('knowledge'),ref('knowledge-source-read.json','show math.topk-margin and math.cauchy-schwarz')),
 N('Symmetry entry requires objective/feasibility invariance. One job of work10 on speed10 or speed1 machines takes1 versus10; swapping assignment labels alone changes objective. Full renaming of physical attributes is distinct. No speed measurement/formal proof follows.',oracle('knowledge.machine_counterexample'),ref('knowledge-source-read.json','show math.symmetry-quotient'),task(cid))]

assert set(rows)==set(rubric)
cases={}
for cid,criteria in rubric.items():
 assert len(criteria)==len(rows[cid]),cid
 cases[cid]=[dict(criterion=criterion,**record) for criterion,record in zip(criteria,rows[cid])]
review={'schema_version':1,'reviewer_actor':'/root/w9_release_audit','reviewed_at':datetime.now(timezone.utc).isoformat(),
 'review_phase':'independent_pre_dispatch_material_review','material_hashes':p.material_bindings(RUN,manifest),
 'cases':cases,'scope':'Actual material correspondence review before any gated-run start; no future output read, no worker dispatch, no prior grades used as material truth. Supported means a legitimate task/input criterion, not a worker pass.',
 'calibration_notes':['research-assistant write is todo: do not invent already-produced stale output','0.12 is sufficient not tight; 0.08 undecided','travel witnesses not unique route requirement; budget follows actual legs','organization duplicate/orphan claims require evidence; no forced duplicate','moving-average exception type and bool policy are not extra frozen clauses'],
 'unsupported_criteria':[]}
target=OUT/'material-review.json';target.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
trust={'path':'revision-w9-gated-controller/material-review.json','sha256':p.digest(target.read_bytes()),'reviewer_actor':review['reviewer_actor']}
# Read-only schema/binding validation; parent must authorize each actual worker.
p.check_material_review(RUN,manifest,'/root/material-validation-only',trust)
assert not list(RUN.glob('cases/*/attempts/*'))
(OUT/'material-review-validation.json').write_text(json.dumps({'observed_at':datetime.now(timezone.utc).isoformat(),'trust':trust,'cases':len(cases),'criteria':sum(map(len,cases.values())),'verify_run_errors':errors,'attempt_directories':0,'schema_binding_check':'passed','dispatch_authorization_performed':False},indent=2)+'\n')
print(json.dumps(trust,indent=2));print('criteria',sum(map(len,cases.values())))

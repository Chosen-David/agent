"""Independent pre-dispatch material facts; never executes supplied target code."""
import csv, json, math, hashlib
from pathlib import Path
from fractions import Fraction as F
ROOT=Path('/workspace/scratch/c12f3d9f92bd/revision-w9-gated-roles-run')
OUT=Path(__file__).resolve().parent
rows=list(csv.DictReader((ROOT/'cases/research-assistant/inputs/measurements.csv').open()))
measure=[]
for r in rows:
 b,c=F(r['baseline_ms']),F(r['candidate_ms'])
 measure.append(dict(r,speedup=str(b/c),latency_reduction=str((b-c)/b)))
assert [x['speedup'] for x in measure]==['5/4','6/5','10/11','2']
assert len(rows)==4 and rows[-1]['scope']=='kernel_only'
weights0=[F(1,2),F(1,2)];weights1=[F(1,4),F(3,4)]
outputs=[sum(p*v for p,v in zip(w,[0,10])) for w in [weights0,weights1]]
assert outputs==[5,F(15,2)]
J=[[weights0[i]*(int(i==j)-weights0[j]) for j in range(2)] for i in range(2)]
dy=[sum(F(v)*J[i][j] for i,v in enumerate([0,10])) for j in range(2)]
assert dy==[F(-5,2),F(5,2)]
# Common logit shifts are a counterexample to any universal amplification.
common_shift=[math.exp(2)/(2*math.exp(2))]*2
assert common_shift==[.5,.5]
epsilon=F(2)*F(3,100);gap_threshold=2*epsilon
assert epsilon==F(6,100) and gap_threshold==F(12,100) and F(15,100)>gap_threshold
# This rank-one matrix perturbation satisfies the operator-norm bound jointly.
E=[-.03/math.sqrt(2),.03/math.sqrt(2)];spectral=math.sqrt(sum(x*x for x in E))
newscore=[.08+2*E[0],2*E[1]]
assert spectral<=.030000000001 and newscore[0]<newscore[1]
def specification(values,window):
 if type(window) is not int or window<=0:raise ValueError('positive integer required')
 return [sum(values[i:i+window])/window for i in range(max(0,len(values)-window+1))]
moving=[]
for values,window,expected in [([1,2,3],2,[1.5,2.5]),([1,2,3],3,[2]),([],1,[]),([1],2,[]),([1],1,[1])]:
 before=values.copy();actual=specification(values,window);assert actual==expected and values==before;moving.append({'values':values,'window':window,'expected':expected})
for invalid in [0,-1,1.5,True]:
 try:specification([1,2,3],invalid)
 except ValueError:pass
 else:raise AssertionError(invalid)
travel=json.loads((ROOT/'cases/travel-planner/inputs/travel.json').read_text())
def hh(m):return f'{m//60:02}:{m%60:02}'
schedules=[]
for leg in [20,35]:
 lunch_start=660+leg;lunch_end=lunch_start+60;rest_start=lunch_end+leg;rest_end=rest_start+75;photo_depart=960-leg
 assert lunch_start>=630 and lunch_start<=840 and lunch_end<=870 and rest_end<=photo_depart and 1020+leg<=1080
 schedules.append({'leg_minutes':leg,'hotel_to_lunch':[hh(660),hh(lunch_start)],'lunch':[hh(lunch_start),hh(lunch_end)],'lunch_to_hotel':[hh(lunch_end),hh(rest_start)],'independent_hotel_rest':[hh(rest_start),hh(rest_end)],'hotel_to_photo':[hh(photo_depart),'16:00'],'photo':['16:00','17:00'],'photo_to_hotel':['17:00',hh(1020+leg)],'unallocated_wait_minutes':photo_depart-rest_end})
budget=[travel['people']*travel['lunch']['price'][i]+travel['photo']['price'][i]+4*travel['commute']['vehicles']*travel['commute']['each_leg_price'][i] for i in [0,1]]
assert budget==[520,600]
arch=json.loads((ROOT/'cases/research-diagrams/inputs/architecture.json').read_text())
assert len(arch['nodes'])==6 and len(arch['edges'])==5 and ['v','output'] in arch['edges'] and ['v','softmax'] not in arch['edges']
result={'measurement_rows':measure,'softmax':{'weights_before':list(map(str,weights0)),'weights_after':list(map(str,weights1)),'outputs':list(map(str,outputs)),'jacobian_at_before':[[str(x) for x in row] for row in J],'dy_dz_at_before':list(map(str,dy)),'fixed_V_local_derivative':'dy = V^T (diag(p)-p p^T) (da+db), no dV term; finite changes need exact recomputation','common_shift_output':5},'knowledge':{'per_score_bound':str(epsilon),'conservative_sufficient_gap':str(gap_threshold),'gap_0.15':'guaranteed','gap_0.08':'undecided: zero perturbation preserves, admissible rank-one perturbation can flip','flip_operator_norm':spectral,'flip_scores':newscore,'machine_counterexample':{'one_job_work':10,'speed_fast':10,'speed_slow':1,'fast_time':1,'slow_time':10}},'moving_average_specification_cases':moving,'moving_boundary':'positive integer required; exception type need not match this oracle; bool rejection is sensible extra strictness, not an independently mandatory rubric clause','travel':{'schedules':schedules,'four_leg_two_person_budget':budget,'assumption':'Same supplied fare per vehicle per leg under duration amendment; no real booking or new price quote; these are feasible witnesses, not unique itineraries'},'architecture':arch,'target_code_executed':False}
(OUT/'oracle-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))

"""Original bounded semantic witnesses, not copied upstream code or benchmarks."""
import bisect,json,itertools
from pathlib import Path
IDS='ABCD'; E=(float('inf'),len(IDS))
class Heap:
 def __init__(self): self.a=[];self.pos={}
 def swap(self,i,j):
  self.a[i],self.a[j]=self.a[j],self.a[i];self.pos[self.a[i][1]]=i;self.pos[self.a[j][1]]=j
 def fix(self,i):
  while i and self.a[i]<self.a[(i-1)//2]:self.swap(i,(i-1)//2);i=(i-1)//2
  while 2*i+1<len(self.a):
   j=2*i+1
   if j+1<len(self.a) and self.a[j+1]<self.a[j]:j+=1
   if self.a[i]<=self.a[j]:break
   self.swap(i,j);i=j
 def set(self,k,p):
  if k in self.pos:
   i=self.pos.pop(k);last=self.a.pop()
   if i<len(self.a):self.a[i]=last;self.pos[last[1]]=i;self.fix(i)
  if p is not None:self.pos[k]=len(self.a);self.a.append((p,k));self.fix(len(self.a)-1)
 def peek(self):return self.a[0] if self.a else E
class Ordered:
 def __init__(self):self.a=[];self.old={}
 def set(self,k,p):
  if k in self.old:self.a.remove((self.old.pop(k),k))
  if p is not None:bisect.insort(self.a,(p,k));self.old[k]=p
 def peek(self):return self.a[0] if self.a else E
class Segment:
 def __init__(self,n,op=min,e=E):
  self.n=n;self.size=1;self.op=op;self.e=e
  while self.size<n:self.size*=2
  self.a=[e]*(2*self.size)
 def set(self,k,v):
  if not 0<=k<self.n:raise IndexError('fixed slot domain')
  i=self.size+k;self.a[i]=v;i//=2
  while i:self.a[i]=self.op(self.a[2*i],self.a[2*i+1]);i//=2
 def prod(self,l,r):
  if not 0<=l<=r<=self.n:raise IndexError('half-open range')
  l+=self.size;r+=self.size;left=right=self.e
  while l<r:
   if l%2:left=self.op(left,self.a[l]);l+=1
   if r%2:r-=1;right=self.op(self.a[r],right)
   l//=2;r//=2
  return self.op(left,right)
 def peek(self):return self.a[1]
def display(t):return None if t==E else {'priority':t[0],'task_id':IDS[t[1]]}
h=Heap();o=Ordered();s=Segment(4);oracle={};rows=[]
ops=[('A',5),('B',2),('C',2),('D',9),('B',8),('D',1),('A',1),('A',None),('D',10),('B',None),('C',None),('D',None),('C',-3)]
for task,p in ops:
 k=IDS.index(task)
 if p is None:oracle.pop(k,None)
 else:oracle[k]=p
 h.set(k,p);o.set(k,p);s.set(k,E if p is None else(p,k))
 expect=min(((v,i) for i,v in oracle.items()),default=E)
 assert h.peek()==o.peek()==s.peek()==expect
 assert all(h.pos[t[1]]==i for i,t in enumerate(h.a))
 rows.append({'set':[task,p],'minimum':display(expect),'all_three_equal_oracle':True})
 for l in range(5):
  for r in range(l,5):assert s.prod(l,r)==min(((v,i) for i,v in oracle.items() if l<=i<r),default=E)
before=s.a[:]
try:s.set(4,(0,4));raise AssertionError('accepted new ID')
except IndexError:pass
assert s.a==before
c=Segment(5,lambda a,b:a+b,'')
for i,x in enumerate('abcde'):c.set(i,x)
assert c.prod(0,3)=='abc' and c.prod(1,5)=='bcde' and c.prod(2,2)==''
# Deliberately reversed right accumulation: a plausible false commutativity assumption.
def wrong(l,r):
 l+=c.size;r+=c.size;left=right=''
 while l<r:
  if l%2:left+=c.a[l];l+=1
  if r%2:r-=1;right+=c.a[r]
  l//=2;r//=2
 return left+right
wrong_value=wrong(0,3);assert wrong_value=='cab' and wrong_value!=c.prod(0,3)
values=[E,(-3,0),(1,1),(1,2),(9,3)]
assert all(min(min(a,b),d)==min(a,min(b,d)) for a,b,d in itertools.product(values,repeat=3))
assert all(min(a,E)==min(E,a)==a for a in values)
result={'status':'pass','trace':rows,'range_oracle_checks':len(ops)*15,'finite_associativity_checks':125,'identity_checks':5,'negatives':{'new_task_E':'IndexError, state unchanged','nonassociative_subtraction':{'left':(5-3)-1,'right':5-(3-1)},'noncommutative_wrong_order':{'correct':'abc','wrong':wrong_value},'range_convention':{'half_open_1_2':c.prod(1,2),'inclusive_1_2':c.prod(1,3)}},'performance_measurement':'not_run','scope':'Bounded semantics only, no external source/API execution.'}
Path(__file__).with_name('witness-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

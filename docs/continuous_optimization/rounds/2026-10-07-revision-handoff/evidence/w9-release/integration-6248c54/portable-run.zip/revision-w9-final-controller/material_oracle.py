import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,hashlib,csv,math,importlib.util,datetime,shutil
W=Path(__file__).resolve().parent.parent; C=Path(__file__).resolve().parent; R=W/'revision-w9-final-run'
sys.path.insert(0,str(R/'snapshot'))
from agent_runtime.knowledge import KnowledgeStore
from agent_runtime.knowledge_reuse import decision_support
spec=importlib.util.spec_from_file_location('pipeline',W/'agent/scripts/agent_eval_pipeline.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
def h(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(name,obj): (C/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
m=json.loads((R/'manifest.json').read_text());p.verify_run(R)
assert not list(R.glob('cases/*/attempts/*/start.json'))
I=R/'cases/research-write/inputs';sources=json.loads((I/'sources.json').read_text())
for rec in sources['local_fixture_map']: assert h(I/rec['fixture'])==rec['sha256']
for rec in sources['external_primary_sources']: assert h(rec['path'])==rec['sha256']
source_bindings=[{**rec,'path':str(Path(rec['path']).relative_to(W))} for rec in sources['external_primary_sources']]
ctx=json.loads((I/'host-context.json').read_text());payload=json.loads(ctx['payload'])
for a in payload['artifacts']:assert h(I/'handoff'/a['path'])==a['sha256']
assert len(ctx['payload'])==ctx['usage']['chars']==689
assert len(ctx['payload'].encode())==ctx['usage']['bytes']
rootproof=W/'agent/docs/continuous_optimization/rounds/2026-10-07-revision-handoff/evidence/w9-release/integration-6248c54/root-context-preparation.json'
proof=json.loads(rootproof.read_text());assert proof['context']==ctx
assert h(W/'revision-w9-handoff-private/messages.sqlite')==proof['original_db_sha256']
shutil.copyfile(rootproof,C/'root-context-preparation.json')
shutil.copyfile(I/'sources.json',C/'source-bindings.json')
shutil.copyfile(R/'tasks.json',C/'reviewed-tasks.json')
shutil.copyfile(R/'rubric.json',C/'reviewed-rubric.json')
corpus=R/'snapshot/plugins/research-assistant/skills/model-with-knowledge/assets/knowledge';store=KnowledgeStore(corpus);card=store.get('ds.segment-monoid');conds=card['reuse']['conditions'];ds={}
for name,context,explicit in [('matched',conds,False),('mismatched',{**conds,'operation':'unbounded insertion of new task IDs'},False),('unknown',{},False),('explicit_reproduction',conds,True)]:
 out=decision_support(store,'segment tree monoid',context,purpose='implementation',explicit_reproduction=explicit)
 hit=next(x for x in out['results'] if x['id']=='ds.segment-monoid');ds[name]=hit
assert [ds[k]['disposition'] for k in ds]==['evaluate_pinned_implementation','minimal_transfer_check','insufficient_context','run_requested_experiment']
# Independent fixed-index scheduler witness; reference sorting versus full min aggregation.
slots={0:7,1:2,2:5};trace=[]
for update in [None,(0,1),(1,9),(0,math.inf)]:
 if update:slots[update[0]]=update[1]
 left=min((v,k) for k,v in slots.items());right=sorted((v,k) for k,v in slots.items())[0];assert left==right;trace.append(list(left))
assert ''.join(['ab','c'])=='abc' and ''.join(['c','ab'])!='abc'
assert (10-3)-2!=10-(3-2)
ratios=[]
from fractions import Fraction
for row in csv.DictReader((I/'handoff/inputs/measurements.csv').open()):
 b=Fraction(row['baseline_ms']);a=Fraction(row['candidate_ms']);ratios.append({'workload':row['workload'],'scope':row['scope'],'speedup':str(b/a),'reduction':str((b-a)/b)})
# Independent recurrence with explicit admissibility; no production reproduction script invocation.
def geom(n,pad,crop):
 s=[];d=4 if pad=='valid' else 0
 for k in range(5):
  n-=d
  if n<=0: return None
  if k<4:s.append(n);n//=2
 for skip in reversed(s):
  n*=2;delta=skip-n
  if delta<0 or (crop=='none' and delta!=0) or (crop=='symmetric' and delta%2):return None
  n-=d
  if n<=0:return None
 return n
rows=list(csv.DictReader((I/'scientific/unet_WRITE_C001_C002/6/geometry.csv').open()));ok=0
for row in rows:
 n=int(row['input']);value=geom(n,row['padding'],row['crop']);assert (value is None)==(row['status']=='error')
 if value is not None:
  assert value==int(row['output']);assert value==(16*(n//16) if row['padding']=='same' else 16*((n-60)//16)-124);ok+=1
# Zero scores => uniform global weights; removed remote value invalidates equivalence.
V=[0]*15+[16];global_first=sum(V)/16;local_first=sum(V[:3])/3;assert(global_first,local_first)==(1,0)
# Real-arithmetic block merge direct scalar witness with nontrivial maxima.
scores=[-2.,1.,3.,0.];vals=[2.,4.,-1.,7.];M=max(scores);direct=sum(math.exp(s-M)*v for s,v in zip(scores,vals))/sum(math.exp(s-M) for s in scores)
m0=-math.inf;z=0.;a=0.
for ss,vv in [(scores[:2],vals[:2]),(scores[2:],vals[2:])]:
 m1=max(m0,max(ss));alpha=0 if m0==-math.inf else math.exp(m0-m1);z=z*alpha+sum(math.exp(s-m1) for s in ss);a=a*alpha+sum(math.exp(s-m1)*v for s,v in zip(ss,vv));m0=m1
assert abs(a/z-direct)<1e-14
facts={'reviewer_actor':'/root/w9_release_audit','phase':'pre_dispatch_materials_only','manifest_sha256':h(R/'manifest.json'),'verify_run':'passed','starts_observed':0,'source_binding_checks':{'local_entries':len(sources['local_fixture_map']),'external_entries':source_bindings,'all_hashes_match':True},'host_context':{'payload_hash':hashlib.sha256(ctx['payload'].encode()).hexdigest(),'actual_root_proof_sha256':h(rootproof),'referenced_artifact_hashes_match':True,'chars':689,'legacy_refs_empty':True,'original_db_unchanged_hash':proof['original_db_sha256'],'original_receipts':len(proof['status']),'forwarded_not_writer_receipt':True},'engineering':{'corpus_snapshot':store.snapshot,'card':card,'decision_branches':ds,'min_selection_trace':trace,'ordered_noncommutative_witness':'ab+c=abc; c+ab=cab','invalid_nonassociative_witness':{'left':(10-3)-2,'right':10-(3-2)},'new_ids':'outside fixed index set; resizing/rebuild/new representation required, no direct applicability','source_pointer_boundary':'Pinned ACL metadata is not inspected upstream implementation bytes; source/API/license must be actually checked before adoption or unknown/non-adoption recorded.'},'synthetic_ratios':ratios,'scientific_oracles':{'unet_rows':len(rows),'success':ok,'rejected':len(rows)-ok,'all_rows_match_independent_recurrence':True,'valid572':geom(572,'valid','symmetric'),'same252_symmetric':geom(252,'same','symmetric'),'same252_asymmetric':geom(252,'same','asymmetric'),'attention_global_first':global_first,'attention_local_first':local_first,'normalization_direct':direct,'normalization_merged':a/z,'limitations':'Scalar/float64 small witnesses only; no new trained quality, GPU timing or full-paper read. Empty all-masked rows require declared handling; overlapping/missing tiles and changed attention masks break the claimed equivalence.'},'leakage_review':'No rubric, material review or independent grades are declared task fixtures. Historical producer manuscripts, ledgers, calculations and self-checks are intentional objects of skeptical rechecking, not authoritative grade answers. Controller oracle remains outside worker inputs.'}
save('material-facts.json',facts)
print(json.dumps({'manifest':h(R/'manifest.json'),'facts':h(C/'material-facts.json'),'oracle':'passed','rows':len(rows),'success':ok,'branches':{k:v['disposition'] for k,v in ds.items()}}))

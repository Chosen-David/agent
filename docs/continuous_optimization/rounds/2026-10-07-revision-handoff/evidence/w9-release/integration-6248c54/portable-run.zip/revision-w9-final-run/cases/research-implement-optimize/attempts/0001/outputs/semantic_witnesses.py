"""Small self-authored semantic models; no ACL code or performance experiment."""
import bisect
import heapq
import itertools
import json


def minimum(a, b):
    if a is None:
        return b
    if b is None:
        return a
    return a if a <= b else b


class Segment:
    def __init__(self, values, op, identity):
        self.n = len(values)
        self.op = op
        self.identity = identity
        self.size = 1
        while self.size < self.n:
            self.size *= 2
        self.data = [identity] * (2 * self.size)
        self.data[self.size:self.size + self.n] = values
        for p in range(self.size - 1, 0, -1):
            self.data[p] = op(self.data[2*p], self.data[2*p+1])

    def set(self, p, value):
        if not 0 <= p < self.n:
            raise KeyError('unknown fixed slot')
        p += self.size
        self.data[p] = value
        while p > 1:
            p //= 2
            self.data[p] = self.op(self.data[2*p], self.data[2*p+1])

    def prod(self, left, right):
        if not 0 <= left <= right <= self.n:
            raise IndexError('invalid half-open range')
        a = b = self.identity
        left += self.size
        right += self.size
        while left < right:
            if left & 1:
                a = self.op(a, self.data[left])
                left += 1
            if right & 1:
                right -= 1
                b = self.op(self.data[right], b)
            left //= 2
            right //= 2
        return self.op(a, b)

    def first(self):
        return self.data[1]


class LazyHeap:
    def __init__(self, n):
        self.n = n
        self.version = [0] * n
        self.active = [False] * n
        self.heap = []

    def set(self, slot, priority):
        if not 0 <= slot < self.n:
            raise KeyError('unknown fixed slot')
        self.version[slot] += 1
        self.active[slot] = priority is not None
        if priority is not None:
            heapq.heappush(self.heap, (priority, slot, self.version[slot]))

    def first(self):
        while self.heap:
            priority, slot, version = self.heap[0]
            if self.active[slot] and self.version[slot] == version:
                return priority, slot
            heapq.heappop(self.heap)
        return None


class Ordered:
    def __init__(self, n):
        self.n = n
        self.values = {}
        self.order = []

    def set(self, slot, priority):
        if not 0 <= slot < self.n:
            raise KeyError('unknown fixed slot')
        if slot in self.values:
            self.order.remove((self.values.pop(slot), slot))
        if priority is not None:
            self.values[slot] = priority
            bisect.insort(self.order, (priority, slot))

    def first(self):
        return self.order[0] if self.order else None


def main():
    n = 4
    tree = Segment([None]*n, minimum, None)
    heap = LazyHeap(n)
    ordered = Ordered(n)
    reference = {}
    observations = []
    actions = [(0,7),(1,2),(2,2),(1,9),(3,-1),(3,None),(2,None),
               (1,-5),(1,-5),(1,None),(0,None),(2,0),(2,None)]
    assert tree.first() == heap.first() == ordered.first() == None
    for slot, priority in actions:
        tree.set(slot, None if priority is None else (priority, slot))
        heap.set(slot, priority)
        ordered.set(slot, priority)
        if priority is None:
            reference.pop(slot, None)
        else:
            reference[slot] = priority
        expected = min(((p,s) for s,p in reference.items()), default=None)
        observed = [tree.first(), heap.first(), ordered.first()]
        assert all(x == expected for x in observed), (observed, expected)
        for left in range(n+1):
            for right in range(left,n+1):
                interval = min(((p,s) for s,p in reference.items() if left<=s<right),default=None)
                assert tree.prod(left,right)==interval
        observations.append({'set':[slot,priority],'expected':expected,'all_models_agree':True})
    domain = [None,(-1,0),(2,1),(2,2)]
    for a,b,c in itertools.product(domain, repeat=3):
        assert minimum(minimum(a,b),c) == minimum(a,minimum(b,c))
    assert all(minimum(None,x)==minimum(x,None)==x for x in domain)
    strings = Segment(list('abcd'),lambda a,b:a+b,'')
    assert strings.prod(0,4)=='abcd'
    assert strings.prod(1,4)=='bcd'
    assert strings.prod(2,2)==''
    strings.set(1,'X')
    assert strings.prod(0,4)=='aXcd'
    rejected=[]
    for model in [tree,heap,ordered]:
        try:
            model.set(4,3)
        except KeyError as exc:
            rejected.append({'model':type(model).__name__,'error':str(exc)})
        else:
            raise AssertionError('fixed slot contract accepted new ID')
    dynamic_heap=[(2,0)];heapq.heappush(dynamic_heap,(1,999))
    assert heapq.heappop(dynamic_heap)==(1,999)
    # A counterexample, not a passing monoid instance.
    bad_left=(5-3)-1;bad_right=5-(3-1)
    assert bad_left!=bad_right
    return {'scheduler_trace':observations,'range_checks':len(actions)*15,
            'associativity_examples':len(domain)**3,'identity_examples':len(domain),
            'noncommutative_order':['abcd','bcd','','aXcd'],
            'new_fixed_slot_rejections':rejected,'dynamic_heap_new_id':999,
            'nonassociative_counterexample':{'left':bad_left,'right':bad_right},
            'explicit_requested_reproduction':'executed string order, empty range, point-set witnesses',
            'scope':'self-authored bounded semantic witnesses, not ACL reproduction, benchmark or production validation',
            'passed':True}

if __name__ == '__main__':
    print(json.dumps(main(),indent=2))

"""Bounded independent reviewer arithmetic, no historical full experiment rerun."""
from pathlib import Path
import csv,json,hashlib,importlib.util
from fractions import Fraction
import numpy as np
O=Path(__file__).resolve().parent; I=O.parents[2]/'inputs'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
H=json.loads((I/'host-context.json').read_text()); P=json.loads(H['payload'])
refs=[]
for a in P['artifacts']:
 f=I/'handoff'/a['path'];got=sha(f);assert got==a['sha256'];refs.append(dict(a,verified=True))
mapping=json.loads((I/'handoff/writer/evidence-mapping.json').read_text())
for key in ['original_manuscript','unchanged_csv']:
 a=mapping[key];assert sha(I/'handoff'/a['path'])==a['sha256']
ratios=[]
for r in csv.DictReader((I/'handoff/inputs/measurements.csv').open()):
 b,c=Fraction(r['baseline_ms']),Fraction(r['candidate_ms']);ratios.append(dict(r,ratio=str(b/c),latency_change_percent=str(100*(c-b)/b)))
A=I/'scientific/attention_A_C01_A_C04'; U=I/'scientific/unet_WRITE_C001_C002'
z=np.load(A/'7/counterexample.npz',allow_pickle=False)
assert set(z.files)=={'q','k','v','full_mask','local_mask'}
q,k,v,full,local=[z[x] for x in ['q','k','v','full_mask','local_mask']]
assert q.shape==k.shape==(16,8) and v.shape==(16,1)
assert np.all(q==0) and np.all(k==0) and np.all(v[:-1]==0) and v[-1,0]==16
assert np.all(full) and np.array_equal(local,abs(np.arange(16)[:,None]-np.arange(16)[None,:])<=2)
g=np.sum(full*v.T,axis=1)/full.sum(axis=1); l=np.sum(local*v.T,axis=1)/local.sum(axis=1)
w=json.loads((A/'6/counterexample.json').read_text())
assert np.array_equal(g,np.array(w['global_output']).ravel()) and np.array_equal(l,np.array(w['local_output']).ravel())
# Import only supplied function definitions; __main__ is not executed and -B prevents pycache.
spec=importlib.util.spec_from_file_location('frozen_fixture',A/'5/reproduce.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
# Nonempty rows with early and late empty tiles; extreme finite scores. This is six small comparisons.
qt=np.array([[1.,0.],[0.,1.],[-1.,0.],[0.,-1.]])*20; kt=qt.copy();vt=np.arange(12.).reshape(4,3)
mask=np.array([[0,0,0,1],[1,0,1,0],[0,1,0,0],[1,1,1,1]],dtype=bool)
att=[]
for dtype in [np.float64,np.float32]:
 for block in [1,2,3]:
  args=[x.astype(dtype) for x in [qt,kt,vt]]
  actual=m.blockwise(*args,mask,block);expected=m.dense(*args,mask)
  err=float(abs(actual-expected).max());assert np.isfinite(actual).all() and err<1e-5
  att.append({'dtype':np.dtype(dtype).name,'block':block,'max_abs_error':err})
reject=[]
for f in [lambda:m.dense(q,k,v,np.zeros_like(full)),lambda:m.blockwise(q,k,v,np.zeros_like(full),7)]:
 try:f();raise AssertionError('fully masked row accepted')
 except ValueError as e:reject.append(str(e))
# Own recurrence implementation, checking every retained geometry CSV row and successful layer trace.
def recurrence(n,pad,crop):
 b=4 if pad=='valid' else 0; t=n; enc=[]; stages=[('input',n,1)]
 for j in range(5):
  e=t-b
  if e<=0:return None
  enc.append(e);stages.append(('encoder'+str(j),e,64*2**j))
  if j<4:t=e//2;stages.append(('pool'+str(j),t,64*2**j))
 d=enc[-1];crops=[]
 for j in [3,2,1,0]:
  u=2*d;delta=enc[j]-u
  if delta<0 or (crop=='none' and delta!=0) or (crop=='symmetric' and delta%2):return None
  crops.append((j,delta//2,delta-delta//2));stages.append(('up'+str(j),u,64*2**j));d=u-b
  if d<=0:return None
  stages.append(('decoder'+str(j),d,64*2**j))
 stages.append(('output',d,2));return d,stages,crops
rows=list(csv.DictReader((U/'6/geometry.csv').open()));traces=json.loads((U/'7/layer_traces.json').read_text());correct=0
for r in rows:
 res=recurrence(int(r['input']),r['padding'],r['crop'])
 assert (res is not None)==(r['status']=='ok')
 if res:
  n=int(r['input']);formula=16*(n//16) if r['padding']=='same' else 16*((n-60)//16)-124
  assert res[0]==int(r['output'])==formula;correct+=1
for trace in traces:
 res=recurrence(trace['input'],trace['padding'],trace['crop']);layers=trace['layers']
 assert res is not None and len(res[1])==len(layers)
 for (stage,h,c),x in zip(res[1],layers):assert (stage,h,h,c)==(x['stage'],x['height'],x['width'],x['channels'])
 for j,left,right in res[2]:
  x=next(x for x in layers if x['stage']=='up'+str(j));assert (left,right)==(x['crop_left'],x['crop_right']);assert x['concat_channels']==2*x['channels']
canonical=next(x for x in traces if x['input']==572 and x['padding']=='valid' and x['crop']=='symmetric')
result={'task_id':'REV-03','input_version':'w9-final-research-review','payload':{'refs':refs,'chars':len(H['payload']),'bytes':len(H['payload'].encode()),'tokens':None,'legacy_knowledge_refs':P['knowledge_refs'],'legacy_evidence_claims':P['evidence_claims']},'synthetic_ratios':ratios,'attention_counterexample':{'global':g.tolist(),'local':l.tolist(),'max_discrepancy':float(abs(g-l).max()),'query0_difference':float(g[0]-l[0]),'npz_matches_json':True},'small_attention_checks':att,'fully_masked_rejections':reject,'unet':{'historical_rows_read':len(rows),'historical_rejections_retained':len(rows)-correct,'successful_rows_matching_recurrence_and_formula':correct,'full_layer_traces_matched':len(traces),'canonical_572_trace':canonical,'same_252_no_crop':recurrence(252,'same','none'),'same_257_no_crop':recurrence(257,'same','none'),'same_572_asymmetric_output':recurrence(572,'same','asymmetric')[0]},'scope':'New reviewer six tiny numerical comparisons, two rejection checks, one counterexample recomputation and scalar recurrence checks only; no 648-case attention or 48-forward UNet rerun.'}
(O/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

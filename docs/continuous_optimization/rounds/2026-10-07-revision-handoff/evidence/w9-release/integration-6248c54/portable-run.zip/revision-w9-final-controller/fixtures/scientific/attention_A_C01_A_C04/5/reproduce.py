#!/usr/bin/env python3
"""T24 bounded CPU evidence; independent NumPy probes, not CUDA or trained U-Net."""
import argparse, csv, hashlib, importlib.util, json, os, platform, subprocess, sys, time
from pathlib import Path
import numpy as np
BASE=Path(__file__).resolve().parent

def dump(p, x):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,allow_nan=False))
def csvout(p, rows):
    with p.open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def core(variant):
    spec=importlib.util.spec_from_file_location('core_'+variant,BASE/'systems'/variant/'agent_runtime/core.py')
    m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);return m

def systems(out):
    rows=[]; traces=[];tests=[]
    for variant in ['baseline','candidate']:
        p=subprocess.run([sys.executable,'-m','unittest','test_task_waiting','-v'],cwd=BASE/'systems'/variant,capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        (out/f'{variant}_tests_stdout.txt').write_text(p.stdout+p.stderr)
        tests.append({'variant':variant,'exit_code':p.returncode})
        m=core(variant)
        for scenario in ['pending_completion','fairness','poll_budget','elapsed_budget','legacy','retry_after_pending','cancel']:
            db=out/f'{variant}_{scenario}.sqlite'
            if db.exists():raise RuntimeError('refusing to overwrite '+str(db))
            def task(name='slow'):
                t={'task_id':name,'action':'observe','owner':'main-ai','depends_on':[],'done_when':{'test':True},'max_attempts':20 if scenario=='fairness' else 2,'estimated_seconds':20,'risk':'low'}
                if scenario!='legacy':t['wait_policy']={'max_polls':2 if scenario=='poll_budget' else 10,'max_seconds':100,'diagnose_after_seconds':20}
                if scenario in ['pending_completion','legacy']:t['max_attempts']=1
                return t
            ts=[task()]+([task('quick')] if scenario=='fairness' else [])
            plan={'schema_version':'task-dag/v1','run_id':'waiting','user_goal':'bounded observation','authorization_reference':'T24 local fixture','supervision':{'min_seconds':1,'max_seconds':1,'rationale':'controlled clock'},'tasks':ts}
            st=m.Store(db);st.create(plan);calls=[];now=[1000.];count=[0]
            class Observer:
                idempotent=True;required_capabilities=frozenset()
                def run(self,t,c):
                    calls.append({'task':t['task_id'],'clock':now[0],'idempotency_key':c.idempotency_key})
                    count[0]+=1
                    if t['task_id']=='quick' or scenario=='pending_completion' and count[0]>4:return m.Outcome('complete',evidence=['checked'])
                    if scenario=='retry_after_pending' and count[0]>1:return m.Outcome('retry','observed failure')
                    return m.Outcome('pending','owned job still running')
                def verify(self,t,e):return e==['checked']
            obs=Observer()
            for tick in range(1,7):
                now[0]+=100 if scenario=='elapsed_budget' and tick==2 else 1
                if scenario=='cancel' and tick==2:st.cancel('waiting','explicit-stop',now=now[0])
                state=m.Engine(st,{'observe':obs},authorize=lambda *_:True,clock=lambda:now[0]).tick('waiting',f'e{tick}')
                traces.append({'variant':variant,'scenario':scenario,'tick':tick,'clock':now[0],'state':state,'calls':list(calls)})
                node=state['tasks']['slow']
                rows.append({'variant':variant,'scenario':scenario,'tick':tick,'clock':now[0],'run_status':state['status'],'slow_status':node['status'],'attempts':node['attempts'],'pending_polls':node.get('pending_polls'),'quick_status':state['tasks'].get('quick',{}).get('status'),'dispatch_count':len(calls),'diagnosis_required':node.get('diagnosis_required'),'reason_kind':node.get('reason_kind')})
    csvout(out/'traces.csv',rows);dump(out/'traces.json',traces);dump(out/'test_results.json',tests)
    print('systems:',json.dumps(tests),'trace rows',len(rows))

def dense(q,k,v,mask):
    # Independent full-matrix float64 calculation; no online accumulator.
    s=q.astype(np.float64)@k.astype(np.float64).T/np.sqrt(q.shape[1])
    s=np.where(mask,s,-np.inf)
    if np.any(~mask.any(axis=1)):raise ValueError('fully masked row')
    p=np.exp(s-np.max(s,axis=1,keepdims=True));p/=p.sum(axis=1,keepdims=True)
    return p@v.astype(np.float64)

def blockwise(q,k,v,mask,block):
    if np.any(~mask.any(axis=1)):raise ValueError('fully masked row')
    n=q.shape[0]; o=np.empty((n,v.shape[1]),dtype=q.dtype)
    for i in range(0,n,block):
        qi=q[i:i+block];m=np.full(len(qi),-np.inf,dtype=q.dtype);l=np.zeros(len(qi),dtype=q.dtype);a=np.zeros((len(qi),v.shape[1]),dtype=q.dtype)
        for j in range(0,n,block):
            s=(qi@k[j:j+block].T)*np.array(q.shape[1]**-.5,dtype=q.dtype)
            s=np.where(mask[i:i+block,j:j+block],s,-np.inf)
            new=np.maximum(m,np.max(s,axis=1));safe=np.where(np.isfinite(new),new,0)
            alpha=np.exp(m-safe);p=np.exp(s-safe[:,None]);a=alpha[:,None]*a+p@v[j:j+block];l=alpha*l+p.sum(axis=1);m=new
        o[i:i+block]=a/l[:,None]
    return o

def attention(out):
    rows=[];naive=[];fixtures={}
    for seed in [0,1,2]:
      for n in [7,31,128]:
       for d in [8,32]:
        for scale in [1,100]:
         rng=np.random.default_rng(seed*100000+n*100+d)
         q0=rng.normal(size=(n,d))*scale;k0=rng.normal(size=(n,d))*scale;v0=rng.normal(size=(n,5));rand=rng.random((n,n))>.5;np.fill_diagonal(rand,True)
         for maskname,mask in [('none',np.ones((n,n),bool)),('causal',np.tri(n,dtype=bool)),('random_nonempty',rand)]:
          for dtype in [np.float64,np.float32]:
           q=q0.astype(dtype);k=k0.astype(dtype);v=v0.astype(dtype);ref=dense(q,k,v,mask)
           score=q@k.T/np.array(np.sqrt(d),dtype=dtype)
           with np.errstate(over='ignore',invalid='ignore',divide='ignore'):
            ex=np.where(mask,np.exp(score),0);unstable=(ex/ex.sum(axis=1,keepdims=True))@v
           naive.append({'seed':seed,'n':n,'d':d,'scale':scale,'mask':maskname,'dtype':np.dtype(dtype).name,'nonfinite_count':int((~np.isfinite(unstable)).sum())})
           for b in [1,7,32]:
            actual=blockwise(q,k,v,mask,b);err=float(np.max(np.abs(actual-ref)));tol=1e-10 if dtype==np.float64 else 5e-4
            rows.append({'seed':seed,'n':n,'d':d,'scale':scale,'mask':maskname,'dtype':np.dtype(dtype).name,'block':b,'max_abs_error':err,'finite':bool(np.isfinite(actual).all()),'threshold':tol,'pass':bool(np.isfinite(actual).all() and err<=tol),'score_tile_elements':min(n,b)**2,'dense_score_elements':n*n})
    q=np.zeros((16,8));k=q.copy();v=np.zeros((16,1));v[-1]=16;mask=np.ones((16,16),bool);local=np.abs(np.arange(16)[:,None]-np.arange(16)[None,:])<=2
    counter={'global_output':dense(q,k,v,mask).tolist(),'local_output':dense(q,k,v,local).tolist(),'max_abs_error':float(np.abs(dense(q,k,v,mask)-dense(q,k,v,local)).max()),'first_query_error':float(abs(dense(q,k,v,mask)[0,0]-dense(q,k,v,local)[0,0]))}
    np.savez(out/'counterexample.npz',q=q,k=k,v=v,full_mask=mask,local_mask=local)
    reject={}
    for name,fun in [('dense',lambda:dense(q,k,v,np.zeros_like(mask))),('block',lambda:blockwise(q,k,v,np.zeros_like(mask),7))]:
        try:fun();reject[name]='unexpected_accept'
        except ValueError as e:reject[name]=str(e)
    csvout(out/'accuracy.csv',rows);csvout(out/'naive_failures.csv',naive);dump(out/'counterexample.json',counter);dump(out/'masked_row_contract.json',reject)
    summary={'comparisons':len(rows),'failed':sum(not r['pass'] for r in rows),'max_error_by_dtype':{dt:max(r['max_abs_error'] for r in rows if r['dtype']==dt) for dt in ['float64','float32']},'naive_nonfinite_cases':sum(r['nonfinite_count']>0 for r in naive),'naive_total':len(naive),'local_query0_error':counter['first_query_error']}
    dump(out/'summary.json',summary);print('attention:',json.dumps(summary))

def geometry(n,padding,crop='asymmetric'):
    nodes=[];skip=[];h=n;ch=1
    def record(stage,h,c,**kw):nodes.append(dict(stage=stage,height=h,width=h,channels=c,**kw))
    record('input',h,ch)
    for level in range(5):
        h-=4 if padding=='valid' else 0;ch=64*2**level
        if h<1:raise ValueError('nonpositive convolution at level '+str(level))
        record('encoder'+str(level),h,ch)
        if level<4:skip.append((h,ch));h//=2;record('pool'+str(level),h,ch)
    for level in range(3,-1,-1):
        h*=2;ch//=2;sh,sc=skip[level];delta=sh-h
        if delta<0:raise ValueError('skip smaller than decoder')
        if crop=='none' and delta:raise ValueError(f'concat mismatch level{level}: skip{sh} decoder{h}')
        if crop=='symmetric' and delta%2:raise ValueError(f'odd crop level{level}: delta{delta}')
        record('up'+str(level),h,ch,skip_height=sh,crop_left=delta//2,crop_right=delta-delta//2,concat_channels=ch+sc)
        h-=4 if padding=='valid' else 0
        if h<1:raise ValueError('nonpositive decoder convolution')
        record('decoder'+str(level),h,ch)
    record('output',h,2);return nodes

# Real reduced-channel convolutions: fixed positive kernels, shared across output channels.
def conv(x,cout,padding):
    if padding=='same':x=np.pad(x,((0,0),(1,1),(1,1)))
    z=np.lib.stride_tricks.sliding_window_view(x,(3,3),axis=(1,2)).mean(axis=(0,3,4))
    return np.repeat(np.maximum(z,0)[None],cout,axis=0)
def forward(x,padding):
    skip=[]
    for lev in range(5):
        x=conv(conv(x,2**lev,padding),2**lev,padding)
        if lev<4:
            skip.append(x);h=x.shape[1]//2;w=x.shape[2]//2;x=x[:,:2*h,:2*w].reshape(x.shape[0],h,2,w,2).max(axis=(2,4))
    for lev in range(3,-1,-1):
        # 2x2 stride2 transposed convolution: normalized channel mean, positive unit spatial weights.
        x=np.repeat(np.repeat(np.repeat(x.mean(axis=0,keepdims=True),2**lev,axis=0),2,axis=1),2,axis=2)
        s=skip[lev];delta=s.shape[1]-x.shape[1];a=delta//2;s=s[:,a:a+x.shape[1],a:a+x.shape[2]]
        x=conv(conv(np.concatenate([s,x]),2**lev,padding),2**lev,padding)
    return np.repeat(x.mean(axis=0,keepdims=True),2,axis=0)

def supports(n,padding):
    # Bitset propagation gives the exact possible input-axis support of each output position.
    # All 3x3 kernels are dense positive; the two axes' structural supports are Cartesian products.
    a=[1<<i for i in range(n)];skip=[]
    def c(a):
        if padding=='same':a=[0]+a+[0]
        return [a[i]|a[i+1]|a[i+2] for i in range(len(a)-2)]
    for lev in range(5):
        a=c(c(a))
        if lev<4:skip.append(a);a=[a[i]|a[i+1] for i in range(0,len(a)-1,2)]
    for lev in range(3,-1,-1):
        a=[v for v in a for _ in range(2)];s=skip[lev];off=(len(s)-len(a))//2;a=[v|s[i+off] for i,v in enumerate(a)];a=c(c(a))
    return a

def unet(out):
    rows=[];shape_traces=[]
    for n in [188,189,190,200,252,253,254,255,256,257,572]:
      for pad in ['valid','same']:
       for crop in ['none','symmetric','asymmetric']:
        try:
            trace=geometry(n,pad,crop);row={'input':n,'padding':pad,'crop':crop,'output':trace[-1]['height'],'status':'ok','error':''};shape_traces.append({'input':n,'padding':pad,'crop':crop,'layers':trace})
        except ValueError as e:row={'input':n,'padding':pad,'crop':crop,'output':None,'status':'error','error':str(e)}
        rows.append(row)
    csvout(out/'geometry.csv',rows);dump(out/'layer_traces.json',shape_traces)
    numeric=[];rf=[];arrays={}
    for n in [188,189,252,253,256,257]:
     for pad in ['valid','same']:
        dep=supports(n,pad);ones=forward(np.ones((1,n,n)),pad);h=ones.shape[1];center=h//2
        assert h==geometry(n,pad)[-1]['height']==len(dep)
        arrays[f'{pad}_{n}_ones']=ones
        for point in [0,center,h-1]:
            ids=[i for i in range(n) if dep[point]>>i&1];rf.append({'input':n,'padding':pad,'output_position':point,'support_min':min(ids),'support_max':max(ids),'support_axis_count':len(ids),'support_area':len(ids)**2})
        numeric.append({'input':n,'padding':pad,'fixture':'ones','output':h,'output_min':float(ones.min()),'output_max':float(ones.max()),'center_output':float(ones[0,center,center]),'corner_output':float(ones[0,0,0]),'predicted_center_depends':None,'measured_center_depends':None,'dependency_agrees':None})
        for label,loc in [('corner',(0,0)),('near_corner',(3,3)),('center',(n//2,n//2))]:
            x=np.zeros((1,n,n));x[0,loc[0],loc[1]]=1;y=forward(x,pad);arrays[f'{pad}_{n}_{label}']=y
            predicted=bool(dep[center]>>loc[0]&1 and dep[center]>>loc[1]&1);measured=bool(y[0,center,center]>1e-14)
            numeric.append({'input':n,'padding':pad,'fixture':'impulse_'+label,'output':h,'output_min':float(y.min()),'output_max':float(y.max()),'center_output':float(y[0,center,center]),'corner_output':float(y[0,0,0]),'predicted_center_depends':predicted,'measured_center_depends':measured,'dependency_agrees':predicted==measured})
    csvout(out/'forward.csv',numeric);csvout(out/'receptive_fields.csv',rf);np.savez_compressed(out/'outputs.npz',**arrays)
    summary={'shape_cases':len(rows),'shape_errors':sum(r['status']=='error' for r in rows),'numeric_cases':len(numeric),'dependency_checks':sum(r['dependency_agrees'] is not None for r in numeric),'dependency_mismatches':sum(r['dependency_agrees'] is False for r in numeric),'original_572_valid_output':geometry(572,'valid')[-1]['height']}
    dump(out/'summary.json',summary);print('unet:',json.dumps(summary))

def main():
    p=argparse.ArgumentParser();p.add_argument('case',choices=['all','systems','attention','unet']);p.add_argument('--run-id',required=True);a=p.parse_args()
    run=BASE/'runs'/a.run_id
    if run.exists():raise RuntimeError('run ID exists; use a new ID')
    run.mkdir(parents=True);start=time.time()
    env={'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),'machine':platform.machine(),'processor':platform.processor(),'cpu_count':os.cpu_count(),'protocol_sha256':hashlib.sha256((BASE/'protocol.md').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':sys.argv,'thread_environment':{k:os.environ.get(k) for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']},'time_start_unix':start}
    dump(run/'environment.json',env)
    for case in ['systems','attention','unet'] if a.case=='all' else [a.case]:
        dest=run/case;dest.mkdir();globals()[case](dest)
    dump(run/'completion.json',{'elapsed_seconds':time.time()-start,'status':'completed'})
if __name__=='__main__':main()

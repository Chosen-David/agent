# U — Padding changes U-Net's geometry and boundary contract

This negative/boundary study tests the proposition that replacing valid convolutions with zero-padded same convolutions is a semantics-preserving drop-in simplification. The finite geometry and signal probes falsify that unrestricted proposition. They do not measure segmentation quality or imply that same-padding U-Nets are ineffective.

## Actual evidence

`../runs/run01/unet/geometry.csv` records66 shape-policy cases (11 input sizes × 2 padding modes × 3 crop policies), including39 explicit shape/crop errors. `layer_traces.json` records every successful encoder, pool, up-convolution, skip crop, concatenation channel count and decoder stage using original channels64–1024. Scalar shape arithmetic reproduces the paper's572→388 valid-convolution anchor. No572-sized numerical array was allocated.

| Square input | Valid output with asymmetric crop | Same output with asymmetric crop | Same with no crop |
|---|---:|---:|---|
|188|4|176|shape mismatch|
|189|4|176|shape mismatch|
|252|68|240|shape mismatch at deepest skip31 vs30|
|253|68|240|shape mismatch at deepest skip31 vs30|
|256|68|256|works|
|257|68|256|shape mismatch at outer skip257 vs256|

The same-padding cases that fail no-crop also fail a strictly symmetric crop when the difference is odd. A floor-left/remainder-right crop permits those executions, but that is an explicit alignment/output-extent policy. This does not prove all same-padding implementations fail odd inputs: padding the input, selecting output-padding or resizing are different policies not studied here. Original-paper input constraints require all prepool dimensions even; arbitrary odd and incompatible even sizes are stress cases, not faithful original tiling configurations.

`forward.csv` contains48 actual CPU forward evaluations: six input sizes, two padding choices, and all-ones plus three impulse inputs. The network uses reduced channels1,2,4,8,16, deterministic positive normalized weights, ReLU, real NumPy3×3 spatial convolutions,2×2 max-pooling and an exact positive2×2 stride2 transposed-convolution equivalent. Outputs and the two identical final channels are stored in `outputs.npz`. Weights are fixed to isolate geometry; they are not original trained weights or a realistic learned channel basis.

For256×256 all-ones input, valid output is uniformly1. Same-padding output ranges from0.11626864920076965 at the corner to1 in the interior. At252×252, the same-padding minimum is0.19086768475540394. These are measured boundary responses caused jointly by specified zero padding, pooling and crop alignment in this fixed-weight network. They are not measured accuracy losses.

`receptive_fields.csv` contains36 structural support probes. At input256, valid output position0 depends structurally on input-axis0..187; center position34 on32..219; final output position67 on64..251. Same-padding output corner has clipped support0..93 and center128 support34..221. These structural sets are derived by exact bitset propagation through the implemented graph; they are NOT learned effective receptive fields or gradients. All36 selected center-output dependency predictions agree with actual impulse responses at the predeclared1e-14 threshold. Arrays retain tiny nonzero responses rather than rounding them away. The experiment only checks selected points and impulses; it does not verify every support pixel by perturbation.

## Primary source and implementation mapping

Ronneberger, Fischer and Brox, *U-Net: Convolutional Networks for Biomedical Image Segmentation*, arXiv1505.04597v1 (18May2015), https://arxiv.org/pdf/1505.04597 . Figure1 (printed p2) provides572→388 spatial sizes and64/128/256/512/1024 channels. §2 (printed p4) specifies two unpadded3×3 convs, ReLU,2×2 stride2 maxpool, upsampling/up-convolution reducing channels, crop/concatenate, and final1×1 class projection. It also states the even prepool-size requirement. Figure2 and its discussion (printed p3) explain overlap-tile context and input mirroring. Our same-padding substitution uses zeros, not that original mirror-context strategy.

Author project page: https://lmb.informatik.uni-freiburg.de/people/ronneber/u-net/ . The page's original2015 release is185MB and depends on Caffe/Matlab; it was not downloaded or executed under this small CPU budget. The geometry probe is independently written in `../reproduce.py`, not a byte-for-byte Caffe reimplementation. Torch is absent. Original training, elastic augmentation, weighted loss and biomedical evaluation are outside scope.

Reproduce: `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python reproduce.py unet --run-id unet-replay-01` from pack root. A fresh run ID is required. Neither padding mode is recommended on accuracy or speed grounds by these data.

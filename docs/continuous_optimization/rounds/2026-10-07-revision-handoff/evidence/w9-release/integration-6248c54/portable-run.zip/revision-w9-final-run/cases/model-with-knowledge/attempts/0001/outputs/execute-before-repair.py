import json,subprocess,hashlib,sys
from pathlib import Path
O=Path(__file__).resolve().parent
R=O.parents[4]; S=R/'snapshot'; I=R/'cases/model-with-knowledge/inputs'
K='plugins/research-assistant/skills/model-with-knowledge/assets/knowledge'
logs=json.loads((O/'command-results.json').read_text())
def save(n,v): (O/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def run(args):
 p=subprocess.run(args,cwd=S,text=True,capture_output=True)
 try: result=json.loads(p.stdout)
 except ValueError: result=p.stdout
 logs.append(dict(command=args,cwd=str(S),returncode=p.returncode,stdout=result,stderr=p.stderr)); save('command-results.json',logs)
 if p.returncode: raise RuntimeError(p.stderr)
 return result
base=[sys.executable,'-B','-m','agent_runtime.knowledge','--root',K]
card=run(base+['show','ds.segment-monoid']);save('knowledge-card.json',card)
assert card['requires']==[]
run(base+['search','heap priority queue ordered list','--limit','3'])
matched=dict(card['reuse']['conditions'])
contexts={'matched':matched,'mismatched':dict(matched,operation='unbounded insertion of new task IDs and point updates'),'unknown':{k:v for k,v in matched.items() if k!='algebra'},'reproduction':matched}
for name,context in contexts.items():
 save('context-'+name+'.json',context)
 args=base+['decision','segment tree monoid','--context',str(O/('context-'+name+'.json')),'--purpose','implementation','--limit','1']
 if name=='reproduction':args+=['--explicit-reproduction']
 save('decision-'+name+'.json',run(args))
save('knowledge-refs.json',card['knowledge_refs'])
run(base+['check-refs',str(O/'knowledge-refs.json')])
sys.path[:0]=[str(S),str(S/'scripts')]
from validate_handoff import validate
from agent_runtime.handoff_basis import check_handoff_basis
host=json.loads((I/'host-context.json').read_text()); payload=json.loads(host['payload'])
checks=[]
for a in payload['artifacts']:
 f=I/'handoff'/a['path']; digest=hashlib.sha256(f.read_bytes()).hexdigest()
 checks.append(dict(id=a['id'],path=a['path'],expected=a['sha256'],actual=digest,match=digest==a['sha256']))
request=json.loads((I/'consumer-request.json').read_text()); old=json.loads((I/'handoff/writer/handoff.json').read_text())
for rel,digest in request['permitted_revision_refs'].items():
 actual=hashlib.sha256((I/'handoff'/rel).read_bytes()).hexdigest();checks.append(dict(path=rel,expected=digest,actual=actual,match=actual==digest))
legacy_errors=validate(old,I/'handoff',True,consumer_request=request)
legacy_basis=check_handoff_basis(I/'handoff',old,request)
assert all(c['match'] for c in checks) and not legacy_errors
save('host-context-verification.json',dict(payload_sha256=hashlib.sha256(host['payload'].encode()).hexdigest(),payload_chars=len(host['payload']),payload_bytes=len(host['payload'].encode()),model_tokens=None,checks=checks,integrity_errors=legacy_errors,basis=legacy_basis,provenance='Actual root prepare_context seq3 to research-review; forwarded by root, not my Mailbox receipt.',legacy_interpretation='Empty knowledge_refs and evidence_claims are compatible, not theorem endorsement.',actions='Read only: no ACK, publish, finding closure or original DB change.'))
print(json.dumps({'decisions':{n:json.loads((O/('decision-'+n+'.json')).read_text()) for n in contexts},'legacy_errors':legacy_errors},ensure_ascii=False))

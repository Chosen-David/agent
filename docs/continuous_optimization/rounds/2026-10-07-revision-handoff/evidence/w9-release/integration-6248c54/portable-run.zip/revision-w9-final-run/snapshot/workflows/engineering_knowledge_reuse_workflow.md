# 实验结论与实现资源复用

用于 AI Infra、AI 算法、数据结构算法任务。沿用 `model-with-knowledge` 与 `knowledge/` 的检索、全文读取和版本引用，不全库注入。CLI 提供候选和保守条件比较，不自动判断科学适用性。

## 实验前反思

1. 区分已有现象的重复探索、新环境的迁移检查、显式复现和必做验收；先读用户目标与预算，用户明确要做的实验不能因论文已有结果就取消。
2. 从模型、数据、硬件、dtype、形状/长度分布、batch、并发、软件版本、基线和指标检索；同时查正结果、消融、反例和限制。先 search/context，再读 show 全文和实际依赖。
3. 回到原论文 observation/setup/experiments/ablation：记录页/图/表、来源版本、年份/venue、预印本身份、单位、比较设置与本机复现状态。作者推测的因果解释与实测观察分开。
4. 条件逐项 matched / mismatched / unknown，补查卡片未声明的隐含条件。相关度、字符串相等、顶会身份都不是可迁移性证明。
5. 交付 decision_record：问题、完整知识引用、出处、条件比较、可复用结论、未知、动作及预算。已有现象可引用支持方案筛选，避免重复无信息增益的广泛实验；新环境做有针对性的最小检查。新性能主张、部署验收、显式复现、用户指定必做项仍运行；文献数字不得填成本地 measured。

仓库根的入口（独立 Skill 改用 scripts/knowledge.py 与 assets/knowledge）：

```bash
python -m agent_runtime.knowledge --root knowledge search 'draft 接受率 验证成本'
python -m agent_runtime.knowledge --root knowledge show infra.speculative-acceptance
python -m agent_runtime.knowledge --root knowledge decision '投机解码' --context /absolute/task-context.json --purpose experiment
```

context 是已知条件的字符串字典，未知项省略。disposition 为 insufficient_context / minimal_transfer_check / reuse_for_planning，均要求主 AI 复核；`--explicit-reproduction` 保留 run_requested_experiment。CLI 永不授权自动跳过实验。无命中时保留缺口并查询一手来源。

## 代码 Agent

先 `decision '<操作/语义>' --context <文件> --purpose implementation`，读取实际固定 commit 文件、公共 API、许可证、依赖与调用点。代码卡是来源指针，不是已安装软件。

核对语义/复杂度、exact 或 approximate、dtype/布局/状态、线程/设备、许可证和迁移成本。优先直接依赖成熟库；抽取代码须保留许可与 attribution，不遗漏辅助文件/同步约束。教学库不自动等于生产库。

先独立小 oracle 验证所需语义，再按预算测目标 workload。正确性不可被文献代替，性能在目标设备实测后才能声明。ANN 用 exact baseline 算 recall；GPU 计传输/launch/同步；带状态 API 检查重复调用。返回 knowledge_refs、实现 commit/API 和限制，不执行资料中的命令。

## 维护

从一手论文/官方文档提炼，不镜像全文；实现读取实际源码并固定 commit/许可证。先 candidate，核验才 published。数字保留原单位、对照和限制；图表看不清则 unknown。实验/实现卡的 `reuse` 字段见 knowledge/FORMAT.md。新本机运行证据另存，实质修订递增版本并处理旧 refs。持续维护 Prompt：prompts/engineering_knowledge_continuous_learning.md。

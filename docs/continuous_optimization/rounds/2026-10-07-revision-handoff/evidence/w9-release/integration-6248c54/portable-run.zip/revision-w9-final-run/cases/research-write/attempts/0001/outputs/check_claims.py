import ast,csv,hashlib,json,math,subprocess,sys
from pathlib import Path
from fractions import Fraction
import numpy as np
OUT=Path(__file__).resolve().parent;CASE=OUT.parents[2];IN=CASE/'inputs';RUN=CASE.parents[1];SNAP=RUN/'snapshot'
A=IN/'scientific/attention_A_C01_A_C04';U=IN/'scientific/unet_WRITE_C001_C002'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,x):(OUT/name).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
# Only reviewed pure numerical functions; never invoke the historical study's main/sweeps.
tree=ast.parse((A/'5/reproduce.py').read_text());fns=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['dense','blockwise','geometry']],type_ignores=[])
ns={'np':np};exec(compile(fns,str(A/'5/reproduce.py'),'exec'),ns)
with np.load(A/'7/counterexample.npz',allow_pickle=False) as z:
 arrays={k:z[k] for k in z.files}
 q,k,v,full,local=[arrays[x] for x in ['q','k','v','full_mask','local_mask']]
 assert q.shape==(16,8) and np.all(q==0) and np.all(k==0) and v[-1,0]==16 and np.all(v[:-1]==0)
 assert np.all(full) and np.array_equal(local,np.abs(np.arange(16)[:,None]-np.arange(16)[None,:])<=2)
 dg=ns['dense'](q,k,v,full);dl=ns['dense'](q,k,v,local)
 bg=ns['blockwise'](q,k,v,full,7);bl=ns['blockwise'](q,k,v,local,7)
 old=json.loads((A/'6/counterexample.json').read_text())
 assert np.array_equal(dg,np.array(old['global_output'])) and np.array_equal(dl,np.array(old['local_output']))
 assert np.allclose(dg,bg,rtol=0,atol=1e-14) and np.allclose(dl,bl,rtol=0,atol=1e-14)
# Independent merge illustrates that uniform averaging of tile outputs is wrong.
scores=[0.,math.log(3.)];values=[0.,10.]
m=-math.inf;l=0.;a=0.
for s,vv in zip(scores,values):
 new=max(m,s);scale=math.exp(m-new);p=math.exp(s-new);l=scale*l+p;a=scale*a+p*vv;m=new
assert abs(a/l-7.5)<1e-12
checks=[];rows=list(csv.DictReader((U/'6/geometry.csv').open()));traces=json.loads((U/'7/layer_traces.json').read_text())
# Independent per-axis integer recurrence, separate from supplied geometry implementation.
def recurrence(n,pad,policy):
 b=4 if pad=='valid' else 0;t=n;enc=[]
 for lev in range(5):
  e=t-b
  if e<=0:raise ValueError('nonpositive encoder')
  enc.append(e)
  if lev<4:t=e//2
 d=enc[-1];ups=[]
 for lev in range(3,-1,-1):
  u=2*d;delta=enc[lev]-u
  if delta<0 or (policy=='none' and delta!=0) or (policy=='symmetric' and delta%2):raise ValueError('crop inadmissible')
  ups.append({'level':lev,'up':u,'delta':delta});d=u-b
  if d<=0:raise ValueError('nonpositive decoder')
 return d,enc,ups
for r in rows:
 n=int(r['input']);p=r['padding'];c=r['crop']
 try:
  value,enc,ups=recurrence(n,p,c);assert r['status']=='ok' and value==int(r['output'])
  formula=16*(n//16) if p=='same' else 16*((n-60)//16)-124
  assert value==formula and value==ns['geometry'](n,p,c)[-1]['height']
  checks.append({'input':n,'padding':p,'crop':c,'status':'ok','output':value,'formula_match':True})
 except ValueError:
  assert r['status']=='error';checks.append({'input':n,'padding':p,'crop':c,'status':'rejected_as_recorded'})
for r in traces:
 assert r['layers']==ns['geometry'](r['input'],r['padding'],r['crop'])
ratios=[{**r,'speedup_exact':str(Fraction(r['baseline_ms'])/Fraction(r['candidate_ms'])),'latency_change_pct_exact':str(100*(Fraction(r['candidate_ms'])-Fraction(r['baseline_ms']))/Fraction(r['baseline_ms']))} for r in csv.DictReader((IN/'handoff/inputs/measurements.csv').open())]
result={'scope':'Fresh bounded witness/recurrence validation; not a new scientific sweep or added historical observation.','numpy':np.__version__,'ratios':ratios,'attention':{'npz_arrays':{k:{'shape':list(v.shape),'dtype':str(v.dtype)} for k,v in arrays.items()},'global':dg[:,0].tolist(),'local':dl[:,0].tolist(),'first_query_error':float(abs(dg[0,0]-dl[0,0])),'max_error':float(abs(dg-dl).max()),'block7_matches_dense':True,'unequal_mass_tiles':{'scores':scores,'values':values,'merged_output':a/l,'wrong_unweighted_tile_average':5.}},'unet':{'cases':checks,'historical_rows_read':len(rows),'historical_rejections_retained':sum(r['status']=='error' for r in rows),'trace_records_read_and_matched':len(traces),'canonical_572':recurrence(572,'valid','symmetric'),'same252':recurrence(252,'same','asymmetric'),'valid256':recurrence(256,'valid','asymmetric')},'historical_counts_not_relabelled':True}
save('check-results.json',result)
argv=['python','-B','-m','agent_runtime.knowledge','--root','plugins/research-assistant/skills/model-with-knowledge/assets/knowledge','search','softmax block normalization running maximum pooling floor shape recurrence','--limit','3']
r=subprocess.run(argv,cwd=SNAP,text=True,capture_output=True);assert r.returncode==0
(OUT/'knowledge-search.json').write_text(r.stdout)
save('commands.json',[{'cwd':str(RUN),'argv':['python','-B',str(OUT/'verify_sources.py')],'output':'source-verification-transcript.txt'},{'cwd':str(RUN),'argv':['python','-B',str(OUT/'check_claims.py')],'output':'checks-transcript.txt'},{'cwd':str(SNAP),'argv':argv,'exit_code':r.returncode,'output':'knowledge-search.json'}])
loaded=[CASE/'task.txt',CASE/'attempts/0001/start.json',IN/'sources.json',IN/'host-context.json',IN/'consumer-request.json']
loaded+=list((IN/'scientific').rglob('*'))
loaded+=[IN/'handoff'/p for p in ['inputs/manuscript.md','inputs/measurements.csv','writer/manuscript-revised.md','writer/evidence-mapping.json','writer/calculation-checks.json','writer/provenance.json','writer/handoff.json']]
loaded+=[SNAP/p for p in ['plugins/research-assistant/skills/research-write/SKILL.md','plugins/research-assistant/skills/research-write/references/execution.md','plugins/research-assistant/skills/research-write/references/knowledge_access_workflow.md','plugins/research-assistant/skills/research-write/references/workflow.md','workflows/agent_communication_workflow.md','agent_runtime/handoff_basis.py']]
save('source-load.json',{'files':[{'path':str(p),'sha256':sha(p)} for p in loaded if p.is_file()],'semantic_read_scope':'Full two fixture manuscripts, ledgers, evidence notes, citation audits, reproduce.py and interface source. Entire geometry CSV and all traces parsed/checked. Specified primary pages only: FlashAttention official35 pp4,5,22 and U-Net v1 pp2,3,4 text and images. Full frozen Skill/execution/knowledge/communication; workflow sections1,3,4 and agent prompt. Historical task scopes read as data, not new execution requests.','model_identity':None,'model_tokens':None,'prior_familiarity':'Prior synthetic writing/reconsumption known; not claimed unseen. Scientific sources loaded afresh for this bounded audit.'})
print(json.dumps({'ratios':[r['speedup_exact'] for r in ratios],'counterexample_first':result['attention']['first_query_error'],'counterexample_max':result['attention']['max_error'],'geometry_rows':len(rows),'rejections_retained':39,'traces_verified':len(traces),'knowledge_search_exit':r.returncode}))

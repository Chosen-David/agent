# A — Numerical boundaries of tiled exact attention

This independent CPU NumPy reproduction checks stable online softmax composition and distinguishes exact global attention from a local approximation. It is not a reproduction of FlashAttention CUDA kernels, speed, IO traffic or training results. The prospective design is `../protocol.md`; implementations are `dense` and `blockwise` in `../reproduce.py`.

## Actual measurements

`../runs/run01/attention/accuracy.csv` contains all 648 comparisons: 3 seeds × 3 sequence lengths × 2 head dimensions × 2 Q/K scales × 3 masks × 2 dtypes × 3 block sizes. All outputs are finite and all meet the predeclared dtype thresholds. Largest absolute discrepancy from independent dense float64 reference is 3.532729664357248e-13 for float64 (limit 1e-10) and 2.988110650203879e-05 for float32 (limit 5e-4). These are maxima over the fixed sweep, not universal error bounds.

`naive_failures.csv` records 216 naive dense exponentiation cases. 108 produce nonfinite values; every one is from the Q/K scale-100 group, while the scale-1 group has zero such cases. Scaling both Q and K by 100 makes scores 10,000 times their corresponding scale-1 scores. The unstable comparator exposes missing maximum subtraction; the stable dense implementation is the correctness baseline.

`counterexample.npz` and `.json` store a deterministic noncausal N=16 construction: Q=K=0 and only the last V entry equals16. Global attention output is1 at every query. A radius-2 local mask returns0 at query0, absolute error1; maximum discrepancy across queries is4.333333333333333. This counterexample shows semantic nonequivalence, not that every application of local attention has poor task quality.

Both implementations reject fully masked rows with ValueError, recorded in `masked_row_contract.json`. Random masks are forced nonempty on the diagonal; causal masks exercise initially empty score tiles. Inputs are regenerated from explicit seeds in NumPy 2.3.5; masks, dimensions, scales and accumulation dtypes are in the CSV/code.

## Method and interface boundary

For each query block, running maximum m, denominator l and unnormalized numerator a are updated on each key block: m'=max(m,max(scores)); alpha=exp(m-m'); l'=alpha*l+sum(exp(scores-m')); a'=alpha*a+exp(scores-m')@V; output=a/l. The dense reference builds the entire score matrix in float64 and normalizes once. The float32 comparison uses the same quantized inputs, then a float64 reference calculation. Blockwise summation and float32 score computation can differ numerically without changing the real-arithmetic operator.

`score_tile_elements` versus `dense_score_elements` is exact shape accounting, NOT measured memory usage. At N=128, block32 uses at most1024 score elements versus16384 dense elements. Inputs, outputs, masks and other temporaries still occupy memory; this implementation allocates an N×N mask and makes no total linear-memory claim. No timing or speed claim is supported.

The author's repository was actually read through GitHub on 2026-10-06: tag v1.0.9, path `flash_attn/flash_attn_interface.py`, Git blob SHA `07e97ce96f688bd62446b432005e2b87a1739aab`. File and license are included; metadata in `upstream_source.json`. The interface imports Torch and `flash_attn_cuda`, uses default head-dimension inverse-square-root scaling, supports causal flag and dropout, and dispatches to CUDA fwd/bwd. `flash_attn_unpadded_func` expects q/k/v shaped `(total, nheads, headdim)` and cumulative sequence lengths. Our single-head NumPy arrays and arbitrary random mask do NOT implement this interface. The value dimension5 is a generic mathematical attention probe, not an accepted claim about this CUDA interface.

## Primary source anchors

- Dao et al., *FlashAttention: Fast and Memory-Efficient Exact Attention with IO-Awareness*, https://arxiv.org/pdf/2205.14135, June24 2022 version inspected: §3.1, printed pp4–5, decomposition and Algorithm1; Theorem1 and AppendixC separate real-arithmetic equality from the finite-precision sweep here. The retrieved PDF has34 pages. Author-paper performance numbers are not this experiment's results.
- Official source: https://github.com/Dao-AILab/flash-attention/blob/v1.0.9/flash_attn/flash_attn_interface.py . Tag plus exact blob SHA records the read code even if the tag later moves. Torch/CUDA were unavailable and upstream code was not imported.

Reproduce: `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python reproduce.py attention --run-id attention-replay-01` from pack root. No backward pass, dropout, half precision, GPU, learned model, long-sequence throughput, peak resident memory or task accuracy was evaluated.

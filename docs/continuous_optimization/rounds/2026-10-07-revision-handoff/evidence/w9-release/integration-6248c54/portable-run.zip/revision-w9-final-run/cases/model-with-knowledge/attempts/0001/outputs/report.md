# REV-03: bounded scheduler reuse decision

The fixed-index min-monoid is applicable to the specified scheduler. An indexed heap is an equally valid planning baseline for global minimum only; neither has measured performance superiority here. No external implementation is adopted: the local card supplies a pinned ACL pointer, but this attempt has not inspected the actual upstream source, API or license. Those remain unknown for adoption.

This is a fresh execution against the final frozen inputs, with prior task familiarity, not an unseen sample. Role: model-with-knowledge. Input version: w9-final-model-with-knowledge. Model identity and token usage are unknown. All work is local and bounded; no benchmark, network, installation, additional agent, Mailbox mutation or finding closure occurred.

## Concrete mapping and alternatives

Let N fixed task-ID slots have ordinals 0 through N−1. A live slot holds an integer priority; smaller wins, and equal priority breaks by fixed slot ordinal. Priority is an ordinal, not milliseconds; slot indices and operation counts are dimensionless. Inactive leaves hold a tagged identity represented in this Python witness by (+infinity,N). No floating priorities, NaN or mutable tie order are admitted. A production finite-width representation needs an explicit inactive tag or proven bounds; do not silently choose a finite sentinel that a valid priority can exceed.

| Structure | State and selection | Point replacement | Structural cost (not measured runtime) | Failure condition |
|---|---|---|---|---|
| Indexed binary heap | Partial order of (priority,slot); ID→position map; root is minimum | Remove/replace and restore order; position map follows swaps | Peek O(1); update O(log N); storage O(N) | A plain heap API does not promise arbitrary ID update; stale handles or unsifted mutation break it |
| Ordered contiguous list | Total order of (priority,slot); first item minimum | Remove prior pair, binary insertion into sorted array | Peek O(1); update O(N) shifts even with O(log N) search; storage O(N) | Binary search alone does not make insertion logarithmic; linked-list navigation differs |
| Segment monoid | Leaf at fixed task slot, internal lexicographic min; root aggregates all slots | Set leaf, recompute ancestors | Peek root O(1); set O(log N); range aggregate O(log N); O(N) storage | Unknown IDs, nonassociative op, wrong identity or interval convention invalidate mapping |

These costs follow from tree height or array movement, not benchmark results. The witness heap uses an explicit position map (no lazy-entry growth). The list witness uses linear removal, consistent with its O(N) bound. Segment storage is less than 4N cells for N>0. A segment root already stores the global min, so range queries are an optional capability, not an invented scheduler requirement. Fixed slots make segment updates direct and deterministic; a heap is also appropriate if only minimum selection and updates are needed. Constant factors and actual workload latency remain unmeasured.

The aggregate is min on lexicographically ordered pairs. For any a,b,c, both min(min(a,b),c) and min(a,min(b,c)) select the least of the same three elements. The inactive identity is above every valid element, so it is a two-sided identity. This establishes the algebra beyond the finite witness checks. Commutativity happens to hold for min but is not required by the generic segment tree; ordered concatenation demonstrates why two accumulators preserve order.

## Actual knowledge retrieval and decisions

`command-results.json` contains real CLI stdout, stderr and exit codes. The structural query found ds.segment-monoid, fully read via `show`; its `requires` is empty, so there are no missing declared prerequisite entries. Other lexical hits (PagedAttention, LoRA, Fenwick sum) do not establish scheduler minimum semantics. The heap/ordered-list query did not supply a relevant local card; no such source was invented. Baseline reasoning and code here are independent elementary constructions.

Corpus snapshot: d09e72e79a39c334285a59d91dbdd5a6be2530eb8e2246ba8f09f2067b1e82b9. Entry ds.segment-monoid v1, hash 704383602e286115a01d428c82e437c1815283ecf44e2b9001864387b1e3d51b. The published status is provenance, not automatic applicability.

| Actual decision input | Returned disposition | Interpretation/action |
|---|---|---|
| Associative op with identity; zero-based half-open; point set/range aggregate | evaluate_pinned_implementation | Candidate mapping matches; inspect source/API/license before adoption |
| Operation changed to unbounded insertion of new IDs and point updates | minimal_transfer_check | Intentional mismatch; fixed-slot witness rejects new slot E without mutation |
| Algebra omitted as unknown | insufficient_context | Do not assume associativity or identity from a data-structure name |
| Matched conditions plus explicit reproduction flag | run_requested_experiment | Reproduction cannot be skipped; performed bounded semantic witnesses requested here |

All four returned automatic_skip_authorized=false. The decision tool compares declared strings; it does not understand arbitrary API facts or prove the conditions. The fixed domain has no dedicated card condition: the mismatch is represented by the changed operation string, and independently established by the domain model and executable rejection. API and licensing are outside these condition strings and remain unknown. No citation grants permission to waive explicit reproduction.

## Executed witnesses and preserved counterexamples

`witness.py` is an original small Python implementation, not upstream ACL execution. Thirteen state transitions agree across indexed heap, ordered list, segment tree and a dictionary-based oracle. They include equal priorities, decrease and increase, deactivation, empty scheduler and reactivation. All 195 half-open range checks pass. There are also 125 finite associativity checks and five identity checks; they supplement the algebraic argument, not prove every program input correct.

Negative outcomes are retained: a new slot E is rejected and state stays unchanged; subtraction is not associative since (5−3)−1=1 while 5−(3−1)=3; a deliberately reversed right accumulator yields `cab` instead of `abc`; [1,2) yields `b` whereas inclusive [1,2] means `bc`. Empty concatenation ranges produce the identity. An unbounded scheduler needs a different domain policy (e.g. heap with dynamic ID map), rebuilding/reindexing with explicit cost, or a separately verified dynamic tree. It cannot inherit this fixed-index acceptance.

ACL pointer reported by the local card: atcoder/ac-library@864245a00b00dd008d1abfdc239618fdb7d139da, atcoder/segtree.hpp, atcoder::segtree<S,op,e>, set/prod; card-reported CC0-1.0. Current attempt has not fetched that source/license or exercised that C++ API. Therefore no implementation reuse adoption is proposed or claimed. Before adoption, verify the pinned bytes, license and integer/sentinel behavior, compile the actual API and rerun these semantic cases. Boundary search is unused; max_right/min_left would additionally require a monotone predicate with f(e)=true. Range updates require a different structure; min priorities cannot simply use a range-sum Fenwick interface.

## Genuine prepared context and historical evidence

The host supplied an actual root `prepare_context` payload for legacy writer delivery seq3 to research-review. It was explicitly forwarded by root; it is not this role's Mailbox receipt. I parsed the payload and fetched all four immutable referenced artifacts under inputs/handoff. All artifact hashes and both consumer-permitted revision hashes match. The legacy complete integrity validation passes. Its empty knowledge_refs/evidence_claims are accepted for legacy compatibility, with no theorem endorsement.

Payload size is exactly 689 characters and 689 UTF-8 bytes; token count is unknown and this does not include tool envelope/model output. The old input_version is synthetic-manuscript-v1, distinct from this task's binding. The revised manuscript is bounded to synthetic single-run CPU data, preserves the 200→220 latency regression, and does not establish GPU or quality effects. The evidence mapping rejects the false hidden-regression premise and has no writer closure decision. These historical artifacts neither prove scheduler correctness nor authorize any ACK/publish/closure. This attempt leaves original evidence intact.

## Integrity and limits

`source-load.json` records actual frozen contract/source paths and hashes. `protected-after.json` rechecks inputs against the pre-execution hash inventory. `handoff.json` uses paths relative to this output directory. Complete validation uses that artifact root and trusted task REV-03/input binding. Basis validation separately uses the host-owned frozen snapshot corpus root; it checks identity, declared prerequisites and premise records, not scientific truth.

One bounded repair was needed: `check-refs` rejected a bare reference list with “refs document must be an object”; the corrected file is an object containing knowledge_refs. The original script and failed command remain saved, and the corrected check passed. An earlier read-only shell path typo failed before correction, recorded in source-load.json. No negative scientific result was erased. Completion means the requested planning, retrieval, semantic checks and handoff are produced; it does not mean external code adopted, benchmark improvement established, or original findings closed.

# Citation audit

Date: 2026-10-06. Scope: supporting passages, not citation identity alone. All prose is original; no source performance values are presented as this study's results.

| Key | Identity/version checked | Supporting passage and manuscript use | Boundary |
| --- | --- | --- | --- |
| vaswani2017 | Official NIPS 2017 11-page PDF, title/author first page and §3.2 opened directly by writer | Physical pp3–4 §3.2.1 and Equation1 define scaled dot-product weighted values with distinct key/value dimensions. p5 §3.2.3 defines forbidden-score masking. Used in §§1,2,5 for the target operator. | No translation scores, architecture effectiveness, or trained-model conclusions borrowed. Official PDF identity is separate from abstract-page metric differences recorded in preflight. |
| dao2022 | arXiv:2205.14135v2, June24 2022, 34-page source opened directly; title/author/date and §3.1 read. | Printed pp4–5 §3.1 gives stable block maximum and normalization decomposition; Algorithm1 gives block updates. Supplied source notes and exemplar notes locate AppendixC induction. Used in §§1,2,5 to attribute the established merge and distinguish sparse extension from fixed-pattern exact evaluation. | This is not the 35-page official extended PDF used as EX04 writing exemplar. No paper GPU timing, IO bound, or training result is claimed reproduced. Writer directly opened §3.1; AppendixC support additionally comes from supplied full-reader notes, not a new writer full-PDF read. |
| interface | Dao-AILab/flash-attention tag v1.0.9, exact Git blob 07e97ce96f688bd62446b432005e2b87a1739aab; supplied source and metadata inspected | `flash_attn_unpadded_func` lines295–327 gives input shape, cumulative lengths, causal/dropout parameters and default scaling. Imports and forward/backward dispatch definitions support §5 interface boundary. | Source inspection only. Torch/CUDA interface not executed. Release year not established; absent from bibliography rather than invented. |

Direct primary URLs:
- https://papers.nips.cc/paper_files/paper/2017/file/3f5ee243547dee91fbd053c1c4a845aa-Paper.pdf
- https://arxiv.org/pdf/2205.14135v2 (retrieval through unversioned https://arxiv.org/pdf/2205.14135 returned v2, dated June24 2022)
- https://github.com/Dao-AILab/flash-attention/blob/v1.0.9/flash_attn/flash_attn_interface.py

Observed browser-source calls in this writer: open both original PDFs; find scaled-attention and §3.1 anchors; open §3.1 and Transformer first page. These reads verify nearby claims; they do not claim a fresh full read of either PDF. The ten-exemplar complete-read precondition belongs to the supplied coordinating-team receipt.

import hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
CASE=OUT.parents[2];IN=CASE/'inputs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((IN/'sources.json').read_text());checks=[]
for r in s['local_fixture_map']+s['external_primary_sources']:
 p=IN/r['fixture'] if 'fixture' in r else Path(r['path'])
 checks.append({'path':str(p),'expected_sha256':r['sha256'],'sha256':sha(p),'match':sha(p)==r['sha256'],'location':r['location']})
assert all(x['match'] for x in checks)
h=json.loads((IN/'host-context.json').read_text());payload=json.loads(h['payload'])
refs=[]
for r in payload['artifacts']:
 p=IN/'handoff'/r['path'];refs.append({**r,'actual_sha256':sha(p),'match':sha(p)==r['sha256']});assert refs[-1]['match']
assert len(h['payload'])==h['usage']['chars'] and len(h['payload'].encode())==h['usage']['bytes']
(OUT/'source-verification.json').write_text(json.dumps({'source_checks':checks,'root_forwarded_payload':payload,'payload_ref_checks':refs,'payload_usage_verified':h['usage'],'legacy_knowledge_refs':payload['knowledge_refs'],'own_mailbox_receipt':False,'no_original_db_opened':True},indent=2)+'\n')
print(json.dumps({'all_source_hashes_match':True,'sources':len(checks),'forwarded_refs':len(refs),'payload_chars':len(h['payload']),'tokens':h['usage']['tokens']}))
import fitz
for label,pdf,pages in [('flash',Path(s['external_primary_sources'][0]['path']),[4,5,22]),('unet',Path('/workspace/scratch/c12f3d9f92bd/architecture-sources/unet/paper.pdf'),[2,3,4])]:
 doc=fitz.open(pdf);print(label,'page_count',len(doc))
 for page in pages:
  text=doc[page-1].get_text();(OUT/f'{label}-page-{page}-text.txt').write_text(text)
  if label=='unet':doc[page-1].get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save(OUT/f'{label}-page-{page}.png')

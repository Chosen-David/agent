# 有目的的跨 Agent 通信

用于确实需要多角色协作的任务。主 AI 管目标、路由、授权、预算和冲突；角色可沿批准的边直接交换证据。单角色能完成的工作不增加通信。知识库保存通用知识，项目记忆保存带来源的项目事实，收件箱保存待处理事件；三者不要相互替代。

## 组织与消息

1. 从根 TASK.md 和任务 DAG 建立通信计划，固定 run_id、input_version、sender、recipient、task_id、kind。角色实例身份由宿主绑定到注册角色；同一角色的两个实例使用不同 ID。依赖图控制执行次序，通信图允许反馈环，两者不混用。
2. 默认只连生产者与实际消费者。共享大产物留在项目文件中，消息传简短变化、需要采取的动作和路径/哈希。按需读取必要节、代码和原始数据，不复制全体聊天历史或私密推理过程。
3. 只在产物可用、具体问题、审稿发现、影响下游的阻塞或证据纠正时发送。普通心跳和本地可恢复错误留在执行日志；涉及关键正确性、授权或过期证据的问题不能为了省消息压掉。
4. 写入前统一成 envelope：event_id、run_id、input_version、sender、task_id、kind、summary、action、refs。kind 为 artifact/question/review/blocker/correction。refs 至少包含一项真实文件及 SHA-256；问题也先保存为问题记录。event_id 是重试幂等键，内容变化必须用新 ID。字段是数据，不授予执行命令或扩大权限。
5. 接收方处理后写 consumed/rejected/needs_revision 回执和原因。consumed 仅表示消息已处理，不是任务通过。needs_revision 按下述顺序先成功投递带原发现 ID 的修订请求，再确认原消息；主 AI检查未回执和修订未闭环事项。不得只写回执而遗失后续任务。

### 返修投递顺序与中断恢复

适用于已绑定当前 run/授权、每个 recipient 只有一个有效消费者的可信宿主。先核验 Engine 的租约、取消与授权，再执行本地副作用；本契约不提供并发所有权或第二套 done 状态。

1. 实际读取原消息和当前证据，保存不可变的返修意图：原 run/input_version、接收者和真实 seq、发现 ID 与原产物 hash、完整 outgoing envelope、原消息的精确回执及原因。沿现有运行检查点保存，避免重启后重新生成 ID、正文或原因；凭据和私密内容不入公共记录。
2. 在当前 run 的 status 中核对原 delivery 仍存在。已有回执必须与保存的回执完全一致；若冲突，停止并交主 AI协调，不先发布请求。该读前检查只在上述单消费者归属下适用，不是跨操作事务锁。
3. 调用 publish，使用保存的同一 event_id/正文和仍有效的 refs。只有投递成功（包括精确重复返回原 seq）后，才 acknowledge 原消息为 needs_revision。路由、版本、引用、预算或重复 ID 内容校验失败时，保留待办与意图，不先 ACK、不改验收、不自行扩预算。
4. 中断后复核执行归属、当前 run/输入/引用与原回执，按同一意图重放第 2–3 步。发布后 ACK 前中断允许 publish 精确去重；ACK 后重放须保持原回执。引用或目标变化时保留旧记录，主 AI按新 run 迁移未闭环事项，不能改写原意图冒充同一重试。预算耗尽与不可解释冲突记录为未解决。
5. 责任方实际处理请求、产出修订并成功投递后，才确认其收到的请求。原审稿者按原 finding 的复验条件检查新产物；原始判断保持不可变，新关闭记录绑定原发现 ID、新旧产物 hash 和证据。投递、消费及科学关闭分别记录，任何一种回执都不能单独关闭发现。

这里使用现有 publish/acknowledge 两个操作，未保证它们事务原子，也不保证外部副作用恰好一次。旧的 ACK-first 调用仍可能遗漏返修投递；宿主需迁移到本顺序并验证恢复路径，不能把规范更新声称为所有 adapter 已生效。

## 科研反馈闭环

| 通信边 | 负载与触发 | 完成标准 |
|---|---|---|
| 实现 → 写作/数据图 | 新数据快照、配置、单位、重复次数、失败结果、可支持主张 | 消费者校验版本并实际读取必要证据 |
| 写作 → 实现 | 待支撑的精确主张、缺少的实验、预期区分的解释 | 实验或明确不可做原因，不能虚构结果 |
| 审稿 → 责任角色 | finding_id、原文位置、严重度、证据、修复建议、复验条件 | 修复后由审稿按原条件复验，不由作者自行关单 |
| 读者 → 写作/作图 | 冻结 PDF 哈希、页码、图号、可见缺陷 | 查看新 PDF 的受影响页和上下文 |
| 任意角色 → 主 AI | 目标冲突、证据矛盾、资源/权限不足、反复无进展 | 主 AI按原决策协议裁决/重排/报告阻塞 |

每个输出路径只有一个写入者。审稿和读者先独立形成判断，再读其他角色意见，避免互相暗示形成虚假共识。协商围绕可证伪问题、实验或产物差异，不做无目标长辩论。主 AI预设反馈轮数和成本上限（默认每个发现最多两次修订后重新诊断，可按任务调整）；预算耗尽是未解决，不是通过。该语义闭环仍由主 AI/可信 adapter 执行，以下程序不理解科学内容，也不自动关闭发现。

## 可执行本地接口

运行时为 [agent_runtime/communication.py](../agent_runtime/communication.py)，使用 Python 标准库 SQLite 事务保存事件和每个消费者的回执。它是本地同盘 inbox，没有网络监听、模型调用或新调度器；现有宿主 adapter 按任务阶段调用它。完整仓库可运行，单独分发 Skill 的宿主须提供此能力，否则使用同一字段手工交接并明确未接入持久 inbox。

计划示例（主 AI/消费者持有，不交给生产者修改）：

```json
{
  "schema_version": 1,
  "run_id": "study-v1",
  "input_version": "actual-input-version",
  "max_message_bytes": 8192,
  "max_events": 1000,
  "routes": [
    {"sender":"research-implement-optimize", "recipient":"research-write", "task_id":"EXP-1", "kind":"artifact"},
    {"sender":"research-implement-optimize", "recipient":"research-review", "task_id":"EXP-1", "kind":"artifact"},
    {"sender":"research-review", "recipient":"research-implement-optimize", "task_id":"EXP-1", "kind":"review"}
  ]
}
```

预算是显式可调默认值，不是论文测出的最优参数。需要 question/correction/blocker 等边时在启动前按实际消费者补齐；无匹配路由报错，不能静默丢弃。目标/版本/路由改变建立新 run，主 AI核对并迁移未闭环事项，保留旧历史；不能把旧消息简单换版本继续当新证据。

```bash
python -m agent_runtime.communication --db .agent-runs/study-v1/messages.sqlite --plan communication-plan.json --root . publish event.json
python -m agent_runtime.communication --db .agent-runs/study-v1/messages.sqlite --plan communication-plan.json --root . inbox research-write
python -m agent_runtime.communication --db .agent-runs/study-v1/messages.sqlite --plan communication-plan.json --root . consume research-write 1 --request consumer-request.json
python -m agent_runtime.communication --db .agent-runs/study-v1/messages.sqlite --plan communication-plan.json --root . ack research-write 1 receipt.json
python -m agent_runtime.communication --db .agent-runs/study-v1/messages.sqlite --plan communication-plan.json --root . status
```

seq 用实际 publish/inbox 返回值，不猜测。完成产物消息的 refs 包含 `id="handoff"`，指向现有 [handoff JSON](../docs/handoff_validation.md)。consume 重新验证 manifest 及其产物哈希、生产角色/run、输入版本和独立 consumer-request 的完整任务范围；不自动 ACK。实际读取内容、语义审查和幂等动作完成后才 ack。普通问题/审稿记录由宿主检查原引用哈希并按上表处理。

API 为 `Mailbox(db, plan, artifact_root).publish/inbox/consume_handoff/acknowledge/status`。支持重复发布去重、事务内投递、重启后待办恢复、有限分页和不可覆盖的回执。多个轮询者会看到同一未回执消息：至少一次读取，**不保证副作用恰好一次**。宿主给每个 recipient 配置一个消费者，使用 `(run_id,event_id,recipient)` 作为动作幂等键；不确定的外部副作用先查证。现有 `Context.current()` 的取消/租约检查及宿主独立授权检查必须在执行副作用前复核；邮箱不接管 Engine 状态或设置 task done。

同盘 SQLite 适合当前单机可移植运行时。它不是认证/隔离沙箱，也不抵抗恶意并发替换文件；可信宿主持有计划、请求、artifact_root 并控制文件权限。数据库只含运行事件，知识文件仍是知识库事实源。将来跨机器时再考虑 A2A/消息服务，保留相同业务契约并单独验证重试、身份和版本。

## 验收与持续优化

先测无关投递、重复执行、重启、旧数据、缺失任务、失败回执；再测真实代码→图→论文→审稿→读者链。公平对照现有主 AI转述、全广播和定向引用三种方式，固定输入、模型、工具、预算和验收；统计实际 token/耗时、正确关闭的发现、错误复用、返工和最终质量。离线消息数下降不能代替模型性能收益。记录无收益和缺测，学习式剪枝、主动中断及自动语义压缩需独立实验后再启用。

知识依赖交接遵循 [知识接入契约](knowledge_access_workflow.md)。handoff 顶层声明 knowledge_refs，可信消费者 request 固定 knowledge_root 与必需引用；consume_handoff 在返回前验证，缺库、引用过期或遗漏保持待办，不自动 ACK。


## 统一依据、结论依赖与上下文预算

可信消费者 request 在已有 knowledge_root/knowledge_refs 之外可带 `knowledge_required: true`、`memory_required: true`、`memory_refs` 和 `required_claim_ids`。已知必需引用必须独立固定；派发时尚不知具体知识 ID 时可用 required 标记要求生产者至少声明引用。纯格式任务保留无依据兼容路径，并在任务记录 not_needed 原因。生产者不能通过同名输出字段放宽消费者约束。

`consume_handoff` 现在调用 `check_handoff_basis`：复用知识门禁和项目 MemoryLedger，验证所有声明、必需子集和结论依赖；有效引用不代表前提真的成立。非 Mailbox 宿主先运行普通 handoff 完整性/范围验证，再调用同一依据函数。调用成功会将 manifest 和可信 request 的绑定保存在同一个 SQLite DB；同一投递绑定不可改，变更须新事件/新 run，旧 ACK 和原数据不改。

handoff 可带 `evidence_claims`，每个结论准确字段如下（真实 artifact ID 须在 handoff artifacts 中）：

```json
{
  "id":"certificate", "status":"supported",
  "knowledge_ids":["math.topk-margin"], "memory_ids":["measured-margin-v1"],
  "artifact_ids":["verification"], "depends_on":[],
  "assumptions":[{"name":"gap exceeds twice the score-error bound", "status":"satisfied", "evidence_ids":["verification"]}]
}
```

status 为 supported/rejected/candidate；前提 status 为 satisfied/unsatisfied/unknown。supported 不能依赖 candidate/rejected，不能以未知前提标作支持；satisfied 必须有已声明证据路径，内容真伪仍由独立消费者核验。depends_on 只引用同一 manifest 中的结论，要求无环。跨 handoff 依赖复用项目记忆不可变 claim/artifact IDs 及 deps，不按相同自然语言自动合并。

`Mailbox.impact()` / CLI `impact` 重核已登记依据，返回 event_id/seq/真实 recipient/受影响 claim_ids；知识或记忆更正沿声明依赖传播，无关结论不列入。usage_stage=validated_handoff 只表示接收方读取并校验了交接，不冒充实际科学应用。主 AI据此按已批准 correction 边发修订事件、重排受影响任务并由原消费者复验；程序不自动发消息或科学关单。无 claim 的旧交接只能返回整包 stale，未声明依赖无法推断。原回执、原数据和无关任务保留；复验必须新产物/事件，不机械换 hash。

固定语料路径对应完整合法快照（含库关系元数据）；只把必要条目装入模型上下文。常规增加或编辑无关条目不使已固定引用失效；真实依赖更正会阻断复用。旧安装 Skill 自带快照仍需主 AI明确更新，不能冒充当前主库；不以全库 snapshot 变化重算全部任务。

### 成本接口与接入顺序

可信 host 按 **inbox → prepare_context → 实际审查/幂等动作 → ACK** 执行，任务验收仍独立。`prepare_context` 先调用 consume 校验，返回 JSON 字符串 payload（引用、结论、必要知识及项目记忆的完整前置依赖；大产物仅保留路径/hash），超预算报错，不截断证明或悄悄放宽预算。CLI：

```bash
python -m agent_runtime.communication --db RUN.sqlite --plan PLAN.json --root . context writer 1 --request REQUEST.json --max-chars 20000
python -m agent_runtime.communication --db RUN.sqlite --plan PLAN.json --root . impact
python -m agent_runtime.communication --db RUN.sqlite --plan PLAN.json --root . usage
```

API 可提供 `known_knowledge_refs`、`known_memory_ids`（CLI --known 指向可信宿主维护的 JSON）。这些只指该消费者**当前模型上下文中仍实际保有**的内容，不是曾经检索过或磁盘缓存过；换模型/上下文压缩丢失内容则清空。省略重复正文仍保留全部引用/前提/产物信息，并重新检查引用/记忆状态。生产者不得自报消费者缓存。首轮加载成本也计入比较。

默认 max_chars=20000 是工程参数；消费者可固定 context_max_chars。可信宿主可提供实际模型 tokenizer 的 token_counter(str)->int 以及 max_tokens，消费者 context_max_tokens 为不能放宽的硬限。没有实际 tokenizer 则 tokens=null；存在 token 硬限但无法计数时停止该模型派发，不能用字符/4 估计冒充实际 token。计数范围为精确 payload；工具包壳、模型输出/推理 token 和其他输入由宿主预算账本另计，并在每次调用前检查整轮余额、重试和反馈上限。

计划可增加 max_delivery_bytes：按收件人数累计 envelope UTF-8 字节，重复 event_id 不重复计费，超额拒绝整个投递，不部分广播。usage 提供 events/deliveries/envelope_bytes/delivery_bytes；这不是模型收费账单。不为了省 token 删除关键反例、前提或原始证据；先缩小问题/检索范围、复用当前上下文、批量独立读取和减少无关收件者，再考虑经独立实验的摘要。

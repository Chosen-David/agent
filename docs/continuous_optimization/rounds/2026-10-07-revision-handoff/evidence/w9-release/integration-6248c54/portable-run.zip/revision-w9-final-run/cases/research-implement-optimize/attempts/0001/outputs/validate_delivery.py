"""Read-only complete integrity + basis verification, no Mailbox/DB side effects."""
from pathlib import Path
import json
import sys
import hashlib

out = Path(__file__).resolve().parent
root = out.parents[4]
sys.path.insert(0, str(root / 'snapshot'))
from scripts.validate_handoff import validate
from agent_runtime.handoff_basis import check_handoff_basis, basis_context

record = json.loads((out / 'handoff.json').read_text())
request = json.loads((out / 'validation-request.json').read_text())
errors = validate(record, root, True, consumer_request=request)
assert not errors, errors
basis = check_handoff_basis(root, record, request)
inputs = out.parents[2] / 'inputs'
legacy = json.loads((inputs / 'handoff/writer/handoff.json').read_text())
legacy_request = json.loads((inputs / 'consumer-request.json').read_text())
legacy_errors = validate(legacy, inputs / 'handoff', True, consumer_request=legacy_request)
assert not legacy_errors, legacy_errors
legacy_basis = check_handoff_basis(inputs / 'handoff', legacy, legacy_request)
prepared = basis_context(inputs / 'handoff', legacy, legacy_request, max_chars=20000)
forwarded = json.loads((inputs / 'host-context.json').read_text())
assert prepared['payload'] == forwarded['payload']
print(json.dumps({'integrity_valid': True, 'completion_verified': True,
                  'basis_valid': True, 'basis': basis,
                  'legacy_integrity_errors': legacy_errors,
                  'legacy_basis': legacy_basis,
                  'forwarded_payload_reconstructed_identically': True,
                  'payload_sha256': hashlib.sha256(prepared['payload'].encode()).hexdigest(),
                  'usage': prepared['usage'],
                  'no_original_mailbox_or_db_operation': True,
                  'scope': 'local integrity/declared basis only; semantic acceptance by main'}, indent=2))

# Latency figure design brief

Show descriptive baseline/candidate differences for every workload. Use two vertical facets determined by scope, with identical 0–250 ms axes. Paired unconnected point marks avoid implying a continuous workload curve. Preserve all integer values with direct labels, including the large regression. Baseline: muted blue circle above each category; candidate: amber square below. No distribution, aggregate, error bar, significance or new analysis.

Provisional 7 × 4.6 inch canvas. DejaVu Sans, 9 pt labels, 11 pt title; pale vertical grids. Separate scope headings, an interfacet gap, shared bottom legend, and unchanged method order. English input labels retained, no translation requested. Font/size are provisional because no venue was supplied. External exemplar learning not run: local-only standalone supplied-data exercise with no exemplar papers. Source is synthetic, provenance and repeats are unavailable. No independent collaborators.

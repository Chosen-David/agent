# Fresh latency figure / author QA

Ready for independent review as a faithful supplied synthetic figure. Main agent owns grading. All source paths and SHA-256, input rows, actual plotted offsets and local versions are in manifest.json. The registry and communication workflow were read earlier in this same fresh sequential execution. No old-run output was read/copied; source freshly written. No network, new installation, subagents, models or new statistics.

Reproduce with `python -B plot.py` from this output directory. Actual exports latency.svg/png/pdf; SVG has editable text and native marks, Python is the editable plotting source. Provisional size 7 × 4.6 in, PNG 1680 × 1104 pixels at 240 dpi. PDF rendered with `pdftoppm -scale-to 1400 -png -singlefile latency.pdf pdf_render`. Actual `pdffonts latency.pdf` report retained and both TrueType subsets embedded.

Actual view_image review on 2026-10-07: final_size.png (700 × 460), grayscale.png, pdf_render.png and page_preview.png opened. One render, no failed version or local repair in this run. PDF glyphs, values and markers checked as pixels separately from PNG. Page preview is approximate rather than a real manuscript/physical print.

Numerical self-QA: pass. Four unique workload rows, no missing or nonfinite numerical values. Actual scatter x offsets equal input values, with all eight values recorded in manifest. Scope faceting preserves source row order. No aggregate, smoothing, extrapolation, exclusion, uncertainty invention or significance. Large regression is visible at 220 vs 200; kernel facet is distinct.

Visual self-QA: pass at provisional displayed size. Scope headers clear, point/value pairs readable, circles and squares distinguish methods in grayscale. Exact values sit beside marks without collision, the 220 label stays inside the right margin. Pale grids stay subordinate; identical axes and method order enable fair comparison. Shared legend sits below the axis label, no overlap. Title/subtitle and first facet heading are separated. No missing glyph or clipped label seen in either PNG or PDF. Color-vision simulation unverified.

Technical/reproduction: SVG XML parse passes, actual plotting and PDF pixel export succeeded. Paths, hashes, code and raw/plotted values preserved. SVG font availability on another machine unverified; PDF embeds fonts. Venue compliance unverified because none was supplied. No Chinese figure requested; English input labels remain unchanged.

External exemplar learning not run: supplied-only standalone task, no paper references. Independent review not performed by this actor. Missing repeat counts/units, uncertainty, hardware/configuration and empirical provenance limit inference, not faithful plotting.

Final exact PNG additionally opened directly with view_image: latency.png.

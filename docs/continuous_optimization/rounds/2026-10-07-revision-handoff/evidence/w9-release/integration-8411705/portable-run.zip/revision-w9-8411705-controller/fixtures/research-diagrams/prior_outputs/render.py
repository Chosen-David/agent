from pathlib import Path
import json,hashlib,math,platform,xml.etree.ElementTree as ET
from xml.sax.saxutils import escape
import fitz
from PIL import Image,ImageOps
OUT=Path(__file__).resolve().parent;CASE=OUT.parents[2];ROOT=OUT.parents[4]
source=CASE/'inputs/architecture.json';spec=json.loads(source.read_text())
boxes={'a':(40,130,210,70),'b':(40,280,210,70),'sum':(330,205,200,70),'softmax':(610,205,240,70),'v':(330,365,200,70),'output':(610,365,240,70)}
paths={('a','sum'):((250,165),(330,234)),('b','sum'):((250,315),(330,246)),('sum','softmax'):((530,240),(610,240)),('softmax','output'):((730,275),(730,365)),('v','output'):((530,400),(610,400))}
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="7.5in" height="4.333333in" viewBox="0 0 900 520">','<title>Proposed two-path logit combination</title>','<desc>Exact supplied six-node, five-edge synthetic unimplemented specification. Arrows mean data flow.</desc>','<rect x="0" y="0" width="900" height="520" fill="white"/>']
def text(x,y,s,size=17,anchor='start',bold=False,color='#22384d'):
 return f'<text x="{x}" y="{y}" font-family="serif" font-size="{size}" font-weight="{"bold" if bold else "normal"}" text-anchor="{anchor}" fill="{color}">{escape(s)}</text>'
svg += [text(40,48,spec['title'],24,bold=True),text(40,80,'Proposed schematic · synthetic specification · not implemented',15,color='#536a80')]
for n in spec['nodes']:
 x,y,w,h=boxes[n['id']]
 svg += [f'<g id="node-{n["id"]}"><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="#eef2f5" stroke="#536a80" stroke-width="1.5"/>',text(x+w/2,y+h/2+6,n['label'],anchor='middle'),'</g>']
for u,v in spec['edges']:
 (x,y),(xx,yy)=paths[(u,v)];length=math.hypot(xx-x,yy-y);dx=(xx-x)/length;dy=(yy-y)/length
 tip=(xx-3*dx,yy-3*dy);base=(tip[0]-10*dx,tip[1]-10*dy);verts=[tip,(base[0]-4*dy,base[1]+4*dx),(base[0]+4*dy,base[1]-4*dx)]
 points=' '.join(f'{a:.3f},{b:.3f}' for a,b in verts)
 svg += [f'<g id="edge-{u}-{v}" data-source="{u}" data-target="{v}" data-kind="data_flow"><path d="M{x},{y} L{base[0]:.3f},{base[1]:.3f}" stroke="#536a80" stroke-width="2" fill="none"/><polygon points="{points}" fill="#536a80"/></g>']
svg += [text(40,483,'Arrows: data flow. Fixed values V enter only the output.',15,color='#536a80'),'</svg>']
(OUT/'method.svg').write_text('\n'.join(svg))
elements=list(ET.parse(OUT/'method.svg').iter());ids=[e.attrib['id'] for e in elements if 'id' in e.attrib]
assert len(ids)==len(set(ids))==11
assert {x for x in ids if x.startswith('node-')}=={'node-'+n['id'] for n in spec['nodes']}
assert {(e.attrib['data-source'],e.attrib['data-target']) for e in elements if 'data-source' in e.attrib}==set(map(tuple,spec['edges']))
with fitz.open(OUT/'method.svg') as doc:doc[0].get_pixmap(matrix=fitz.Matrix(2.5,2.5)).save(OUT/'method.png')
im=Image.open(OUT/'method.png').convert('RGB');im.resize((900,520)).save(OUT/'final_size.png');ImageOps.grayscale(im).resize((900,520)).save(OUT/'grayscale.png')
page=Image.new('RGB',(1050,1359),'white');page.paste(im.resize((900,520)),(75,160));page.save(OUT/'page_preview.png')
contract={'status':spec['status'],'evidence_type':spec['evidence_type'],'source_path':str(source.relative_to(ROOT)),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'nodes':[dict(n,svg_id='node-'+n['id'],source_pointer=f'/nodes/{i}',incoming=[u for u,v in spec['edges'] if v==n['id']],outgoing=[v for u,v in spec['edges'] if u==n['id']]) for i,n in enumerate(spec['nodes'])],'edges':[{'source':u,'target':v,'direction':f'{u} to {v}','kind':spec['edge_kind'],'label':None,'source_pointer':f'/edges/{i}','svg_id':f'edge-{u}-{v}'} for i,(u,v) in enumerate(spec['edges'])],'groups':[],'invariants':spec['constraints'],'label_changes':[],'unknown':['tensor dimensions','hardware','training/inference distinction','measured performance','accuracy']}
(OUT/'semantic_contract.json').write_text(json.dumps(contract,indent=2))
loaded=['snapshot/config/role_registry.json','snapshot/workflows/agent_communication_workflow.md','snapshot/workflows/diagram_workflow.md']+['snapshot/plugins/research-assistant/skills/research-diagrams/'+p for p in ['SKILL.md','references/execution.md','references/workflow.md','references/figure_shared.md','references/paper_exemplar_learning.md']]+[str((CASE/p).relative_to(ROOT)) for p in ['task.txt','inputs/architecture.json']]
manifest={'run_id':ROOT.name,'role':'research-diagrams','route':'diagram','evidence_type':spec['evidence_type'],'loaded_sources':[{'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()} for p in loaded],'loaded_sections':{'paper_exemplar_learning':'section 7'},'editable_master':'method.svg','generator':'render.py','render_method':'PyMuPDF opens actual SVG and rasterizes it','tools':{'python':platform.python_version(),'PyMuPDF':fitz.VersionBind,'MuPDF':fitz.VersionFitz},'semantic_check':'Exact six nodes and five directed edges asserted against input; 11 unique IDs','dimensions_inches':[7.5,4.333333]}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Fresh native SVG written and rasterized. Exact six nodes/five directed edges and unique SVG IDs checked.')

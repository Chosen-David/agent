"""Contract oracle uses end positions and exact rational accumulation."""
import copy
from fractions import Fraction
import importlib.util
import json
from pathlib import Path
import random
import sys
sys.dont_write_bytecode=True

def reference(values, width):
    answer=[]
    for end in range(width, len(values)+1):
        terms=(Fraction(values[end-j-1]) for j in range(width))
        answer.append(float(sum(terms, Fraction(0))/width))
    return answer

def check(path):
    spec=importlib.util.spec_from_file_location("candidate",path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    failures=[];checks=0
    cases=[([1,2,3],2),([],1),([9],1),([1,2,3],3),([1,2],3),([1,2,3],1),([-6,0,6],2),([0.5,1.5,2.5],2),((3,6,9),2),([10**30,1,-10**30],3)]
    rng=random.Random(20261007)
    for _ in range(100):
        cases.append(([rng.randrange(-100,101) for _ in range(rng.randrange(21))],rng.randrange(1,24)))
    for values,width in cases:
        checks+=1;before=copy.deepcopy(values);expected=reference(values,width)
        try:
            actual=module.moving_average(values,width)
            assert actual==expected,(actual,expected)
            assert values==before,"input mutation"
        except Exception as exc:
            failures.append({"values":repr(before),"window":width,"error":repr(exc)})
    for width,error in [(0,ValueError),(-2,ValueError),(2.5,TypeError),("2",TypeError),(None,TypeError),(True,TypeError),(False,TypeError)]:
        checks+=1;values=[1,2,3];before=values.copy()
        try:
            module.moving_average(values,width)
        except error:
            if values!=before:failures.append({"window":repr(width),"error":"mutation on error"})
        except Exception as exc:
            failures.append({"window":repr(width),"error":repr(exc),"expected":error.__name__})
        else:
            failures.append({"window":repr(width),"error":"did not reject","expected":error.__name__})
    return {"checks":checks,"passed":not failures,"failures":failures,"seed":20261007}

if __name__=="__main__":
    result=check(Path(sys.argv[1]));print(json.dumps(result,indent=2));sys.exit(0 if result["passed"] else 1)

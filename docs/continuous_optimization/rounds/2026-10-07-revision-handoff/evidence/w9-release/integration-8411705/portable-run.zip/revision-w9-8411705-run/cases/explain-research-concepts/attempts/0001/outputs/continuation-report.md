# explain-research-concepts — protected continuation

Fresh independent arithmetic confirms y=5 for equal logits and y=7.5 after b changes to (0,log 3) with fixed V=(0,10)^T. The local sensitivities at equal logits are (-2.5,2.5) for each branch; central differences with h=1e-4 agree within 1e-7. Common shifts leave softmax unchanged, and cancelling a/b perturbations leave the combined logits unchanged. These local derivatives do not justify a global linear approximation to finite perturbations or predict unspecified real-model accuracy.

The actual frozen-corpus search and full read of math.cauchy-schwarz v1 supplied only a relevant boundary warning: a score-error norm bound does not imply unchanged softmax output or task quality. Its requires list is empty. The q/k quantitative bound was not applied because this fixture supplies direct logits, not a q/k factorization and norm premises. The eigenspace-gap candidate was rejected on metadata because its matrix/eigenspace premises are absent. The retrieved entry does not provide the softmax Jacobian theorem; that result follows directly by quotient/chain rule and the new numerical check. Search results do not establish exhaustive absence of other coverage. Actual check-refs passed for the pinned ID/version/hash; this certifies identity, not applicability.

The historical explanation has a retained TeX defect: S=\operatorname{diag}$p$-pp^T inside display math. erratum.md gives the corrected S=diag(p)-pp^T display as an additive repair. No historical file was changed, and the old formatting check is not represented as flawless. The correction is explicitly tracked in the current REV-03 task evidence.

Prior output identity/version remains historical. This supplement does not claim new paper facts, experiments, network checks, exhaustive corpus coverage, or a PDF render.

All recorded source hashes still match at finalization. Completion here refers only to the assigned supplemental work; independent acceptance remains with the parent.

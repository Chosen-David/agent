# Additive erratum: EXPL-001

The protected historical explanation remains unchanged. Its displayed softmax derivative matrix contains a typesetting defect: `S=\operatorname{diag}$p$-pp^T`. Read that line as:

$$
S=\operatorname{diag}(p)-pp^T.
$$

This is a formatting correction to the historical source, not a change to the derivation. The independently rechecked Jacobian is $J_z=V^T S$ and $J_{(a,b)}=[J_z\;J_z]$. At the supplied initial point it is $(-2.5,2.5,-2.5,2.5)$. The exact output change remains $5\to7.5$. The old formatting-check assertion did not cover this separate delimiter defect; its historical record is retained, not rewritten as successful new validation.

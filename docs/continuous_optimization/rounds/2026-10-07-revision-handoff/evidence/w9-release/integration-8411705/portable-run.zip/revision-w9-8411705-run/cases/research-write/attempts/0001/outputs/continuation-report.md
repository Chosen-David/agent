# research-write — protected continuation

The protected synthetic working draft remains supported within its explicit scope. A fresh exact-fraction calculation gives small 1.25×, medium 1.20×, large 10/11 ≈ 0.90909× end-to-end speedups and kernel-only 2×. The large workload is a 10% latency regression. Kernel timing is already included in end-to-end timing; the two scopes cannot be added. These are descriptive single-run CPU records: no repeats, variance, output quality or GPU evidence was added.

Knowledge assessment is not_needed: the requested changes concern supplied facts and elementary ratios. The math corpus cannot fill measurement gaps. No corpus search or imported theorem is claimed. The original task has no input_version; the historical handoff version remains distinct from this trusted supplemental binding.

The extra communication continuation reread the original seq2 review request and validated all immutable references with the current 8411705 runtime. SQLite mode=ro and query_only guarded the diagnostic connection; inherited Mailbox.status/inbox performed current runtime reads. The ordinary review event has no handoff manifest and was validated directly, rather than incorrectly calling consume_handoff. Original/new manuscripts, CSV, finding records, mapping, intent and exact receipt were reread. No publish, ACK, experiment or scientific closure occurred. The before/after state remains three receipts and zero pending deliveries, with unchanged database SHA-256. REV-F003 remains the original rejected allegation of missing regression disclosure. The original reviewer owns finding closure.

This is a fresh semantic and contract supplement, not a rerun or relabeling of historical manuscript authorship. The diagnostic read-only connection override is not a deployed Engine adapter. Historical failures and original artifacts remain immutable.

All recorded source hashes still match at finalization. Completion here refers only to the assigned supplemental work; independent acceptance remains with the parent.

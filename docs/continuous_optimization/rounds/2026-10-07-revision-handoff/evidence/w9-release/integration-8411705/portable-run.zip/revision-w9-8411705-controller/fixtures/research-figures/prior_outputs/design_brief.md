# Mixed figure design brief (fresh run)

Purpose: place the supplied proposed architecture beside all synthetic latency values without implying causal validation. A routes to diagram work; B routes to data visualization; sole owner research-figures executes these steps sequentially in the same context. No independent specialist invocation.

Use a provisional 9.5 × 3.8 inch two-panel canvas. Left: A/B parallel in the first column, addition in the second, softmax in the third; V below addition and output below softmax. Right: zero-based paired horizontal bars and exact B/C labels, with kernel-only separated by a dashed rule and footer. Blue-gray baseline, amber candidate, consistent upper/lower order plus text labels for grayscale. DejaVu Sans 8–11 pt, pale grid and backgrounds, sufficient space below axes for legend and scope. No errors or new statistics; keep large regression. No external exemplars supplied or accessed; local-only standalone figure, not a ten-paper manuscript task.

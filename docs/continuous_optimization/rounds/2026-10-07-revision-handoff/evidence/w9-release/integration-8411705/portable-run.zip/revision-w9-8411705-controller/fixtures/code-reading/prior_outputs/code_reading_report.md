# CODE-READ-001 — selector mechanism, fresh gated source

Scope/version: inputs/synthetic_selector.py, SHA-256 `6fc687e85d2c169c5dc88d7dc126b970036f22b822c00c9f8f0d8b628a6e8ea1`. Standalone fixture has no supplied Git commit, AGENTS.md, .agents/skills, tests or runtime logs. All 30 lines were read after this dispatch; no target import/execution, mutation, graph build or performance test occurred. This is self-checked static analysis, not independent review or observed execution.

| Claim ID | Module narrative at L1–2 | Source fact and static correction |
|---|---|---|
| CR-1 | near is forced | select L19 sets boundary=max(0,n−near_len); L20 independently creates trailing forced positions. L24 ranks nonforced near candidates and L25 truncates them to remaining capacity. Near range is not a guaranteed inclusion set. |
| CR-2 | skip means no scoring | skip_far only selects [] at L23. L21–22 still represent query/all keys and compute reduced scores, L24 still sorts near, and run L30 always calls full_score. |
| CR-3 | projector is query-trained | represent L7–8 defaults to coordinates 0 and 2. Optional basis branch L9 computes dot products with supplied columns. No training/update/query-driven basis construction exists in this file; external origin is unknown. |
| CR-4 | final scoring uses reduced keys | run L30 passes original query/keys and positions to full_score L12–13. Reduced scores are used for selection only. Full-score zip uses original coordinates up to shorter operand length; true full-D requires equal lengths. |

Resolved syntactic call edges (not observed calls): run→select at L29; select→represent(query,basis) at L21; select→represent(k,basis) at L22 for each key; run→full_score at L30. Functions are local definitions L6/12/16/28; this resolution assumes no external rebinding of module globals. No registered backend or separate model is supplied.

Data edges: query + basis → qsmall (L6–9,21); keys[k] + basis → reduced key → dot with qsmall → scores[k] (L22); len(keys) → n → boundary and forced indices (L18–20); scores indexed by positional ranges → descending far/near rankings (L23–24); budget minus actual far and forced counts → truncated near slice (L25); far + near slice + forced → positions (L25,29); original query + original keys[positions] → output scalar list (L13,30). Returned tuple is positions and corresponding final scores, preserving concatenation order, not final-score rank. No softmax/values aggregation or attention mask is implemented.

| Configuration | Default | Override/consumer | What is constrained |
|---|---:|---|---|
| near_len | 4 | run **options L28–29 → select L16,19,24 | Positional split; not quota. |
| forced_len | 1 | L16,20,24–25 | Tail [max(0,n−forced_len),n), appended without truncation. |
| budget | 3 | L16,25 | Only near capacity max(0,budget−len(forced)−len(far)). |
| far_budget | 1 | L16,23 | Slice cap of sorted far candidates if skip_far false. |
| skip_far | False | L17,23 | Disables far selection, not scoring. |
| basis | None | L17,21–22 → represent L6–9 | Optional external columns, not a learned default. |

Actual runtime option values are unknown. No env/file/CLI config source exists in the supplied source.

Coverage: default basis yields a two-element list and requires each queried vector have at least three coordinates; optional basis yields one entry per column if reusable, with zip silently truncating mismatched widths. No orthogonality, dtype, shape, finiteness or reusable-container validation exists. qsmall and keys are transformed with the same supplied object, so a one-shot iterator could be exhausted. No state training/reset is present.

For valid nonnegative lengths and forced_len≤near_len, far range is [0,boundary), near candidates [boundary,max(boundary,n−forced_len)), forced is final forced_len positions clipped at zero. Python stable sorting under ordinary equal finite scores preserves ascending positional ties. Forced remains ascending; far ranks precede near ranks. There is no global deduplication or final sort.

Static boundary counterexamples (not executed): n=6/defaults gives boundary 2, forced [5], one far selection among [0,1], and just one near selection among [2,3,4]. budget=0 does not remove forced or far selections, so budget is not a hard total cap. n=6, near_len=1, forced_len=3 makes far candidates [0,1,2,3,4] overlap forced [3,4,5]; an overlapping winner is scored twice because no dedup occurs. Negative far_budget invokes Python negative slicing, not a meaningful count. Empty keys still invokes represent(query) L21, so a short query can fail before yielding an empty result.

Unknown/unresolved: outside callers/consumers, actual dimensions/types/options, basis provenance, validation intended by API, numerical/selection quality, timings and applicability to real models. These unresolved cases are not generalized into an all-model claim. Suggested later checks require separate execution authorization: malformed dimensions, excessive/negative budgets, forced/far overlap and optional iterator basis. No such checks ran here.

Verification performed: read new source and role dependencies; reconciled each module claim with expression/caller/consumer; fixed exact SHA and line evidence. Next owner: main for review.

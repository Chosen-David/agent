from pathlib import Path
import json,hashlib,csv,subprocess,xml.etree.ElementTree as E
O=Path(__file__).resolve().parent;C=O.parents[2];R=O.parents[4];role=C.name;I=C/'inputs'/role;P=I/'prior_outputs';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
B=R.parent/'revision-w9-8411705-controller/dispatch-input-bindings.json';dispatch=json.loads(B.read_text());bind=dispatch['cases'][role]
before={str(p.relative_to(R)):h(p) for p in I.rglob('*') if p.is_file()}
old=json.loads((P/'output_hashes.json').read_text());bad=[k for k,v in old.items() if not(P/k).is_file() or h(P/k)!=v];assert not bad
rows=list(csv.DictReader((I/'inputs/measurements.csv').open()));m=json.loads((P/'manifest.json').read_text());assert m['raw_rows']==rows
expected={(r['workload'],r['scope'],label,float(r[key])) for r in rows for key,label in [('baseline_ms','Baseline'),('candidate_ms','Candidate')]}
actual={(r['workload'],r['scope'],r['method'],r['latency_ms']) for r in m['actual_plotted_values']};assert actual==expected and len(actual)==8
root=E.parse(P/'latency.svg');coords=[]
for e in root.iter():
 if e.get('id','').startswith('PathCollection_'):
  coords.append([float(u.get('x')) for u in e.iter() if u.tag.endswith('}use') and u.get('x')])
expected_groups=[[100,120,200],[80,100,220],[20],[10]]
assert len(coords)==4
for xs,values in zip(coords,expected_groups):
 assert len(xs)==len(values)
 for x,v in zip(xs,values):assert abs(x-(.16*7*72+v/250*.78*7*72))<1e-5
corpus=R/'snapshot'/dispatch['corpus_relative_to_snapshot'];assert corpus.is_dir();inventory={str(p.relative_to(corpus)):h(p) for p in corpus.rglob('*') if p.is_file()};pin=hashlib.sha256(json.dumps(inventory,sort_keys=True).encode()).hexdigest()
cmd=dispatch['tool_from_snapshot']+['check-refs','--help'];r=subprocess.run(cmd,cwd=R/'snapshot',text=True,capture_output=True)
(O/'command-results.json').write_text(json.dumps({'commands':[{'argv':cmd,'cwd':str(R/'snapshot'),'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}],'retrieval_commands':[],'new_render_commands':[]},indent=2))
k={'task_id':bind['task_id'],'input_version':bind['input_version'],'role':role,'status':'not_needed','knowledge_refs':[],'reason':'The continuation checks eight literal synthetic CSV latencies, ms units, workload identity and existing scope facets. It introduces no estimator, uncertainty, theorem, distribution, empirical or causal claim. General corpus knowledge cannot provide absent repetitions or errors.','demand_assessment':{'theory':'not_needed: no statistical model or mathematical guarantee adopted','project_facts':'needed: exact CSV, old manifest/plot.py/SVG/caption and image pixels checked','current_external_facts':'not_needed: no venue/current standard/empirical benchmark claims requested'},'corpus_snapshot':{'path':str(corpus.relative_to(R)),'file_count':len(inventory),'inventory_sha256':pin},'actual_entries_read':[],'queries':[],'prerequisite_checks':[{'requirement':'Latency units/values and scopes come from source','evidence':'Exact manifest tuples equal CSV; existing SVG marker positions map to all 8 values on 0–250 axis','verdict':'satisfied'},{'requirement':'No unsupported uncertainty or end-to-end generalization','evidence':'Caption retains unknown repeats, no error bars; kernel-only distinct','verdict':'satisfied'}],'tool_availability':'actual check-refs --help exit 0, discovery only','check_refs':'not_run: nonempty refs required by CLI; none adopted','original_task_input_version':{'status':'absent','value':None},'historical_output_input_version':json.loads((P/'handoff_event.json').read_text())['input_version'],'historical_run_id':m['run_id'],'new_render':False}
(O/'knowledge-use.json').write_text(json.dumps(k,indent=2))
paths=[C/'task.txt',C/'attempts/0001/start.json',I/'original-task.json',I/'inputs/measurements.csv',B]+[P/n for n in ['manifest.json','handoff_event.json','output_hashes.json','caption.md','qa.md','plot.py','latency.svg','latency.png','final_size.png','grayscale.png','pdf_render.png']]+[R/'snapshot/plugins/research-assistant/skills'/role/p for p in ['SKILL.md','references/execution.md','references/workflow.md','references/knowledge_access_workflow.md']]+[R/'snapshot/plugins/research-assistant/skills/research-figures/references/figure_shared.md']
(O/'source-loads.json').write_text(json.dumps({'loaded_files':[{'path':str(p),'sha256':h(p)} for p in paths],'shared_contract':'Current figure_shared.md already read in preceding assigned role; same common figure contract','corpus_inventory_discovery_only':inventory},indent=2))
after={str(p.relative_to(R)):h(p) for p in I.rglob('*') if p.is_file()};assert before==after
(O/'preservation-check.json').write_text(json.dumps({'protected_bundle_files':len(after),'hashes_before':before,'hashes_after':after,'unchanged':True,'old_manifest_entries_checked':len(old),'old_manifest_mismatches':bad,'checks':['CSV and raw_rows exact','all 8 descriptive tuples exact','actual SVG PathCollection x coordinates match all 8 values to 1e-5 SVG unit'],'svg_marker_x_coordinates':coords,'no_original_files_written':True},indent=2))
print(role,'protected files',len(after),'historical hash entries',len(old),'unchanged; SVG positions match; knowledge not_needed; no rendering')

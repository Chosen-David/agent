from pathlib import Path
import csv,json,hashlib
out=Path(__file__).resolve().parent
p=out.parents[2]/'inputs/measurements.csv'
rows=list(csv.DictReader(p.open()))
assert len(rows)==4
computed=[]
for x in rows:
 b=float(x['baseline_ms']);c=float(x['candidate_ms']);assert b>0 and c>0
 computed.append({**x,'speedup':b/c,'latency_change_percent':100*(c-b)/b,'kind':'derived_from_supplied_synthetic_value'})
report={'source':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':computed,'scope_aggregation':'none','new_runs':0}
(out/'derived_metrics.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))

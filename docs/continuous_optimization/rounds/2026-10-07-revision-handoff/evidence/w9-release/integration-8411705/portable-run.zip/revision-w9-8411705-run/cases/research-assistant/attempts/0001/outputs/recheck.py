from pathlib import Path
import csv,json,math
out=Path(__file__).resolve().parent
case=out.parents[2]
bundle=case/'inputs/research-assistant'
rows=list(csv.DictReader((bundle/'inputs/measurements.csv').open()))
old=json.loads((bundle/'prior_outputs/computed_metrics.json').read_text())['rows']
results=[]
for row,prior in zip(rows,old):
 b=float(row['baseline_ms']);c=float(row['candidate_ms']);speed=b/c;red=100*(b-c)/b
 assert row['workload']==prior['workload'] and row['scope']==prior['scope']
 assert math.isclose(speed,prior['speedup']) and math.isclose(red,prior['latency_reduction_percent'])
 results.append({'workload':row['workload'],'scope':row['scope'],'baseline_ms':b,'candidate_ms':c,'speedup':speed,'latency_reduction_percent':red,'agrees_with_historical':True})
assert len(rows)==len(old)==4
chain=json.loads((bundle/'prior_outputs/task_chain.json').read_text());seen=set()
for t in chain['tasks']:
 assert set(t['depends_on'])<=seen;seen.add(t['task_id'])
 if t['status']=='done': assert all((bundle/'prior_outputs'/f).is_file()for f in t['outputs'])
assert next(t for t in chain['tasks']if t['task_id']=='CODE-DIAG')['status']=='blocked'
print(json.dumps({'rows':results,'dag':'acyclic; all dependencies exist; done outputs exist in archive','historical_status_policy':'done stays historical, main acceptance pending; CODE-DIAG stays blocked','experiment_count':0},indent=2))

from pathlib import Path
from datetime import datetime,timedelta
from copy import deepcopy
import json
O=Path(__file__).resolve().parent;f=json.loads((O.parents[2]/'inputs/travel.json').read_text())
def moment(t):return datetime.fromisoformat(f['date']+'T'+t+':00+08:00')
def dump(n,v):
 with (O/n).open('x') as s:json.dump(v,s,ensure_ascii=False,indent=2);s.write('\n')
unknowns=[{'unknown_id':'U1','content':'输入未指定币种；预算暂假设所有金额同币种，不能称人民币报价。','owner':'user'},{'unknown_id':'U2','content':'酒店房费、额外午休费、已支付情况及附加消费未提供；房间可用不等于免费。','owner':'user'},{'unknown_id':'U3','content':'城市、出入口、上车点、实际道路及公交/步行候选未知；不补造路线。','owner':'transport'},{'unknown_id':'U4','content':'天气、候位、写真妆造是否计入预约、通勤是否包含步行候车均未说明。','owner':'context'},{'unknown_id':'U5','content':'18:00后返程地点、车次及提前到站要求未知；只按回酒店结束规划。','owner':'user'}]
locations={'H':'Hotel H, 1 Test Road','A':'Cafe A, 2 Test Road','B':'Studio B, 3 Test Road'}
legs=[('H','A','抵达指定午餐地点；仅此种合成车辆通勤有时长和费用依据。'),('A','H','回已给定可用房间，保证75分钟独立午休。'),('H','B','按固定16:00写真预约倒推出发，并提前20分钟抵达准备。'),('B','H','回到假设的结束锚点，返程段同样计时计费。')]
def price(bounds,unit,qty,orig):return {'min':bounds[0],'max':bounds[1],'currency':None,'unit':unit,'quantity':qty,'original_unit':orig,'includes':[],'excludes':['Unspecified extras'],'source_status':'reference','checked_at':None}
checks=[]
for rev,duration in [(1,f['commute']['each_leg_minutes']),(2,35)]:
 # V1 is actually written before AM1 is applied in the second iteration.
 slots=[];t=moment('11:00')
 def add(id,mins,kind,label,candidate=None):
  global t
  end=t+timedelta(minutes=mins)
  slots.append({'slot_id':id,'kind':kind,'candidate_id':candidate,'intent_ids':[id] if id in f['must_do'] else [],'start':t.isoformat(),'end':end.isoformat(),'label':label,'conditions':['Synthetic fixture and stated planning assumptions only'],'depends_on':['F-commute'] if kind=='transfer' else [],'built_from_revision':rev,'validated_for_revision':rev,'validity':'current'})
  t=end
 add('L1',duration,'transfer','Hotel H → Cafe A')
 add('Q1',10,'buffer','进店、候位和点单准备；规划缓冲')
 add('lunch',60,'activity','Cafe A午餐；开始时点单','C-A')
 add('Q2',5,'buffer','结账、离店缓冲')
 add('L2',duration,'transfer','Cafe A → Hotel H')
 add('Q3',5,'buffer','回房整理缓冲')
 add('rest',75,'rest','Hotel H房间内独立午休','C-H')
 depart=moment('15:40')-timedelta(minutes=duration)
 assert depart>=t
 add('FLEX',int((depart-t).total_seconds()/60),'buffer','留在酒店的机动时间，可继续休息')
 add('L3',duration,'transfer','Hotel H → Studio B')
 add('Q4',20,'buffer','写真报到/准备；不是已核实妆造时长')
 add('photo',60,'activity','Studio B用户已确认的16:00–17:00写真','C-B')
 add('Q5',5,'buffer','离店、上车缓冲')
 add('L4',duration,'transfer','Studio B → Hotel H')
 add('END',int((moment('18:00')-t).total_seconds()/60),'buffer','已回酒店，18:00前余量')
 commutes=[{'commute_id':'L'+str(j),'origin':locations[a],'destination':locations[b],'entrance':None,'mode':'共乘1辆车；具体服务类型未知','route':None,'stations':None,'transfers':None,'duration_minutes':[duration,duration],'duration_scope':'Assumed door-to-door including walking/waiting; not verified','price':price(f['commute']['each_leg_price'],'per_car',1,'per_vehicle'),'people':2,'source_ids':['S1'],'status':'reference','reason':reason,'alternatives':[],'built_from_revision':rev,'validated_for_revision':rev,'depends_on':['F-commute'],'validity':'current'} for j,(a,b,reason) in enumerate(legs,1)]
 meal=[v*f['people'] for v in f['lunch']['price']];photo=f['photo']['price'];car=[v*len(legs)*f['commute']['vehicles'] for v in f['commute']['each_leg_price']];subtotal=[sum(v) for v in zip(meal,photo,car)];contingency=[round(.1*v,2) for v in subtotal];total=[a+b for a,b in zip(subtotal,contingency)]
 budget={'currency':None,'lunch':meal,'photo':photo,'transport':car,'subtotal':subtotal,'contingency_rate':.1,'contingency':contingency,'known_total_with_contingency':total,'excluded_unknown_ids':['U2'],'complete_trip_total':None,'assumptions':['All supplied amounts share an unspecified currency','One vehicle holds both travelers','No price amendment supplied; retain input range'],'built_from_revision':rev,'validated_for_revision':rev,'depends_on':['commutes','candidates'],'validity':'current'}
 candidates=[{'candidate_id':'C-A','entity_id':'A','kind':'meal','name':'Cafe A','navigable_address':'2 Test Road','intent_ids':['lunch'],'fact_ids':['F-lunch'],'price':price(f['lunch']['price'],'per_person',2,'per_person'),'duration_minutes':60,'admission':'admitted','unknowns':['Synthetic admission only; unmeasured queue']},{'candidate_id':'C-B','entity_id':'B','kind':'photo','name':'Studio B','navigable_address':'3 Test Road','intent_ids':['photo'],'fact_ids':['F-photo'],'price':price(f['photo']['price'],'per_package',1,'per_group'),'duration_minutes':60,'admission':'admitted','unknowns':['Preparation inclusions unknown']},{'candidate_id':'C-H','entity_id':'H','kind':'rest','name':'Hotel H','navigable_address':'1 Test Road','intent_ids':['rest'],'fact_ids':['F-rest'],'price':{'amount':None,'currency':None,'unit':'per_room','quantity':1,'source_status':'unknown'},'duration_minutes':75,'admission':'admitted','unknowns':['Room usable per fixture; fees unknown']}]
 facts=[]
 for id,entity,claim,value in [('F-lunch','A','service_windows',[[moment(a).isoformat(),moment(b).isoformat()] for a,b in f['lunch']['service_windows']]),('F-order','A','last_order',moment(f['lunch']['last_order']).isoformat()),('F-photo','B','appointment',[moment(a).isoformat() for a in f['photo']['appointment']]),('F-rest','H','room_available',True),('F-commute','transport','each_leg_minutes',duration)]:
  facts.append({'fact_id':id,'entity_id':entity,'claim':claim,'value':value,'applies_on':f['date'],'timezone':f['timezone'],'source_ids':['S1'],'checked_at':None,'status':'user_confirmed' if id=='F-photo' else 'reference'})
 lookup={s['slot_id']:s for s in slots};mins=lambda s:int((datetime.fromisoformat(s['end'])-datetime.fromisoformat(s['start'])).total_seconds()/60)
 tests={'contiguous_no_overlap':all(a['end']==b['start'] for a,b in zip(slots,slots[1:])),'all_four_transfer_lengths':all(mins(lookup['L'+str(i)])==duration for i in range(1,5)),'lunch60':mins(lookup['lunch'])==60,'meal_and_exit_in_one_window':any(moment(a).isoformat()<=lookup['lunch']['start'] and lookup['Q2']['end']<=moment(b).isoformat() for a,b in f['lunch']['service_windows']),'order_by14':lookup['lunch']['start']<=moment('14:00').isoformat(),'independent_rest75':mins(lookup['rest'])==75,'photo_unchanged':lookup['photo']['start']==moment('16:00').isoformat() and lookup['photo']['end']==moment('17:00').isoformat(),'return_by18':lookup['L4']['end']<=moment('18:00').isoformat(),'subtotal_correct':subtotal==[520,600],'contingency_correct':total==[572,660]}
 assert all(tests.values()),tests
 checks.append({'revision':rev,'checks':tests,'transfer_total_minutes':4*duration,'hotel_flex_minutes':mins(lookup['FLEX']),'return_buffer_minutes':mins(lookup['END']),'budget':budget})
 changes=[] if rev==1 else [{'amendment_id':'AM1','from_revision':1,'to_revision':2,'changed_fields':['commute.each_leg_minutes:20→35'],'source':'travel.json amendment','affected_ids':['F-commute','L1','L2','L3','L4','itinerary','budget','intent_coverage','deliverables'],'reason':'Four transfers each gain15min; preserve mandatory lunch/rest/photo','invalidated':'V1 commutes, itinerary, budget verification and document projections stale for current use; V1 retained as historical artifact','actions':['Recompose times','Recompute same-price budget','Recheck all hard windows'],'reused':['Cafe A windows and prices','Studio B booking and price','Hotel H room availability']}]
 bundle={'schema_version':'local-travel/v1','trip_id':'gated-synthetic-day','revision':rev,'as_of':None,'request_contract':{'trip_brief':{'destination':None,'timezone':f['timezone'],'dates':{'start':f['date'],'end':f['date']},'people':2,'anchor':{'kind':'hotel','entity_id':'H'},'arrival':moment('11:00').isoformat(),'departure':moment('18:00').isoformat(),'budget':{'min':None,'max':None,'currency':None,'scope':'two people'},'rest_preferences':{'default_enabled':True,'midday_minutes':75,'needs_room':True,'walking_tolerance':None},'assumptions':['Start and finish at Hotel H','Commute duration is treated as full door-to-door time','One vehicle accommodates both travelers','Currency consistent but unspecified']},'hard_constraints':[{'constraint_id':'HC1','content':'11:00–18:00 available; do not book','source':'S1','user_confirmed':True},{'constraint_id':'HC2','content':'Photo16:00–17:00 and rest75min preserved','source':'S1','user_confirmed':True}],'desired_intents':[{'intent_id':x,'goal':x,'must_do':True,'acceptance_criteria':'See calculation_checks.json scoped timeline checks'} for x in f['must_do']],'soft_preferences':[],'unknowns':unknowns,'acceptance_criteria':list(tests)},'research_queries':[],'capabilities':[{'name':'Python standard library','scope':'local planning, arithmetic and schedule checks'}],'facts':facts,'experiences':[],'weather':[],'candidates':candidates,'selection_plan':[{'intent_id':i,'primary':c,'alternatives':[],'fallbacks':[],'reason':'Input-specified entity, no alternative facts supplied','conditions':['Synthetic-only plan']} for i,c in [('lunch','C-A'),('photo','C-B'),('rest','C-H')]],'itinerary':slots,'commutes':commutes,'budget':budget,'intent_coverage':[{'intent_id':x,'slot_ids':[x],'outcome':'satisfied','evidence':'Scoped fixture time checks; not real availability assurance'} for x in f['must_do']],'sources':[{'source_id':'S1','url':None,'source_type':'synthetic supplied travel.json','published_at':None,'checked_at':None,'access_scope':'full','scope':'Fixture only, not real businesses'}],'open_questions':[{'unknown_id':x['unknown_id']} for x in unknowns],'change_log':changes,'deliverables':[{'format':'Markdown','path':str(O/f'plan_v{rev}.md'),'bundle_revision':rev,'validity':'current','QA':'limited','checked_pages':None,'total_pages':None,'limits':'Arithmetic/schedule checks only; no network or Word requested'}],'run_state':{'stages':[{'stage_id':'compose-and-check','status':'COMPLETED','input_revision':rev,'depends_on':[],'outputs':[f'plan_v{rev}.md',f'bundle_v{rev}.json'],'error':None,'blocked_reason':None}]}}
 dump(f'bundle_v{rev}.json',bundle)
 doc=f'# 合成行程 V{rev}\n\n2026-10-04，Asia/Shanghai（UTC+08:00），2人，11:00–18:00。所有实体与事实仅来自travel.json，不是真实商户。本方案暂以Hotel H（1 Test Road）为出发及结束点。'+('本版为修订前基线；应用AM1后以V2为当前安排。' if rev==1 else '本版已应用AM1：每段通勤20→35分钟，写真预约和独立午休保留。')+'\n\n## 时间表\n\n| 时间 | 活动 |\n|---|---|\n'
 for s in slots:doc+=f"| {s['start'][11:16]}–{s['end'][11:16]} | {s['label']} |\n"
 doc+='\nCafe A（2 Test Road）午市10:30–14:30、晚市16:00–21:00，两个窗口分开处理。按午餐开始时点单，早于14:00最后点单，完整60分钟用餐及离店缓冲均在午市内。Studio B（3 Test Road）的16:00–17:00预约由输入声明用户已确认，本次没有创建或更改任何预约。Hotel H房间可用由输入给出，75分钟午休不包含用餐或通勤。所有缓冲为规划选择，不代表已测排队/妆造时长。\n\n## 逐段通勤\n\n| 起点 → 终点 | 方式及全程时间 | 双人单程费用 | 理由 |\n|---|---|---|---|\n'
 for c in commutes:doc+=f"| {c['origin']} → {c['destination']} | 2人共乘1车，{duration}分钟 | 15–25 / 整车 | {c['reason']} |\n"
 doc+='\n路线号、道路、入口、实际上车处及替代公交/步行时间没有给出，不编造。暂把给定时长视为含步行候车的门到门时间；若实际不是全程，应从机动时间中增加相应余量并重排。仅此车辆方案有输入依据，不能声称它是最便宜或最快的方式。\n\n## 双人预算\n\n金额使用输入单位，币种未知；暂假设各项同币种。\n\n| 项目 | 计算口径 | 双人合计 |\n|---|---|---|\n| 午餐 | 80–100/人 ×2人 | 160–200 |\n| 写真 | 300/组 ×1组，per_group→per_package | 300 |\n| 通勤 | 15–25/车次 ×4段 ×1车，per_vehicle→per_car，不乘2人 | 60–100 |\n| 已知项目小计 | 上述相加 | 520–600 |\n| 机动金 | 规划选择10% | 52–60 |\n| 已知项目含机动金 | 小计＋机动金 | 572–660 |\n\n完整总预算为572–660再加未知费用。酒店房费、午休额外费和未给定附加消费尚未计价，未按零处理；已支付情况未知，不能把表中金额称为精确新增现金支出。'
 if rev==2:doc+='修订只改变时长，没有新车价且仍为4段，故重算后金额范围不变；不擅造按时长涨价，也不保证现实车费不变。通勤总时长80→140分钟，酒店机动65→20分钟，返店余量35→20分钟；午餐顺延15分钟，午休顺延30分钟，前往写真提前15分钟出发。'
 doc+='\n\n## 未知与执行边界\n\n'+'\n'.join('- '+u['content'] for u in unknowns)+'\n\n两版均通过给定模型内的时间和预算算术检查；没有声称真实天气、道路、候位或妆造已核实。出现额外延误时先消耗酒店机动时间；不能自动缩短75分钟午休或改变写真预约。若仍无法兼容硬时间窗，应明确冲突后重新决定；没有合成替代实体，故不编雨天新商户。\n'
 with (O/f'plan_v{rev}.md').open('x') as s:s.write(doc)
 print(json.dumps({'revision':rev,'written':[f'bundle_v{rev}.json',f'plan_v{rev}.md'],'checks':tests,'transfer_minutes':4*duration,'return_at':lookup['L4']['end'],'budget_total':total},ensure_ascii=False))
dump('calculation_checks.json',{'status':'scoped checks passed','versions':checks,'new_external_facts':False})

# Fresh mixed-figure execution / author QA

Ready for review as a supplied synthetic example. Independent grading is owned by the main agent. Source paths/hashes, panel routes, editable sources, exact input values and graph are in manifest.json. All work was newly generated in this run from its inputs; no prior-run output was read or copied. No network, installation, independent subagent, model execution or generated imagery.

Reproduce: `python -B build.py` from this output directory. A and B use independent editable Python panel sources; build.py is the vector assembly source; SVG text remains editable. SVG/PNG/PDF actually generated for both panels and the combined figure. Provisional combined size 9.5 × 3.8 in; 240 dpi PNG. No specified venue. Poppler command: `pdftoppm -scale-to 1500 -png -singlefile figure.pdf figure_pdf_render`; 1000 used for individual panels. `pdffonts figure.pdf` produced the saved font_report.txt and shows both TrueType subsets embedded.

Actual image viewing: view_image opened figure_final_size.png (950 × 380), figure_grayscale.png, figure_pdf_render.png, panel_a_pdf_render.png, panel_b_pdf_render.png and page_preview.png. Date: 2026-10-07. First render was usable; no failed visual version or local revision occurred in this run. No old failure is presented as a current one.

Scientific/numerical self-check: pass. All four rows/eight values retained; bar widths programmatically compared against source values. No aggregation, exclusions, interpolation, invented error bars or significance. Large candidate regression remains visible and kernel timing has explicit scope separation.

Semantic self-check: pass. Six labeled nodes, five correctly directed data-flow arrows. A/B parallel into sum; sum to softmax; softmax to output; V only to output. No extra edges, feedback or topology inference. The diagram does not establish implementation.

Whole-figure visual self-check: pass at the provisional inspected size. Each panel title/status is readable, numbers sit clear of bars, kernel scope text has dedicated space below legend, no arrow touches node text, no clipped labels or boundaries. The two incoming sum arrows remain distinguishable. Layout uses a clear interpanel gap. Lower V bypass and output are aligned. Grayscale identity survives through B/C direct labels and consistent bar order; color-vision simulation unverified. All PDF text and values were checked as actual pixels, not inferred from PNG.

Technical self-check: SVG XML parsed; editable text/no embedded raster panels; actual PDF and PNG exports opened. Font portability in SVG depends on installed DejaVu Sans; PDF embeds it. Page preview is approximate, not an actual manuscript or physically calibrated print. Reproduction on another machine and venue compliance unverified.

External exemplar study not run: standalone provided-material task, no papers supplied and network prohibited. Independent role review not run: same agent executed diagram, data and assembly sequentially. Missing repetition unit/count, uncertainty, hardware/provenance and architecture/performance linkage prevent empirical conclusions; they do not prevent faithful synthetic illustration.

Final exact PNG additionally opened directly with view_image: figure.png.

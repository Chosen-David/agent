# Protected continuation: final PDF reader

Current Skill/execution/knowledge-access loaded. Original-task.json has no input_version; supplemental version is trusted dispatch-only, while historical handoff retains the PDF-hash version. Re-rendered exact PDF at140dpi, then actually reopened all3pages including Appendix, without source-code inspection. Current ledger is separate from historical coverage.

Historical READ-F001 remains supported: physical2/printed1 turns5→7.5 into a universal RoPE error assertion; physical3/printedA1 declares an invented teaching example with no RoPE study. No error definition or q/k/RoPE mapping appears. No new PDF was supplied, so original acceptance is not met and finding stays open. Direct natural-log arithmetic confirms the toy5→7.5; no numeric error is alleged.

Actual corpus search returned Cauchy–Schwarz plus unrelated lexical candidates. Read the complete relevant candidate through show, including requires=[]; pinned/check-refs succeeded. Its vector/query/key prerequisites are absent, and an inner-product upper bound cannot establish universal model-error amplification. Candidate was inspected but not adopted; knowledge_refs=[] reflects no theorem used, with inspected refs retained separately. No forced unrelated theorem, no external source verification, no fake proof. Corpus hash-check success is not applicability.

All original input and historical output hashes are unchanged. No old execution is said to use new knowledge code. New source hashes, commands, page images, coverage and finding-continuation are additive. Scope is reader recheck, not empirical RoPE validation or new manuscript revision.

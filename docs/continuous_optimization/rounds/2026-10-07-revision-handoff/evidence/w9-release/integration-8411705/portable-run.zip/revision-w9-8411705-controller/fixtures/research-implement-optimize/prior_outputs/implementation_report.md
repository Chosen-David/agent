# CODE-T001 — fresh gated repair

This release attempt loaded the new gated task, inputs and frozen role dependencies, then generated and executed new checks. Prior attempts are not evidence for this run.

Minimal reproduction observed before repair: moving_average([1,2,3],2) returns [1.5], but full consecutive windows require [1.5,2.5]. The exclusive range bound omitted the last start index. The candidate adds +1 and validates positive integer-like windows through operator.index; bool/noninteger inputs raise TypeError, zero/negative raise ValueError. Exception classes were not specified by the original docstring; this report makes the chosen behavior explicit. Signature and sum-of-slices arithmetic are preserved, with no assignments to values. Empty input and windows longer than the input return [].

Independent verification ran an endpoint/reverse-index Fraction oracle, not the candidate slice expression. Integer and exactly representable fractional fixtures permit exact output equality, fixed before execution. Boundary, tuple, large-integer, signed/fractional, 100 seeded random, invalid-window and nonmutation cases total 117; candidate passed all. Baseline had 62 failures, preserved in baseline_check.json including first failure. The failed baseline was run before candidate creation. Commands, return codes and stderr are retained in command_log.json. This is CPU correctness validation, not timing validation or all-type coverage.

CSV-derived descriptive results (supplied data, not timings of this patch):

| Workload | Scope | baseline/candidate speedup | (baseline−candidate)/baseline latency reduction |
|---|---|---:|---:|
| small | end_to_end | 1.25× | 20% |
| medium | end_to_end | 1.20× | 16.67% |
| large | end_to_end | 0.9091× | −10% |
| kernel | kernel_only | 2× | 50% |

Large regresses by 10% latency. No universal end-to-end improvement is supported; kernel gain does not imply system gain. There are no repeats, dispersion, session units, configurations, timing boundaries, deployment weights or version/correctness links. Therefore no confidence interval, significance, attribution to this repair, or generalizable gain can be reported. No benchmark, GPU probe/execution or profiler was run.

Candidate reasoning/landscape (offline_fallback, merged here for this small repair): direct window sums retain arithmetic order; time O((n−w+1)w), temporary O(w), output O(n−w+1) for 1≤w≤n. A running sum would give O(n) time/O(1) extra memory but changes cancellation and nonfinite-value recovery; prefix sums add O(n) storage and change rounding. Neither was implemented or measured. No external tooling or current-best claim is required or made. One minimal repair candidate was retained on correctness; no unsupported optimization result is claimed.

Reproduce from the run root: python -B cases/research-implement-optimize/attempts/0001/outputs/check_correctness.py cases/research-implement-optimize/attempts/0001/outputs/buggy.py. Analyze with the adjacent analyze_measurements.py and inputs/measurements.csv.

Next owner is main for independent review/grading. If performance evidence is later required, freeze workload, versions, timing and repeat/session protocol first, then collect paired raw timings; do not extrapolate this four-row CSV. Inputs and repository were not edited.

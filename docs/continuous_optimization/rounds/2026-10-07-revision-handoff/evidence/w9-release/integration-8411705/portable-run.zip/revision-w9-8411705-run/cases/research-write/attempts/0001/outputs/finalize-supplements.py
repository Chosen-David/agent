import hashlib,json,sys
from pathlib import Path
RUN=Path('/workspace/scratch/c12f3d9f92bd/revision-w9-8411705-run')
SNAP=RUN/'snapshot';sys.path.insert(0,str(SNAP))
from scripts.validate_handoff import validate
from agent_runtime.knowledge import check_handoff_knowledge
BIND=Path('/workspace/scratch/c12f3d9f92bd/revision-w9-8411705-controller/dispatch-input-bindings.json')
bindings=json.loads(BIND.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
reports={
'research-write':'''The protected synthetic working draft remains supported within its explicit scope. A fresh exact-fraction calculation gives small 1.25×, medium 1.20×, large 10/11 ≈ 0.90909× end-to-end speedups and kernel-only 2×. The large workload is a 10% latency regression. Kernel timing is already included in end-to-end timing; the two scopes cannot be added. These are descriptive single-run CPU records: no repeats, variance, output quality or GPU evidence was added.

Knowledge assessment is not_needed: the requested changes concern supplied facts and elementary ratios. The math corpus cannot fill measurement gaps. No corpus search or imported theorem is claimed. The original task has no input_version; the historical handoff version remains distinct from this trusted supplemental binding.

The extra communication continuation reread the original seq2 review request and validated all immutable references with the current 8411705 runtime. SQLite mode=ro and query_only guarded the diagnostic connection; inherited Mailbox.status/inbox performed current runtime reads. The ordinary review event has no handoff manifest and was validated directly, rather than incorrectly calling consume_handoff. Original/new manuscripts, CSV, finding records, mapping, intent and exact receipt were reread. No publish, ACK, experiment or scientific closure occurred. The before/after state remains three receipts and zero pending deliveries, with unchanged database SHA-256. REV-F003 remains the original rejected allegation of missing regression disclosure. The original reviewer owns finding closure.

This is a fresh semantic and contract supplement, not a rerun or relabeling of historical manuscript authorship. The diagnostic read-only connection override is not a deployed Engine adapter. Historical failures and original artifacts remain immutable.''',
'explain-research-concepts':'''Fresh independent arithmetic confirms y=5 for equal logits and y=7.5 after b changes to (0,log 3) with fixed V=(0,10)^T. The local sensitivities at equal logits are (-2.5,2.5) for each branch; central differences with h=1e-4 agree within 1e-7. Common shifts leave softmax unchanged, and cancelling a/b perturbations leave the combined logits unchanged. These local derivatives do not justify a global linear approximation to finite perturbations or predict unspecified real-model accuracy.

The actual frozen-corpus search and full read of math.cauchy-schwarz v1 supplied only a relevant boundary warning: a score-error norm bound does not imply unchanged softmax output or task quality. Its requires list is empty. The q/k quantitative bound was not applied because this fixture supplies direct logits, not a q/k factorization and norm premises. The eigenspace-gap candidate was rejected on metadata because its matrix/eigenspace premises are absent. The retrieved entry does not provide the softmax Jacobian theorem; that result follows directly by quotient/chain rule and the new numerical check. Search results do not establish exhaustive absence of other coverage. Actual check-refs passed for the pinned ID/version/hash; this certifies identity, not applicability.

The historical explanation has a retained TeX defect: S=\\operatorname{diag}$p$-pp^T inside display math. erratum.md gives the corrected S=diag(p)-pp^T display as an additive repair. No historical file was changed, and the old formatting check is not represented as flawless. The correction is explicitly tracked in the current REV-03 task evidence.

Prior output identity/version remains historical. This supplement does not claim new paper facts, experiments, network checks, exhaustive corpus coverage, or a PDF render.''',
'travel-planner':'''Fresh parsing and independent checks of both protected synthetic itineraries confirm lunch service/order windows, the confirmed 16:00–17:00 studio appointment, at least 75 minutes of room rest, sequential travel/buffer feasibility, and return before 18:00. The 35-minute transfer amendment increases total transfer time from 80 to 140 minutes; the revised plan retains 75 minutes of rest and moves return to 17:40 with 20 minutes remaining. The original 20-minute-transfer plan returns at 17:25 with 35 minutes remaining.

The known subtotal is 520–600: lunch for two people 160–200, studio one group 300, and four one-vehicle transfers 60–100. Ten-percent contingency is 52–60, for a known total 572–660. Per-group was correctly represented as per-package and per-vehicle as per-car multiplied by one car, not two people. Currency and hotel costs remain unknown; missing costs are not zero.

Knowledge assessment is not_needed: this task is bounded by explicit fictional business facts, supplied travel times and elementary time/price arithmetic. The mathematical corpus cannot verify fictional routes, weather, currency or missing hotel costs. No corpus search, live-business verification, booking or service operation was claimed or performed. The original task lacks input_version and its old handoff binding is preserved separately.

The historical plans were reread and checked without regeneration or mutation. This supplement claims only local constraint and schema compatibility, not real-world availability.'''
}
for role in ['research-write','explain-research-concepts','travel-planner']:
    out=RUN/'cases'/role/'attempts/0001/outputs'
    k=json.loads((out/'knowledge-use.json').read_text())
    b=bindings['cases'][role]
    loads=json.loads((out/'source-load-transcript.json').read_text())
    verified=[{'path':r['path'],'expected_sha256':r['sha256'],'actual_sha256':sha(Path(r['path']))} for r in loads['reads']]
    assert all(x['expected_sha256']==x['actual_sha256'] for x in verified)
    save(out/'final-immutability-check.json',{'files':verified,'all_unchanged':True})
    (out/'continuation-report.md').write_text('# '+role+' — protected continuation\n\n'+reports[role]+'\n\nAll recorded source hashes still match at finalization. Completion here refers only to the assigned supplemental work; independent acceptance remains with the parent.\n')
    request={'schema_version':1,'input_version':b['input_version'],'tasks':[{'task_id':b['task_id'],'allow_skip':False}],'knowledge_root':'snapshot/'+bindings['corpus_relative_to_snapshot'],'knowledge_refs':[]}
    save(out/'consumer-request-from-dispatch.json',{'request':request,'authority':'Projection of independently supplied parent dispatch, not inferred from producer handoff. Parent requested completion validation against REV-03 and this binding.','source':str(BIND),'source_sha256':sha(BIND)})
    names=['continuation-report.md','knowledge-use.json','recheck.py','command-transcript.txt','recheck-results.json','source-load-transcript.json','provenance.json','final-immutability-check.json']
    if role=='research-write':names+=['read-only-reconsumption.json','reconsume-readonly.py','reconsumption-transcript.txt']
    if role=='explain-research-concepts':names+=['erratum.md','knowledge-search.json','knowledge-show.json','knowledge-ref-check.json']
    arts=[{'id':p.replace('.','_'),'path':p,'sha256':sha(out/p)} for p in names]
    checks=[{'criterion':'Fresh result semantics and protected bytes rechecked','status':'pass','artifact_ids':['recheck-results_json','final-immutability-check_json']},{'criterion':'Knowledge demand, prerequisites/applicability or grounded not_needed recorded','status':'pass','artifact_ids':['knowledge-use_json','continuation-report_md']}]
    if role=='research-write':checks.append({'criterion':'Current runtime read-only seq2 semantic continuation; unchanged three receipts, zero pending','status':'pass','artifact_ids':['read-only-reconsumption_json']})
    if role=='explain-research-concepts':checks.append({'criterion':'Historical TeX defect disclosed and additive correction tracked without original mutation','status':'pass','artifact_ids':['erratum_md','continuation-report_md']})
    handoff={'schema_version':1,'run_id':RUN.name,'role':role,'input_version':b['input_version'],'status':'completed','artifact_root':str(out),'knowledge_refs':k['knowledge_refs'],'limitations':['Synthetic/protected supplied evidence only; no external verification or invented experiments.','Completion applies to this additive supplement; prior versions/bytes retained and independent semantic acceptance remains with parent.'],'artifacts':arts,'checks':checks,'tasks':[{'task_id':b['task_id'],'depends_on':[],'status':'done','evidence':[a['id'] for a in arts]}]}
    assert not (out/'handoff.json').exists(),'Refuse overwrite; preserve failures first'
    save(out/'handoff.json',handoff)
    errors=validate(handoff,out,require_complete=True,expected_input_version=b['input_version'],consumer_request=request)
    knowledge_check=check_handoff_knowledge(RUN,handoff,request)
    save(out/'handoff-validation.json',{'integrity_valid':not errors,'errors':errors,'completion_verified':not errors,'consumer_request_source':str(BIND),'consumer_request':request,'artifact_root':str(out),'knowledge_project_root':str(RUN),'knowledge_check':knowledge_check,'validator':str(SNAP/'scripts/validate_handoff.py'),'validator_sha256':sha(SNAP/'scripts/validate_handoff.py'),'knowledge_runtime_sha256':sha(SNAP/'agent_runtime/knowledge.py'),'scope':'Local integrity and explicit consumer contract, not semantic certification; no independent acceptance claimed.'})
    print(json.dumps({'role':role,'errors':errors,'knowledge_refs':k['knowledge_refs'],'protected_bytes_unchanged':True,'handoff':str(out/'handoff.json')}))
    assert not errors,errors

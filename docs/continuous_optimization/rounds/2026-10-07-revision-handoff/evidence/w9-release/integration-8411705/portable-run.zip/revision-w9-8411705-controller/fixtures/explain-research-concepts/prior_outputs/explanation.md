# EXPL-001：两路打分的误差如何影响输出

**不能仅由“分别打分、分别检查误差”保证输出不变。** 在给定模型中，两路先求和，再共同归一化；量化误差必须通过这个共同映射和固定的值矩阵来判断。这里是教学推导，不是任何论文的实测结果。

保持 $a=(0,0)$ 和 $V=(0,10)^T$ 不变。原先 $b=(0,0)$，因此权重为 $(1/2,1/2)$，输出 $y=5$。仅将 $b$ 改为 $(0,\log3)$ 后：

\[
p'=\left(\frac1{1+3},\frac3{1+3}\right)=(1/4,3/4),\qquad y'=7.5,\qquad \Delta y=2.5.
\]

第一路毫无误差，输出仍改变。分别计算误差本身没有问题；错误的是从“两路独立打分”直接推到“共同输出必然不变”。

为写清Jacobian，把logits和概率作为列向量：$z=a+b\in\mathbb R^n$、$p=\operatorname{softmax}(z)$，固定 $V\in\mathbb R^{n\times d}$，输出列向量为 $y=V^Tp\in\mathbb R^d$，与题中行向量表达等价。logits无量纲，$y$与$V$同单位。由商法则：

\[
p_i=\frac{e^{z_i}}{\sum_k e^{z_k}},\qquad
\frac{\partial p_i}{\partial z_j}=p_i\delta_{ij}-p_ip_j,\qquad
S=\operatorname{diag}$p$-pp^T.
\]

于是 $J_z=V^TS\in\mathbb R^{d\times n}$，并有

\[
J_a=J_b=J_z,\qquad J_{(a,b)}=[J_z\;J_z],\qquad
\Delta y=J_z(\Delta a+\Delta b)+O(\|\Delta a+\Delta b\|^2).
\]

也就是说，敏感度依赖合并后的 $p$ 和 $V$，不是两个孤立分数。逐列看，$\partial y/\partial z_j=p_j(V_{j,:}^T-y)$。本例初始点 $p=(1/2,1/2)^T$，故

\[
S=\begin{pmatrix}1/4&-1/4\\-1/4&1/4\end{pmatrix},\quad
J_z=(-2.5,2.5),\quad J_{(a,b)}=(-2.5,2.5,-2.5,2.5).
\]

一阶估计 $\Delta y\approx2.5\log3\approx2.7465$，不同于精确变化2.5：Jacobian仅是小扰动下的局部近似，不能凭一次线性检验保证有限量化扰动的输出不变。附带脚本已实际复算输出，并用中心差分核对四个偏导。

**边界：** 非零误差不一定改变输出。若 $\Delta a+\Delta b=c\mathbf1$，softmax的共同平移不变性保证权重严格不变；两路误差相抵是 $c=0$ 的特例。若 $V$所有行相同，权重改变也不改变输出。一般的精确条件是 $V^T(p'-p)=0$；仅在当前点满足一阶零变化，不能保证有限变化为零。分别获得的误差界可以用于联合输出误差分析，但误差“小”不是误差“零”。

回看输入concept.txt第2–4行，关键是softmax作用于 $a+b$，并非分别归一化后各自决定输出。本例反驳的是无条件保证，不能推出真实模型一定退化、退化幅度、具体量化方案优劣或硬件加速效果；真实模型的数值分布、质量与实现均未在此测量。

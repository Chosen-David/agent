# Results
alpha.json declares ALPHA/inconclusive; beta.json declares BETA/rejected.
These declarations are synthetic examples, not verified measurements.
The JSON script/input labels agree with script comments; provenance remains unknown.
beta.json is explicitly a running output in active_tasks.json.
Keep both paths unchanged while consumers or lifecycle are unknown.
See this delivery's CODEMAP.md and inventory.json for exact source versions.

import csv, hashlib, io, json, sqlite3, sys, subprocess
from contextlib import contextmanager
from pathlib import Path
from fractions import Fraction
REPO=Path('/workspace/scratch/c12f3d9f92bd/agent')
OUT=Path(__file__).parent
ROOT=REPO/'docs/continuous_optimization/rounds/2026-10-07-revision-handoff/evidence/w9-release/handoff'
sys.path.insert(0,str(REPO))
from agent_runtime.communication import Mailbox, check_plan, canonical
from scripts.validate_handoff import validate
h=json.loads((ROOT/'host-context.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
class ReadOnlyMailbox(Mailbox):
    def __init__(self):
        check_plan(h['plan']);self.plan=json.loads(canonical(h['plan']));self.run_id=self.plan['run_id'];self.root=Path(h['artifact_root']).resolve();self.path=Path(h['db'])
        with self.connect() as db:
            row=db.execute('SELECT body,root FROM communication_plans WHERE run_id=?',(self.run_id,)).fetchone()
            assert tuple(row)==(canonical(self.plan),str(self.root))
    @contextmanager
    def connect(self):
        db=sqlite3.connect(self.path.as_uri()+'?mode=ro',uri=True)
        db.row_factory=sqlite3.Row
        db.execute('PRAGMA query_only=ON')
        try:yield db
        finally:db.close()
box=ReadOnlyMailbox();db_before=sha(box.path);before=box.status()
assert len(before)==3 and all(x['receipt'] is not None for x in before)
with box.connect() as db:
    event=json.loads(db.execute('SELECT e.body FROM communication_events e JOIN communication_deliveries d ON e.seq=d.seq WHERE e.run_id=? AND e.seq=2 AND d.recipient=?',(box.run_id,'research-write')).fetchone()[0])
assert event['event_id']=='w9-review-v1-revision-request-001' and event['kind']=='review' and event['sender']=='research-review' and event['task_id']=='REV-03' and event['input_version']==box.plan['input_version']
assert not any(r['id']=='handoff' for r in event['refs'])
def refscheck(e):
    errors=validate(dict(schema_version=1,run_id=box.run_id,role=e['sender'],input_version=e['input_version'],status='partial',limitations=['Read-only reference validation; ordinary review is not completion handoff.'],artifacts=e['refs'],checks=[],tasks=[]),ROOT)
    assert not errors,errors
    return errors
refscheck(event)
paths=[r['path'] for r in event['refs']]+['inputs/manuscript.md','inputs/measurements.csv','writer/manuscript-revised.md','writer/evidence-mapping.json','writer/immutable-intent.json','writer/incoming-receipt.json','writer/provenance.json','writer/outgoing-event.json']
reads={p:{'sha256':sha(ROOT/p),'content':(ROOT/p).read_text()} for p in paths}
request=json.loads(reads['review-initial/revision-request.json']['content'])
assert reads['inputs/manuscript.md']['sha256']==request['original_manuscript_sha256']
assert reads['inputs/measurements.csv']['sha256']==request['original_csv_sha256']
intent=json.loads(reads['writer/immutable-intent.json']['content']);refscheck(intent['event'])
assert reads['writer/manuscript-revised.md']['sha256']==intent['revised_manuscript_sha256']
assert before[1]['receipt']==json.loads(reads['writer/incoming-receipt.json']['content'])==intent['receipt']
rows=list(csv.DictReader(io.StringIO(reads['inputs/measurements.csv']['content'])))
calculations=[{'workload':r['workload'],'scope':r['scope'],'speedup':str(Fraction(r['baseline_ms'])/Fraction(r['candidate_ms'])),'latency_change_pct':str(100*(Fraction(r['candidate_ms'])-Fraction(r['baseline_ms']))/Fraction(r['baseline_ms']))} for r in rows]
assert [r['speedup'] for r in calculations]==['5/4','6/5','10/11','2']
mapping=json.loads(reads['writer/evidence-mapping.json']['content'])
assert [f['original_status'] for f in mapping['finding_mapping']]==['confirmed','confirmed','rejected']
assert not mapping['scientific_findings_closed_by_writer']
after=box.status();inboxes={r:box.inbox(r) for r in ['research-write','research-review']}
assert before==after and not any(inboxes.values()) and db_before==sha(box.path)
result={'runtime_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'runtime_files':[{'path':str(REPO/p),'sha256':sha(REPO/p)} for p in ['agent_runtime/communication.py','scripts/validate_handoff.py','workflows/agent_communication_workflow.md']],'method':'Inherited current Mailbox.status/inbox with diagnostic read-only connection override; constructor bypass prevents schema/plan writes. Ordinary review seq2 directly validates refs, not consume_handoff. No publish/ACK. Not an Engine adapter deployment.','event':event,'reads':reads,'reference_errors':[],'calculations':calculations,'status_before':before,'status_after':after,'inboxes_after':inboxes,'receipt_count':3,'pending_count':0,'db_sha256_before':db_before,'db_sha256_after':sha(box.path),'knowledge_assessment':{'status':'not_needed','knowledge_refs':[],'reason':'Bounded direct ratios and comparison to explicit original request/manuscript. Corpus cannot supply missing quality/variance/GPU evidence.'},'scientific_closure_performed':False,'semantic_observation':'Revised synthetic working draft retains all four scoped ratios, large regression, single-run CPU limits, unmeasured variance/quality and no GPU evidence. Original REV-F003 rejection retained. Review closure remains original reviewer responsibility.'}
(OUT/'read-only-reconsumption.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'event_id':event['event_id'],'seq':2,'receipt_count':3,'pending_count':0,'before_equals_after':before==after,'db_unchanged':db_before==sha(box.path),'runtime_commit':result['runtime_commit']}))

| Experiment | Conclusion | Script | Data | Result | Citation |
|---|---|---|---|---|---|
| HIST-0 | unknown | archived/missing.py | unknown | unknown | unknown |
| ALPHA | inconclusive (synthetic declaration) | experiments/alpha.py | synthetic-x label; data file not supplied | results/alpha.json | comment L1 / result JSON; actual provenance unknown |
| BETA | rejected (synthetic declaration) | experiments/beta.py | synthetic-y label; data file not supplied | results/beta.json (running/protected) | comment L1 / result JSON; actual provenance unknown |
| UNKNOWN-NOTE | protected; scientific provenance unknown | unknown | unknown | notes/orphan.txt | active_tasks.json protected_files |
| UNKNOWN-STATE | declared active/protected paths | experiments/alpha.py; experiments/beta.py | unknown | active_tasks.json | supplied state declaration, not live telemetry |

Paths above are relative to the supplied organization input root, not this output-only draft. Existing CODEMAP header and historical rows were retained exactly before appending new records. Missing HIST-0 script remains unresolved; no missing data, citation or ownership was invented.

| Anchor | Producer | Consumer | Evidence kind | Status |
|---|---|---|---|---|
| HIST-0 | unknown | unknown | historical mapping | source script absent |
| ALPHA | declared script experiments/alpha.py; actual actor unknown | unknown | synthetic fixture | existing, not accepted as measured evidence |
| BETA | declared script experiments/beta.py; actual actor unknown | unknown | synthetic fixture | existing and declared running; not accepted as measured evidence |
| UNKNOWN-NOTE | unknown | unknown | historical note | protected by explicit state reference |
| UNKNOWN-STATE | unknown | this inventory; external consumers unknown | supplied runtime-path declaration | actual OS process status unverified |

All seven supplied files and exact hashes are in inventory.json. No actual dataset, result execution log or paper citation is supplied. ALPHA/BETA are experiment IDs from source declarations, not newly invented root TASK identifiers. Main owns the project task index.

from pathlib import Path
import math,json

def sm(z):
 e=[math.exp(x-max(z)) for x in z];return [x/sum(e) for x in e]
def output(ab,values=(0,10)):
 p=sm([ab[0]+ab[2],ab[1]+ab[3]])
 return sum(x*y for x,y in zip(p,values))
z=[0.,0.,0.,0.];q=[0.,0.,0.,math.log(3)];h=1e-5
fd=[]
for j in range(4):
 plus=z.copy();minus=z.copy();plus[j]+=h;minus[j]-=h
 fd.append((output(plus)-output(minus))/(2*h))
assert abs(output(z)-5)<1e-12 and abs(output(q)-7.5)<1e-12
assert all(abs(x-y)<1e-8 for x,y in zip(fd,[-2.5,2.5,-2.5,2.5]))
assert output([0,0,3,3])==5
assert output([1,-2,-1,2])==5
assert abs(output(q,(8,8))-output(z,(8,8)))<1e-12
r={'initial_p':sm([0,0]),'quantized_p':sm([0,math.log(3)]),'initial_y':output(z),'quantized_y':output(q),'exact_delta':output(q)-output(z),'analytic_joint_jacobian':[-2.5,2.5,-2.5,2.5],'central_difference_joint_jacobian':fd,'step':h,'tolerance':1e-8,'linear_delta':2.5*math.log(3),'boundary_checks':['common logit shift: output unchanged','opposing path errors: output unchanged','constant V rows: output unchanged'],'result':'passed','scope':'Supplied teaching model and additional algebraic boundary examples, not model experiments'}
Path(__file__).with_name('calculation_checks.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))

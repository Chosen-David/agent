# 自动编排与持久监督

此流程补齐 [有界续跑协议](supervised_continuation_workflow.md) 的运行时能力，不改变它的授权门禁。简单一次答复不建链；多步骤、需要等待或可恢复任务由主 AI 主动编排。当前提供 [Python 核心](../agent_runtime/core.py)、[前台本地 scheduler](../agent_runtime/scheduler.py)；不代表已在当前宿主安装守护进程或绑定云任务。

## 主 AI 执行步骤

1. 读取最新用户指令与已有任务状态。维护唯一 run_id、用户目标、硬约束、当前权限/预算、输入版本、owner、依赖 DAG、action、outputs、done_when、最大尝试次数。主 AI 负责自然语言拆解；核心校验依赖/环/预算，不假装内置了 LLM。各独立支线都保留；基线验收必须是替代探索的前置节点。
2. 已有 `task_chain.yaml` 的决定/假设/预算字段仍为主 AI 的决策记录；本轮在其 `runtime` 记录 DB 路径、run_id、plan SHA、monitor ID。运行后节点状态以 SQLite 为唯一执行状态，YAML/JSON 导出只是快照，禁止两边独立改 status。先为当前链构造 [task-dag/v1 JSON](../templates/task_dag.json)，不可变计划绑定 run_id。语义重规划建立新版本/新 run_id、显式关联旧链与验证后的产物，不能直接修改已执行的动作/验收或盲重放副作用。
3. 选择宿主**实际可调用且已授权**的动作适配器与 scheduler。模块存在、Prompt、配置或磁盘数据库均不证明后台服务可用。当前 CLI 仅注册只读 `verify_artifacts`；真实动作通过可信 Python Handler 的 run/verify 与宿主 authorize 回调接入。没有动作接口就记 `blocked: host action adapter unavailable` 并继续其他支线；不可假装计划文字已执行。
4. 主 AI 按预计耗时、风险、进度变化给出 min/max/rationale 和每任务 ETA/risk。核心以 ETA×0.25（高风险×0.1）作为工程初值，无进展指数退避，最终严格 clamp。参数并非论文测得最优。后端若最低一小时，主 AI 必须把有效下限提高到一小时；不要创建不支持的高频任务。可信变化事件可提前唤醒但不越过下限，重试截止仍有效。
5. 只有 scheduler capability ready，create 返回真实 ID，且 readback 确认当前 run_id、active、live，才报告“已启动”。保存 receipt 与宿主限制。云/平台 scheduler 必须由宿主真实工具绑定执行环境、权限、状态持久路径、恢复入口并读回；本仓库没有这些平台的预装适配器。没有绑定就准确报告阻塞，当前会话继续可执行部分。禁止修改平台内部监督/Heartbeats，禁止自行开账户、凭据、部署基础设施或安装用户机 daemon。
6. 每次可信 tick 去重、读取最新授权与取消、恢复过期租约、核对已有完成证据、只领取依赖就绪任务。执行与验收分离，只有验收器确认证据才能 done。Handler 的异常产生诊断和有限重试；非幂等未知副作用 blocked 等核实。模型自评、无 ready 节点、预算耗尽、用户沉默都不是完成条件。
7. 权限阻塞不消耗尝试次数，继续其他已授权支线；定时检查退避且状态/原因保留，主 AI 明确汇报恢复条件。不会因未答复自动授权 paid compute/security/外发。可逆低风险默认及 baseline-first 隔离探索仍按既有有界续跑规则。宿主授权回调须在每次执行前检查最新批准/撤回，监督器不是权限源。
8. 全部必要节点 verified done 才算任务目标完成；读回本链 monitor 已 stopped 才宣布收尾完成。failed/cancelled 分别报告，failed 需诊断、预算与恢复方案，不能无声停止或伪报 done。终态仅停止自有 monitor，不碰其他任务。取消使旧结果失效；外部工具已发生副作用不自动撤销，需合作取消/核实。

## 本地使用与能力边界

在仓库根目录运行，Python 3.10+，标准库 SQLite；真实运行状态置于被 gitignore 的私有目录：

```bash
python -m agent_runtime --db .agent-runs/my-task/state.sqlite init .agent-runs/my-task/plan.json
python -m agent_runtime --db .agent-runs/my-task/state.sqlite capabilities
python -m agent_runtime --db .agent-runs/my-task/state.sqlite tick my-run --artifact-root /absolute/authorized/project --event-id trusted-event-1
python -m agent_runtime --db .agent-runs/my-task/state.sqlite status my-run
```

没有前台服务时 `arm` 正确返回 blocked。只有用户/宿主已经允许运行服务时，才在其管理的进程环境启动；以下是使用说明，本次仓库升级不替用户安装或启动常驻服务：

```bash
python -m agent_runtime --db .agent-runs/my-task/state.sqlite serve --artifact-root /absolute/authorized/project
# 另一终端；成功输出必须含 monitor ID 和实时 readback
python -m agent_runtime --db .agent-runs/my-task/state.sqlite arm my-run
python -m agent_runtime --db .agent-runs/my-task/state.sqlite wake my-run --reference trusted-artifact-change
python -m agent_runtime --db .agent-runs/my-task/state.sqlite cancel my-run --reference user-stop-instruction
```

`serve` 为前台进程，SIGTERM/SIGINT 正常退出；进程/主机关闭后不会执行。相同 DB 重启保留任务与定时记录并恢复；服务心跳最多30秒滞后，readback 是截至当时的存活证据，不是未来可用性保证。blocked 的 monitor 继续低频检查；failed 的 monitor 停止但失败在 state/journal 中保留，宿主负责读取并向用户报告。没有消息传输后端，不声称离线推送通知。

`python scripts/demo_task_supervisor.py` 可运行十秒上限的真实本地 SQLite/文件/前台线程演示，最终停止服务，临时文件自动清理；任务本身为 synthetic deterministic fixture，不是 LLM 效果实验。

## 适配器契约

- 可信宿主注册固定 action→Handler，元数据 idempotent/required_capabilities 来自代码，不接受计划自行赋权。`authorize(plan, task, handler)` 默认拒绝；CLI 只对白名单 ArtifactHandler 及显式 root 授权。宿主需验证任务输入、真实工具权限、剩余预算与批准版本，plan 中 authorization_reference 只是引用。
- `run(task, Context)` 返回 Outcome；`verify(task, evidence)` 必须只读、独立校验当前验收，不得仅返回模型的 true。内置 hash 验收只证明预声明字节一致，不能证明论文质量/业务语义。非预知输出需要宿主提供测试/评审验收器，不应事后随意更改预声明验收来过关。
- Context 提供稳定 idempotency_key、代次 token、current()。适配器必须在副作用前检查 current，并让外部系统按键去重/按代次隔离；SQLite 只 fence 状态提交，不提供外部 exactly-once。长作业应使用短时间 submit/poll handler，持久化远端 job ID 到自己的幂等账本，不能阻塞超过 lease。没有这类后端时准确 blocked。
- 调度/动作间崩溃使用过期租约恢复。只有代码声明幂等的 handler 自动重试；其他结果不明动作必须 `Engine.reconcile` 以真实证据核实，不能由模型口述标 done。重试次数耗尽 failed；要增加预算需新的明确授权与版本化恢复方案，不偷偷归零。
- 此版本 SQLite 适于单宿主本地磁盘，多进程共享该文件；不承诺 NFS、多机分布式锁、时钟大幅跳变安全性、数据库丢失恢复、任意外部进程强制取消或生产 SLA。事务外副作用、最终验收后产物改动和恶意同权限进程不在核心保证内。日志可能含私有任务信息，不提交运行 DB/原始私密资料。

研究来源与取舍见 [研究索引](../docs/supervisor_research/README.md)，实现验证见 [验证记录](../docs/task_supervisor_validation.md)。

## tmux 与 TASK.md 闭环

2026-10-06 用户配置覆盖上文旧版“仅前台 serve”的默认启动方式：在用户授权的 Linux/server 多步骤任务中，**主 AI 负责配置、启动、维护任务链、监督器、定时器和所有工作 Agent**，默认用下述 tmux 入口。旧 `serve` 保留用于诊断/已有 API，不再是主 AI 在 SSH 下启动正式监督的方式。本次提供可运行工具与配置；不等于已登录用户服务器或部署模型后端。

### 两种入口，同一份任务依据

1. **自动入口**：主 AI 开始项目工作时读取项目根 `TASK.md`，从目标、验收、限制、依赖编排任务链；已有链先读进度、证据、上下文，不能重新开始已完成工作。
2. **手动入口**：用户说“编排任务链/继续完成这些任务”时，主 AI 将已授权目标合并到同一个 `TASK.md`，保留原有条目与证据，再编排。`mode=manual` 记录来源，不获得额外权限。

`http://TASK.md` 在此指项目文件，不抓取同名网站。用户原始文件是自由文本时，由主 AI 保留原文并规范化为 `- [ ] [T1] 目标` 形式；每个可验收要求有稳定 ID，可附多行验收/数据说明。运行时要求源路径恰为当前项目根 `TASK.md`，拒绝把 Agent 子目录内的同名文件当总清单。所有复选框（包括已勾选项）都必须映射到 DAG，不能靠勾选跳过验证。非任务说明使用普通段落；代码围栏中的示例不当作任务。[模板](../templates/TASK.md)只用于新项目，不覆盖用户现有文件。

主 AI 用 `prepare` 自动提取清单，得到**不可直接执行的规划草稿**；它不是自然语言 LLM，不推断依赖或凭空提供 Agent。主 AI 随即填好依赖、owner、action、输入、验收、report_path、风险/耗时/预算及现有授权引用，不把这一步留给用户逐项配置。

```bash
python -m agent_runtime.task_supervisor prepare \
  --task-file /absolute/project/TASK.md --run-id project-v1 --mode auto \
  --authorization-reference current-user-instruction \
  --out /absolute/project/.agent-runs/project-v1/plan.json
# 主 AI 完成草稿中的动作/依赖/验收配置，并准备真实 host adapter 后：
python -m agent_runtime.task_supervisor start \
  --plan /absolute/project/.agent-runs/project-v1/plan.json \
  --project-root /absolute/project \
  --state-dir /absolute/project/.agent-runs/project-v1 \
  --adapter /absolute/project/host_adapter.py
```

没有 adapter 参数时仅注册 `verify_artifacts`；它不执行模型、实验或自动修复。`configure_host_action`/未配置验收的草稿拒绝启动。主 AI 必须实际配置可用后端，缺少模型接口/凭据/预算时准确报告缺项并继续可做工作，不假装“已经让 AI 常驻”。不要把凭据写进计划、TASK.md 或公共仓库。

### 生命周期、定时与断线恢复

- `start` 总是在独立 tmux server socket `agent-supervisors` 的自有 `agent-<hash>` 会话中 detached 启动 guard/worker，即使调用者已经在 tmux。独立会话避免主 AI pane 退出带走监督。路径按参数安全引用；重复启动相同配置复用会话，同一 state-dir 的启动锁与 worker 锁避免重复创建 Agent。
- guard 将 stdout/stderr 追加到 `supervisor.log`；worker 意外非零退出后每 5 秒重启，同盘 DB/计划、幂等键、已完成证据和定时 due 保留。非幂等动作结果不明仍阻塞核实，不因重启盲重放。正常取消/全部完成返回 0，guard 退出后仅自有 session 自动消失。
- 使用已有 SQLite 定时器及受 min/max 限制的自适应 due，不创建额外 cron。专用 worker 只 drain 自有 run_id。主 AI 根据实际 ETA、风险、等待状态调整下一版本策略，并维护所有远端 job/Agent ID 和取消方式。
- `receipt.json` 记录实际 run_id/session/monitor 及读取到的 live；成功声明要求 tmux pane 存活、匹配 worker 心跳和 monitor 读回。状态不是未来可用性承诺。不要用 `$TMUX` 存在或磁盘文件存在代替活性核查。
- SSH 客户端断开不会终止 detached 会话；服务器重启/断电、tmux server 或 guard 被杀仍会停止。主 AI/管理员重连后运行相同 `start` 恢复，不删 DB/重置尝试次数。若要求开机自动恢复，需要另行配置宿主开机服务；本配置没有安装 systemd/cron。OS logout 清理策略、磁盘空间和模型服务可用性也应由主 AI 检查。
- `failed` 或 TASK.md 变化时 worker 保留，maintain 回调持续以受限间隔提交/查询主 AI 的诊断/恢复工作；耗尽尝试的动作不再盲跑。缺 maintain 后端会在进度中显示 `maintenance_available=false`，只能监测而不能自动修复。没有后端时不得许诺所有工作自动完成。

```bash
python -m agent_runtime.task_supervisor status \
  --config /absolute/project/.agent-runs/project-v1/launch.json
# session 名从 receipt.json 读取，不猜测，也不碰用户其他 session。
tmux -L agent-supervisors attach -t agent-REPLACE_WITH_RECEIPT_HASH
python -m agent_runtime.task_supervisor cancel \
  --config /absolute/project/.agent-runs/project-v1/launch.json \
  --reference explicit-user-stop
```

取消停止自有定时记录，worker 在下一轮退出；外部作业仍由适配器按 Context.current/job ID 合作取消，不声称强行撤销副作用。禁止 `kill-server` 或杀用户主 AI 会话。正常中断用于维护时再次 start 保留状态；SIGKILL 恢复仍遵循已有租约/未知副作用规则。

### 每完成一项，对照 TASK.md

每个 DAG 节点必须有 `task_refs`（对应 TASK.md 稳定 ID）和独立 `report_path`。同一要求可映射多个执行/审查节点，全部 done 才完成该要求。完整 TASK.md 内容哈希绑定到不可变计划；清单的任何变化均需主 AI 核对后新建版本/run_id，显式关联旧链与已验证产物，再停旧链。运行时不自动改用户清单勾选，避免把生成报告写入原文件造成自触发版本漂移。

适配器完成工作时先写真实产物、完成独立验收，再原子写节点报告，最后返回 `Outcome('complete', evidence=...)`。报告示例：

```json
{
  "task_id": "T1",
  "summary": "完成该任务的实现并验收；此处必须替换为实际结论",
  "data": [
    {"kind": "not_applicable", "description": "此任务是配置修改，无性能测量；验收证据见 evidence"}
  ]
}
```

data 每项含 kind、description；kind 只能为 measured/derived/synthetic/not_applicable。数值数据还应记录 value/unit、原始日志、环境/配置和计算口径，适配器的专业 verifier 负责其正确性。结构检查与哈希一致性不证明论文质量或数值真实性。

`ReportingHandler` 只有在底层独立 verifier 通过且报告有效时才允许 done；报告内容哈希进入 evidence，后续改写会失效。每个 tick/outcome 立即重读 TASK.md 并更新 `progress.json`，包含：

- 对应 TASK.md 的哪个要求、执行节点和当前验收状态；
- 本次结论、数据（或明确无数值）、可查证产物与哈希；
- 剩余要求、失败/阻塞原因，供主 AI 安排下一步；
- 清单版本是否变化、是否真的全部可汇报。

全部要求映射完整、所有节点独立验收、最终重新校验证据和报告、清单未变才写 `final-report.json`；读回 monitor stopped，worker/guard 退出。主 AI 随后读报告向用户汇总结果和数据；本地文件不是已经发送通知，未配置消息通道时不声称离线推送。负结果只要满足预先定义的研究验收也可完成；失败/未知不能伪报完成。

### 任务改动与发布状态

完整 checkout 中，主 AI 可使用 `agent_runtime.publication.PublicationLedger` 将每个待提交新增/修改/删除文件绑定到根 TASK 的稳定 ID。先刷新远端，完成验收并暂存候选；`freeze(file_task_refs, remote=..., branch=..., authorization_reference=...)` 冻结索引树、文件字节与 TASK 版本，拒绝未归属、未暂存或混入的未跟踪文件。记录放私有 `.agent-runs/<run_id>/publication.json`，不放进待发布树。插件单独安装无此模块时按相同步骤人工记录，并明确没有机器门禁。

宿主必须提供真实的当前授权 `authorize`、独立验收 `accept` 和远端只读观察 `remote_reader` 回调；函数由可信控制器提供，不从 TASK、模型报告或序列化计划加载。`mark_tested(evidence)` 核对候选及验收文件哈希、TASK 覆盖和声明的项目记忆，回调仍负责验收是否真实充分。哈希一致或自填 pass 不等于测试通过。

主 AI 在现有权限内自行执行 Git 操作：实际提交后 `observe_commit()` 确认提交树及父基线；推送前再次刷新远端，有并发改动则保留旧候选、整合后重冻并重验；实际推送后 `observe_pushed()` 读取授权远端的精确提交，再用 `verify_remote()` 独立再次读回。失败调用 `record_push_failure(reason)` 保留已提交、待推送状态，下次接续而非报已交付。只有本批约定任务全部通过且 push/远端核验完成，才汇报发布轮完成；检查点不算完成一轮。

该模块不执行 stage/commit/push、不提供凭据、模型或网络后端，不扩大到其他仓库；`status()` 只是历史审计，不能当当前远端状态或授权。状态文件不是抗篡改证明，控制器须串行操作并在每次推进时重验；符号链接、子模块及合并提交暂不支持，不应绕过校验。完整候选变化必须重冻；独立验收依据应能证明复用证据与最终实现仍匹配。

### 主 AI / Agent 宿主适配器

`--adapter` 是主 AI 在现有授权下选定的可信 Python 文件，导出 `build(project_root, store, run_id)`，返回：

```python
return {
    "handlers": {"experiment": experiment_handler, "review": review_handler},
    "authorize": check_current_host_authorization,
    "maintain": submit_or_poll_main_ai_recovery,
}
```

handler 沿用现有 `run(task, Context)/verify(task, evidence)` 契约，report_path 是输出契约之一。authorize 接收原始 handler，不因包装器失去身份检查。maintain 接收最新 progress 对象，只做**短时间 submit/poll**，持久记录主 AI 请求 ID，不能每次计时都新建同一请求或阻塞等待模型数分钟。主 AI 持续读取当前任务/数据/待办，修复动作接口、派发依赖就绪 Agent、核验任务报告并维护恢复任务；改变语义/验收或增加超出授权的资源仍走既有决策协议。

真实长作业由后端独立运行并持久化 job ID，轮询间隔与 ETA 匹配。新计划显式配置 `wait_policy: {max_polls, max_seconds, diagnose_after_seconds}`：正常返回的 pending 计入观察预算、不消耗失败尝试；retry、异常和租约过期仍按 max_attempts 处理。时间从首次 pending 对应的领取时刻累计，不因重启或夹杂 retry 归零。观察次数或时间耗尽会 blocked，保留监督给 maintain 诊断，不自动重启、杀作业或记 done。没有 wait_policy 的旧计划保持 pending/retry 共用尝试预算；不能直接修改已绑定计划来延长预算，迁移需新版本并核实原 job 和证据。prepare 草稿附带120次/3600秒观察预算、300秒诊断阈值，主 AI 在启动前按具体任务与授权细化；这些是工程初值，不代表最优或新增资源授权。

领取任务从持久化游标轮转，仍检查依赖、各节点 next_at、授权及租约；一项长期等待不会总占列表首位。progress 的每项节点附 task_refs 与 execution（attempts、dispatches、pending_polls、时间、策略、diagnosis_required）。诊断阈值仅提醒检查，不能据耗时认定卡死；旧记录缺计数时为 unknown，不补造历史。

主 AI 收到诊断提醒后读取当前 TASK、具体 job ID、最近有意义进度与耗时分解，区分正常计算、外部等待、资源瓶颈和无新信息重复；证据不足标未知，继续独立任务。有明确瓶颈才提出缓存、复用、批处理或授权内并发等小方案；固定输入、正确性/质量门禁、主要耗时口径和剩余预算，保留原方案，用实际对照决定采用或回退。没有公平比较不宣称提速，不能凭自我怀疑更改正确结果或跳过用户指定基线。具体变更、验证及剩余项引用 TASK ID；符合用户发布范围且全部验收通过后才提交、推送并核验远端，不把已生成文件当作已发布。上述流程需要真实 maintain/动作后端；核心只暴露诊断证据和有界调度，不内置模型优化器或 Git 发布器。主 AI 所在 tmux 不会自动让 Web 聊天拥有远端模型执行能力。

官方行为依据：[tmux 手册](https://man.openbsd.org/tmux.1)，2026-10-06 核查；说明 detached 会话能继续运行、连接断开后可重新附着。实际验证范围见[本次验证记录](../docs/tmux_supervisor_validation.md)。

# 核验→处理→复查

- READ-T001 (verify) 依赖 []：Re-read all three pages at recorded hash. Ask which assumption/proof could justify a universal claim; do not infer real-model truth from toy arithmetic.
- READ-T002 (resolve) 依赖 ['READ-T001']：Choose minimal supported scope change and regenerate PDF with new hash; preserve arithmetic.
- READ-T003 (recheck) 依赖 ['READ-T002']：Render and visually reopen revised pages 1–3; check original acceptance.

from pathlib import Path
import csv,json
from fractions import Fraction
out=Path(__file__).resolve().parent
rows=list(csv.DictReader((out.parents[2]/'inputs/measurements.csv').open()))
results=[]
for n,row in enumerate(rows,2):
 b=Fraction(row['baseline_ms']);c=Fraction(row['candidate_ms'])
 results.append({'source_line':n,**row,'speedup_exact':str(b/c),'speedup':float(b/c),'latency_change_percent_exact':str(100*(c-b)/b),'latency_change_percent':float(100*(c-b)/b)})
assert len(results)==4
assert [r['speedup_exact'] for r in results]==['5/4','6/5','10/11','2']
assert results[2]['latency_change_percent_exact']=='10'
assert [r['scope'] for r in results]==['end_to_end']*3+['kernel_only']
record={'formulas':{'speedup':'baseline/candidate','latency_change_percent':'100*(candidate-baseline)/baseline'},'rows':results,'checks':'Four supplied pairs recalculated with exact rational arithmetic; negative result and timing scopes retained. No aggregate or double counting.','new_measurements':False}
(out/'calculation_checks.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))

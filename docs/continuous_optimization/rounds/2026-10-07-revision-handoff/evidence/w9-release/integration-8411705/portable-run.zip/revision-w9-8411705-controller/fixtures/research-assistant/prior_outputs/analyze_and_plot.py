from pathlib import Path
import csv,json,hashlib,os
out=Path(__file__).resolve().parent
case=out.parents[2]
os.environ['MPLCONFIGDIR']=str(out/'.mpl-cache')
source=case/'inputs/measurements.csv'
rows=list(csv.DictReader(source.open()))
assert len(rows)==4
for row in rows:
 b=float(row['baseline_ms']);v=float(row['candidate_ms'])
 assert b>0 and v>0 and row['scope'] in ('end_to_end','kernel_only')
 row.update(baseline_ms=b,candidate_ms=v,speedup=b/v,latency_reduction_percent=100*(b-v)/b)
(out/'computed_metrics.json').write_text(json.dumps({'kind':'derived from supplied synthetic fixture','input_version':'v2','source':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'formula':'speedup=baseline/candidate; reduction_pct=100*(baseline-candidate)/baseline','rows':rows,'new_experiments':0},indent=2))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axs=plt.subplots(1,2,figsize=(9.5,3.8),gridspec_kw={'width_ratios':[3,1]})
for ax,scope,title in zip(axs,['end_to_end','kernel_only'],['End-to-end','Kernel only']):
 rr=[x for x in rows if x['scope']==scope]; xs=list(range(len(rr)))
 for shift,col,color,label,hatch in [(-.19,'baseline_ms','#5d7187','Baseline',''),(.19,'candidate_ms','#188f90','Candidate','//')]:
  bars=ax.bar([x+shift for x in xs],[x[col] for x in rr],width=.36,color=color,label=label,hatch=hatch)
  ax.bar_label(bars,labels=[f"{x[col]:.0f}" for x in rr],padding=3,fontsize=9)
 ax.set_xticks(xs,[x['workload'] for x in rr]);ax.set_ylim(0,250);ax.set_ylabel('Latency (ms)');ax.set_title(title)
 ax.spines[['top','right']].set_visible(False)
axs[0].legend(frameon=False,loc='upper left');fig.suptitle('Provided synthetic data · measurements v2')
fig.text(.5,.02,'One supplied value per configuration; repeats and uncertainty unspecified.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.05,1,.96))
fig.savefig(out/'figure_v2.png',dpi=160);fig.savefig(out/'figure_v2.svg');plt.close(fig)
print(json.dumps(rows,indent=2))
print('Four rows recalculated; PNG and SVG generated from current input.')

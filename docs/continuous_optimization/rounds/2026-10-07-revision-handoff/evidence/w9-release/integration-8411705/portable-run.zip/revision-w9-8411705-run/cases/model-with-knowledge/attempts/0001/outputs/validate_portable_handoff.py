from pathlib import Path
import json,hashlib,importlib.util
out=Path(__file__).resolve().parent
case=out.parents[2];run=case.parents[1];role=case.name
binding_path=Path('/workspace/scratch/c12f3d9f92bd/revision-w9-8411705-controller/dispatch-input-bindings.json')
bind=json.loads(binding_path.read_text())['cases'][role]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
module_path=run/'snapshot/scripts/validate_handoff.py'
spec=importlib.util.spec_from_file_location('validate_handoff',module_path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
# Consumer scope comes ONLY from root trusted dispatch binding and follow-up, not output tasks.
request={'schema_version':1,'input_version':bind['input_version'],'tasks':[{'task_id':bind['task_id']}]}
use=json.loads((out/'knowledge-use.json').read_text())
source=json.loads((out/'source_manifest.json').read_text())
assert source['all_protected_bytes_unchanged']
for item in source['protected_files']:
 assert sha(Path(item['path']))==item['sha256_after']==item['sha256_before']
old=out/'handoff.json'
if old.exists() and not (out/'handoff.before-repair.json').exists():
 before=old.read_bytes();(out/'handoff.before-repair.json').write_bytes(before)
 errors=mod.validate(json.loads(before),out,True,expected_input_version=bind['input_version'],consumer_request=request)
 (out/'handoff.initial-validation.json').write_text(json.dumps({'validator':str(module_path),'validator_sha256':sha(module_path),'record_sha256':hashlib.sha256(before).hexdigest(),'trusted_request':request,'errors':errors,'integrity_valid':not errors,'scope':'actual check of earlier manual envelope; preserved, not hidden'},indent=2))
filenames=['continuation_report.md','knowledge-use.json','command-results.json','role_load.json','source_manifest.json','recheck.py','recheck_results.json','validate_portable_handoff.py']
for optional in ['candidate_models.md','knowledge-demand.md','handoff.before-repair.json','handoff.initial-validation.json']:
 if (out/optional).is_file():filenames.append(optional)
artifacts=[{'id':f'A{i+1}','path':name,'sha256':sha(out/name)}for i,name in enumerate(filenames)]
ids={x['path']:x['id']for x in artifacts}
checks=[{'criterion':'Current supplementary analysis and explicit limitations rechecked against protected original task; independent root acceptance remains separate','status':'pass','artifact_ids':[ids['continuation_report.md'],ids['recheck_results.json']]},{'criterion':'Current knowledge-demand judgment and actual command observations recorded; needed refs checked, not_needed grounded for exact task','status':'pass','artifact_ids':[ids['knowledge-use.json'],ids['command-results.json']]},{'criterion':'Protected input and historical-output hashes unchanged','status':'pass','artifact_ids':[ids['source_manifest.json']]},{'criterion':'Current role contract loaded with exact trusted dispatch binding','status':'pass','artifact_ids':[ids['role_load.json'],ids['knowledge-use.json']]}]
corpus=use.get('corpus_snapshot') or use.get('corpus_snapshot_observation',{}).get('snapshot')
record={'schema_version':1,'run_id':run.name,'role':role,'task_id':bind['task_id'],'input_version':bind['input_version'],'status':'completed','artifact_root':'.','artifact_root_context':'explicit root is this handoff parent outputs directory','limitations':['Supplemental review only; prior artifacts remain historical and have not been regenerated or relabeled.','No new performance experiments, network, install, or delegated agents.','Completeness/integrity is not final scientific acceptance; root independently reviews semantics.'],'knowledge_root':'plugins/research-assistant/skills/model-with-knowledge/assets/knowledge','knowledge_root_context':'relative to current authorized snapshot cwd, independently supplied by root binding','corpus_snapshot':corpus,'knowledge_refs':use['knowledge_refs'],'artifacts':artifacts,'checks':checks,'tasks':[{'task_id':bind['task_id'],'depends_on':[],'status':'done','evidence':[ids['continuation_report.md'],ids['knowledge-use.json'],ids['recheck_results.json'],ids['source_manifest.json']]}]}
(out/'handoff.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
errors=mod.validate(record,out,True,expected_input_version=bind['input_version'],consumer_request=request)
result={'validator':str(module_path),'validator_sha256':sha(module_path),'method':'validate(record, explicit_own_outputs_root, True, expected_input_version=binding, consumer_request=trusted_scope)','explicit_own_outputs_root':str(out),'trusted_binding':{'path':str(binding_path),'sha256':sha(binding_path),'source':'root dispatched task/version and required REV-03 follow-up; no inference from producer tasks'},'trusted_request':request,'handoff_sha256':sha(out/'handoff.json'),'errors':errors,'integrity_valid':not errors,'completion_verified':not errors,'consumer_scope_verified':not errors,'scope':'local integrity and exact consumer contract only, not semantic or visual certification'}
(out/'handoff.validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({'role':role,'errors':errors,'completion_verified':not errors,'handoff_sha256':result['handoff_sha256']},indent=2))
assert not errors

# 选择性执行：通用工作稿

以下结果和摘要仅依据给定合成材料，未新增实验或文献，不代表已发表论文。

## 中文结果段落

在给定的单次 CPU 合成记录中，替换选定内核后，小型工作负载的端到端延迟由100 ms降至80 ms，中型工作负载由120 ms降至100 ms，分别对应1.25×和1.20×的加速比，以及20.0%和约16.7%的延迟降低。大型工作负载的端到端延迟却由200 ms增至220 ms，增加10.0%，对应约0.90909×的加速比；该退化已在原稿附录A中披露，应与正向结果一并保留。独立计时的内核延迟由20 ms降至10 ms，其2.00×加速比与50.0%的延迟降低仅适用于内核级测量。由于内核已包含在端到端路径中，两种计时不可相加，内核加速也不能改写为所有工作负载的端到端收益。因此，原摘要“所有工作负载均获得2×端到端加速且没有退化”的结论不受这些记录支持。全部测量使用相同CPU进程与输入配置，但每个数值仅来自一次运行，无独立重复；方差和输出质量未测量，也没有GPU测量。以上仅描述已有记录的差异，不能据此断言统计显著性、可重复收益、质量保持或跨硬件泛化；大型负载退化的原因亦未得到材料支持。

## English abstract

We describe supplied synthetic timing records for replacing a selected kernel under the same CPU process and input configuration. End-to-end latency falls from 100 to 80 ms for the small workload and from 120 to 100 ms for the medium workload, corresponding to speedup ratios of 1.25× and 1.20× and latency reductions of 20.0% and approximately 16.7%, respectively. The large workload regresses from 200 to 220 ms: latency increases by 10.0%, with a speedup ratio of approximately 0.90909×. Separately timed kernel latency falls from 20 to 10 ms, yielding a 2.00× kernel-only speedup and a 50.0% latency reduction. Because the kernel is already included in the end-to-end paths, its timing must not be added to end-to-end latency, and its speedup does not establish a uniform 2× end-to-end improvement. Each value represents one run without independent repeats. Variance and output quality were not measured, and no GPU measurements are available. These descriptive CPU observations include both improvements and a regression; they do not establish statistical significance, repeatable gains, quality preservation, or performance on other hardware. The cause of the large-workload regression remains undetermined.

## 主张证据表

加速比 = baseline_ms / candidate_ms；延迟变化 = 100 × (candidate_ms − baseline_ms) / baseline_ms。负变化表示延迟降低。数字舍入不意味着统计精度。每条证据的文件版本和SHA-256见execution_record.json，计算见calculation_checks.json。

| 主张ID | 主张 | 证据位置 | 支持范围、限制或反证 | 稿内位置 |
|---|---|---|---|---|
| WRITE-C001 | 小型端到端1.25×，延迟降低20.0% | measurements.csv 第2行，100→80 ms | 单次CPU合成记录；不证明重复性 | 结果、摘要 |
| WRITE-C002 | 中型端到端1.20×，延迟降低约16.7% | measurements.csv 第3行，120→100 ms | 单次CPU合成记录；不证明显著性 | 结果、摘要 |
| WRITE-C003 | 大型端到端约0.90909×，延迟增加10.0% | measurements.csv 第4行，200→220 ms；manuscript.md 附录A第10行 | 负结果保留，原稿已披露；机制未知 | 结果、摘要 |
| WRITE-C004 | 内核级2.00×，延迟降低50.0% | measurements.csv 第5行，20→10 ms | 仅kernel_only，不等于端到端或GPU收益 | 结果、摘要 |
| WRITE-C005 | 内核已在端到端路径中，不应叠加计时 | manuscript.md Results第8行 | 来源明确的口径限制；不推算未提供的开销分解 | 结果、摘要 |
| WRITE-C006 | 相同CPU进程/输入；每值单次、无独立重复；质量、方差与GPU未测 | manuscript.md Method第6行、Results第8行、Appendix A第10行 | 只作描述，保留所有证据缺口 | 结果、摘要 |
| WRITE-C007 | 原摘要的普遍2×/无退化主张不成立 | manuscript.md Abstract第4行与CSV第2–5行对照 | 三个端到端比值均非2×，大型实际退化；替换错误主张 | 结果中的纠正、替换后摘要 |

完成状态：所请求的工作稿已完成，数值已重算。没有进行新实验、独立科学审稿或投稿检查。

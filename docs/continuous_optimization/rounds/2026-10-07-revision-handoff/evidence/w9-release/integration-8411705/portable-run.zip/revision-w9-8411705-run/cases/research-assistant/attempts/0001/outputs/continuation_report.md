# 8411705补充续接：历史结论保留，新增知识需求审查

本次重新读当前Skill、execution与knowledge-access契约；补充记录使用可信派发的REV-03/input_version，original-task.json没有input_version字段，另行记录为absent。project.json所述measurements v2及concept v1为实际项目声明，不重命名原产物。旧role_load中的3851bbb快照、旧命令及旧输出仍属历史，不能宣称它们当时使用8411705。

知识需求：当前任务是四个标量比率、数据版本传播与旧产物复核，理论知识not_needed；项目事实required，已读取。concept.txt只用于确认背景依赖独立，不把它的教学题扩成当前目标。无当前外部事实需求。实际运行指定CLI的snapshot确认工具/语料可访问，未为了“调用过知识”检索无关数学；空knowledge_refs是诚实的无使用声明，而非机器已验证。

重新执行recheck.py：small1.25×/降20%，medium1.20×/降16.6667%，large0.909091×/增10%，kernel2×/降50%，与历史数值一致。scope分开，未算混合平均。重新读历史DAG并程序确认依赖存在且无环，历史done节点对应归档文件存在，CODE-DIAG仍blocked。文件存在不证明科学质量，具体语义另核如下。

v2更新使figure@v1和旧write安排失效，collect@v1作为历史保留而不编造重新采集；background仅依赖concept@v1，适用性保留，但原background正文依然缺失，不能当本轮已验收。RES-KEEP是实际保留检查，不用skipped历史任务满足下游。新本轮不产生新图或结果段落，历史v2成果维持归档身份。

本次实际打开归档figure_v2.png：四对柱的100/80、120/100、200/220、20/10标值与输入一致，end_to_end和kernel_only分面，零基线、ms单位、large回退及无不确定性脚注保留。未发现遮挡或裁切。这个动作是当前复查旧图，不是重新生成、不是独立新设计评审。

继续决定不变：保留baseline，优先有界诊断large；缺实现、正确性契约、原始重复/配置，尚不能判定机制或统计稳定性。当前只做已有数据，新增实验数0。恢复CODE-DIAG需取得材料与必要预算；不可把新知识访问能力误当额外实验许可。

旧analyze_and_plot.py按原工作目录定位输入，归档后路径层级已变化；保持它的字节与历史命令原样，不直接执行它来覆盖归档。当前归档复核入口：在此outputs目录运行 `python -B recheck.py`，脚本解析本补充case的明确inputs/research-assistant路径，只输出重新计算结果。本轮命令与结果见command-results.json；所有受保护输入/旧产物前后哈希见source_manifest.json。

一次早期start路径观察存在命名/时序差异：attempt_start.json不存在，随后实际读取到start.json并确认actor、case、attempt后执行本补充工作；未据缺失文件声称已开始。最终验收由root进行，手工交接不等于ACK或科学通过。已有前次上下文熟悉性，不是未见样本。

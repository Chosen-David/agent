import math,json
eta=2*.03;tight=math.sqrt(2)*eta
q=2.;K=[.04,0.];D=[-.021,.021]
score=[q*k for k in K];approx=[q*(k+d)for k,d in zip(K,D)]
err=math.hypot(*D);se=math.hypot(*[q*d for d in D])
assert err<=.03 and se<=eta
assert score[0]>score[1] and approx[0]<approx[1]
assert .15>tight and .08<tight
speeds=[1.,2.];work=2.;times=[work/v for v in speeds];assert times[0]!=times[1]
result={'kind':'deterministic derived arithmetic; not new measured performance','eta':eta,'coordinatewise_threshold':2*eta,'joint_l2_threshold':tight,'gap_015_lower_remaining_margin':.15-tight,'gap_015_guaranteed':True,'gap_008_guaranteed':False,'counterexample':{'q':q,'K':K,'D_Khat_minus_K':D,'operator_norm_D':err,'score_error_l2':se,'scores':score,'approx_scores':approx,'original_top1':0,'approx_top1':1},'preserving_example':{'q':q,'K':K,'D':[0.,0.],'scores':score,'approx_scores':score},'boundary_tie':{'gap':tight,'score_perturbations':[-eta/math.sqrt(2),eta/math.sqrt(2)],'remaining_gap':0.},'machine_example':{'speed_work_units_per_s':speeds,'job_work_units':work,'completion_seconds':times,'objective_preserved':False},'assertions':'passed','formal_prover_run':False,'benchmark_run':False}
print(json.dumps(result,indent=2))

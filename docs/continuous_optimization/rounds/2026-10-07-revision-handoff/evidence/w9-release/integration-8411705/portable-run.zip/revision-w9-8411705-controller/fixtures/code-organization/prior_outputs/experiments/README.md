# Experiments
alpha.py and beta.py are synthetic documentation fixtures.
Both appear in active_tasks.json active_scripts; do not execute or relocate.
Their first-line comments name input labels and result paths.
No real dataset or execution provenance is supplied.
See this delivery's CODEMAP.md and inventory.json for mappings and hashes.

import pathlib,json,hashlib,csv
R=pathlib.Path.cwd();O=R/'cases/research-review/attempts/0001/outputs'
def sha(p):return hashlib.sha256((R/p).read_bytes()).hexdigest()
def save(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2))
h=sha('cases/research-review/inputs/manuscript.md');rows=[]
for r in csv.DictReader((R/'cases/research-review/inputs/measurements.csv').open()):
 b,c=float(r['baseline_ms']),float(r['candidate_ms']);rows.append(dict(**r,speedup=b/c,latency_change_percent=100*(c-b)/b))
save('recomputed.json',rows)
f=[]
def add(i,status,typ,sev,loc,ev,impact,verify,repair,accept):
 f.append(dict(finding_id=f'REV-F{i:03}',snapshot_id=h,status=status,category='correctness' if i==1 else 'evidence' if i==2 else 'reporting',assertion_type=typ,severity=sev,confidence='high',location=dict(physical_page=None,printed_page=None,anchor=loc),evidence=ev,why_it_matters=impact,verification=verify,resolution_options=repair,acceptance=accept,related_findings=[]))
add(1,'confirmed','confirmed_error','major','Abstract line 4; CSV lines 2–5',['All-workload 2x end-to-end/no-regression assertion conflicts with baseline/candidate ratios 1.25, 1.2, 0.90909.','Large 200→220 ms is a 10% latency regression; 20→10 ms 2x is only kernel scope.'],'Central summary exceeds and contradicts data.','Recalculate rowwise baseline/candidate and check Appendix A; do not add included kernel timing.',['Replace universal claim with descriptive scoped ratios, preserving large regression.'],['Abstract, Results and Appendix agree with all three end-to-end ratios and separate 2x kernel-only scope.'])
add(2,'confirmed','reporting_gap','major','Results line 8; Appendix A line 10',['Each value is one run, no independent repeats; quality and variance unmeasured.'],'Cannot establish reproducibility or quality preservation from the supplied records. Not evidence the differences are merely noise.','Clarify intended generalization; recover raw paired logs if available, otherwise stay descriptive.',['Limit conclusions to these one-run CPU observations, retaining unknown variance/quality and no GPU measurement.','If broader claims retained, prospectively define matched randomized/interleaved session pairs, independent units, warmup/timing scope, effect/precision target, fixed sampling and stopping plan based on independent pilot; new experiments require separate authorization.'],['Claims explicitly remain descriptive, or valid independently collected evidence and prespecified analysis support a broader revised claim without fabricated CI.'])
add(3,'rejected','suspected_error','minor','Appendix A line 10; CSV large row',['Appendix explicitly reports 200→220 ms regression.'],'Avoid falsely alleging omission or concealment. Abstract mismatch is independently real.','Cross-read Appendix A and large CSV row.',['No correction required for alleged missing regression; retain disclosure.'],['Existing disclosure refutes omission suspicion; no repair claimed for rejected issue.'])
save('findings.yaml',dict(schema_version='1.0',snapshot_id=h,findings=f))
t=[]
for x in f[:2]:
 prev=None
 for stage in ['verify','resolve','recheck']:
  tid=f'REV-T{len(t)+1:03}';t.append(dict(task_id=tid,finding_ids=[x['finding_id']],stage=stage,depends_on=[] if prev is None else [prev],owner='research-review' if stage=='recheck' else 'main_ai',preconditions=['Matching evidence snapshot available' if stage=='verify' else 'Predecessor evidence available'],action=x['verification'] if stage=='verify' else 'Apply minimal evidence-supported resolution; rejected means no edit, unresolved remains blocked.' if stage=='resolve' else 'Independently read revised artifact at its new hash and assess original acceptance.',outputs=[f'{stage}/{x["finding_id"]}.md'],done_when=x['acceptance'] if stage=='recheck' else ['Evidence and decision recorded'],on_missing_input='blocked; name missing evidence, never invent',status='todo'));prev=tid
save('task_chain.yaml',dict(tasks=t));(O/'task_chain.md').write_text('# Verification, resolution, recheck\n\n'+'\n'.join(f'- {x["task_id"]} {x["stage"]} {x["finding_ids"]}, dependencies {x["depends_on"]}: {x["action"]}' for x in t)+'\n\nREV-F003 rejected after Appendix check; no revision needed for the alleged omission.\n')
(O/'review_report.md').write_text('''# 材料内审阅

日期 2026-10-07。完整读取本轮 manuscript.md（含 Appendix A）与 measurements.csv。合成 fixture，不是真实论文结果。无 venue/track，采用 provisional rubric：正确性、证据、可复现性和表达。未联网或修改原稿，不给录用概率。

中性总结：作者替换选定内核，在相同 CPU 进程/输入配置报告三个端到端计时对及一个独立内核计时对。摘要声称所有工作负载 2x 端到端加速且无退化。数据仅支持 small/medium 单次延迟降低、large 单次延迟增加；内核独立计时减半。

| 负载 | baseline/candidate | 延迟变化 | 范围 |
|---|---:|---:|---|
| small | 1.25x | −20% | 端到端 |
| medium | 1.20x | −16.67% | 端到端 |
| large | 0.90909x | +10% | 端到端 |
| kernel | 2.00x | −50% | 内核独立计时 |

优点：明确内核计时已包含于端到端、不能加和；披露单次运行、未测 GPU 和质量/方差；附录直接披露负结果。这些披露值得保留。

REV-F001（major，已确认）：摘要 line 4 的全体 2x/无退化与逐行复算矛盾，最小补救是统一摘要、Results 与附录的数字及范围。REV-F002（major，证据不足）：单次配对值不能建立重复性或质量保持，但也不能据此断言差异为噪声。缩小为单次 CPU 描述性结论即可，若坚持更强主张才需前瞻设计的独立补测。不能凭这些汇总伪造 CI 或强制一个任意固定重复数。

撤销 REV-F003：检查“是否未报告 large 退化”后，Appendix A line 10 已明确回答，故拒绝遗漏指控，不把该项作为待修。

待回答：2x 是否原本只想描述 kernel-only？是否要声称跨 session 重复收益或质量保持？答案决定最小修订范围。未提供实现，无法检查实现正确性。历史及当前新颖性、必要性、成本收益未验证；未联网是任务约束，不代表方法无创新。最强材料内替代是现有 baseline；不同 workload 存在权衡，不能宣称全面支配。

优先纠正 REV-F001，再明确 REV-F002 的描述范围。核验→处理→复查任务已生成但未执行；没有新稿，不关闭确认问题。范围内审阅完成，外部查新/新实验/实现审计不在完成声明中。
''')
paths=['snapshot/config/role_registry.json','snapshot/workflows/agent_communication_workflow.md','snapshot/plugins/research-assistant/skills/research-review/SKILL.md','snapshot/plugins/research-assistant/skills/research-review/references/execution.md','snapshot/plugins/research-assistant/skills/research-review/references/workflow.md','snapshot/workflows/reviewer_workflow.md','snapshot/plugins/research-assistant/skills/research-review/references/measurement_evidence_contract.md','cases/research-review/task.txt','cases/research-review/inputs/manuscript.md','cases/research-review/inputs/measurements.csv']
save('provenance.json',dict(run_id=R.name,attempt='0001',context='Prior context familiar; fresh execution, not unseen blind study. No old output files read/copied.',mode='offline_fallback',loaded_files=[dict(path=p,sha256=sha(p),coverage='lines 1–40' if p.endswith('/references/workflow.md') else 'selected lines 94–168,210–350,370–470; truncated middle recovered in focused reread' if p.endswith('/reviewer_workflow.md') else 'full') for p in paths],tool_trace=['30555e: registry, task, skill, execution, entire current manuscript and CSV','1f1549: communication workflow, selected reviewer workflow, measurement contract; long result truncated','Focused read recovered reviewer sections 5/6 and prompt opening','build_review.py: actual rowwise calculations and newly authored outputs; no prior output imports'],limits=['No external sources','No implementation/repeated-trial evidence','No configured mailbox: manual file handoff']))

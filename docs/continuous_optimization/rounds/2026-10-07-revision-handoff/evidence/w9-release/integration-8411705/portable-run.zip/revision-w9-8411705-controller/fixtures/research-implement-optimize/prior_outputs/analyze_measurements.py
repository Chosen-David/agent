import csv,json,sys
rows=[]
with open(sys.argv[1],newline="") as f:
    for item in csv.DictReader(f):
        b=float(item["baseline_ms"]);c=float(item["candidate_ms"])
        rows.append({**item,"speedup":b/c if c>0 else None,"latency_reduction_percent":100*(b-c)/b if b>0 else None})
print(json.dumps(rows,indent=2))

import pathlib,json,hashlib,math,subprocess,sys,re
R=pathlib.Path.cwd();O=R/'cases/paper-reading-companion/attempts/0001/outputs';P=R/'cases/paper-reading-companion/inputs/paper.pdf';H=hashlib.sha256(P.read_bytes()).hexdigest()
def save(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2))
a='''因为值 10 的权重从 1/2 变成 3/4。
原文定位：物理第 2 页，印刷第 1 页，前两行算例。必要公式来自物理第 1 页（印刷 i）：y = softmax(a+b)V。
我的推导：本例 a、b 各含两个 logits，V=(0,10) 是两个标量值，y 为标量；单位未给出。以自然对数解释 log，softmax(z)ᵢ = exp(zᵢ)/Σⱼexp(zⱼ)。
初始 a+b=(0,0)：指数 (1,1)，共同分母 2，权重 (1/2,1/2)，输出 (1/2)×0+(1/2)×10=5。
只把 b 改为 (0,ln 3)，保持 a、V 不变：a+b=(0,ln 3)，指数 (1,3)，共同分母 4，权重 (1/4,3/4)，输出 (1/4)×0+(3/4)×10=7.5。
所以第二个 logit 变化通过共享分母改变了两个权重；a 不变也不意味着输出固定。两条路径先相加后一起归一化，不是各自归一化。以上是教学例子验算，不是模型实验。'''
b='''不能证明。这个算例只展示特定数字下改变 b 会使输出变化。
作者在物理第 2 页最后一句声称这证明所有真实模型中的 RoPE 都放大误差。但该页没有定义误差、参考正确输出、放大比较标准，也没有给出 RoPE 与 a、b 的具体对应。输出增大并不等于误差增大。
物理第 3 页（印刷 A1）明确说：这是虚构教学例子，不是经验证据；没有研究 RoPE 特定模型、数据或实验。
自拟边界例子：保持 V=(5,5) 时，不论两个归一化权重怎样变化，y 都是 5；给所有 logits 同加一个常数也不改 softmax。它们只说明不能把一般 logits 变化自动等同输出变化，并非真实 RoPE 模型的实验反例。
回到这页：可把它理解为共享 softmax 对某些输入变化的敏感性示意。更强的 RoPE 结论需要明确机制、误差定义、假设及相应论证或范围限定的实验。未查外部文献，不断言真实 RoPE 普遍改善或普遍恶化。'''
cards=[dict(id='EXPL-001',page=2,anchor='物理2/印刷1 · 前两行数值示例；公式上下文物理1',question='为什么输出从5到7.5？',answer=a,sources=[]),dict(id='EXPL-002',page=2,anchor='物理2/印刷1 · 最后Claim句；附录上下文物理3',question='能证明RoPE在所有模型里都放大误差吗？',answer=b,sources=[])]
save('notes.json',dict(paper_sha256=H,cards=cards))
state=dict(paper=dict(title='Synthetic paper: Two logit paths',sha256=H,path=str(P),total_physical_pages=3,source_url=None,version_date=None),current_position=dict(physical_page=2,printed_page='1',anchor='Example and a claim'),user_goal='Explain5→7.5 and scope of universal RoPE claim; no full review',viewed_pages=[dict(physical_page=2,printed_page='1',purpose='requested page'),dict(physical_page=1,printed_page='i',purpose='formula context'),dict(physical_page=3,printed_page='A1',purpose='claim-scope context')],discussion_questions=[c['question'] for c in cards],explanation_card_ids=['EXPL-001','EXPL-002'],unresolved=['COMP-Q001: no RoPE/error mapping or general proof in supplied context'],glossary=dict(a='first logit path',b='second logit path',V='two scalar values',softmax='exponential shared normalization',y='scalar weighted output'),html_pages=[2],full_paper_review=False,user_comprehension='not assessed',version_policy='Hash mismatch requires relocalization and new notes; no silent reuse')
save('reading_state.json',state)
save('question_record.json',dict(id='COMP-Q001',paper_sha256=H,physical_page=2,printed_page='1',anchor='last Claim sentence',status='unsupported_from_supplied_context',question='What explicit RoPE mapping/error definition/assumptions could support the universal claim?',verification='Only if user requests further review: obtain and verify these materials; current task does not start full audit.',acceptance='Traceable scoped support or clarification that claim is only illustrative.',owner='main_ai'))
checks=[]
for z,v in [([0,0],[0,10]),([0,math.log(3)],[0,10]),([0,math.log(3)],[5,5])]:
 e=[math.exp(q) for q in z];w=[q/sum(e) for q in e];checks.append(dict(logits=z,values=v,weights=w,output=sum(x*y for x,y in zip(w,v))))
save('arithmetic_check.json',dict(type='Teaching arithmetic; no empirical experiment',assumption='natural logarithm',checks=checks))
(O/'answer.md').write_text('# 当前物理第2页（印刷第1页）\n\n'+a+'\n\n'+b+'\n\nreader.html 为离线原页与解释双栏，当前只展示物理第2页。当前位置和卡片已保存。页面没有模型后端；复制问题上下文回聊天继续。\n')
cmd=[sys.executable,'snapshot/plugins/research-assistant/skills/paper-reading-companion/scripts/build_reader.py','cases/paper-reading-companion/inputs/paper.pdf','--out',str(O/'reader.html'),'--pages','2','--notes',str(O/'notes.json')]
r=subprocess.run(cmd,capture_output=True,text=True);save('builder-result.json',dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));assert r.returncode==0
html=(O/'reader.html').read_text();data=json.loads(re.search(r'<script id="reader-data" type="application/json">(.*?)</script>',html,re.S).group(1));assert data['sha256']==H and [p['number'] for p in data['pages']]==[2] and len(data['cards'])==2
assert 'grid-template-columns' in html and '本页没有模型连接' in html and 'data:image/png;base64,' in html
save('html_validation.json',dict(status='static_pass',embedded_original_page=2,cards=2,hash_match=True,dual_column_css=True,offline_backend=False,browser_interaction_tested=False))
paths=['snapshot/config/role_registry.json','snapshot/workflows/agent_communication_workflow.md','snapshot/plugins/research-assistant/skills/paper-reading-companion/SKILL.md','snapshot/plugins/research-assistant/skills/paper-reading-companion/references/execution.md','snapshot/plugins/research-assistant/skills/paper-reading-companion/references/workflow.md','snapshot/workflows/paper_reading_companion_workflow.md','snapshot/plugins/research-assistant/skills/paper-reading-companion/references/concept_explanation_workflow.md','snapshot/plugins/research-assistant/skills/explain-research-concepts/references/execution.md','snapshot/plugins/research-assistant/skills/paper-reading-companion/scripts/build_reader.py','snapshot/plugins/research-assistant/skills/paper-reading-companion/assets/reader.html','cases/paper-reading-companion/task.txt','cases/paper-reading-companion/inputs/paper.pdf']
save('provenance.json',dict(run_id=R.name,attempt='0001',mode='offline_fallback',context='Prior context familiar; new input reading and new outputs, no copying prior files.',loaded_files=[dict(path=p,sha256=hashlib.sha256((R/p).read_bytes()).hexdigest(),coverage='full' if not p.endswith('.pdf') else 'physical2 plus necessary formula1 and Appendix3, viewed as images') for p in paths],tool_trace=['51db0f: task/skill/execution/registered workflow','361213: concept workflow/execution, complete builder/template, hash+pagecount before render','Next functions.exec: actual view_image emitted pages2,1,3; 4d75a8 read skill-local workflow','build_notes.py: actual arithmetic, hash-bound cards/current position; actual frozen build_reader subprocess and static HTML checks'],limits=['No external RoPE fact verification','No full-paper audit','No live model connection','No browser interaction performed']))
print(r.stdout)

# Verification, resolution, recheck

- REV-T001 verify ['REV-F001'], dependencies []: Recalculate rowwise baseline/candidate and check Appendix A; do not add included kernel timing.
- REV-T002 resolve ['REV-F001'], dependencies ['REV-T001']: Apply minimal evidence-supported resolution; rejected means no edit, unresolved remains blocked.
- REV-T003 recheck ['REV-F001'], dependencies ['REV-T002']: Independently read revised artifact at its new hash and assess original acceptance.
- REV-T004 verify ['REV-F002'], dependencies []: Clarify intended generalization; recover raw paired logs if available, otherwise stay descriptive.
- REV-T005 resolve ['REV-F002'], dependencies ['REV-T004']: Apply minimal evidence-supported resolution; rejected means no edit, unresolved remains blocked.
- REV-T006 recheck ['REV-F002'], dependencies ['REV-T005']: Independently read revised artifact at its new hash and assess original acceptance.

REV-F003 rejected after Appendix check; no revision needed for the alleged omission.

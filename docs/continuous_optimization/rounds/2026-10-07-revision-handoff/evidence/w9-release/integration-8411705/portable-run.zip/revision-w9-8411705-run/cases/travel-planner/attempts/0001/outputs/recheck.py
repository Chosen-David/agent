from pathlib import Path
from datetime import datetime
import json,hashlib,sys
O=Path(__file__).resolve().parent;C=O.parents[2];R=C.parents[1];S=R/'snapshot';I=C/'inputs/travel-planner'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
B=Path('/workspace/scratch/c12f3d9f92bd/revision-w9-8411705-controller/dispatch-input-bindings.json');b=json.loads(B.read_text())['cases']['travel-planner'];f=json.loads((I/'inputs/travel.json').read_text())
paths=[C/'attempts/0001/start.json',C/'task.txt',B]+sorted(p for p in I.rglob('*') if p.is_file())+[S/'plugins/travel-assistant/skills/travel-planner'/p for p in ['SKILL.md','references/execution.md','references/knowledge_access_workflow.md','references/planning_contract.md','references/workflow.md']]
before=[{'path':str(p),'sha256':sha(p)} for p in paths];checks=[]
for rev,d in [(1,20),(2,35)]:
 bundle=json.loads((I/f'prior_outputs/bundle_v{rev}.json').read_text());slots=bundle['itinerary'];x={s['slot_id']:s for s in slots};parse=datetime.fromisoformat;minutes=lambda s:(parse(s['end'])-parse(s['start'])).total_seconds()/60
 assert all(a['end']==z['start'] for a,z in zip(slots,slots[1:]))
 assert all(minutes(x['L'+str(j)])==d for j in range(1,5))
 assert minutes(x['rest'])==75 and minutes(x['lunch'])==60
 assert x['photo']['start'][11:16]=='16:00' and x['photo']['end'][11:16]=='17:00'
 assert any(a<=x['lunch']['start'][11:16] and x['Q2']['end'][11:16]<=z for a,z in f['lunch']['service_windows'])
 assert x['lunch']['start'][11:16]<=f['lunch']['last_order'] and x['L4']['end'][11:16]<='18:00'
 computed=[f['lunch']['price'][i]*2+f['photo']['price'][i]+f['commute']['each_leg_price'][i]*4 for i in [0,1]]
 assert computed==bundle['budget']['subtotal']==[520,600]
 assert [v*1.1 for v in computed]==bundle['budget']['known_total_with_contingency']==[572.0,660.0]
 assert bundle['budget']['currency'] is None and bundle['budget']['complete_trip_total'] is None
 assert len(bundle['commutes'])==4 and all(c['price']['unit']=='per_car' and c['price']['quantity']==1 and c['price']['original_unit']=='per_vehicle' for c in bundle['commutes'])
 assert next(c for c in bundle['candidates'] if c['candidate_id']=='C-B')['price']['unit']=='per_package'
 checks.append({'revision':rev,'transfer_minutes':4*d,'independent_rest_minutes':minutes(x['rest']),'lunch_start':x['lunch']['start'],'photo_start':x['photo']['start'],'return_at':x['L4']['end'],'buffer_minutes':minutes(x['END']),'budget_recalculated':computed,'known_total_plus_10percent':[v*1.1 for v in computed],'semantic_checks':'No overlap; separate service window; last order; all4 transfers; fixed photo; rest75; units and unknown budget preserved'})
old=json.loads((I/'prior_outputs/handoff.json').read_text());corpus=S/'plugins/research-assistant/skills/model-with-knowledge/assets/knowledge';assert corpus.is_dir()
ku={'task_id':b['task_id'],'input_version':b['input_version'],'status':'not_needed','knowledge_refs':[],'knowledge_demand':{'theory_method':'Finite supplied timeline inequalities and unit multiplication; no external theorem required','project_facts':'All entity, timing and price data are explicitly synthetic travel.json facts','current_external_facts':'Real business, route and weather verification is outside this synthetic-only task; unknowns retained'},'reason':'A math corpus cannot determine unspecified currency, room fees, true traffic or weather. The requested supplement only needs direct checks of two existing synthetic schedules against given windows,75-minute rest,16:00 booking and four per-vehicle fares. No corpus claim used.','corpus_root':str(corpus),'corpus_accessible':True,'queries':[],'read_entries':[],'prerequisite_checks':[],'original_task_input_version':None,'original_version_state':'absent in original-task.json','historical_handoff_input_version':old['input_version'],'old_execution_relabelled':False,'validation_artifacts':['recheck-results.json']}
save('knowledge-use.json',ku);save('recheck-results.json',{'newly_executed':True,'versions':checks,'status':'synthetic constraints satisfied','real_world_validation':False})
save('source-load-transcript.json',{'reads':before,'semantic_scope':['Original task, exact travel fixture, full historical V1/V2 Markdown','Both historical JSON bundles parsed; all time/price constraints checked','Current Skill/execution/knowledge access/planning contract and workflow task-relevant sections'],'protected_bytes_unchanged':all(sha(Path(x['path']))==x['sha256'] for x in before)})
save('provenance.json',{'run_id':R.name,'role':'travel-planner',**b,'original_task_input_version':None,'historical_handoff_input_version':old['input_version'],'knowledge_refs':[],'actual_execution':'New read-only parsing and independent time/price checks of protected prior bundles, not rerun of authoring script','limitations':['Synthetic businesses only','No network/booking/service/install','Hotel fees/currency/routes/weather remain unknown','No new itinerary or changed booking'],'next_owner':'root independent acceptance'})
print(json.dumps({'knowledge_status':'not_needed','rechecks':checks,'protected_hashes_unchanged':True},ensure_ascii=False,indent=2))

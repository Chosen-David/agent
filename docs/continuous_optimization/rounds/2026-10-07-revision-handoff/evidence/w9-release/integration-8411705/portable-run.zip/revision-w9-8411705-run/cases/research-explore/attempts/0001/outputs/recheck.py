from pathlib import Path
import csv,json,math
out=Path(__file__).resolve().parent;b=out.parents[2]/'inputs/research-explore'
rows=list(csv.DictReader((b/'inputs/measurements.csv').open()));old=json.loads((b/'prior_outputs/derived_metrics.json').read_text())['rows'];res=[]
for x,y in zip(rows,old):
 a=float(x['baseline_ms']);z=float(x['candidate_ms']);v=a/z;d=100*(z-a)/a
 assert x['workload']==y['workload'] and x['scope']==y['scope'] and math.isclose(v,y['speedup']) and math.isclose(d,y['latency_change_percent'])
 res.append({'workload':x['workload'],'speedup':v,'latency_change_percent':d,'scope':x['scope']})
assert len(rows)==len(old)==4
chain=json.loads((b/'prior_outputs/task_chain.yaml').read_text());seen=set()
for t in chain:assert set(t['depends_on'])<=seen;seen.add(t['task_id'])
assert all(x['status']=='blocked'for x in chain[1:])
print(json.dumps({'rows':res,'historical_numeric_match':True,'dag_valid':True,'future_tasks_blocked':True,'conditional_multiplicity_math':{'three_valid_marginal_failure_bounds':.05,'union_bound_at_most':3*.05,'allocation_for_total_005':.05/3,'note':'algebra only; not an estimated error rate or validation of t assumptions'},'current_data_independent_repeats':0,'new_experiments':0},indent=2))

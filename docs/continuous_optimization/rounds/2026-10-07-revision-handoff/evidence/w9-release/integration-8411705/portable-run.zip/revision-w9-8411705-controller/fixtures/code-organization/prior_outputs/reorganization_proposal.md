# ORGANIZE-001 — gated documentation proposal

New gated inputs and skill dependencies were read after dispatch. Mapping was displayed to parent /root before any organization documentation was written, using the task's explicit noninteractive authorization. Outputs have one writer /root/w9_code. Main remains sole task-index owner; no TASK.md was created or edited.

Scope: supplied organization directory, all seven files inventoried and searched for references with rg. No TASK.md, Git metadata, process logs, raw datasets or paper are supplied in that synthetic root. Do not interpret unknown process state as stopped. Names and reciprocal comments/JSON demonstrate declared association only, not producer execution or scientific result validity.

| Item | Evidence | Proposal / next owner |
|---|---|---|
| experiments/alpha.py and beta.py | active_tasks.json active_scripts, comment-only fixtures | Retain locations; main identify actual owners and execution evidence. No script execution. |
| results/beta.json | listed in running_output_paths | Protect in place; main must establish stopped state and consumers before future reorganization. |
| results/alpha.json | agrees with alpha comment, no running/stopped evidence | Keep in place; main establish lifecycle/provenance. |
| notes/orphan.txt | lacks scientific provenance, explicitly referenced by protected_files | Keep protected; ask owner for provenance. Any archive option is future proposal only, not an authorized move. |
| HIST-0 archived/missing.py | existing CODEMAP row, no corresponding supplied file | Preserve row/order and unknown values; main locate missing source or retain unresolved history. |
| synthetic-x/y labels | script comments and result input fields agree; no datasets supplied | Mark source files missing, do not fabricate or reconstruct. |

No duplication or mtime rationale justifies deletion. Whole supplied-tree reference search covers scripts, results, state and CODEMAP, but cannot rule out external consumers. New directory documentation is output-only: experiments/README.md and results/README.md are drafts for those input directories, not copied scripts/data. Each has at most ten lines. Existing layout should remain until a separately authorized, reversible migration plan addresses source/consumer gaps.

Documentation checks: all 7 supplied files registered; 2/2 declared active scripts mapped; 2/2 results mapped; source/result experiment IDs, input labels and paths agree; exact historical CODEMAP prefix preserved. No target runs, input modifications, moves or deletes. File existence is not experiment completion. Main receives the unresolved provenance, missing historical script and lifecycle questions. No scientific acceptance is asserted.

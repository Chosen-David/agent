from matplotlib.patches import FancyBboxPatch,FancyArrowPatch

def draw(ax,spec):
    ax.set(xlim=(0,10),ylim=(0,7));ax.axis('off')
    centers={'a':(1.7,5.0),'b':(1.7,3.1),'sum':(4.95,4.05),'softmax':(8.2,4.05),'v':(4.95,1.45),'output':(8.2,1.45)}
    w,h=2.6,.9
    for node in spec['nodes']:
        x,y=centers[node['id']]
        patch=FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=0.02,rounding_size=.1',fc='#eef2f5',ec='#536a80',lw=.9)
        patch.set_gid('node-'+node['id']);ax.add_patch(patch)
        ax.text(x,y,node['label'],ha='center',va='center',fontsize=8.5,color='#22384c')
    for u,v in spec['edges']:
        x,y=centers[u];xx,yy=centers[v]
        start,end=((x,y-h/2),(xx,yy+h/2)) if x==xx else ((x+w/2,y),(xx-w/2,yy))
        patch=FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=10,color='#536a80',lw=1,shrinkA=2,shrinkB=2)
        patch.set_gid('edge-'+u+'-'+v);ax.add_patch(patch)
    ax.text(0,6.6,'A  Two-path logit combination',fontsize=11,weight='bold',color='#22384c')
    ax.text(0,6.03,'Proposed schematic • not implemented',fontsize=8,color='#536a80')
    ax.text(0,.12,'Arrows: data flow. V enters only the output.',fontsize=8,color='#536a80')

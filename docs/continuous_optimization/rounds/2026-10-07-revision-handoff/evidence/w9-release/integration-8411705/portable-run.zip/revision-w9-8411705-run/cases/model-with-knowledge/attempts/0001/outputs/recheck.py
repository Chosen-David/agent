from pathlib import Path
import math,json
out=Path(__file__).resolve().parent;old=json.loads((out.parents[2]/'inputs/model-with-knowledge/prior_outputs/numeric_checks.json').read_text())
Q=2.;delta=.03;eta=Q*delta;threshold=math.sqrt(2)*eta
assert math.isclose(eta,old['eta']) and math.isclose(threshold,old['joint_l2_threshold'])
q=2.;key=[.04,0.];pert=[-.021,.021]
s=[q*x for x in key];sh=[q*(x+y)for x,y in zip(key,pert)]
assert math.hypot(*pert)<delta and s[0]>s[1] and sh[0]<sh[1]
# Similar-looking problem where fixed-query premise is false.
K=[[.075,0.],[0.,.1]];q0=[2.,0.];q1=[0.,2.]
score=lambda q:[sum(K[i][j]*q[i]for i in range(2))for j in range(2)]
s0=score(q0);s1=score(q1);dq=math.hypot(*[a-b for a,b in zip(q1,q0)]);actual_error=math.hypot(*[a-b for a,b in zip(s1,s0)])
assert math.hypot(*q0)<=Q and math.hypot(*q1)<=Q
assert math.isclose(s0[0]-s0[1],.15) and s1[0]<s1[1]
assert actual_error<=.1*dq
work=2.;speeds=[1.,2.];seconds=[work/v for v in speeds]
assert seconds==[2.,1.]
report={'kind':'derived deterministic arithmetic, not experiment','original_recheck':{'eta':eta,'conservative_threshold':2*eta,'tight_threshold':threshold,'gap_015_guaranteed':.15>threshold,'gap_008_guaranteed':.08>threshold,'admissible_flip':{'q':q,'K':key,'D':pert,'spectral_norm_D':math.hypot(*pert),'old_scores':s,'new_scores':sh},'preserving_case':'D=0','matches_historical_constants':True},'false_premise_case':{'K':K,'Khat':K,'operator_error':0.,'q':q0,'qhat':q1,'q_norm':math.hypot(*q0),'qhat_norm':math.hypot(*q1),'original_scores':s0,'new_scores':s1,'original_gap':s0[0]-s0[1],'fixed_query':False,'actual_score_error_l2':actual_error,'omitted_query_term_upper_bound':.1*dq,'conclusion':'Norm bounds on both queries do not replace fixed-query premise.'},'machine_units_check':{'work_units':work,'speed_work_units_per_s':speeds,'processing_seconds':seconds,'objective_preserved_under_allocation_swap':False},'assertions':'passed','formal_proof_run':False,'performance_measurements':0}
print(json.dumps(report,indent=2))

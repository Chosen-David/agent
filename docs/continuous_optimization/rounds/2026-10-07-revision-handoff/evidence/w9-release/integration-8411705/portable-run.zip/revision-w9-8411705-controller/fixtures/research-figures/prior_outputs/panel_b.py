import numpy as np

def draw(ax,rows):
    y=np.arange(len(rows)); colors=['#617b91','#ce8c3f']
    for key,label,prefix,color,offset in [('baseline_ms','Baseline','B',colors[0],-.17),('candidate_ms','Candidate','C',colors[1],.17)]:
        vals=[float(r[key]) for r in rows];bars=ax.barh(y+offset,vals,height=.3,color=color,label=label)
        assert [p.get_width() for p in bars]==vals
        for yy,val in zip(y+offset,vals):ax.text(val+3,yy,f'{prefix} {val:g}',va='center',fontsize=8)
    ax.set_yticks(y,[r['workload'] for r in rows]);ax.invert_yaxis();ax.set_xlim(0,260)
    ax.axhline(2.5,ls='--',lw=.8,color='#8d9ca8')
    ax.set_xlabel('Latency (ms; lower is better)',fontsize=8.5)
    ax.set_title('B  Supplied latency values',loc='left',fontsize=11,weight='bold',pad=36,color='#22384c')
    ax.text(0,1.09,'Synthetic • repeats / uncertainty not supplied',transform=ax.transAxes,fontsize=8,color='#536a80')
    ax.text(0,-.52,'Kernel: kernel-only. Other rows: end-to-end.',transform=ax.transAxes,fontsize=7.5,color='#536a80')
    ax.legend(frameon=False,ncol=2,fontsize=8,loc='lower right',bbox_to_anchor=(1,-.4))
    ax.xaxis.grid(True,color='#e6ebef');ax.set_axisbelow(True);ax.tick_params(labelsize=8,length=0)
    for side in ['top','right','left']:ax.spines[side].set_visible(False)
    ax.spines['bottom'].set_color('#8d9ca8')

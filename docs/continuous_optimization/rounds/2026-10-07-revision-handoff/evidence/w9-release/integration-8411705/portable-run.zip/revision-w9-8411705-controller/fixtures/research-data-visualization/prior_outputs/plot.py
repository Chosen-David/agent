from pathlib import Path
import csv,json,hashlib,platform,xml.etree.ElementTree as ET
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image,ImageOps
OUT=Path(__file__).resolve().parent;CASE=OUT.parents[2];ROOT=OUT.parents[4]
rows=list(csv.DictReader((CASE/'inputs/measurements.csv').open()))
assert len(rows)==len({r['workload'] for r in rows})==4
assert all(r[k] and np.isfinite(float(r[k])) for r in rows for k in ['baseline_ms','candidate_ms'])
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none','pdf.fonttype':42})
fig=plt.figure(figsize=(7,4.6)); axs=[fig.add_axes([.16,.49,.78,.33]),fig.add_axes([.16,.17,.78,.13])]
fig.text(.045,.94,'Latency by workload and timing scope',fontsize=11,weight='bold',color='#23384d')
fig.text(.045,.892,'Synthetic values • repeats and uncertainty not supplied',fontsize=8,color='#536a80')
plotted=[];handles=[]
for ax,scope,title in zip(axs,['end_to_end','kernel_only'],['End-to-end','Kernel only']):
    group=[r for r in rows if r['scope']==scope];ys=np.arange(len(group))
    for key,label,marker,color,dy in [('baseline_ms','Baseline','o','#456c88',-.16),('candidate_ms','Candidate','s','#bd742c',.16)]:
        vals=np.array([float(r[key]) for r in group]);artist=ax.scatter(vals,ys+dy,color=color,marker=marker,s=32,label=label,zorder=3)
        assert np.array_equal(np.asarray(artist.get_offsets())[:,0],vals)
        if scope=='end_to_end':handles.append(artist)
        for r,x,y in zip(group,vals,ys+dy):
            ax.annotate(f'{x:g}',(x,y),xytext=(7,0),textcoords='offset points',va='center',fontsize=9)
            plotted.append({'workload':r['workload'],'scope':scope,'method':label,'latency_ms':float(x)})
    ax.set(xlim=(0,250),ylim=(len(group)-.5,-.5));ax.set_xticks([0,50,100,150,200,250]);ax.set_yticks(ys,[r['workload'] for r in group])
    ax.set_title(title,loc='left',fontsize=9,weight='bold',pad=10);ax.tick_params(length=0,pad=7)
    ax.grid(axis='x',color='#e6ebef');ax.set_axisbelow(True)
    for side in ['top','right','left']:ax.spines[side].set_visible(False)
    ax.spines['bottom'].set_color('#97a5b1')
axs[1].set_xlabel('Latency (ms; lower is better)',labelpad=9)
fig.legend(handles=handles,frameon=False,ncol=2,loc='lower right',bbox_to_anchor=(.95,.003))
for ext in ['svg','png','pdf']:fig.savefig(OUT/f'latency.{ext}',dpi=240,facecolor='white')
plt.close(fig);ET.parse(OUT/'latency.svg')
im=Image.open(OUT/'latency.png').convert('RGB');im.resize((700,460)).save(OUT/'final_size.png');ImageOps.grayscale(im).resize((700,460)).save(OUT/'grayscale.png')
page=Image.new('RGB',(850,1100),'white');page.paste(im.resize((700,460)),(75,150));page.save(OUT/'page_preview.png')
paths=['snapshot/config/role_registry.json','snapshot/workflows/agent_communication_workflow.md','snapshot/workflows/data_visualization_workflow.md']+['snapshot/plugins/research-assistant/skills/research-data-visualization/'+p for p in ['SKILL.md','references/execution.md','references/workflow.md','references/figure_shared.md','references/data_visualization_learning.md']]+[str((CASE/p).relative_to(ROOT)) for p in ['task.txt','inputs/measurements.csv']]
manifest={'run_id':ROOT.name,'role':'research-data-visualization','route':'data_visualization','evidence_type':'synthetic','loaded_sources':[{'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()} for p in paths],'tools':{'matplotlib':matplotlib.__version__,'python':platform.python_version()},'editable_source':'plot.py','raw_rows':rows,'actual_plotted_values':plotted,'transformations':['numeric string parsing','separate provided scopes without exclusions; preserve row order within scope'],'uncertainty':{'available':False,'shown':False,'repeat_count':'unknown','independent_unit':'unknown'},'dimensions_inches':[7,4.6],'claim_type':'descriptive only'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Fresh data figure rendered. Eight scatter positions verified against four input rows; no missing input values.')

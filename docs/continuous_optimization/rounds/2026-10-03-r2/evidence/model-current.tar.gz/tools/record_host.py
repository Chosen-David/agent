import sys,datetime
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import agent_eval_pipeline as p
kind,cid,actor=sys.argv[1:4]
run=Path(sys.argv[4]) if len(sys.argv)>4 else Path(__file__).parent/'pipeline-r2-accepted'
(run/'host').mkdir(exist_ok=True)
value={'event_id':kind+':'+actor,'kind':kind,'actor':actor,'adapter':'host','case_id':cid,'attempt':1,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'actual collaboration.spawn_agent response' if kind=='start' else 'actual collaboration FINAL_ANSWER received','host_task_name':actor,'context':'fork_turns=none; shared filesystem; no provider snapshot exposed'}
if kind=='complete':value.update(status='produced',note='Delivery observed, correctness assigned only by independent reviewer. Executor tool transcript export unavailable; artifact and reviewer checks retained.')
receipt=run/'host'/(cid+'-'+kind+'.json');p.write(receipt,value)
if kind=='start':print(p.record_start(run,cid,actor,receipt))
else:
 result=p.collect(run,cid,1,receipt);print(cid,len(result['output_hashes']),'collected')

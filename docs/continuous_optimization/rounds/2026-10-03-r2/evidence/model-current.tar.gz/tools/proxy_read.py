import sys,json,hashlib,datetime
from pathlib import Path
run=Path(sys.argv[1]).resolve(); actor,label=sys.argv[2:4]; names=sys.argv[4:]
records=[]
for name in names:
    p=run/name
    assert p.resolve().is_relative_to(run) and not p.is_symlink()
    b=p.read_bytes(); records.append({'path':name,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'text':b.decode('utf-8')})
record={'actor':actor,'request':'actual collaboration send_message before task analysis','tool':'controller exec_command invoking proxy_read.py; read_bytes only, target not imported/executed','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':sys.argv,'files':records}
out=run/'host'/f'{label}.json'
with out.open('x') as f:json.dump(record,f,ensure_ascii=False,indent=2)
print(out)
for x in records:print(x['path'],x['bytes'],x['sha256'])

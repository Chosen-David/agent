"""Independent streaming reference; accepts an explicit module path for regressions."""
import importlib.util
import math
from collections import deque
from fractions import Fraction
from pathlib import Path
import random
import sys
import unittest

path = Path(sys.argv.pop(1)) if len(sys.argv) > 1 else Path(__file__).with_name("buggy.py")
spec = importlib.util.spec_from_file_location("subject", path)
subject = importlib.util.module_from_spec(spec)
spec.loader.exec_module(subject)


def reference(values, window):
    queue = deque()
    result = []
    for value in values:
        queue.append(Fraction(value))
        if len(queue) > window:
            queue.popleft()
        if len(queue) == window:
            result.append(float(sum(queue, Fraction(0)) / window))
    return result


class Correctness(unittest.TestCase):
    def verify(self, values, window, expected=None):
        before = values[:]
        actual = subject.moving_average(values, window)
        expected = reference(values, window) if expected is None else expected
        self.assertIsInstance(actual, list)
        self.assertEqual(len(actual), len(expected))
        for a, b in zip(actual, expected):
            self.assertTrue(math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12), (a, b))
        self.assertEqual(values, before, "input changed")

    def test_last_window_regression(self):
        self.verify([1, 2, 3], 2, [1.5, 2.5])

    def test_boundaries(self):
        for values, window, expected in [([], 1, []), ([7], 1, [7.0]),
                ([1, 2, 3], 1, [1.0, 2.0, 3.0]),
                ([1, 2, 3], 3, [2.0]), ([1, 2], 3, []),
                ([-3, -1, 2, 2], 2, [-2.0, .5, 2.0]),
                ([0, 0, 0], 2, [0., 0.]), ((1, 3, 5), 2, [2., 4.])]:
            with self.subTest(values=values, window=window):
                self.verify(values, window, expected)

    def test_seeded_independent_reference(self):
        rng = random.Random(20261003)
        for n in range(41):
            values = [rng.randrange(-10000, 10001) / 8 for _ in range(n)]
            for window in range(1, n + 3):
                with self.subTest(n=n, window=window):
                    self.verify(values, window)

    def test_invalid_window_and_nonmutation(self):
        for window in [0, -1, -10, 1.5, 2.0, "2", None, True, False]:
            for values in [[], [1, 2, 3]]:
                with self.subTest(window=window, values=values):
                    before = values[:]
                    with self.assertRaises(ValueError):
                        subject.moving_average(values, window)
                    self.assertEqual(values, before)


if __name__ == "__main__":
    unittest.main(verbosity=2)

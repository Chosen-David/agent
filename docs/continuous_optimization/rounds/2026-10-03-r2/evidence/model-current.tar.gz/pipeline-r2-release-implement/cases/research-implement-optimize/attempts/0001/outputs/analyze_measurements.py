"""Summarize supplied observations; this script does not benchmark code."""
import csv
import json
from pathlib import Path
import sys

source = Path(sys.argv[1])
rows = []
with source.open(newline="") as f:
    for raw in csv.DictReader(f):
        b, c = float(raw["baseline_ms"]), float(raw["candidate_ms"])
        rows.append({**raw, "speedup_baseline_over_candidate": b / c if b > 0 and c > 0 else None,
                     "latency_reduction_percent": (b-c)/b*100 if b > 0 else None})
e2e = [r for r in rows if r["scope"] == "end_to_end"]
b = sum(float(r["baseline_ms"]) for r in e2e)
c = sum(float(r["candidate_ms"]) for r in e2e)
print(json.dumps({"source": str(source), "rows": rows,
    "illustrative_one_run_each_end_to_end": {"baseline_total_ms": b,
       "candidate_total_ms": c, "speedup": b/c, "latency_reduction_percent": (b-c)/b*100},
    "caveat": "One run each is an explicit illustrative mix, not supplied production weights. No repeated samples, uncertainty, timing setup, or code-version mapping supplied."}, indent=2))

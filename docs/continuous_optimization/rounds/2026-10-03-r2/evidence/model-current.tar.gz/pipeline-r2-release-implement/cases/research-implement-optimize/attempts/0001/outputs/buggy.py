def moving_average(values, window):
    """Return all full consecutive-window means; positive integer window required.
    A window longer than the input returns []; never mutate values.

    Invalid window values (including bool) raise ValueError.
    """
    if isinstance(window, bool) or not isinstance(window, int) or window <= 0:
        raise ValueError("window must be a positive integer")
    return [sum(values[i:i + window]) / window
            for i in range(len(values) - window + 1)]

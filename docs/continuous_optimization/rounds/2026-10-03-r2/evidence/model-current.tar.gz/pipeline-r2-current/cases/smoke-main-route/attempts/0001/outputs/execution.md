# Execution record — smoke-main-route

The actual host start.json existed before worker output creation. The general orchestrator was read first; selected primary mode paper_reading, capability paper-reading-companion, with sequential explain-research-concepts. No nested agent, network, installation, or whole-paper audit was used. loaded.json records actual snapshot reads and hashes.

## Actual source/visual work
- Read host_worker.md and host_tool_proxy.md with cat, then own task.txt and pinned prompts/orchestrator.md.
- Requested exact workflows, registry, SKILL.md and execution supplements through collaboration.send_message before work. Received and read host/n01-load-1.json and n01-load-2.json in full. Requested and read bundled generator/template through host/n01-reader-source.json before running it.
- Requested page 2 render/open, received host/smoke-main-route-render.json and smoke-main-route-view.json. Parent rendered at 144 dpi with PyMuPDF 1.26.6. Worker actually opened outputs/proxy-pages/page-2.png using tools.view_image: legible full weights (1/3 each), recent weights (0,1/2,1/2), outputs8/11; draft-claim caveat visible.
- Page 2 lacked input definitions, so requested necessary adjacent page 1. Read host/smoke-main-route-page1-render.json and parent's actual visual observation; worker also opened outputs/proxy-pages/page-1.png using tools.view_image. Observed sensor values2,8,14, recent=last two, synthetic/deterministic status, no forecasting-accuracy test. Original text was preserved in reader.
- Calculated using Python fractions.Fraction on CPU: [2,8,14] ->8,11,+3; [14,8,2] ->8,5,-3; [8,8,8] ->8,8,0. Asserted R-F=(x2+x3-2*x1)/6 for these cases. An earlier temporary illustration [2,10,12] was explicitly marked illustrative pending input verification, then replaced with actual fixture values after page1 evidence; no such illustration remains in final explanation.

## Actual generation command
```sh
python -B RUN/snapshot/plugins/research-assistant/skills/paper-reading-companion/scripts/build_reader.py RUN/cases/smoke-main-route/inputs/reading_excerpt.pdf --out OUTPUTS/reader.html --pages 2 --notes OUTPUTS/notes.json
```
Here RUN=/workspace/scratch/643bcb955317/agent/.agent-runs/pipeline-r2-current and OUTPUTS=RUN/cases/smoke-main-route/attempts/0001/outputs. Exit0; rendered_pages=[2], total_pages=2, matching paper SHA-256, live_chat_backend=false. Editable sources are notes.json, reading_state.json and reader.html; generator is the pinned read-only source listed in loaded.json.

## Checks and limitations
Read embedded JSON from final HTML; asserted matching PDF hashes in notes/state/reader, page2-only selection, three cards, decodable embedded PNG, absence of external script/stylesheets. validation.json records these actual checks. Both source-page PNGs actually opened; browser interaction/layout is not claimed by this worker and is checked independently by the host after delivery. No external facts or real forecasting performance asserted. User understanding remains not_confirmed. reader.html is self-contained, copy-context workflow explicitly has no model backend, and its input drafts are not promised to survive closing. continuation.txt and reading_state.json preserve next-session context.

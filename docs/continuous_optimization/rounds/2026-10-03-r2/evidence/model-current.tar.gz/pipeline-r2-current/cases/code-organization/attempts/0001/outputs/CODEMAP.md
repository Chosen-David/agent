| Experiment | Conclusion | Script | Data | Result | Citation |
|---|---|---|---|---|---|
| HIST-0 | unknown | archived/missing.py | unknown | unknown | unknown |
| ALPHA | inconclusive | experiments/alpha.py | synthetic-x | results/alpha.json | unknown |
| BETA | rejected | experiments/beta.py | synthetic-y | results/beta.json | unknown |

表内路径相对于 inputs/organization；本交付为增量文档副本，输入文件未修改。

- HIST-0 历史行按原文原位保留；archived/missing.py 不在提供的七文件清单中，来源与结论仍为 unknown。
- ALPHA/BETA 的实验名、数据名称与结果路径来自对应脚本头部注释，并与 JSON 的 experiment/input/script 交叉核对一致；脚本仅为注释型文档夹具，未执行，不能证明结果由代码实际生成。
- synthetic-x 与 synthetic-y 仅为声明的数据名称，输入中无数据实体；生成时间、提交历史及论文引用均 unknown。结论仅抄录 JSON，不外推其科学含义。
- active_tasks.json 列出两项活跃脚本，已覆盖 2/2（100%）；results/beta.json 是活动输出路径，当前读到的 rejected 是快照值，未来可能变化。
- notes/orphan.txt 在 active_tasks.json 的 protected_files 中：有保护性引用，不能称为完全无引用文件；其内容声明缺乏实验来源。
- 只读来源证据：代理原始记录为运行根目录 host/n08-inventory.json，记录七个文件原文与 SHA256。

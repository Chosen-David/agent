# Execution account

- Scope: own `task.txt` and `inputs/concept.txt`; pinned explain-research-concepts entry, execution supplement and full workflow only. Snapshot hashes and input hashes are in `loaded.json`.
- Observed `attempts/0001/start.json` present before creating `outputs/`; no host receipt created or changed.
- Selected minimal workflow: provided-model derivation plus Python standard-library CPU arithmetic/finite differences. No additional skills, downloads, network, GPU, or nested agents.
- Read command: `cat` on the task, entry, execution supplement, workflow, and concept input; own case paths enumerated with `rg --files`.
- Before model execution, ran `python -B` to save actual read paths, SHA-256 hashes, scope and UTC observation time in `loaded.json`.
- Wrote editable `verify.py`, then ran exactly:
  `python -B agent/.agent-runs/pipeline-r2-current/cases/explain-research-concepts/attempts/0001/outputs/verify.py > agent/.agent-runs/pipeline-r2-current/cases/explain-research-concepts/attempts/0001/outputs/verification.json`
- Observed successful exit, all assertions passed: initial output 5; perturbed output 7.5; change 2.5. Analytic Jacobian [-2.5, 2.5]; central finite differences [-2.500000000349445, 2.500000000349445] at h=1e-6. Linear prediction 2.7465307216702746 is explicitly distinguished from exact change. Common shift and opposing path errors both yielded 5.
- `answer.md` gives the requested Chinese answer, dimensions, derivative, finite-perturbation limit, exact invariance conditions and real-model limitations.
- No paper was provided, read, or claimed as evidence. No visual artifact was necessary for this two-element algebraic example. This is an executor report, not independent evaluation.

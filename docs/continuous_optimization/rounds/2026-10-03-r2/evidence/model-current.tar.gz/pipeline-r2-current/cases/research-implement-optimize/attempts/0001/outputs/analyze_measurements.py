"""Descriptive arithmetic only: does not execute performance workloads."""
import csv
import json
from pathlib import Path
import sys

rows = []
with Path(sys.argv[1]).open(newline="") as handle:
    for row in csv.DictReader(handle):
        b, c = float(row["baseline_ms"]), float(row["candidate_ms"])
        rows.append(dict(row, speedup=b / c if c > 0 else None,
                         latency_reduction=(b - c) / b if b > 0 else None))
print(json.dumps(rows, indent=2))

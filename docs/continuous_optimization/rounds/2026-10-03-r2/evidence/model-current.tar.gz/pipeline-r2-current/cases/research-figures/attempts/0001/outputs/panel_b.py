from style import *
import csv
from pathlib import Path

def draw(ax, rows):
    ax.text(-.02,1.12,"B",fontsize=15,fontweight="bold",transform=ax.transAxes)
    ax.text(.055,1.12,"Latency by workload",fontsize=12,fontweight="bold",transform=ax.transAxes)
    ax.text(-.02,1.045,"Synthetic values • lower is better",fontsize=9,color="#637080",transform=ax.transAxes)
    ys=[3,2,1,-.3]
    for i,row in enumerate(rows):
        for off,col,color,label,hatch in [(.16,"baseline_ms",BLUE,"Baseline",""),(-.16,"candidate_ms",ORANGE,"Candidate","///")]:
            val=float(row[col]); ax.barh(ys[i]+off,val,height=.27,color=color,label=label if i==0 else None,hatch=hatch,edgecolor="white",linewidth=.5)
            ax.text(val+4,ys[i]+off,f"{val:g}",va="center",fontsize=9)
    ax.set_yticks(ys,[r["workload"].capitalize() for r in rows]); ax.set_xlim(0,250); ax.set_ylim(-.85,3.9)
    ax.set_xticks([0,50,100,150,200,250]); ax.set_xlabel("Latency (ms)",labelpad=6)
    ax.axhline(.35,color="#A5ADB6",ls="--",lw=.8)
    ax.text(247,3.65,"END-TO-END",ha="right",fontsize=8,color="#637080")
    ax.text(247,.05,"KERNEL ONLY",ha="right",fontsize=8,color="#637080")
    ax.grid(axis="x",color="#E5E8EC",lw=.65); ax.set_axisbelow(True)
    ax.spines["left"].set_visible(False); ax.spines["bottom"].set_color("#A5ADB6"); ax.tick_params(axis="y",length=0)
    ax.legend(loc="lower left",bbox_to_anchor=(0,-.30),frameon=False,ncol=2,fontsize=9)
if __name__=="__main__":
    root=Path(__file__).resolve().parent
    fig,ax=plt.subplots(figsize=(6,4.5)); fig.subplots_adjust(left=.14,right=.96,bottom=.23,top=.80)
    draw(ax,list(csv.DictReader((root/"measurements.csv").open())))
    for ext in ["svg","png"]:fig.savefig(root/("panel_b."+ext),dpi=200,facecolor="white")

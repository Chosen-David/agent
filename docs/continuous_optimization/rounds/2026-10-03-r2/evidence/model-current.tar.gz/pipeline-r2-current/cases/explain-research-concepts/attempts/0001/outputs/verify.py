"""CPU-only verification of the supplied teaching model; Python standard library."""
import json
import math

def softmax(z):
    m = max(z)
    e = [math.exp(x-m) for x in z]
    return [x / sum(e) for x in e]

def output(a, b, v):
    return sum(p*x for p,x in zip(softmax([x+y for x,y in zip(a,b)]),v))

a = [0.0, 0.0]
b = [0.0, 0.0]
v = [0.0, 10.0]
q = [0.0, math.log(3.0)]
y0 = output(a,b,v)
y1 = output(a,q,v)
p = softmax(a)
jacobian = [pi*(vi-y0) for pi,vi in zip(p,v)]
h = 1e-6
finite_difference = []
for j in range(2):
    plus, minus = b.copy(), b.copy()
    plus[j] += h
    minus[j] -= h
    finite_difference.append((output(a,plus,v)-output(a,minus,v))/(2*h))
assert abs(y0-5.0) < 1e-12
assert abs(y1-7.5) < 1e-12
assert max(abs(x-y) for x,y in zip(jacobian,finite_difference)) < 1e-8
shift_output = output(a,[2.0,2.0],v)
cancel_output = output([0.0,-math.log(3.0)],q,v)
assert abs(shift_output-y0) < 1e-12
assert abs(cancel_output-y0) < 1e-12
print(json.dumps({
    "model": "supplied teaching example, not paper measurements",
    "probabilities_before": softmax(b),
    "probabilities_after": softmax(q),
    "output_before": y0,
    "output_after": y1,
    "actual_change": y1-y0,
    "analytic_jacobian_wrt_either_path": jacobian,
    "central_finite_difference_h": h,
    "central_finite_difference_jacobian": finite_difference,
    "local_linear_predicted_change": sum(x*y for x,y in zip(jacobian,q)),
    "common_shift_output": shift_output,
    "opposite_path_errors_output": cancel_output,
    "assertions": "all passed"
},ensure_ascii=False,indent=2))

# experiments
源目录含 alpha.py、beta.py 两个活跃实验的注释型文档夹具，禁止执行。
文件名与 results 中的同名 JSON 对应；实验标识使用 ALPHA/BETA。
数据源名称仅由注释声明，实际数据文件与执行历史未知。
参阅 [CODEMAP](../CODEMAP.md)。

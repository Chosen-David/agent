# results
源目录保存 alpha.json、beta.json 两个结果记录，按实验脚本同名命名。
experiment/input/script 字段可与对应脚本头部交叉核对，不代表已验证执行来源。
beta.json 是 active_tasks.json 声明的运行中输出路径，不移动、不重命名。
参阅 [CODEMAP](../CODEMAP.md)。

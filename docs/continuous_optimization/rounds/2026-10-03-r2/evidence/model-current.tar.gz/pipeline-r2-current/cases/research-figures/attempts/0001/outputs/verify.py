from pathlib import Path
import json,csv,hashlib,xml.etree.ElementTree as ET
from style import *
import panel_a,panel_b
from matplotlib.patches import FancyArrowPatch,FancyBboxPatch
root=Path(__file__).resolve().parent
arch=json.loads((root/"architecture.json").read_text()); rows=list(csv.DictReader((root/"measurements.csv").open()))
fig,(a,b)=plt.subplots(1,2)
panel_a.draw(a,arch);panel_b.draw(b,rows)
assert sum(isinstance(p,FancyBboxPatch) for p in a.patches)==len(arch["nodes"])==6
assert sum(isinstance(p,FancyArrowPatch) for p in a.patches)==len(arch["edges"])==5
actual=[p.get_width() for p in b.patches]
expected=[float(row[k]) for row in rows for k in ["baseline_ms","candidate_ms"]]
assert actual==expected
assert b.get_xlim()[0]==0
svg_checks={}
for name in ["panel_a.svg","panel_b.svg","combined.svg"]:
 tree=ET.parse(root/name);ids=[x.attrib["id"] for x in tree.iter() if "id" in x.attrib]
 assert len(ids)==len(set(ids))
 assert not any(x.tag.endswith("}image") for x in tree.iter())
 assert any(x.tag.endswith("}text") for x in tree.iter())
 svg_checks[name]={"valid_xml":True,"unique_ids":True,"editable_text":True,"no_raster_embedding":True}
report={"nodes":6,"edges":5,"plotted_values_ms":actual,"source_values_ms":expected,"equal_values":True,"zero_based_latency_axis":True,"source_sha256":{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ["architecture.json","measurements.csv"]},"svg_checks":svg_checks,"matplotlib_version":__import__("matplotlib").__version__}
(root/"checks.json").write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

# 主张—证据表

材料性质：合成示例；证据版本见 `computed_metrics.json` 中输入 SHA-256。CSV 行号包含表头。加速比为 baseline/candidate；延迟变化率为 (candidate−baseline)/baseline×100%，负值表示降低。正文与摘要使用相同计算口径，百分数保留一位、加速比保留两位。

| 主张 ID | 主张及证据 ID | 来源位置 | 支持范围与限制 |
| --- | --- | --- | --- |
| WRITE-C001 | small：100→80 ms；降低 20.0%；1.25×（WRITE-E001） | measurements.csv:2 | 支持该端到端单次记录的描述性比较 |
| WRITE-C002 | medium：120→100 ms；降低 16.7%；1.20×（WRITE-E002） | measurements.csv:3 | 支持该端到端单次记录的描述性比较 |
| WRITE-C003 | large：200→220 ms；增加 10.0%；0.91×（WRITE-E003、WRITE-E006） | measurements.csv:4；manuscript.md Appendix A | 明确退化；不能称无退化 |
| WRITE-C004 | kernel：20→10 ms；降低 50.0%；2.00×（WRITE-E004、WRITE-E005） | measurements.csv:5；manuscript.md Results | 仅内核级；已含于端到端路径，禁止相加或外推为端到端收益 |
| WRITE-C005 | 无独立重复、未测质量和 GPU（WRITE-E005、WRITE-E006） | manuscript.md Method、Results、Appendix A | 不能判断方差、显著性、质量保持、GPU 性能或普遍收益 |
| WRITE-C006 | 原摘要的所有工作负载 2× 端到端加速且无退化不成立（WRITE-E001–004） | manuscript.md Abstract；measurements.csv:2–5 | 原主张已删除并改写；large 为直接反证，2× 只属于内核计时 |

未提供退化原因的证据，稿件不作机制归因；未添加文献或实验。可编辑机器可读底账见 `claim_evidence_ledger.yaml`（JSON 兼容 YAML）。

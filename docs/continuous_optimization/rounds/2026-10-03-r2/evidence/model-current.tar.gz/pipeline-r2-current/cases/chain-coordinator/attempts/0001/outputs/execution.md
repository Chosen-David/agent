# 执行与交接记录

本节点按固定快照的 research-assistant 入口及 loaded.json 中已读取的参考文件执行，仅分析提供的 synthetic-v3 合成值。已先确认本次 start.json 存在，再创建 outputs。没有读取评分材料、其他 case 或历史运行产物，没有联网、安装运行时、GPU、新 benchmark、嵌套 Agent 或监督器部署。

实际 CPU 命令由宿主代理应本节点的 send_message 请求执行：

```bash
python -B .agent-runs/pipeline-r2-current/cases/chain-coordinator/attempts/0001/outputs/analyze.py
```

宿主在当前工作过程中执行并返回 exit_code=0，原始 stdout 保存在 `/workspace/scratch/643bcb955317/agent/.agent-runs/pipeline-r2-current/host/n04-analysis-execution.json`。本节点在收到结果后实际读取了该记录，并读取 aggregate.csv 和 cpu_results.json。它是本次真实执行的代理记录，不是之后的回放；不声称其提供 OS 隔离证明。

Python 3.12.14，Linux x86_64，标准库 csv、statistics、fractions、hashlib。18 行全部纳入，3 个工作负载，每版本各 3 行；检查版本、端到端 scope、正延迟、重复键及 repeat={1,2,3}。没有排除数据或补值。Fraction 保留算术精确值，CSV 写出浮点表示：

| workload | baseline 中位 ms | candidate 中位 ms | speedup | 延迟降幅 |
|---|---:|---:|---:|---:|
| small | 32 | 24 | 4/3 | 25% |
| medium | 56 | 58 | 28/29 | -25/7% |
| large | 96 | 80 | 6/5 | 50/3% |

medium 的候选延迟上升约 3.57%，不能称为加速。全部行低于旧文所称的至少 1.8x。WRITE-OLD 因数据版本更换及数值矛盾失效；BACKGROUND-1 仅保留与延迟无关的 baseline/candidate 定义适用范围。历史背景原文未提供，不能把项目中的 complete 标记当成本轮读过并验收的历史文件。另设 RETAIN-CHECK-1 完成适用性检查，写作节点不依赖 skipped 历史执行。

交付后的 Python 只读核验实际执行：重新计算 3 个输入哈希及 aggregate.csv、analysis.json 哈希；对照宿主原始 stdout；检查所需字段和类型、CSV 列顺序、样本量和逐行公式，浮点相对容差 1e-14；检查任务依赖存在且无环。结果存于 handoff_validation.json。验证后未修改 analysis.json 或 aggregate.csv。

aggregate.csv SHA256：`ecdd7ddb5671baf99449eba1336b559f40a3fef08fe3b785cd60a85d0557cb7b`

analysis.json SHA256：`1ae4b8e86c83a75879e8b6a64a22703df7c2e38274ec16c9cead5dd00853537f`

输入 SHA256 逐一保存在 analysis.json 的 source_files；精确算术结果及实际环境在 cpu_results.json。分析只支持这些合成值的描述性比较，不支持显著性、真实硬件加速、质量保持、机制归因或普遍优越性。没有图或 PDF 交付，因此视觉检查不适用。

当前已验证能力是宿主前台 CPU 执行及文件读写。没有当前链 scheduler ready/create/readback 证据；未启动 monitor，没有 monitor ID，未部署常驻后台服务。外部运行时是否安装未探测，不能称可用。task_chain.json 是静态交接 DAG，不冒充 SQLite 执行状态或后台监控。

下一位写作者应接收 analysis.json 与 aggregate.csv 原字节，先核对 aggregate 哈希。文件缺失或哈希不符时阻塞写作。写作者负责中文 Results 段落与英文摘要；本节点未代写，也未完成独立审稿。

def moving_average(values, window):
    """Return all full consecutive-window means; positive integer window required.
    A window longer than the input returns []; never mutate values.

    Non-integer windows (including bool) raise TypeError; nonpositive integers
    raise ValueError. Values must support len(), slicing, sum(), and division.
    """
    if isinstance(window, bool) or not isinstance(window, int):
        raise TypeError("window must be a positive integer")
    if window <= 0:
        raise ValueError("window must be positive")
    return [sum(values[i:i + window]) / window
            for i in range(len(values) - window + 1)]

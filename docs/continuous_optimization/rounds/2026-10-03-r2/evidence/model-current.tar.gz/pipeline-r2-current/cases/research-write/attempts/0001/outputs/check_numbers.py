from pathlib import Path
import csv, hashlib, json, math
root = Path(__file__).resolve().parent
inputs = root.parents[2] / 'inputs'
computed = json.loads((root / 'computed_metrics.json').read_text())
source = list(csv.DictReader((inputs / 'measurements.csv').open()))
assert len(source) == len(computed['rows']) == 4
for name, digest in computed['input_sha256'].items():
    assert hashlib.sha256((inputs / name).read_bytes()).hexdigest() == digest
for raw, derived in zip(source, computed['rows']):
    b, c = float(raw['baseline_ms']), float(raw['candidate_ms'])
    assert derived['workload'] == raw['workload']
    assert derived['scope'] == raw['scope']
    assert math.isclose(derived['speedup'], b / c)
    assert math.isclose(derived['latency_change_percent'], (c / b - 1) * 100)
expected = {'small': (1.25, -20), 'medium': (1.2, -100 / 6), 'large': (10 / 11, 10), 'kernel': (2, -50)}
for row in computed['rows']:
    speed, delta = expected[row['workload']]
    assert math.isclose(row['speedup'], speed)
    assert math.isclose(row['latency_change_percent'], delta)
zh = (root / 'results_zh.md').read_text()
en = (root / 'abstract_en.md').read_text()
for token in ['20.0%', '16.7%', '10.0%', '1.25', '1.20', '0.91', '2.00']:
    assert token in zh and token in en, token
ledger = json.loads((root / 'claim_evidence_ledger.yaml').read_text())
assert len(ledger['claims']) == 6
assert ledger['claims'][-1]['status'] == 'unsupported'
print('Verified 4 CSV rows, source hashes, speedup and latency-change calculations, shared rounded numbers in Chinese and English, and 6 claim ledger entries.')
print('Limits: text token checks supplement manual semantic review; no statistical tests, new experiments, PDF generation, or independent review were performed.')

"""Independent exact-rational oracle; deterministic, bounded CPU checks."""
import argparse
import copy
from fractions import Fraction
import importlib.util
import json
import math
from pathlib import Path
import random
import sys


def reference(values, window):
    # Build a complete trailing window by visiting each endpoint; no slicing
    # or shared loop bounds with the implementation under test.
    result = []
    for end, _ in enumerate(values):
        if end + 1 >= window:
            total = Fraction(0)
            for distance in range(window):
                total += Fraction(values[end - distance])
            result.append(float(total / window))
    return result


def run(target):
    spec = importlib.util.spec_from_file_location("subject", target)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    f = module.moving_average
    failures = []
    count = 0
    cases = [([], 1), ([], 5), ([7], 1), ([7], 2),
             ([1, 2, 3], 1), ([1, 2, 3], 2), ([1, 2, 3], 3),
             ([1, 2, 3], 4), ([-5, 0, 5, 10], 2),
             ([0.25, -0.5, 1.25, 2.0], 3), ([0] * 6, 3)]
    rng = random.Random(1947)
    for n in range(33):
        values = [rng.randint(-10000, 10000) for _ in range(n)]
        cases.extend((values, w) for w in range(1, n + 3))
    for values, w in cases:
        for container in (list, tuple):
            x = container(values)
            before = copy.deepcopy(x)
            expected = reference(x, w)
            count += 1
            try:
                got = f(x, w)
                assert isinstance(got, list), "output must be list"
                assert len(got) == len(expected), (got, expected)
                assert all(math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12)
                           for a, b in zip(got, expected)), (got, expected)
                assert x == before, "input was mutated"
                assert got is not x, "output aliases input"
            except Exception as exc:
                failures.append({"case": repr((x, w)), "error": repr(exc)})
    for w, exception in [(0, ValueError), (-1, ValueError), (-100, ValueError),
                         (1.0, TypeError), (2.5, TypeError), ("2", TypeError),
                         (None, TypeError), (True, TypeError), (False, TypeError)]:
        for values in ([], [1, 2, 3]):
            before = values.copy()
            count += 1
            try:
                f(values, w)
            except exception:
                if values != before:
                    failures.append({"case": repr((before, w)), "error": "mutated input"})
            except Exception as exc:
                failures.append({"case": repr((values, w)), "error": repr(exc)})
            else:
                failures.append({"case": repr((values, w)), "error": "missing exception"})
    return {"target": str(target.resolve()), "seed": 1947,
            "oracle": "Fraction endpoint enumeration", "checks": count,
            "failures": len(failures), "examples": failures[:8]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", type=Path, default=Path(__file__).with_name("buggy.py"))
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()
    result = run(args.target)
    rendered = json.dumps(result, indent=2) + "\n"
    if args.json_output:
        args.json_output.write_text(rendered)
    print(rendered, end="")
    sys.exit(bool(result["failures"]))

# 核验—处理—复查任务链

当前作者稿件未修改。REV-F001、REV-F002 的材料内核验已完成，尚未解决；REV-F003、REV-F004 已驳回，未改稿且无需修复。

| 发现 | 核验 | 处理 | 复查 | 最先可执行动作 |
|---|---|---|---|---|
| REV-F001 | REV-T001 done | REV-T002 todo | REV-T003 todo | 主 AI 在授权修稿时限定摘要的数值与范围 |
| REV-F002 | REV-T004 done | REV-T005 todo | REV-T006 todo | 主 AI 将结论限为单次探索性观测；无需当前运行新实验 |
| REV-F003 | REV-T007 done | REV-T008 skipped | REV-T009 done | 附录反证已足够，保持 rejected |
| REV-F004 | REV-T010 done | REV-T011 skipped | REV-T012 done | Results L8 反证已足够，保持 rejected |

依赖均为每行 verify → resolve → recheck；精确动作、关闭条件、缺输入处置见 task_chain.yaml。后续若修改输入，先生成新快照，再由审阅角色对照原 ID 复查。建议不构成当前代理修改原稿或执行新实验的授权。

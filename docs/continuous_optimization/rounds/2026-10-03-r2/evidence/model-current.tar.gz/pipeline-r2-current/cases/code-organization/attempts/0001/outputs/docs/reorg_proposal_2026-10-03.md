# 重组提案（2026-10-03，仅提案）

范围为 inputs/organization 全部七个提供的文件。映射已在写文档前向主控制器展示，主控制器已审阅。所有输入保持不变；无脚本执行、导入、移动、重命名或删除。

## 引用证据

父控制器通过只读全文固定字符串搜索，逐行计数全部七文件；这相当于固定字符串 grep 检索，实际实现为 read_text 与字符串计数。下表不包含此次新增输出文档，也不覆盖输入树外的未知调用者。

| 字符串 | 出现次数 | 位置 |
|---|---:|---|
| `experiments/alpha.py` | 2 | active_tasks.json:1（1次）；results/alpha.json:1（1次） |
| `experiments/beta.py` | 2 | active_tasks.json:1（1次）；results/beta.json:1（1次） |
| `results/alpha.json` | 1 | experiments/alpha.py:1（1次） |
| `results/beta.json` | 2 | active_tasks.json:1（1次）；experiments/beta.py:1（1次） |
| `notes/orphan.txt` | 1 | active_tasks.json:1（1次） |
| `archived/missing.py` | 1 | CODEMAP.md:3（1次） |

原始全文/hash 记录：运行根目录 `host/n08-inventory.json`；引用及复查 hash 记录：`host/n08-reference-search.json`。两次记录中的七文件 SHA256 一致。

## 建议、风险与回滚

| 对象 | 分类与证据 | 建议动作 | 风险及回滚 |
|---|---|---|---|
| experiments/alpha.py 与 results/alpha.json | 活跃脚本；JSON声明脚本来源，注释与JSON对应一致 | 保留原位并补充生成过程证据；本轮仅新增映射 | 当前文件为文档夹具，不能假定可重跑；无源文件改动，无需回滚 |
| experiments/beta.py 与 results/beta.json | 活跃脚本；结果路径另有运行中保护标记 | 保留路径；运行结束且调用方明确授权前不重组 | 移动会中断活动输出写入；本轮无改动，无需回滚 |
| notes/orphan.txt | 来源不明的历史笔记；全文路径引用1次，来自 protected_files；脚本/结果中的路径引用0次 | 标记“受保护、实验来源 unknown”；补充作者/实验关联证据后再审阅，不提自动归档或删除 | 文件名不能证明孤儿身份；受保护内容不可改；本轮无改动，无需回滚 |
| archived/missing.py（HIST-0） | 仅历史CODEMAP引用1次；实际文件不在输入清单 | 保留历史行及unknown；请求补充历史来源或归档清单 | 不存在目标不能移动、删除或推断已废弃；文档副本可撤回，原历史不变 |
| alpha.py 与 beta.py | 注释结构近似，但实验标识、数据名与结果不同 | 无证据认定重复实现，不选“最新版”、不合并 | 未提供git历史或实现内容，贸然合并会混淆独立实验 |

命名核验：两个实验均是 `experiments/<name>.py` → `results/<name>.json`，标识 ALPHA/BETA 与文件名大小写属于可解释的命名约定；当前无已证实命名漂移。提供范围内没有无结果配对的活跃脚本，也没有无声明脚本来源的 JSON；这仅证明文档关联一致，不证明实际生成 provenance。

## 待拍板与后续条件

1. 是否补充 HIST-0 的脚本/数据来源及论文引用；当前保持 unknown。
2. 是否请笔记作者补充 orphan.txt 的实验归属；保持 protected_files 保护。
3. 是否补充真实生成日志、提交、数据实体与时间戳；当前结果仅作快照记载。

本轮没有可执行移动/删除项。未来若提出重组，先确认活动任务已停止、保护约束已明确解决，检查全部下游引用及后台/接力日志，并获得针对具体动作的授权。输入未提供 git 元数据、后台日志、nohup或接力脚本，不能推断不存在外部运行者；active_tasks.json 是本次唯一活动路径证据。若未来在git内执行，经授权后按逻辑组 git mv 并提交，回滚使用实际提交的 git revert；没有git时先完整快照，并从快照恢复。删除始终单独交由用户决定。本轮不运行目标的 --help 或干跑。

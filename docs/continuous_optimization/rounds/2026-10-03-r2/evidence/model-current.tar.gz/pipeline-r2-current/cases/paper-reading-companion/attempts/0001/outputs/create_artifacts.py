from pathlib import Path
import hashlib,json,math,datetime,subprocess,re
OUT=Path(__file__).resolve().parent
CASE=OUT.parents[2]
RUN=CASE.parents[1]
PDF=CASE/'inputs/paper.pdf'
sha=hashlib.sha256(PDF.read_bytes()).hexdigest()
answer='''短回答：输出从 5 变为 7.5，是因为值 10 的权重从 1/2 变为 3/4；这不能证明 RoPE 在所有模型里都放大误差。

原文定位：物理第 1 页（印刷 i），y = softmax(a + b) V，两条路径共同决定同一组归一化权重。物理第 2 页（印刷 1）给出数值例子和待判断的普遍断言。

验算／本次推导：a、b 都是两个 logit 组成的向量，V 是两个标量值 (0, 10)，输出 y 是标量。固定 a=(0,0) 和 V=(0,10)，只改 b 的第二项。softmax 对相加后的每项取指数，再除以指数总和。这里 log(3) 按自然对数理解，才能得到原文的 7.5。
初始 a+b=(0,0)，指数为 (1,1)，权重为 (1/2,1/2)，y=(1/2)×0+(1/2)×10=5。
改变后 a+b=(0,ln 3)，指数为 (1,3)，权重为 (1/4,3/4)，y=(1/4)×0+(3/4)×10=7.5。
所以 Δy=2.5。两条路径不是各自产生输出后相加；即使 a 没变，b 也会通过共同分母改变整组权重。

结论边界：物理第 3 页（印刷 A1，Appendix: scope）明确写这是虚构教学例子，不是实验证据，也没有研究任何 RoPE 专属模型、数据或实验。因此第 2 页“这证明所有真实模型里 RoPE 都放大误差”的断言不受材料支持。
本例甚至没有定义真值或误差指标。输出增大不等于误差增大：例如以目标 10 为参照，绝对误差从 5 降到 2.5；以目标 0 为参照则从 5 增到 7.5（这是本次补充教学反例，不是论文实验）。此外，Δy 与 logit 改变量不是已定义的同一误差尺度。

更小的边界例子／本次推导：给 b 两项同加 c，会因 softmax 的共同因子 exp(c) 抵消而保持权重和输出不变。这只说明本算子的变化依赖扰动方向，不能冒充真实 RoPE 模型的反例。

现在可将原段读作：这个特定的 logit 改动把更大权重分给值 10，展示共同归一化的作用；不能把它读作 RoPE 的普遍误差定理。若要讨论真实 RoPE，仍需其具体映射、误差定义、条件与相应证明或实验证据；本次未做外部检索或全篇审稿。'''
notes={'paper_sha256':sha,'cards':[{'id':'EXPL-001','page':2,'anchor':'Example and a claim；数值例子与 RoPE 普遍断言','question':'输出为何从5到7.5，以及这能证明RoPE在所有模型里都放大误差吗？','answer':answer,'sources':[],'source_locations':[{'kind':'provided_pdf','physical_page':1,'printed_page':'i','anchor':'y = softmax(a + b) V'}, {'kind':'provided_pdf','physical_page':2,'printed_page':'1','anchor':'Example and a claim'}, {'kind':'provided_pdf','physical_page':3,'printed_page':'A1','anchor':'Appendix: scope'}],'external_background_verified':False,'unresolved':['未提供 RoPE 具体模型及误差定义，不能判断真实模型中的误差效应。']}]}
(OUT/'notes.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2))
(OUT/'explanation.md').write_text(answer+'\n',encoding='utf8')
state={'paper':{'title':'Synthetic paper: Two logit paths','source':str(PDF),'sha256':sha,'total_physical_pages':3,'version':'Provided local synthetic PDF; metadata has no author/date/version','printed_page_map':{'1':'i','2':'1','3':'A1'}},'current_physical_page':2,'current_printed_page':'1','anchor':'Example and a claim','user_goal':notes['cards'][0]['question'],'visually_viewed_pages':[1,2,3],'discussed_pages':[2],'context_pages':[1,3],'rendered_pages':[1,2,3],'user_understanding':'not_assessed','explanation_card_ids':['EXPL-001'],'open_questions':notes['cards'][0]['unresolved'],'glossary':{'a,b':'两条 logit 路径的长度为 2 的向量；相加后统一归一化','V':'两个标量值 (0,10)','y':'softmax 权重对 V 加权所得标量','log(3)':'为匹配给定结果按自然对数 ln 3 解释'},'scope':'Focused explanation, not full-paper review','updated_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT/'reading_state.json').write_text(json.dumps(state,ensure_ascii=False,indent=2))
def calc(b):
 e=[math.exp(x) for x in b];w=[x/sum(e) for x in e];return {'b':b,'weights':w,'y':sum(x*v for x,v in zip(w,[0,10]))}
checks={'baseline':calc([0,0]),'changed':calc([0,math.log(3)]),'common_shift':calc([2,2]),'absolute_error_if_target_10':[5,2.5]}
assert abs(checks['baseline']['y']-5)<1e-12
assert abs(checks['changed']['y']-7.5)<1e-12
assert abs(checks['common_shift']['y']-5)<1e-12
(OUT/'cpu_checks.json').write_text(json.dumps(checks,indent=2))
cmd=['python','-B',str(RUN/'snapshot/plugins/research-assistant/skills/paper-reading-companion/scripts/build_reader.py'),str(PDF),'--out',str(OUT/'paper.html'),'--pages','1-3','--notes',str(OUT/'notes.json')]
r=subprocess.run(cmd,text=True,capture_output=True,check=True)
(OUT/'build_output.json').write_text(r.stdout)
p=OUT/'paper.html';s=p.read_text();match=re.search(r'(<script id="reader-data" type="application/json">)(.*?)(</script>)',s,re.S)
d=json.loads(match.group(2));d['title']='Synthetic paper: Two logit paths'
for page in d['pages']: page['label']={1:'i',2:'1',3:'A1'}[page['number']]
encoded=json.dumps(d,ensure_ascii=False).replace('&','\\u0026').replace('<','\\u003c').replace('>','\\u003e')
s=s[:match.start(2)]+encoded+s[match.end(2):]
s=s.replace('let index=0,zoom=100,textMode=false;','let index=data.pages.findIndex(p=>p.number===2),zoom=100,textMode=false;')
s=s.replace('<title>paper.pdf · 论文伴读</title>','<title>Synthetic paper: Two logit paths · 论文伴读</title>')
p.write_text(s)
print(json.dumps({'files':[p.name for p in OUT.iterdir()],'checks':checks,'default_page':2},ensure_ascii=False))

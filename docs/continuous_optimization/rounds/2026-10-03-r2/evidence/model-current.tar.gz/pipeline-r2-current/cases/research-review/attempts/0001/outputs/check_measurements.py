"""Recompute supplied measurements; no new benchmark or experimental run."""
import csv, json, hashlib, pathlib, datetime
root = pathlib.Path(__file__).resolve().parent
inputs = root.parents[2] / 'inputs'
rows = list(csv.DictReader((inputs/'measurements.csv').open()))
results=[]
for row in rows:
    b,c = float(row['baseline_ms']),float(row['candidate_ms'])
    results.append(dict(row, baseline_ms=b,candidate_ms=c,speedup=b/c,latency_change_percent=100*(c-b)/b,meets_2x=b/c>=2,regression=c>b))
evidence={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_versions':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [inputs/'manuscript.md',inputs/'measurements.csv']},'rows':results,'all_end_to_end_2x':all(x['meets_2x'] for x in results if x['scope']=='end_to_end'),'end_to_end_regressions':[x['workload'] for x in results if x['scope']=='end_to_end' and x['regression']],'scope_rule':'kernel_only is already included in end-to-end paths; no timings added','operation':'arithmetic over existing CSV; no new measurements'}
(root/'measurement_check.json').write_text(json.dumps(evidence,indent=2)+'\n')
print(json.dumps(evidence,indent=2))

# 逐贡献价值矩阵（本地材料边界）

| 主张 / 位置 | 材料内对照与公平性 | 可行性 / 必要性 | 收益与代价 | 状态 / 下一步 |
|---|---|---|---|---|
| C1：替换选定 kernel，L6 | baseline 未命名；同 CPU 进程、输入；实现、配置和调优预算未知 | CSV 有 kernel 20→10 ms 观测；无代码可核验机制；组件必要性无消融证据 | 单次 kernel 2x；质量、复杂度、能耗等未知 | insufficient_evidence（机制和增量价值）；保持局部观测，不判断创新性 |
| C2：每个 workload 端到端 2x 且无退化，L4 | 与自身 CSV 可直接比较；无需引入外部基线反驳 | 全部端到端点估计未达 2x；large 退化 | small/medium 单次改善，large +10% 延迟；无方差 | 本地主张已被证据反驳，见 REV-F001；缩小范围并复查 |

最接近工作、发布日期、强简单替代方案：未查证。historical_assessment/current_assessment：均不作外部价值判断。source_ids：LOCAL-M（manuscript.md）、LOCAL-D（measurements.csv）。search_cutoff：不适用，用户限定本地。下一负责人若扩展为查新，应先取得明确扩展任务；本次不要求新实验或文献检索来修复已经可由材料解释的问题。

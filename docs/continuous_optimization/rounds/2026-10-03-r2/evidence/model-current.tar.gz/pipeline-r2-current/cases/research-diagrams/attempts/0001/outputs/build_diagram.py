from pathlib import Path
import json,hashlib,html,subprocess
out=Path(__file__).parent
src=out.parents[2]/'inputs/architecture.json'
d=json.loads(src.read_text())
contract={'source':str(src),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'status':d['status'],'evidence_type':d['evidence_type'],'nodes':[dict(n,type='data' if n['id'] in ['a','b','v'] else 'operation',source_pointer=f'/nodes/{i}',inputs=[a for a,b in d['edges'] if b==n['id']],outputs=[b for a,b in d['edges'] if a==n['id']]) for i,n in enumerate(d['nodes'])],'edges':[{'id':f'edge_{a}_{b}','source':a,'target':b,'direction':'source_to_target','kind':d['edge_kind'],'label':None,'source_pointer':f'/edges/{i}'} for i,(a,b) in enumerate(d['edges'])],'groups':[],'invariants':d['constraints'],'unknowns':['Tensor dimensions and implementation are not specified.','Training/inference distinction is not specified.'],'label_changes':{'output':'SVG uses an editable superscript T for the source label y = p^T V.'}}
(out/'semantic_contract.json').write_text(json.dumps(contract,indent=2))
parts=['''<svg xmlns="http://www.w3.org/2000/svg" width="180mm" height="85.09mm" viewBox="0 0 1100 520">
<title>Two-path logit combination — proposed schematic</title>
<desc>Two parallel inputs a and b merge by addition. Softmax transforms z to p. Fixed values V bypass softmax and enter only y = p transpose V. Synthetic specification, not implemented.</desc>
<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto" markerUnits="strokeWidth"><path d="M 0 0 L 10 5 L 0 10 z" fill="#425469"/></marker></defs>
<rect width="1100" height="520" fill="white"/>
<g font-family="DejaVu Sans,sans-serif" fill="#182f44">
<text x="50" y="50" font-size="26" font-weight="700">Two-path logit combination</text>
<text x="50" y="82" font-size="17" fill="#5f6b76">PROPOSED SCHEMATIC · Synthetic specification; not implemented</text>
<text x="50" y="137" font-size="15" fill="#5f6b76">PARALLEL INPUTS</text>
''']
positions={'a':(50,170,210,70),'b':(50,310,210,70),'sum':(340,240,170,70),'softmax':(570,240,220,70),'v':(850,110,200,70),'output':(850,240,200,70)}
paths={'edge_a_sum':'M260 205 H300 V260 H340','edge_b_sum':'M260 345 H300 V290 H340','edge_sum_softmax':'M510 275 H570','edge_softmax_output':'M790 275 H850','edge_v_output':'M950 180 V240'}
for e in contract['edges']:
 parts.append(f'<path id="{e["id"]}" data-source="{e["source"]}" data-target="{e["target"]}" data-kind="data_flow" d="{paths[e["id"]]}" fill="none" stroke="#425469" stroke-width="2.5" stroke-linejoin="round" marker-end="url(#arrow)"/>')
for n in d['nodes']:
 x,y,w,h=positions[n['id']]
 color=('#edf5fa','#4683a2') if n['id'] in ['a','b'] else ('#e9f5ef','#3f8167') if n['id'] in ['sum','softmax'] else ('#f3f4f6','#7e8997') if n['id']=='v' else ('#fdf1df','#af8138')
 label=html.escape(n['label']) if n['id']!='output' else 'y = p<tspan baseline-shift="super" font-size="14">T</tspan> V'
 parts.append(f'<g id="{n["id"]}" data-node="true"><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="12" fill="{color[0]}" stroke="{color[1]}" stroke-width="2"/><text x="{x+w/2}" y="{y+43}" text-anchor="middle" font-size="21">{label}</text></g>')
parts.append('''<text x="967" y="214" font-size="15" fill="#5f6b76">bypass</text>
<line x1="50" y1="433" x2="1050" y2="433" stroke="#dbe1e6"/>
<path d="M50 463 H105" stroke="#425469" stroke-width="2.5" marker-end="url(#arrow)"/>
<text x="120" y="469" font-size="16" fill="#5f6b76">Data flow</text>
<text x="350" y="469" font-size="16" fill="#5f6b76">Only specified connections are shown; no measured results.</text>
</g></svg>''')
(out/'architecture.svg').write_text('\n'.join(parts))
import xml.etree.ElementTree as ET
root=ET.parse(out/'architecture.svg').getroot()
assert set(n.attrib['id'] for n in root.iter() if n.attrib.get('data-node')=='true')==set(n['id'] for n in d['nodes'])
actual=[(n.attrib['data-source'],n.attrib['data-target']) for n in root.iter() if 'data-source' in n.attrib]
assert actual==[tuple(e) for e in d['edges']]
assert len(actual)==5 and len(set(n['id'] for n in d['nodes']))==6
assert not root.findall('.//{http://www.w3.org/2000/svg}image')
subprocess.run(['inkscape',str(out/'architecture.svg'),'--export-type=png',f'--export-filename={out}/architecture.png','--export-width=1100'],check=True)
from PIL import Image
im=Image.open(out/'architecture.png'); im.convert('L').save(out/'architecture_grayscale.png')
(out/'checks.json').write_text(json.dumps({'node_count':6,'edge_count':5,'exact_topology_match':True,'xml_valid':True,'external_images':False,'png_dimensions':im.size},indent=2))
(out/'caption.md').write_text('Figure. Proposed two-path logit combination (schematic). The parallel paths provide logits a and b, combined as z = a + b. Applying softmax gives p = softmax(z), and the output is y = pᵀV. Fixed values V bypass softmax and enter only the output operation. Arrows denote the five data-flow connections explicitly declared in architecture.json; no feedback or A-to-B connection is implied. This is a synthetic specification, not an implemented or experimentally validated model; no performance or accuracy result is shown.\n')
print('Built architecture.svg and architecture.png; 6 nodes, exact 5-edge match; PNG', im.size)

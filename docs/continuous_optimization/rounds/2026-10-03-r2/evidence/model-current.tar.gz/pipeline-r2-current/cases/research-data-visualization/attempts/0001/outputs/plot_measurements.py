"""Rebuild all exports: python -B plot_measurements.py. Input snapshot is unchanged."""
from pathlib import Path
import os
HERE=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(HERE/'mplconfig')
import csv, hashlib, json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
SOURCE=HERE/'measurements.csv'
rows=list(csv.DictReader(SOURCE.open()))
assert len(rows)==4
assert len({r['workload'] for r in rows})==4
assert all(r[k] and np.isfinite(float(r[k])) for r in rows for k in ['baseline_ms','candidate_ms'])
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.labelsize':9,'axes.titlesize':10,'xtick.labelsize':9,'ytick.labelsize':8,'svg.fonttype':'none','axes.linewidth':0.7,'savefig.facecolor':'white'})
fig,axs=plt.subplots(1,2,figsize=(7.2,3.8),sharey=True,gridspec_kw={'width_ratios':[3,1]})
fig.subplots_adjust(left=.095,right=.975,bottom=.19,top=.77,wspace=.17)
colors=['#0072B2','#D55E00']
plotted=[]
for ax,scope,title in zip(axs,['end_to_end','kernel_only'],['a  End-to-end time','b  Kernel-only time']):
    group=[r for r in rows if r['scope']==scope]
    x=np.arange(len(group))
    for j,(key,name,hatch) in enumerate([('baseline_ms','Baseline',None),('candidate_ms','Candidate','///')]):
        vals=[float(r[key]) for r in group]
        bars=ax.bar(x+(-.19 if j==0 else .19),vals,width=.34,color=colors[j],edgecolor='white',linewidth=.7,hatch=hatch,label=name,zorder=3)
        for r,v,b in zip(group,vals,bars):
            ax.text(b.get_x()+b.get_width()/2,v+4,f'{v:g}',ha='center',va='bottom',fontsize=9,color='#222222')
            plotted.append({'workload':r['workload'],'scope':scope,'series':name,'ms':v,'bar_height':b.get_height()})
    ax.set_xticks(x,[r['workload'] for r in group])
    ax.set_xlim(-.65,len(group)-.35)
    ax.set_ylim(0,240)
    ax.set_yticks([0,50,100,150,200])
    ax.set_title(title,loc='left',pad=12,fontweight='bold')
    ax.yaxis.grid(True,color='#E3E6E8',linewidth=.7,zorder=0)
    ax.spines[['top','right']].set_visible(False)
    ax.spines[['bottom','left']].set_color('#80909A')
    ax.tick_params(axis='both',length=3,color='#80909A')
axs[0].set_ylabel('Time (ms)')
axs[1].tick_params(axis='y',left=False)
axs[1].spines['left'].set_visible(False)
fig.legend(*axs[0].get_legend_handles_labels(),loc='upper center',bbox_to_anchor=(.52,.985),ncol=2,frameon=False,handlelength=1.7,columnspacing=2.4)
fig.text(.53,.045,'Workload  ·  Timing scopes shown separately',ha='center',fontsize=8,color='#48545A')
fig.savefig(HERE/'timing_results.svg')
fig.savefig(HERE/'timing_results.png',dpi=300)
fig.savefig(HERE/'timing_results_final_size.png',dpi=100)
plt.close(fig)
with Image.open(HERE/'timing_results_final_size.png') as im:
    im.convert('L').save(HERE/'timing_results_grayscale.png')
    page=Image.new('RGB',(827,1169),'white')
    page.paste(im.convert('RGB'),((827-im.width)//2,125))
    page.save(HERE/'timing_results_page.png')
expected={(r['workload'],r['scope'],s):float(r[k]) for r in rows for s,k in [('Baseline','baseline_ms'),('Candidate','candidate_ms')]}
actual={(p['workload'],p['scope'],p['series']):p['bar_height'] for p in plotted}
assert actual==expected
assert len(actual)==8
assert actual[('large','end_to_end','Candidate')]==220
assert actual[('kernel','kernel_only','Candidate')]==10
with (HERE/'plotted_values.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(plotted[0]));w.writeheader();w.writerows(plotted)
checks={'input_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'rows':len(rows),'plotted_values':len(plotted),'missing_values':0,'duplicate_workloads':0,'all_bar_heights_match_input_exactly':actual==expected,'large_regression_retained_ms':{'baseline':200,'candidate':220},'kernel_scope_separate':True,'shared_axis_ms':[0,240],'aggregation':'none','error_bars':'none; replicate information absent','matplotlib_version':matplotlib.__version__,'figure_inches':[7.2,3.8],'png_pixels':[2160,1140],'svg_editable_text':True,'statistical_inference':'none'}
(HERE/'numerical_checks.json').write_text(json.dumps(checks,indent=2))
print(json.dumps(checks,indent=2))

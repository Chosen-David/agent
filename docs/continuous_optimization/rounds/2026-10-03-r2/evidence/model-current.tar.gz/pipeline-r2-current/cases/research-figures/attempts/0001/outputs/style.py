import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
INK="#243447"
BLUE="#267B99"
ORANGE="#C77437"
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":10,"svg.fonttype":"none","axes.spines.top":False,"axes.spines.right":False,"axes.labelcolor":INK,"text.color":INK,"xtick.color":INK,"ytick.color":INK})

from pathlib import Path
import csv,json
base=Path(__file__).resolve().parents[3]/"inputs"
rows=list(csv.DictReader((base/"measurements.csv").open()))
assert len(rows)==4
results=[]
for x in rows:
    b=float(x["baseline_ms"]); c=float(x["candidate_ms"])
    assert b>0 and c>0
    results.append(dict(workload=x["workload"],scope=x["scope"],baseline_ms=b,candidate_ms=c,speedup=b/c,latency_change_percent=100*(c-b)/b,saved_ms=b-c))
assert [x["workload"] for x in results if x["scope"]=="end_to_end" and x["candidate_ms"]>x["baseline_ms"]]==["large"]
print(json.dumps({"source":"provided synthetic single-run data", "rows":results,"independent_repeats":False,"kernel_added_to_end_to_end":False},indent=2))

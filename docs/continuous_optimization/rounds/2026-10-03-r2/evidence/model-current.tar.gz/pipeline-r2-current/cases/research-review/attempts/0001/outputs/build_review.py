import pathlib,json,datetime,hashlib
out=pathlib.Path(__file__).resolve().parent
check=json.loads((out/'measurement_check.json').read_text())
snapshot=next(v for k,v in check['source_versions'].items() if k.endswith('manuscript.md'))
findings=[]
def finding(id,cat,sev,typ,status,loc,evidence,impact,verify,resolve,accept,history=None):
    findings.append(dict(finding_id=id,snapshot_id=snapshot,category=cat,severity=sev,confidence='high',assertion_type=typ,status=status,location={'physical_page':None,'printed_page':None,'anchor':loc},evidence=evidence,why_it_matters=impact,verification=verify,resolution_options=resolve,acceptance=accept,related_findings=[],history=history or []))
finding('REV-F001','correctness','major','confirmed_error','confirmed','manuscript.md L4 (Abstract); L8; L10; measurements.csv L2–L5',[
'摘要声称每个 workload 端到端 2x 且无退化。','复算 baseline/candidate：small=1.25，medium=1.20，large=0.90909；kernel_only=2.00。','large 延迟 200→220 ms，增加 10%；附录 L10 与数据一致。','数值证据：measurement_check.json。'],
'核心摘要同时夸大计时范围与改善覆盖面；单核结果不能直接冒充端到端收益。',
'以 scope 筛选 CSV，分别计算 baseline/candidate 与 (candidate-baseline)/baseline；核对正文和附录。现有材料已确认此矛盾。',
['将摘要限缩为三个输入的一次运行观测，分别报告收益和退化；2x 仅限定 kernel-only。','若认为 CSV 不是摘要依据，应提供可追溯的对应结果和计时定义后重新核验；不能用计划代替数据。'],
['新稿摘要与对应 CSV 一致，明确 kernel-only 与 end-to-end。','不再保留 every workload / without any regression 的不实范围；关联结果和附录一致。'])
finding('REV-F002','evidence','major','reporting_gap','confirmed','manuscript.md L4, L8, L10',[
'L8 明确每个数值仅一次运行、没有独立重复；L10 明确未测方差。','CSV 无重复标识或不确定性；本次没有生成置信区间或显著性。'],
'即使修正点估计，当前数据仍仅支持这些单次观测，无法量化稳定性或一般化性能。此处是证据缺口已披露，不是未报告重复次数的指控。',
'确认没有补充重复记录；若有，先核对独立研究单位、配对方式和原始样本。无记录时保持单次观测结论。',
['最小充分补救：把结论限定为探索性单次观测，并保留无法判断波动的限制，无需本轮新实验。','若作者坚持稳定或普遍提升主张：另行授权重复测量，固定比较条件、记录运行顺序和原始配对样本，再分析不确定性。'],
['修订明确单次探索性结果，不暗示稳定、显著或普遍提升；或另有可核验重复数据支持具体缩小后的主张。'])
finding('REV-F003','reporting','suggestion','suspected_error','rejected','manuscript.md Appendix A L10',[
'附录直接写明 large 从 200 ms 退化到 220 ms。'],
'筛查“退化是否未披露”的疑点已被正文附件反证；不能归咎隐瞒。摘要矛盾仍由 REV-F001 单独处理。',
'已完整读取附录并与 CSV L4 交叉核对。',['无需修改附录以解决此疑点。'],['保留反证与 rejected 状态，不计作待修缺陷。'],[
{'status':'open','note':'审阅中的条件性筛查：检查是否披露退化。'}, {'status':'rejected','note':'Appendix A L10 明确披露，数值吻合。'}])
finding('REV-F004','reporting','suggestion','suspected_error','rejected','manuscript.md Results L8',[
'L8 明确 kernel-only 单独计时且包含在端到端路径中，并明确不可相加。'],
'计时包含关系本身有说明。不能将独立 kernel 行重复加入端到端总时长，或指控作者未说明包含关系。',
'已读 L8；复算仅按 scope 分组，未求和或推导组件归因。',['无需为此疑点改稿。'],['驳回“计时关系未说明”疑点，后续核验保持 scope 区分。'],[
{'status':'open','note':'条件性检查：kernel 与端到端是否可加、是否说明。'}, {'status':'rejected','note':'L8 已明确包含和不可相加。'}])
(out/'findings.yaml').write_text(json.dumps({'schema_version':'1.0','agent':'research-review','snapshot':{'id':snapshot,'inputs':check['source_versions']},'findings':findings},ensure_ascii=False,indent=2)+'\n')
tasks=[]
for i,f in enumerate(findings):
    base=i*3+1; rejected=f['status']=='rejected'
    acts=[f['verification'], '若核验 confirmed，选择最小充分补救并记录变更；若 rejected，记录不修改；若 unresolved，列缺失证据。 '+ ' '.join(f['resolution_options']), '核对最新稿件哈希与对应位置；复算 CSV，逐项检查 acceptance。未修改则核验驳回证据。']
    for j,stage in enumerate(['verify','resolve','recheck']):
        tid=f'REV-T{base+j:03d}'
        status='done' if j==0 or rejected and j==2 else ('skipped' if rejected and j==1 else 'todo')
        tasks.append(dict(task_id=tid,finding_ids=[f['finding_id']],stage=stage,depends_on=[] if j==0 else [f'REV-T{base+j-1:03d}'],owner='main_ai' if j<2 else 'research-review',preconditions=['当前输入哈希与快照一致'] if j==0 else ['前置任务产物可读'],action=acts[j],outputs=['findings.yaml','measurement_check.json'] if status in ('done','skipped') else [f'future/{tid}.md'],done_when= f['acceptance'] if j==2 else ['给出有证据的确认、驳回或未决结论'] if j==0 else ['记录修改及依据，或有证据地明确不需修改'],on_missing_input='blocked；列明缺失的源稿或测量记录，由主 AI/作者提供；继续其余任务。',status=status,evidence='本次完整阅读正文和附录并复算 CSV；见 findings.yaml 对应证据。' if status=='done' else '反证充分，无修改必要。' if status=='skipped' else None))
(out/'task_chain.yaml').write_text(json.dumps({'schema_version':'1.0','snapshot_id':snapshot,'tasks':tasks},ensure_ascii=False,indent=2)+'\n')
(out/'task_chain.md').write_text('''# 核验—处理—复查任务链

当前作者稿件未修改。REV-F001、REV-F002 的材料内核验已完成，尚未解决；REV-F003、REV-F004 已驳回，未改稿且无需修复。

| 发现 | 核验 | 处理 | 复查 | 最先可执行动作 |
|---|---|---|---|---|
| REV-F001 | REV-T001 done | REV-T002 todo | REV-T003 todo | 主 AI 在授权修稿时限定摘要的数值与范围 |
| REV-F002 | REV-T004 done | REV-T005 todo | REV-T006 todo | 主 AI 将结论限为单次探索性观测；无需当前运行新实验 |
| REV-F003 | REV-T007 done | REV-T008 skipped | REV-T009 done | 附录反证已足够，保持 rejected |
| REV-F004 | REV-T010 done | REV-T011 skipped | REV-T012 done | Results L8 反证已足够，保持 rejected |

依赖均为每行 verify → resolve → recheck；精确动作、关闭条件、缺输入处置见 task_chain.yaml。后续若修改输入，先生成新快照，再由审阅角色对照原 ID 复查。建议不构成当前代理修改原稿或执行新实验的授权。
''')
(out/'review_report.md').write_text('''# 材料内科学审阅

审阅日期：2026-10-03。输入是 synthetic fixture；不是已发表论文。未提供 venue/year/track，采用 **provisional rubric**：主张正确性、测量证据、复现范围和表达一致性。不提供分数或录用概率。

已完整阅读 manuscript.md L1–L10（正文、Appendix A）及 measurements.csv L1–L5；先读稿件再核对表格。输入哈希见 measurement_check.json，角色快照见 loaded.json。未提供代码或 PDF，未进行实现审计、PDF 审读、GPU 测量或新实验。仅执行现有 CSV 算术核查。

## 中性总结与证据

作者替换一个选定 kernel，使用同一 CPU 进程与输入配置比较基线和候选。当前材料给出三个端到端工作负载和一个 kernel-only 计时对，每个值仅一次运行。摘要声称所有工作负载都有 2x 端到端提升且无退化；该主张比数据支持的范围更强。

| 范围 / workload | baseline ms | candidate ms | speedup（baseline/candidate） | 延迟变化 |
|---|---:|---:|---:|---:|
| end-to-end / small | 100 | 80 | 1.25× | −20% |
| end-to-end / medium | 120 | 100 | 1.20× | −16.67% |
| end-to-end / large | 200 | 220 | 0.91× | +10% |
| kernel-only / kernel | 20 | 10 | 2.00× | −50% |

以上是点观测，不是总体性能参数或统计显著性结论。未将 kernel-only 加入端到端计时；L8 已明确包含关系，也未把 kernel 计时强行映射到某一 workload。

## 有依据的优点

- L6 限定 CPU、相同进程/输入配置，并明确没有 GPU 测量，避免把未执行后端伪装为已测量结果。
- L8 明确计时包含关系以及仅一次运行；Appendix A 明确披露 large 退化及未测质量、方差。
- CSV 保留基线和候选原始时长，足以发现摘要与结果不一致并直接复算。

## 主要意见

**REV-F001（major；高置信度；confirmed_error）**：摘要 L4 的 “2x end-to-end … every workload … without any regression” 与全部三个端到端行均不符。2x 只成立于 kernel-only；large 延迟增加 10%。附录也明确承认退化。最小修复是准确限定摘要的范围、分开 kernel 和端到端结果，并保留负结果；不是在端到端结果上叠加 kernel 时间。验收以修订稿和数据一致为准。

**REV-F002（major；高置信度；已披露的证据缺口）**：L8、L10 表明无独立重复且未测方差，因此连修正后的点估计也不能支持稳定或普遍性能收益。不能由单次测量生成置信区间，也不能将未测波动当作零波动。允许通过缩小结论到单次探索性观测关闭；若作者坚持更强结论，需另行提供独立重复的原始证据。当前任务未执行也不要求立即执行新实验。

## 反证与意见撤销

**REV-F003 rejected**：关于退化是否未披露的检查已由 Appendix A L10 解答；不指控隐瞒。该反证不消除摘要矛盾。

**REV-F004 rejected**：关于 kernel-only 与端到端包含关系不明的检查已由 Results L8 解答；不存在必须补充“不可相加”说明的缺口。

没有为了覆盖所有类别而新增正确性或新颖性指控。未测质量是 L10 明示的限制，稿件没有给出质量保持的独立证据；不能据此声称算法输出错误。方法实现、CPU 型号、基线身份与输入规模未提供，复现完整性有限，但本轮无法核验实现或断言比较不公平。

## 可回答问题与修改优先级

1. 摘要的 2x 是否仅指 kernel？如果是，直接限定其计时范围；如指其他端到端数据，需提供准确来源供复查。这可改变 REV-F001 的证据判断。
2. 作者是否接受将结果限定为单次探索性观测？接受可通过范围修订解决 REV-F002；坚持稳定提升则需要额外原始证据，当前数据不足。

优先处理 REV-F001，再同步处理 REV-F002，最后按原 ID 核查新稿与测量记录。具体任务见 task_chain.md / task_chain.yaml；当前源稿保持原样，confirmed 不等于 resolved。

## 新颖性、替代方案与范围

外部查新按本任务要求未执行（offline_fallback），检索截止不适用；投稿截止和首次公开日期未知。历史新颖性与当前相对研究价值均未验证，不能判断已被他人完成、被强基线支配或无发表价值。材料内唯一对照是未具体命名的 baseline，最强替代方案未知；详情见 novelty_utility_matrix.md。没有给出引用、模拟研究共识或外部范文评价。
''')
(out/'novelty_utility_matrix.md').write_text('''# 逐贡献价值矩阵（本地材料边界）

| 主张 / 位置 | 材料内对照与公平性 | 可行性 / 必要性 | 收益与代价 | 状态 / 下一步 |
|---|---|---|---|---|
| C1：替换选定 kernel，L6 | baseline 未命名；同 CPU 进程、输入；实现、配置和调优预算未知 | CSV 有 kernel 20→10 ms 观测；无代码可核验机制；组件必要性无消融证据 | 单次 kernel 2x；质量、复杂度、能耗等未知 | insufficient_evidence（机制和增量价值）；保持局部观测，不判断创新性 |
| C2：每个 workload 端到端 2x 且无退化，L4 | 与自身 CSV 可直接比较；无需引入外部基线反驳 | 全部端到端点估计未达 2x；large 退化 | small/medium 单次改善，large +10% 延迟；无方差 | 本地主张已被证据反驳，见 REV-F001；缩小范围并复查 |

最接近工作、发布日期、强简单替代方案：未查证。historical_assessment/current_assessment：均不作外部价值判断。source_ids：LOCAL-M（manuscript.md）、LOCAL-D（measurements.csv）。search_cutoff：不适用，用户限定本地。下一负责人若扩展为查新，应先取得明确扩展任务；本次不要求新实验或文献检索来修复已经可由材料解释的问题。
''')
(out/'domain_brief.md').write_text('''# 材料内领域说明

问题：替换一个 CPU kernel 能否改善包含它的端到端路径。材料支持的评价量是毫秒延迟及 baseline/candidate 比值。kernel 的局部计时与端到端计时范围不同且有包含关系；局部 2x 不直接证明端到端 2x。

已知材料边界：同进程、同输入配置，一次运行；没有 GPU 结果、质量和方差测量。路线、实际硬件瓶颈、强基线与领域共识未知；本文没有进行外部检索，不能将模型记忆当作已核实的领域背景。
''')
(out/'search_log.md').write_text('''# 检索与能力选择记录

2026-10-03：本任务明确禁止网络和外部范文检索；未发出任何网络查询。使用指定快照 research-review 入口及 execution/workflow，未安装或替换技能。选择状态 offline_fallback；本地 Python 标准库足以复算四行 CSV，不需要外部后端、PDF 工具或多代理。

未核验最新文献、真实 venue 标准或历史/当前新颖性。此项是任务范围排除，不伪称已完成，也不将其列为作者必须补救的科研缺陷。
''')
(out/'source_registry.yaml').write_text(json.dumps({'sources':[{'id':'LOCAL-M','path':k,'sha256':v,'coverage':'all lines, including appendix'} if k.endswith('manuscript.md') else {'id':'LOCAL-D','path':k,'sha256':v,'coverage':'header and all four rows'} for k,v in check['source_versions'].items()],'external_sources':[]},ensure_ascii=False,indent=2)+'\n')
(out/'execution.md').write_text('''# 实际执行记录

执行者：/root/n16_review；2026-10-03 UTC。

1. 读取 host_worker.md、当前 case task.txt 和固定快照中的 research-review/SKILL.md、references/execution.md、references/workflow.md（完整）。未读其他 case、rubric、旧输出或评测答案。
2. `test -f .../attempts/0001/start.json` 成功后才在已存在 attempt 下创建 outputs；先保存 loaded.json，包含实际已读角色文件的路径、SHA-256、观察时间和任务范围。没有读取或制造调度回执。
3. `nl -ba .../inputs/manuscript.md` 与 `nl -ba .../inputs/measurements.csv`：完整读取 10 行稿件与 5 行 CSV，检查附录后撤销相应疑点。
4. `python -B .../outputs/check_measurements.py`：实际用 Python 标准库复算 baseline/candidate 和延迟变化，生成 measurement_check.json。观察 small=1.25x，medium=1.2x，large=0.90909x，kernel-only=2x；large 增加 10%。未重复计算包含的 kernel 计时，没有新实验。
5. `python -B .../outputs/build_review.py`：写入审稿、发现与任务链等产物。YAML 文件采用 JSON 兼容 YAML 语法，可用标准 JSON 解析器复核。
6. 随后的结构检查验证两份任务/发现文件可解析、ID 唯一、依赖存在且无环、所有输入 SHA-256 未变化。确认源稿保持只读，见工具返回。

限制：没有目标 venue、真实发表时间、代码或 PDF；未做外部检索、GPU 执行、质量/方差估计、实现正确性或统计显著性验证。没有渲染任务或视觉观察。新稿改写和新增实验均未执行。REV-F001、REV-F002 confirmed 但未 resolved；两项筛查疑点依据附录/正文已 rejected。报告不提供评分、录用概率或评测通过结论。
''')
print('Created review artifacts')

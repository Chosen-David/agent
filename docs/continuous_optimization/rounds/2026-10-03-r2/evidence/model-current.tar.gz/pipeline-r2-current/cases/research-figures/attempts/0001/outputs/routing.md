# Figure routing and design

Whole-figure owner: /root/n06_figures. Route: mixed. Both professional workflows were executed sequentially by this worker; no independent agents, exemplar search or network were used. The explicit synthetic local task limits sources to the supplied files.

| Panel | Route | Evidence | Input | Editable master | Status |
|---|---|---|---|---|---|
| A | diagram | conceptual, proposed synthetic specification; not implemented | architecture.json; hash in checks.json | panel_a.py + style.py; editable panel_a.svg | rendered and inspected in composition |
| B | data_visualization | supplied synthetic latency examples | measurements.csv; hash in checks.json | panel_b.py + style.py; editable panel_b.svg | rendered and inspected in composition |
| Whole | mixed | preserves panel-specific evidence types | both sources | compose.py + panel modules; combined.svg | rendered; final QA in execution.md |

Composition: left-to-right A then B. Shared DejaVu Sans typography, dark slate text, sparse pale blue node fills. A uses six equal-width rounded blocks, exactly five directed data-flow arrows, parallel A/B branches and a separate V-to-output path. B uses a zero-based horizontal latency scale, direct numeric labels, blue baseline and orange hatched candidate. Hatching preserves identity in grayscale. Kernel-only is partitioned from end-to-end results to prevent scope conflation. No causal or empirical connection is added between the panels.

Dimensions are provisional because no venue or publication template was supplied: panels 6 × 4.5 inches; combined 12 × 4.5 inches. High-resolution PNGs are 200 dpi; final-size screen preview is 100 dpi. Text remains editable in all SVG files. No claim of submission-spec compliance.

Reproduce from this directory with: `python -B panel_a.py`, `python -B panel_b.py`, `python -B compose.py`, `python -B verify.py`. Input copies are byte-identical snapshots of read-only case sources. Data transformations: none. No rows excluded; no error bars fabricated. CSV does not supply replication counts, error definitions, hardware or run protocol, so empirical inference is out of scope.

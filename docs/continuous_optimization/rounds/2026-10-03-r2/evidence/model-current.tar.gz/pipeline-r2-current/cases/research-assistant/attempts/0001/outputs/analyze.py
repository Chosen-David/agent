from pathlib import Path
import csv,json,hashlib,platform
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image,ImageOps
O=Path(__file__).resolve().parent
I=O.parents[2]/'inputs'
rows=list(csv.DictReader((I/'measurements.csv').open()))
assert len(rows)==4 and len({r['workload'] for r in rows})==4
for r in rows:
    b,c=float(r['baseline_ms']),float(r['candidate_ms'])
    assert b>0 and c>0 and r['scope'] in ('end_to_end','kernel_only')
    r.update(baseline_ms=b,candidate_ms=c,latency_change_pct=(c/b-1)*100,speedup=b/c)
with (O/'analysis.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
assert abs(rows[0]['speedup']-1.25)<1e-12
assert abs(rows[1]['latency_change_pct']+100/6)<1e-10
assert abs(rows[2]['latency_change_pct']-10)<1e-10
assert rows[3]['speedup']==2
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'svg.fonttype':'none'})
fig,axes=plt.subplots(1,2,figsize=(7.2,3.7),gridspec_kw={'width_ratios':[3,1.2]},layout='constrained')
for ax,rs,title in zip(axes,[rows[:3],rows[3:]],['End-to-end','Kernel only']):
    y=list(range(len(rs)))
    ax.barh([i-.17 for i in y],[r['baseline_ms'] for r in rs],height=.3,color='#59718A',label='Baseline')
    bars=ax.barh([i+.17 for i in y],[r['candidate_ms'] for r in rs],height=.3,color='#DD8A39',hatch='//',label='Candidate')
    ax.set_yticks(y,[r['workload'] for r in rs]);ax.invert_yaxis();ax.set_xlim(0,250 if len(rs)>1 else 25)
    ax.set_xlabel('Latency (ms)');ax.set_title(title,fontsize=11,loc='left')
    ax.spines[['top','right']].set_visible(False);ax.set_axisbelow(True);ax.xaxis.grid(alpha=.15)
    for i,r in enumerate(rs):
        ax.text(r['baseline_ms']+2 if len(rs)>1 else r['baseline_ms']+.2,i-.17,f"{r['baseline_ms']:g}",va='center',fontsize=9)
        ax.text(r['candidate_ms']+2 if len(rs)>1 else r['candidate_ms']+.2,i+.17,f"{r['candidate_ms']:g}",va='center',fontsize=9)
fig.legend(*axes[0].get_legend_handles_labels(),loc='outside lower center',ncol=2,frameon=False,fontsize=9)
fig.suptitle('Supplied measurements v2 — descriptive comparison',fontsize=12)
fig.savefig(O/'figure_v2.png',dpi=180)
fig.savefig(O/'figure_v2.svg')
plt.close(fig)
ImageOps.grayscale(Image.open(O/'figure_v2.png')).save(O/'figure_v2_gray.png')
fig=plt.figure(figsize=(8.27,11.69),facecolor='white');ax=fig.add_axes([.07,.46,.87,.4]);ax.imshow(Image.open(O/'figure_v2.png'));ax.axis('off')
fig.text(.08,.43,'Figure v2. Supplied values; no repeats or uncertainty reported.\nSeparate panels have different x-axis ranges.',fontsize=10)
fig.savefig(O/'page_preview.png',dpi=110);plt.close(fig)
(O/'checks.json').write_text(json.dumps({'rows':4,'missing_fields':False,'duplicate_workloads':False,'positive_latencies':True,'formula_checks':'passed','source_sha256':hashlib.sha256((I/'measurements.csv').read_bytes()).hexdigest(),'python':platform.python_version(),'matplotlib':matplotlib.__version__,'independent_acceptance':'pending'},indent=2))
print((O/'analysis.csv').read_text())

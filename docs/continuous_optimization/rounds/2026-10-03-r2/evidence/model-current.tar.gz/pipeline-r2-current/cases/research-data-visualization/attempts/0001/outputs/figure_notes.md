# FIG timing-results

Source: current case `inputs/measurements.csv`, preserved byte-for-byte as `measurements.csv`. SHA-256: 57201d75a6e7ea0b7581c2d94f4bf46c2b9a66e37b5df94c8e6b4c5ef3924248.

Evidence: supplied timing measurements; experimental provenance, independent unit and repeat count unspecified. Four distinct workload rows, no blank fields, no duplicate workloads. Each supplied record is plotted directly; no aggregation, omission, new statistical analysis or error bars. Scope is preserved as a two-panel partition.

Editable source: `plot_measurements.py`; SVG retains editable text. Rebuild locally with `python -B plot_measurements.py` from any working directory; Python with Matplotlib 3.10.8, NumPy and Pillow 12.3.0 was available. `plotted_values.csv` records actual bar heights. `numerical_checks.json` records executed exact equality checks. Design is in `design.md`, caption in `caption.md`.

## QA observations

- Scientific/numerical/semantic: all 8 bar heights match the CSV exactly (zero tolerance). Large candidate=220 and baseline=200 are preserved; kernel baseline=20/candidate=10 appears only under Kernel-only time. Missing values are absent; absence of repeat information is explicitly disclosed.
- Hierarchy/read order: actual final PNG shows shared legend above panel titles, then bars and workload labels. Two labeled panels clearly separate scopes.
- Typography/final size: opened 2160×1140 export and 720×380 100-dpi final-size preview. All numbers, titles and axis labels visible with no clipping or collisions. Provisional 7.2×3.8 inches; display scaling is device dependent.
- Palette/accessibility: opened grayscale preview; solid baseline versus diagonal candidate hatch remains identifiable including the short kernel bar. Color vision simulation was not performed.
- Whitespace/layout: balanced 3:1 panel allocation for three workloads versus one; aligned axes and common baseline. Empty upper kernel region honestly reflects the shared scale.
- Legend/annotations: legend occupies dedicated top margin and does not overlap data. All eight numeric labels sit above the bars.
- Technical: parsed SVG XML successfully, verified editable text, unique IDs and all local href/url references; no remote image assets. PNG dimensions checked at 2160×1140, export configured at 300 dpi.
- Full-page preview: opened `timing_results_page.png`, an A4-sized white-page preview at 100 dpi with the figure embedded at its declared 7.2-inch width; labels are legible with ample margins.
- Reproducibility: script executed successfully with assertions and exported both requested formats plus previews. Original and delivered data snapshots match byte-for-byte.
- Submission: unverified; no venue or journal specifications were supplied. Figure is ready for user review, not claimed submission-compliant.

Host proxy visual observation is recorded in execution.md after receipt; it supplements the worker’s own actual image openings.

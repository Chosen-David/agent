# Figure notes

ID: research-diagrams / pipeline-r2-current / attempt 0001.
Purpose: explain the exact proposed parallel-logit merge and the independent fixed-value bypass.
Evidence: conceptual, synthetic specification; not implemented. Source/hash and JSON pointers are in semantic_contract.json. No experiment or model was executed.

Design: single panel, left-to-right flow; parallel A/B inputs occupy separate rows. Addition and softmax share green operation styling; blue inputs, neutral fixed values and a warm output distinguish roles. Text labels and position provide redundant identity in grayscale. Orthogonal arrows enter distinct ports of the sum and output. No grouping boundaries imply hardware or privacy constraints. Editable DejaVu Sans text, 21-unit node labels, restrained fills, 50-unit side margins; no external assets.

The main SVG is 180 mm × 85.09 mm, a provisional wide figure (not a verified venue specification). PNG is 1100 × 520. A 96-dpi A4 page preview places the figure at approximately 180 mm width. Caption is separate to allow manuscript integration.

QA observations from actual image-tool opens:
- Scientific/semantic: six nodes and five declared source-to-target connections; A and B independently enter addition; sum enters softmax; softmax and V independently enter output. No A-to-B edge or feedback. Computational ordering preserved. Tensor sizes are unknown and not invented.
- Typography/final size: viewed full PNG and 180 mm page preview. Node text, p superscript T, title and status are readable without clipping. Page preview footer is secondary but legible.
- Layout: arrows touch intended node boundaries, sum arrows use separate ports, V enters the top of output. No connector crossings or text collisions. Parallel branches visually align.
- Palette/accessibility: opened grayscale PNG. Labels, block outlines and arrow direction retain identity; color is not the sole semantic key. Color-vision simulation not performed.
- Technical: XML parsed; stable node and edge IDs matched input exactly. No embedded or linked raster source. Inkscape 1.2.2 rendered successfully despite profile/font-cache warnings in the read-only environment.
- Reproducibility: run `python -B build_diagram.py` in this output folder with original input in place. Uses standard Python, Inkscape CLI and Pillow. SVG is the editable master; Python regenerates it from the specification.
- Submission requirements: unverified because no venue was specified.

The local synthetic task explicitly disallows network and nested agents; no exemplar-paper research was performed. Parent visual observation was requested during execution, prior to final delivery, and is recorded in execution.md after receipt.

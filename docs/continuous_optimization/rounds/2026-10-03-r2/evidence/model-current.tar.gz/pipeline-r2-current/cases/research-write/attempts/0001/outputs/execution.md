# Execution account

Actor: `/root/n15_write`. Scope: Chinese Results, English abstract and claim-evidence table for a synthetic fixture; general working draft only.

## Actual reads and routing

Read `host_worker.md`, the case `task.txt`, and the pinned `research-write/SKILL.md`, `references/execution.md`, and all of `references/workflow.md` using shell `cat`. Snapshot paths and SHA-256 hashes are recorded in `loaded.json`. Observed the existing `attempts/0001/start.json` via `ls`; verified its existence before writing `loaded.json`. No attempt directory or host receipt was created.

Read only this case's `inputs/manuscript.md` and `inputs/measurements.csv` for scientific content. The full-paper exemplar/PDF route is outside this explicit bounded task. Used the pinned local role and Python standard library as `offline_fallback`; did not claim external discovery or current-best tool selection.

## Executed work and commands

1. Ran inline `python -B` to hash actually read snapshot files, save `loaded.json`, and print both inputs.
2. Ran inline `python -B` using `csv.DictReader` to compute `speedup = baseline_ms / candidate_ms` and `latency_change_percent = 100 * (candidate_ms - baseline_ms) / baseline_ms`. Saved versioned calculations and the evidence ledger before writing both prose drafts and the readable evidence table.
3. Wrote `check_numbers.py` and executed the actual command:

```bash
python -B agent/.agent-runs/pipeline-r2-current/cases/research-write/attempts/0001/outputs/check_numbers.py
```

Observed exit code 0. Output: “Verified 4 CSV rows, source hashes, speedup and latency-change calculations, shared rounded numbers in Chinese and English, and 6 claim ledger entries.” The script also explicitly reports that no statistical tests, new experiments, PDF generation, or independent review were performed.

## Observed results and content check

Small: 1.25× and −20.0% latency; medium: 1.20× and −16.7%; large: 0.91× and +10.0%; kernel: 2.00× and −50.0%. The source describes kernel-only timing as included in end-to-end paths; no timings were added together. The drafts remove the original universal 2×/no-regression claim, preserve the large regression, distinguish local from end-to-end timing, and state synthetic provenance and the absence of repeats, quality, and GPU measurements. No causal explanation for regression or significance claim is supplied.

Status: `draft_complete` within the requested scope. Numeric checks completed; broader research validation is unavailable from these inputs. No outside citations, experiments, network calls, external runtime installation, nested agents, or PDF/visual review were used. No claim of submission readiness or independent scientific review is made.

## Deliverables

- `results_zh.md`: complete Chinese Results paragraphs.
- `abstract_en.md`: complete English abstract.
- `claim_evidence.md`: readable claim-evidence table.
- `claim_evidence_ledger.yaml`: machine-readable ledger, JSON-compatible YAML.
- `computed_metrics.json`: inputs' SHA-256 hashes, definitions and computed values.
- `check_numbers.py`: reproducible CPU arithmetic and consistency check.
- `loaded.json`: actual pinned-role reads and scope.
- `execution.md`: this execution account.

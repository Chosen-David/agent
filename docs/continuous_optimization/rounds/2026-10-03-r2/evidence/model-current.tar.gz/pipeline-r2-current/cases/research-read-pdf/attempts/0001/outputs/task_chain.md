# 核验与复查任务链

READ-T001 核验 → READ-T002 处理 → READ-T003 新 PDF 复查。

1. 主 AI/审稿角色核对正文普遍结论、附录教学范围、RoPE 映射与误差定义，记录 confirmed/rejected/unresolved。
2. 依据核验收窄主张并统一正文附录；若坚持更强结论而缺证据，记录 blocked，不编造。
3. 读者角色核对新 PDF 哈希并重渲染、重读三页，按 findings.yaml 的验收条件关闭或重新打开发现。

三项均为 todo；本轮只审读，未改稿，未关闭发现。

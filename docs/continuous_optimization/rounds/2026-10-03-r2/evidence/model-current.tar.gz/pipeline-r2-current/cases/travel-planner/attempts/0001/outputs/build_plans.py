from pathlib import Path
import json,datetime,copy
OUT=Path(__file__).resolve().parent
SRC=OUT.parents[2]/'inputs/travel.json'
data=json.loads(SRC.read_text())
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
def iso(t): return data['date']+'T'+t+':00+08:00'
def minute(t):
    if 'T' in t: t=t.split('T')[1][:5]
    h,m=map(int,t.split(':'));return 60*h+m
unknowns=[
 {'id':'u_currency','detail':'输入没有币种；所有金额仅为输入计价单位，暂按同一币种计算。','owner':'user'},
 {'id':'u_hotel_cost','detail':'Hotel H 房间可用已给定，但房费、是否已付及午休附加费未知；不作零费用。','owner':'user'},
 {'id':'u_payment','detail':'写真预约已由用户确认，是否已付款、套餐内容和额外化妆换装时长未提供。','owner':'user'},
 {'id':'u_routes','detail':'城市、入口/上客点、真实道路、公交/步行路线、车种和候车时长未知；输入通勤时长暂按门到门总时长。','owner':'user'},
 {'id':'u_context','detail':'天气、临时营业变化、餐厅预约/排队、写真报到要求未知；新增缓冲均为规划假设。','owner':'user'},
 {'id':'u_anchor','detail':'假设11:00从Hotel H出发、18:00前回Hotel H；没有车站返程票、预算上限信息。','owner':'user'}]
reason=['两人共用输入中的一辆车前往午餐；只有这一方式有合成时间和费用数据。','餐后返回已提供可用房间的Hotel H，保证独立午休，不将车程算成休息。','从午休地点直接前往Studio B；预留15分钟报到缓冲，守住16:00预约。','写真结束返回Hotel H，完成闭环并在18:00前保留余量。']
places={'hotel':('Hotel H','1 Test Road'),'lunch':('Cafe A','2 Test Road'),'photo':('Studio B','3 Test Road')}
slots=[
 [('11:00','11:20','transfer','c1'),('11:20','11:25','buffer','午餐入店/点单准备'),('11:25','12:25','activity','lunch'),('12:25','12:30','buffer','午餐离店'),('12:30','12:50','transfer','c2'),('12:50','14:05','rest','hotel'),('14:05','15:25','buffer','酒店自由留白'),('15:25','15:45','transfer','c3'),('15:45','16:00','buffer','写真报到/入场'),('16:00','17:00','activity','photo'),('17:00','17:05','buffer','写真离场'),('17:05','17:25','transfer','c4'),('17:25','18:00','buffer','酒店返程余量')],
 [('11:00','11:35','transfer','c1'),('11:35','11:40','buffer','午餐入店/点单准备'),('11:40','12:40','activity','lunch'),('12:40','12:45','buffer','午餐离店'),('12:45','13:20','transfer','c2'),('13:20','14:35','rest','hotel'),('14:35','15:10','buffer','酒店自由留白'),('15:10','15:45','transfer','c3'),('15:45','16:00','buffer','写真报到/入场'),('16:00','17:00','activity','photo'),('17:00','17:05','buffer','写真离场'),('17:05','17:40','transfer','c4'),('17:40','18:00','buffer','酒店返程余量')]]
def price(lo,hi,unit,qty,original=None):
    p={'min':lo,'max':hi,'currency':None,'unit':unit,'quantity':qty,'includes':[],'excludes':['未提供的附加费用'],'source_status':'reference','checked_at':now}
    if original:p['original_unit']=original
    return p
def build(rev):
    dur=20 if rev==1 else 35
    commutes=[]
    for i,(a,b) in enumerate([('hotel','lunch'),('lunch','hotel'),('hotel','photo'),('photo','hotel')]):
        commutes.append({'commute_id':f'c{i+1}','from':dict(zip(['name','address'],places[a])),'to':dict(zip(['name','address'],places[b])),'mode':'输入指定的一辆车，具体车种未知','route':'直接地点转换的合成模型；道路、入口、上下车点、公交对照未知','duration_minutes':[dur,dur],'price':price(15,25,'per_car',1,'per_vehicle'),'people':2,'status':'reference','source_ids':['input'],'reason':reason[i],'alternatives':[],'alternative_limitation':'没有其他方式数据，不能判断哪一种现实交通最便宜。','built_from_revision':rev,'validated_for_revision':rev,'depends_on':['commute','amendment'] if rev==2 else ['commute'],'validity':'current'})
    itinerary=[]
    for i,(s,e,k,x) in enumerate(slots[rev-1]):
        itinerary.append({'slot_id':f's{i+1}','kind':k,'candidate_id':x if x in places else None,'commute_id':x if k=='transfer' else None,'intent_ids':[('rest' if x=='hotel' else x)] if k in ['rest','activity'] else [],'start':iso(s),'end':iso(e),'label':x,'conditions':['基于合成输入；缓冲不是实际排队或商户规定'],'depends_on':['commute'] if k=='transfer' else [x],'built_from_revision':rev,'validated_for_revision':rev,'validity':'current'})
    items=[{'item':'双人午餐','price':price(80,100,'per_person',2),'total':[160,200]}, {'item':'双人写真一组','price':price(300,300,'per_package',1,'per_group'),'total':[300,300]}, {'item':'四段交通','price':price(15,25,'per_car',4,'per_vehicle'),'total':[60,100],'quantity_note':'每段1辆车，共4个单程，不乘2位乘客'}]
    budget={'items':items,'currency':None,'currency_assumption':'输入金额同一未指定计价单位','known_subtotal':[520,600],'contingency_rate':0.10,'contingency':[52,60],'known_total_with_contingency':[572,660],'excluded_unknown_ids':['u_hotel_cost','u_payment'],'all_in_total':None,'paid_amount':None,'additional_spend':None,'note':'已知项目总成本；已付款与待付款拆分未知。未知费用另加，不能用机动金代替。','built_from_revision':rev,'validated_for_revision':rev,'depends_on':['lunch.price','photo.price','commute.each_leg_price','commutes'],'validity':'current'}
    change=[] if rev==1 else [{'amendment_id':'a1','from_revision':1,'to_revision':2,'changed_fields':['commute.each_leg_minutes'],'old_value':20,'new_value':35,'source':'travel.json amendment','affected_ids':['c1','c2','c3','c4','itinerary','budget','intent_coverage','plan-r1.md'],'invalidated_before_rebuild':['commutes','itinerary','budget','intent_coverage','deliverables'],'reused_after_review':['lunch windows and prices','photo booking and price','room availability','75-minute rest','per-vehicle fares and vehicles'],'reason':'每段增加15分钟，四段合计增加60分钟；重新排程与核算。','historical_deliverable':'plan-r1.md 为原始版本；当前计划是 plan-r2.md。'}]
    candidates=[]
    for key,(name,address) in places.items():
        candidates.append({'candidate_id':key,'entity_id':key,'kind':key,'name':name,'navigable_address':address,'intent_ids':['rest' if key=='hotel' else key],'fact_ids':[key], 'price':items[0]['price'] if key=='lunch' else items[1]['price'] if key=='photo' else {'amount':None,'currency':None,'unit':'per_room','quantity':1,'source_status':'unknown'},'duration_minutes':75 if key=='hotel' else 60,'admission':'admitted','scope':'仅合成事实范围；不是现实核验','unknowns':[u['id'] for u in unknowns]})
    return {'schema_version':'local-travel/v1','trip_id':'synthetic-travel-planner','revision':rev,'as_of':now,'request_contract':{'trip_brief':{'destination':'合成地点，城市未知','timezone':data['timezone'],'dates':{'start':data['date'],'end':data['date']},'people':2,'anchor':{'kind':'hotel','entity_id':'hotel'},'arrival':iso('11:00'),'departure':iso('18:00'),'budget':{'amount':None,'currency':None,'scope':'预算上限未提供'},'rest_preferences':{'default_enabled':True,'midday_minutes':75,'needs_room':True,'walking_tolerance':None},'assumptions':['首尾锚点为Hotel H','门到门通勤采用输入时长，包含步行/候车为建模假设','点单取用餐开始时刻','缓冲是假设，不是新增商户事实','金额暂按同一未知币种']},'hard_constraints':[{'id':'photo_booking','content':'16:00–17:00 Studio B预约不动','source':'input','user_confirmed':True},{'id':'rest75','content':'Hotel H独立午休75分钟','source':'input','user_confirmed':True},{'id':'available','content':'11:00–18:00','source':'input','user_confirmed':True}], 'desired_intents':[{'intent_id':x,'must_do':True,'goal':x,'acceptance':'保留独立活动及给定时长'} for x in data['must_do']], 'soft_preferences':[], 'unknowns':unknowns,'acceptance_criteria':['午餐完整落在单一营业窗口并符合最后点单','保留写真预约和75分钟午休','逐段交通、费用单位及双人汇总','不预订、不联网、仅用合成事实']},'research_queries':[],'capabilities':[{'name':'local Python','scope':'离线解析、排程和算术断言','limitations':'不验证现实商户/地图/天气'}],'facts':[{'fact_id':k,'entity_id':k,'claim':'合成输入事实','value':v,'applies_on':data['date'],'timezone':data['timezone'],'source_ids':['input'],'checked_at':now,'status':'user_confirmed' if k=='photo' else 'reference'} for k,v in [('lunch',data['lunch']),('photo',data['photo']),('hotel',data['rest']),('commute',dict(data['commute'],each_leg_minutes=dur))]],'experiences':[],'weather':[],'candidates':candidates,'selection_plan':[{'intent_id':x,'primary':'hotel' if x=='rest' else x,'alternatives':[],'fallbacks':[],'reason':'输入只有指定实体；不编造替代商户','conditions':['只适用于合成模型']} for x in data['must_do']], 'itinerary':itinerary,'commutes':commutes,'budget':budget,'intent_coverage':[{'intent_id':x,'slot_ids':[s['slot_id'] for s in itinerary if x in s['intent_ids']],'outcome':'conditional','evidence':'给定事实和明示假设下时长满足；不推断现实可执行性'} for x in data['must_do']],'sources':[{'source_id':'input','url':None,'source_type':'synthetic_user_fixture','path':str(SRC),'published_at':None,'checked_at':now,'access_scope':'full','scope':'本任务全部事实'}],'open_questions':[u['id'] for u in unknowns],'change_log':change,'deliverables':[{'format':'markdown','path':str(OUT/f'plan-r{rev}.md'),'bundle_revision':rev,'validity':'current','QA':'limited','limitations':'仅数学与约束检查，非真实旅行核验'}],'run_state':{'stages':[{'stage_id':'offline_plan','status':'COMPLETED','input_revision':rev,'depends_on':['input'],'outputs':[f'bundle-r{rev}.json',f'plan-r{rev}.md'],'blocked_reason':None}]}}

def render(b):
    rev=b['revision']; text=[f'# 合成一日行程 · revision {rev}', '', '日期：2026-10-04，Asia/Shanghai（UTC+08:00）；2人；11:00–18:00。Hotel H、Cafe A、Studio B及地址均为合成测试实体，不代表真实商户。', '', '默认从 Hotel H（1 Test Road）出发并返回。Studio B 16:00–17:00 是输入中用户已确认的预约；本次没有预订或变更预约。所有事实仅来自 travel.json。', '', 'Cafe A 午市10:30–14:30、晚市16:00–21:00，两个窗口分开保留；最后点单14:00。本计划只用午市。','', '| 时间 | 安排 |','|---|---|']
    for s in b['itinerary']:
        x=s['label']; label=places[x][0]+'（'+places[x][1]+'）'+('，独立房间午休75分钟' if x=='hotel' else '，用餐60分钟并在开始时点单' if x=='lunch' else '，保留预约60分钟') if x in places else x
        if s['kind']=='transfer':
            c=next(c for c in b['commutes'] if c['commute_id']==x);label=c['from']['name']+' → '+c['to']['name']+f'，1辆车，{c["duration_minutes"][0]}分钟'
        text.append(f'| {s["start"][11:16]}–{s["end"][11:16]} | {label} |')
    text+=['','缓冲均为规划假设：午餐前后各5分钟、写真提前15分钟到达及结束后5分钟离场。自由留白与返程余量不是另加收费活动。输入未注明通勤时间的组成，暂将其当作含步行、候车及上下车的全程时间；超出时须重排。','','## 逐段通勤','', '| 段 | 起终点 | 推荐方式/总时长 | 双人单程费用 | 理由 |','|---|---|---|---|---|']
    for c in b['commutes']:
        text.append(f'| {c["commute_id"]} | {c["from"]["name"]}，{c["from"]["address"]} → {c["to"]["name"]}，{c["to"]["address"]} | 输入中的1辆车，{c["duration_minutes"][0]}分钟 | 15–25／车×1 | {c["reason"]} |')
    text+=['','车种、入口、上客点、道路、线路和公共交通/步行对照未知；不能声称此方案现实最便宜，也不能编造站点或替代路线。相反方向的两段均独立计时计费。','','## 双人预算','', '币种未提供，下表使用输入计价单位，并暂按同一币种计算。','', '| 项目 | 计算 | 区间 |','|---|---|---|','| 午餐 | 80–100／人 × 2人 | 160–200 |','| 写真 | 300／组 × 1组（per_group → per_package） | 300 |','| 交通 | 15–25／车／段 × 1车 × 4段（per_vehicle → per_car） | 60–100 |','| 已知项目小计 | 午餐＋写真＋交通 | 520–600 |','| 机动金 | 小计的10%，规划预留 | 52–60 |','| 已知项目含机动金 | 小计＋机动金 | 572–660 |','', '房间可用不等于免费：酒店房费、午休附加费和其他未列费用未知，未计入上述数字且没有当作0。写真是否已支付未知，因此这是已知项目总成本，不是确定的新增待付款金额；完整总预算仍未知。']
    if rev==2:text+=['','## amendment 与版本变化','','每段通勤由20分钟改为35分钟，四段合计由80增加到140分钟；车数、段数和给定车费没有改变，所以重新计算后的预算仍为572–660（另加未知项），不按时间自行涨价。','','午餐11:25–12:25 → 11:40–12:40；午休12:50–14:05 → 13:20–14:35，仍75分钟；酒店出发去写真由15:25提前至15:10，仍15:45到达；写真16:00–17:00不变；回酒店17:25 → 17:40，剩20分钟余量。午后自由留白80 → 35分钟，返程余量35 → 20分钟，合计释放60分钟。','','依赖处理：先将旧通勤、日程、预算、覆盖记录及交付标记为受影响，再用revision 2重建并检查；未变化的营业窗口、套餐价、车辆数、房间可用性和预约事实复用。plan-r1.md保留为历史版本，当前采用plan-r2.md。']
    text+=['','## 未知项与适用范围','']+[f'- {u["detail"]}' for u in unknowns]+['','未联网、未联系商户、未下单、未付款、未启用监控。没有真实天气/关闭备选候选可供核验；若合成事实不再成立，应先补充新事实再修订，不能暗改预约或删除午休。']
    return '\n'.join(text)+'\n'
checks=[]
for rev in (1,2):
    b=build(rev)
    it=b['itinerary']
    assert all(minute(s['end'])>minute(s['start']) for s in it)
    assert all(it[i]['end']==it[i+1]['start'] for i in range(len(it)-1))
    assert minute(it[0]['start'])==660 and minute(it[-1]['end'])==1080
    lunch=next(s for s in it if s['candidate_id']=='lunch');rest=next(s for s in it if s['kind']=='rest');photo=next(s for s in it if s['candidate_id']=='photo')
    assert minute(lunch['end'])-minute(lunch['start'])==60
    assert any(minute(o)<=minute(lunch['start']) and minute(lunch['end'])+5<=minute(c) for o,c in data['lunch']['service_windows'])
    assert minute(lunch['start'])<=minute(data['lunch']['last_order'])
    assert minute(rest['end'])-minute(rest['start'])==75 and data['rest']['room_available']
    assert photo['start']==iso('16:00') and photo['end']==iso('17:00')
    trips=[s for s in it if s['kind']=='transfer'];assert len(trips)==4
    assert all(minute(s['end'])-minute(s['start'])==(20 if rev==1 else 35) for s in trips)
    assert it[7]['end']==iso('15:45')
    lo=sum(x['total'][0] for x in b['budget']['items']);hi=sum(x['total'][1] for x in b['budget']['items'])
    assert [lo,hi]==[520,600]
    assert [lo*1.10,hi*1.10]==[572.0,660.0]
    (OUT/f'bundle-r{rev}.json').write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n')
    (OUT/f'plan-r{rev}.md').write_text(render(b))
    checks.append({'revision':rev,'timeline_minutes':sum(minute(s['end'])-minute(s['start']) for s in it),'commute_minutes':sum(minute(s['end'])-minute(s['start']) for s in trips),'lunch_order_at':lunch['start'],'meal_exit':it[3]['end'],'rest_minutes':75,'photo_appointment':[photo['start'],photo['end']],'return_at':trips[-1]['end'],'return_margin_minutes':1080-minute(trips[-1]['end']),'known_subtotal':[lo,hi],'contingency':[lo*.1,hi*.1],'known_total_including_contingency':[lo*1.1,hi*1.1],'assertions_completed':['positive durations','continuous nonoverlapping timeline','available window','60-minute meal in single service window including exit','last order','75-minute independent room rest','fixed photo appointment','four exact transfer durations','15-minute pre-photo buffer','per-person/package/car arithmetic'],'scope':'CPU constraint checks only; no rubric or self-grading'})
(OUT/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(checks,ensure_ascii=False,indent=2))

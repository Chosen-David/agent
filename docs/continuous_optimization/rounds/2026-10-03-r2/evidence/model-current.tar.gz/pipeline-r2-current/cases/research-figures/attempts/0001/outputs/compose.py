from style import *
from pathlib import Path
import panel_a,panel_b,json,csv
from PIL import Image
root=Path(__file__).resolve().parent
fig=plt.figure(figsize=(12,4.5))
a=fig.add_axes([.025,.12,.46,.74]); b=fig.add_axes([.575,.24,.40,.57])
arch=json.loads((root/"architecture.json").read_text()); rows=list(csv.DictReader((root/"measurements.csv").open()))
panel_a.draw(a,arch); panel_b.draw(b,rows)
for ext in ["svg","png"]:fig.savefig(root/("combined."+ext),dpi=200,facecolor="white")
fig.savefig(root/"combined_target_size.png",dpi=100,facecolor="white")
Image.open(root/"combined_target_size.png").convert("L").save(root/"combined_grayscale.png")

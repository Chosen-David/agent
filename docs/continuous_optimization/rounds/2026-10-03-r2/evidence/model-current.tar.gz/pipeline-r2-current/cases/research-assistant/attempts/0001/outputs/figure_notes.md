# FIG-T-v2

路线：pinned offline data_visualization；只用 matplotlib，未调用付费工具或外部范文。读者问题：收益是否随工作负载改变，kernel 是否可代表端到端。
设计：7.2×3.7 inch provisional；两面板明确区分 scope，DejaVu Sans 10pt，蓝/橙及斜线冗余编码，数值直接标注，图例图外，横轴为 ms 从零开始。不同面板范围明确披露。无聚合、平滑、删点或误差推断。
输入及 hash 见 loaded.json、checks.json；主源 analyze.py；导出 figure_v2.svg（可编辑文本）、figure_v2.png；灰度和页内预览同时输出。
视觉实查：第一轮发现图例覆盖 large 柱以及右面板 xlabel 裁切；移图例至下方、缩短轴标签后重绘。实际再次打开最终彩色、灰度、A4 整页嵌入预览：数值和轴标签完整，图例不遮数据，灰度斜线可辨，面板无重叠。未进行色觉模拟；无投稿目标，submission=unverified。
科学数值：四行全部保留；scope 分面；checks.json 记录执行公式断言。执行者 QA 不代替独立 reviewer 接受。
复现：在 outputs 中运行 `PYTHONDONTWRITEBYTECODE=1 python -B analyze.py`；脚本从相邻 case inputs 读取同一 CSV，不写输入。

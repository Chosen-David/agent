# 组织文档交付
本目录保存输入仓库的增量映射、目录说明与重组提案，目标文件未复制或变动。
源文件路径均相对于 inputs/organization。
实验代码与结果遵循同名 alpha/beta 配对；历史条目按原顺序保留。
参阅 [CODEMAP](CODEMAP.md) 和 [重组提案](docs/reorg_proposal_2026-10-03.md)。

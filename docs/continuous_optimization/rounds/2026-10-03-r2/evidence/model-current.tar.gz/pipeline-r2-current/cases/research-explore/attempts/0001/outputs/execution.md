# Actual execution record

Actor: /root/n14_explore. Scope: own research-explore case; no other cases, rubric, old runs, or controller metadata read.

1. Used `cat` to read the host worker protocol, own task.txt, pinned SKILL.md, references/execution.md and full references/workflow.md. Used `ls -la` on own inputs and start.json. Observed start.json present before any output creation; did not manufacture a host receipt.
2. Ran `python -B` to assert the start file exists, create only the existing attempt's outputs directory, and save loaded.json with SHA-256 hashes of the three actually read snapshot files. Then used `cat` to read manuscript.md and measurements.csv in full. Input hashes are in input_versions.json.
3. Wrote an editable standard-library CSV calculation script with `python -B`; executed:

```bash
python -B /workspace/scratch/643bcb955317/agent/.agent-runs/pipeline-r2-current/cases/research-explore/attempts/0001/outputs/analyze.py > /workspace/scratch/643bcb955317/agent/.agent-runs/pipeline-r2-current/cases/research-explore/attempts/0001/outputs/analysis.json
```

Observed: four positive baseline/candidate timing pairs; end-to-end speedups 1.25, 1.20, 0.90909; kernel-only 2.0. The script asserted that large is the sole observed end-to-end regression. Existing data were analyzed; no new experiment or independent performance observation was collected.
4. Used `python -B` to write the research brief, evidence map, hypothesis cards, bounded plan, task chain, handoff and capability selection record. JSON syntax in .yaml files is valid YAML 1.2 and is used to avoid an external YAML dependency.
5. Ran a final `python -B` structural check: parsed six structured artifacts, verified the five task IDs and topological dependency order, checked allowed statuses, and confirmed four rows plus the large +10% and kernel 2x arithmetic. All assertions completed without error. This is artifact validation, not scientific replication or independent review.

Limitations: no network, literature search, installation, GPU, subagents, benchmark, source inspection or quality/variance measurement. No images/PDFs were part of this case, so none were rendered. Future CPU measurements and mechanism interventions in research_plan.md are proposed and blocked on missing code, executable inputs, correctness contract and confirmed resources. The report distinguishes a bounded pivot decision from an inconclusive mechanism.

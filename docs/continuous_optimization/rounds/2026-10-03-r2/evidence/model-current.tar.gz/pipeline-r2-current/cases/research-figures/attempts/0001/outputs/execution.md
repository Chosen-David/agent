# Execution and whole-figure QA

Executed the pinned research-figures role for this attempt after reading the actual start.json. loaded.json records the snapshot resources actually read before writing figure sources. No network, external exemplars, installation, GPU or nested agents were used. All task deliverables are inside this attempt's outputs directory.

Real commands: `python -B panel_a.py`, `python -B panel_b.py`, `python -B compose.py`, and `python -B verify.py`. All exited 0. Matplotlib 3.10.8 generated SVG/PNG successfully; the runtime printed a read-only default cache warning and automatically used a temporary cache. This did not prevent rendering. checks.json records computed audit output, input hashes, all plotted widths, XML validation, unique SVG IDs, editable text and absence of raster images in final SVGs.

The actual tools.view_image calls opened combined_target_size.png and combined_grayscale.png during execution, followed by page_preview.png at 91% embedding width. At the final-size color preview, both panel titles and every node/bar label are legible; arrows land on the intended blocks without crossing labels; there is no visible clipping. The diagram has six nodes and five arrows, two parallel logit branches merging into z, then p and y, and a distinct direct V-to-y route. The numeric plot retains 100/80, 120/100, 200/220 and 20/10 ms, a zero origin, a clear kernel-only divider, and the unfavorable large result. The two bar series remain distinguishable by hatching in grayscale. At the 91% draft-page embedding scale, all values and labels remain readable and neither panel crowds the page boundary. No revision was necessary after viewing.

Before delivery, the worker explicitly requested a host image-tool observation. The parent actually opened combined_target_size.png and returned concrete observations in `../../../../../host/n06-final-view.json` (absolute path below). The worker read that record and verified its image SHA-256 matches the delivered preview. The parent observed readable panels without clipping/overlap, correct six-node/five-arrow topology with V bypass, every supplied numeric pair including large 220 > 200, and readable scope separation/legend/hatching. This is an actual requested host observation, not an invented independent model review.

Host proxy: /workspace/scratch/643bcb955317/agent/.agent-runs/pipeline-r2-current/host/n06-final-view.json

| QA dimension | Result | Evidence / limitation |
|---|---|---|
| Scientific and evidence distinction | pass | A explicitly proposed/schematic; B synthetic; caption does not claim B validates A |
| Numerical | pass | eight bar widths exactly equal eight CSV values; all four rows retained; zero-based ms axis |
| Semantic | pass | source edge list drives the five arrows; six source nodes; parallel branches and V bypass preserved |
| Typography / final size | pass | actual color and page-preview views; labels readable with no visible overflow |
| Hierarchy / whitespace | pass | left method/right result reading order, grouped nodes, room for scope labels and legend |
| Palette / accessibility | pass for grayscale | actual grayscale view; candidate hatching preserved; color-vision simulation not performed |
| Legend and annotation | pass | all values, units, synthetic status and latency direction explicit; legend outside bars |
| Technical | pass | SVG XML/IDs/text/vector checks; PNG render and real image opening |
| Reproducibility | pass | editable Python modules and SVGs, exact input snapshots, command sequence and hashes |
| Submission specification | unverified | no venue/template/required physical width supplied; dimensions are provisional |

The provisional whole figure is 12 × 4.5 inches; PNG is 2400 × 900 pixels (200 dpi), screen QA is 1200 × 450 (100 dpi). The draft page preview scales it to 10.9 inches wide on an A4-landscape-proportion canvas and is only a raster placement preview; combined.svg remains a vector composition. No uncertainty, significance or causal conclusion is inferred from this synthetic dataset.

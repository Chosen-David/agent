# CODE-READ N03：synthetic_selector.py 静态机制核查

## 范围与版本

- 唯一目标：`cases/code-reading/inputs/synthetic_selector.py`，30 行全部通过父任务只读工具代理取得。
- 目标 SHA-256：`6fc687e85d2c169c5dc88d7dc126b970036f22b822c00c9f8f0d8b628a6e8ea1`；初读前后相同。原始证据：`host/n03-source-read.json`，命令退出码 0。交付前通过 `host/n03-final-read.json` 再读 L6–30，退出码 0，前后哈希仍相同。
- 这是独立合成文件，无独立 Git commit、AGENTS 或局部技能（父任务提供的范围说明）。技能快照提交为 `a223ffca305cd7dac1b6b5195c04c532179b84a4`，不能把它冒充目标源码提交；源码身份使用上述文件哈希。
- 下文所有 L 行号均指该哈希对应的 `synthetic_selector.py`。没有导入、执行目标，也没有运行其测试。`source_fact` 指源码表达式，`static_inference` 指在所列前提下的静态推导；没有 `executed` 类型的机制或性能结论。

## 与模块叙述逐项对照

| ID / 类型 | 模块叙述 | 可达实现及修正 | 源码证据 |
|---|---|---|---|
| C1 source_fact | near 是强制窗口（L1） | near 是可排序、可截断的候选区；forced 独立构造，并在返回值末尾直接追加。near 候选可能一个都不选。 | select L19–20、L24–25 |
| C2 source_fact | skip 表示不评分（L1） | `skip_far` 只让 far 取空列表，跳过 far 排序及切片。此前 qsmall 和所有 keys 的 scores 已计算；near 仍排序，run 仍调用 full_score。 | select L21–25；run L29–30 |
| C3 source_fact | projector 是 query-trained（L2） | 默认固定取原向量第 0、2 个分量；可选 basis 由调用者提供，对 query 和每个 key 使用相同投影式。此文件没有训练、拟合、更新或 query 驱动构造 basis 的逻辑。外部 basis 是否训练过未知。 | represent L6–9；select L17、L21–22 |
| C4 source_fact | 最终评分使用 reduced keys（L2） | reduced 分数只决定候选位置；最终调用接收原始 query、keys 和 positions，从 keys[i] 取原始键计算内积。不会把 qsmall 或 reduced keys 传给 full_score。 | select L21–25；full_score L12–13；run L29–30 |
| C5 static_inference | budget 可理解为总输出限额 | 仅 near 的切片受剩余预算限制；far 和 forced 均先独立确定，随后拼接，故总数可以超过 budget。 | select L20、L23–25 |

“full”在这里表示使用原始表示，而非所有位置；而且 Python `zip` 会按短的一方截断。只有 query 与 keys[i] 维度相同时，L13 才等于预期的完整维度内积。

## 调用边：从 run 到最终输出

以下均为源码可解析的 `syntactic_call` / `resolved_target`，没有运行观测边。

| Caller → callee | 调用行 | 条件与消费 |
|---|---|---|
| run → select | L29 | `query, keys, **options` 转交；返回位置列表绑定为 positions。若调用或内部表达式抛错，L30 不可达。 |
| select → represent(query, basis) | L21 | 对所有成功进入的 select 调用均执行，独立于 skip_far。返回 qsmall。 |
| select → represent(k, basis) | L22 | 对 keys 中每个 k 执行；与 qsmall 做 zip 内积，生成 scores。 |
| select → sorted(far range) | L23 | 仅当 skip_far 为假；按 `-scores[i]` 升序，等价于按分数降序，取 `[:far_budget]`。 |
| select → sorted(near range) | L24 | 前序成功则执行；按同一分数降序。 |
| run → full_score | L30 | select 成功返回后必调用；原始 query、keys、选出的 positions 传入；返回值与 positions 组成二元组。 |

没有反射、注册表、FFI 或无法解析的内部调用。调用者传入对象的自定义运算行为不在这份普通数值序列分析的范围内。

## 数据边与表示

| 生产者 → 转换 → 消费者 | 表示与含义 | 证据 |
|---|---|---|
| query → represent → qsmall | 默认 `[query[0], query[2]]`，长度 2；basis 为非 None 时得到长度 `len(basis)` 的列表，每个元素是 query 与一个 column 的 zip 内积。 | L6–9、L21 |
| 每个原始 key → represent → 与 qsmall 内积 → scores[i] | 普通可重复遍历序列前提下，scores 长度 n；score 是候选选择分数，没有缩放、归一化或误差界。 | L18、L22 |
| n / near_len → boundary → far、near 范围 | 索引是原始 keys 的逻辑列表位置，没有物理槽映射。 | L19、L23–24 |
| forced_len → forced；scores → far / near；budget → near 截断 → positions | 输出按 far、被选 near、forced 三组拼接；不是全局分数排序，也没有去重。 | L20、L23–25 |
| positions + 原始 query/keys → full_score → 最终分数 | 对每个位置 i 计算原始表示的 zip 内积；分数顺序和 positions 一致。重复位置会重复计算及返回。 | L12–13、L30 |

实现使用 Python 列表和数值运算，没有声明 tensor shape、dtype、设备、量化、mask、softmax、batch 或 head 语义。不能把这些性质补成某个模型实现。basis 的 column 长度不足时也会被 zip 截断；若 basis 或 column 是一次性迭代器，重复消费可改变后续结果，源码没有保证其为可重复遍历矩阵。

## 配置、候选范围与预算

所有可选配置只在 `select` 的签名声明（L16–17），`run` 通过 `**options` 覆盖（L28–29）。未见环境变量、CLI 或配置文件消费路径。当前实际运行值全部 unknown，因为没有运行；下表给出的只是声明默认值。

| 配置 | 默认 | 实际消费与边界 |
|---|---:|---|
| near_len | 4 | `boundary=max(0,n-near_len)`（L19）。far 范围 `[0,boundary)`；near 范围 `[boundary,max(boundary,n-forced_len))`（L23–24）。这是范围，不是 near 的固定配额。 |
| forced_len | 1 | forced 为 `[max(0,n-forced_len),n)`（L20）。这些索引直接追加，不受 budget 再次截断（L25）。 |
| budget | 3 | 仅控制 near 的名额 `max(0,budget-len(forced)-len(far))`（L25）。 |
| far_budget | 1 | 仅对 far 排序结果切片（L23）；不与 budget 自动协调。 |
| skip_far | False | 真值只把 far 置空（L23）；不会跳过 L21–22、L24 或 L30。 |
| basis | None | None 路径固定选维；任何非 None 对象走显式投影式（L7–9），不自动训练或校准。空列表 basis 将产生空表示及零选择分数。 |

在非负整数配置、普通可重复遍历数值序列的前提下，令 F=forced，A=far，N=排序后的 near，r=max(0,budget-|F|-|A|)，则结果是 `A + N[:r] + F`。列表长度为 `|A|+min(|N|,r)+|F|`。如果 `|A|+|F|>budget`，超预算部分不会被删；如果候选不足，也没有从 far 补足预算的回填步骤。重复索引不减少列表长度。

默认参数且 n≥4 时，far 是 `[0,n-4)`，near 是 `[n-4,n-1)`，forced 为 `[n-1]`。当 n=4，far 为空；当 n>4，far 默认取一个，near 最多取一个，再加一个 forced。当 n≤3（合法输入维度仍需满足）时，far 为空，near 与 forced 合起来覆盖这些索引。n=0 时 forced 和最终位置列表为空，但 L21 仍先对 query 调 represent；默认 query 维度不足仍可在空 keys 时出错。

## 边界与反证（静态推导，未执行）

1. **跳过后仍评分**：`skip_far=True` 时，L21–22 在 L23 分支前就执行；run 仍达 L30。因此“不评分”叙述不成立。该开关可能释放 near 的名额，但不保证消除评分成本。
2. **预算不是硬上限**：取 n=6、合法长度向量、`budget=0`，其余默认。far 仍取一个，forced 仍为 `[5]`，near 名额归零；返回列表长度是 2。这是表达式推导，不是实际测试输出。
3. **强制范围可能与 far 重叠**：若 n=6、near_len=1、forced_len=3，则 boundary=5，far 范围 `[0,5)`，forced 为 `[3,4,5]`。当 far 选中 3 或 4 时，同一位置会重复出现；L25 无去重。这也说明任意可选配置下不能声称三区天然互斥。
4. **稳定排序与顺序**：普通数值分数且没有 NaN 的情形下，同分项保留 range 的升序位置顺序；最终列表仍按三组拼接，不按全局分数排序。原始 full_score 不参与第二次重排。
5. **维度/配置未校验**：默认 represent 要求 vector 至少有第 2 个元素，否则索引错误；最终 zip 不验证维度相等。负 far_budget 使用 Python 的负切片含义而非零名额。负 near_len 或 forced_len 等配置可能构造越界候选并在 scores[i] 处出错；非整数范围或切片参数也可能抛错。源码未提供回退。
6. **没有分数界保证**：默认选维内积一般不能称为完整内积的 lower bound；遗漏维度的乘积可能为正或负。basis 分支也没有误差界或训练性质声明可证明其精度。

## 未知项、覆盖与验证状态

| 项目 | 状态 | 限制 / 最小后续验证 |
|---|---|---|
| run、select、represent 两分支、full_score 的源码链 | inspected | 已覆盖唯一文件全部 30 行；结论止于静态可达实现。 |
| 默认及覆盖参数、skip 分支、强制集、预算、最终消费者 | inspected | 当前实际配置与数据 unknown。 |
| basis 来源、是否离线校准或 query 训练、数值质量 | unknown | 需要调用者构造 basis 的源码或绑定输入日志；本文件不能证明。 |
| 输入实际维度、dtype、数值、NaN 与容器类型 | unknown | 需要明确输入契约；zip 截断和迭代器行为须按契约判断。 |
| 运行正确性、性能、后端/模型适用性 | not executed | 本任务禁止执行目标；没有时间、准确率或模型泛化结论。另获执行授权后可用最小 CPU 例核对预算溢出、重叠和空输入。 |
| 外部调用者与其他入口 | unresolved outside scope | 仅提供该单文件；不能宣称覆盖真实仓库或所有模型。 |

这是作者自查，不是独立审阅。代理记录证明已观察到的只读命令及其结果，不能宣称提供操作系统隔离或证明不存在任何未观察到的操作。

"""CPU-only aggregation of supplied synthetic measurements; no benchmarks."""
from pathlib import Path
from fractions import Fraction
from statistics import median
from collections import defaultdict
import csv
import hashlib
import json
import platform
import sys

OUT = Path(__file__).resolve().parent
INPUT = OUT.parents[2] / 'inputs'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

project = json.loads((INPUT / 'chain_project.json').read_text())
schema = json.loads((INPUT / 'handoff_fields.json').read_text())
with (INPUT / project['data']).open(newline='') as f:
    raw = list(csv.DictReader(f))
groups = defaultdict(list)
seen = set()
workloads = []
for row in raw:
    assert row['input_version'] == project['input_version']
    assert row['scope'] == 'end_to_end'
    assert row['variant'] in ('baseline', 'candidate')
    key = (row['workload'], row['variant'], int(row['repeat']))
    assert key not in seen, f'duplicate: {key}'
    seen.add(key)
    value = Fraction(row['latency_ms'])
    assert value > 0
    groups[key[:2]].append(value)
    if row['workload'] not in workloads:
        workloads.append(row['workload'])

aggregate = []
findings = []
exact = []
for row_number, workload in enumerate(workloads, 2):
    b = groups[(workload, 'baseline')]
    c = groups[(workload, 'candidate')]
    assert len(b) == len(c) == project['measurement_conditions']['repeats_per_variant']
    assert {key[2] for key in seen if key[:2] == (workload, 'baseline')} == {1,2,3}
    assert {key[2] for key in seen if key[:2] == (workload, 'candidate')} == {1,2,3}
    bm, cm = median(b), median(c)
    ratio = bm / cm
    reduction = 100 * (bm - cm) / bm
    values = [workload, len(b), len(c), float(bm), float(cm), float(ratio), float(reduction)]
    aggregate.append(dict(zip(schema['aggregate_csv_columns'], values)))
    direction = '降低' if reduction > 0 else '增加'
    findings.append({'id': f'LATENCY-{workload.upper()}', 'workload_rows': [{'file':'aggregate.csv','row':row_number,'workload':workload}], 'evidence_type':'synthetic descriptive arithmetic', 'finding': f'在提供的 synthetic-v3 合成端到端延迟中，{workload} 的 baseline/candidate 中位延迟为 {float(bm):g}/{float(cm):g} ms；speedup ratio = {float(ratio):.9g}，延迟降幅 = {float(reduction):.9g}%，即延迟{direction} {abs(float(reduction)):.9g}%。每版本仅 3 个提供值。', 'speedup_ratio':float(ratio), 'latency_reduction_pct':float(reduction)})
    exact.append({'workload':workload,'baseline_median_ms':str(bm),'candidate_median_ms':str(cm),'speedup_ratio':str(ratio),'latency_reduction_pct':str(reduction)})

with (OUT / 'aggregate.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=schema['aggregate_csv_columns'], lineterminator='\n')
    writer.writeheader()
    writer.writerows(aggregate)

source_files = [{'path': name, 'sha256': sha(INPUT/name)} for name in ['chain_project.json','chain_latencies.csv','handoff_fields.json']]
analysis = {
    'schema_version': 1,
    'project_id': project['project_id'],
    'input_version': project['input_version'],
    'source_files': source_files,
    'source_path_resolution': 'Source paths are filenames relative to the supplied coordinator inputs directory; the host must retain these source hashes when moving the handoff.',
    'aggregate_file': {'path':'aggregate.csv','sha256':sha(OUT/'aggregate.csv')},
    'aggregate_path_resolution': 'Relative to analysis.json; host copies both files unchanged into writer inputs.',
    'formulas': schema['formulas'],
    'findings': findings,
    'limitations': [
        '全部数据是离线评估合成数据，不是真实模型或 GPU 实验；本次 CPU 仅执行算术分析，没有新 benchmark。',
        '每个工作负载每版本只有 3 个给定值；重复的独立性、采样机制和配对设计未说明，仅报告描述性中位数，不声称统计显著性或总体效果。',
        '硬件未指定，不能推广至真实硬件、其他系统或全部工作负载。',
        '质量指标未提供，不能主张质量保持、准确率不变或整体系统优越性。',
        '提供的是端到端延迟，无法归因于缓存机制、某个 kernel 或组件。',
        '不同工作负载有改善也有退化，不能宣称全面加速；没有定义跨工作负载权重，因此不生成总体平均 speedup。',
        '历史正文和背景原文未提供；旧工作处置仅依据 chain_project.json 的描述及当前重算，不能声称已逐字审阅历史产物。'
    ],
    'invalidated_work':['WRITE-OLD'],
    'retained_work':['BACKGROUND-1'],
    'previous_work_assessment': {
        'WRITE-OLD': {'status':'invalidated','reason':'旧文绑定 synthetic-v2，且声称每工作负载至少 1.8x；v3 三行均低于 1.8x，medium 低于 1，故该性能结论失效。不得搬用旧数字或全面加速叙述。'},
        'BACKGROUND-1': {'status':'retained_scope_only','reason':'baseline/candidate 比较定义据项目记录独立于延迟值，可以保留这一概念范围；未提供背景正文，不将历史 complete 声明视为当前产物验收。'}
    },
    'runtime': {'mode':'bounded foreground CPU execution via actual parent tool proxy','background_monitor_started':False,'monitor_id':None,'scheduler_readback':None,'persistent_supervision_status':'not started; no current-chain live scheduler or action-adapter receipt observed; deployment forbidden in this task','external_runtime_availability':'unverified; no installation or network probe performed'},
    'next_owner':'writer (host dispatch)',
    'next_step':'先校验 analysis.json 所记录的 aggregate.csv SHA256；缺文件或 hash 不一致则阻塞写作。仅据本轮合成数据撰写中文 Results 段落和英文摘要，明确 medium 退化及限制；本节点未代写。'
}
required=schema['analysis_json_required']
assert all(k in analysis for k in required)
save_json(OUT/'analysis.json', analysis)

verification = {'input_rows':len(raw),'workload_count':len(workloads),'duplicate_rows':0,'missing_values':0,'excluded_rows':0,'scope':'end_to_end','unit':'ms','exact_fraction_results':exact,'python':sys.version,'platform':platform.platform(),'aggregate_sha256':sha(OUT/'aggregate.csv'),'analysis_sha256':sha(OUT/'analysis.json'),'schema_required_fields_present':True,'aggregate_columns_match':list(aggregate[0]) == schema['aggregate_csv_columns']}
save_json(OUT/'cpu_results.json', verification)
print(json.dumps({'verification':verification,'aggregate':aggregate,'source_files':source_files}, ensure_ascii=False, indent=2))

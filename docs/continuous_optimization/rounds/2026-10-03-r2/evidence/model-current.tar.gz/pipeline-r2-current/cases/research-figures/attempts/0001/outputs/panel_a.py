from style import *
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import json
from pathlib import Path

def draw(ax, arch):
    ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis("off")
    ax.text(0,1.04,"A",fontsize=15,fontweight="bold",transform=ax.transAxes)
    ax.text(.07,1.04,"Proposed method",fontsize=12,fontweight="bold",transform=ax.transAxes)
    ax.text(0,.97,"Schematic • synthetic specification",fontsize=9,color="#637080")
    pos={"a":(.19,.76),"b":(.19,.48),"sum":(.49,.62),"softmax":(.81,.62),"v":(.49,.23),"output":(.81,.23)}
    w,h=.26,.17
    labels={"a":"Path A logits a","b":"Path B logits b","sum":"z = a + b","softmax":"p = softmax(z)","v":"Fixed values V","output":"y = pᵀ V"}
    for node in arch["nodes"]:
        x,y=pos[node["id"]]
        ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle="round,pad=0.007,rounding_size=0.018",edgecolor=BLUE,facecolor="#EFF6F8",lw=1.15))
        ax.text(x,y,labels[node["id"]],ha="center",va="center",fontsize=10)
    for src,dst in arch["edges"]:
        x,y=pos[src]; xx,yy=pos[dst]
        if src in ["a","b"]: start=(x+w/2+.01,y); end=(xx-w/2-.01,yy)
        elif src=="softmax": start=(x,y-h/2-.01); end=(xx,yy+h/2+.01)
        else: start=(x+w/2+.01,y); end=(xx-w/2-.01,yy)
        ax.add_patch(FancyArrowPatch(start,end,arrowstyle="-|>",mutation_scale=11,lw=1.2,color=INK))
    ax.text(.19,.30,"Parallel paths",ha="center",fontsize=9,color="#637080")
    ax.text(0,.03,"Arrows: data flow. V enters the output only.",fontsize=9,color="#637080")
if __name__=="__main__":
    root=Path(__file__).resolve().parent
    fig,ax=plt.subplots(figsize=(6,4.5)); fig.subplots_adjust(left=.045,right=.98,bottom=.08,top=.87)
    draw(ax,json.loads((root/"architecture.json").read_text()))
    for ext in ["svg","png"]:fig.savefig(root/("panel_a."+ext),dpi=200,facecolor="white")

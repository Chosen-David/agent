# docs
本交付目录保存只读盘点后的重组提案，不含源仓库改动。
提案按 reorg_proposal_YYYY-MM-DD.md 命名。
参阅 [CODEMAP](../CODEMAP.md) 和 [本次提案](reorg_proposal_2026-10-03.md)。

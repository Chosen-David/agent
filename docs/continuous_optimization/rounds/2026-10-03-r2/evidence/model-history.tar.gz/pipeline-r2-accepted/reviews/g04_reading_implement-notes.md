# Independent review: /root/g04_reading_implement

Scope: pipeline-r2-accepted frozen artifacts for smoke-main-route, paper-reading-companion and research-implement-optimize. Read full tasks, relevant inputs, all collected text/source artifacts (HTML image base64 decoded rather than printed), load accounts, collection and host dispatch/completion records. Did not edit collected outputs or inputs, use network, install anything, or create nested agents.

## Actual checks

- Recomputed every collection output hash across the three cases. Recomputed reading-case declared snapshot hashes and implementation input hashes; all matched. Hash consistency proves correspondence, not historical process or hard isolation.
- Independently rendered all two smoke PDF pages and all three companion PDF pages into reviews/g04-assets; opened each original through view_image. Opened the collected smoke page-2 PNG and all three companion PNGs. Sparse original text, numbers, headings, physical/printed numbering and claims agree with explanations.
- Opened the host-provided corrected desktop.png and mobile.png for both readers. Desktop layout has original on left, readable Chinese explanation on right; mobile stacks the original above the explanation with wrapping controls. Initial page is 2. Small source text on mobile can use the supplied zoom controls; no new visual defect found. These screenshots used the host temporary Noto font according to the controller; no HTML change claimed. I did not launch the browser myself. Read both browser.json records: Chromium 154, HTTP(S) blocked, empty errors/external requests, loaded image, pageSelect 2.
- Read complete HTML/JS/CSS, decoded embedded PNGs, compared every embedded page pixel-for-pixel with fresh input renders at 120 DPI. Verified notes equal embedded cards, hashes match actual PDFs, no external asset/network dependency or live model backend. Clipboard/button runtime was not separately tested by me.
- Independently recomputed exact rational means for forward/reverse/equal sequences and Python softmax for baseline/change/common shift; calculations agree within floating precision.
- Actually ran supplied implementation suite with python -B against repaired code: four methods pass. Same hand-computed suite against original: eight failures, exit 1. Ran independently constructed 8201 exhaustive valid combinations, invalid-window checks, no-mutation/output-identity checks. All pass. Preserved results under reviews/g04-assets.
- Recomputed all four CSV speedups/reductions with Fraction. Large regression is correctly retained; kernel-only scope and absent GPU/benchmark evidence are explicit.

## Verdicts and limits

Six pass, three ungradable, no observed substantive fail. Smoke criterion 1 is ungradable because actual worker workflow-loading trace is unavailable. Smoke criterion 2 is ungradable only for its literal historical read/render clause; mathematics, source correspondence and images pass artifact review. Implementation criterion 2 is ungradable only for literal historical worker test execution; independent reviewer execution and current input integrity are verified. Executor loaded.json/execution.md/logs are accounts, not direct observed historical tools. Controller-supplied start/completion receipts substantiate dispatched separate contexts and produced delivery only; no raw full transcript is available. No cryptographic execution attestation or hard isolation claim is made. Host browser observations independently establish opening behavior and are attributed to the host rather than the worker.

These reviews concern this frozen historical run, not subsequently changed main or a new checkpoint. Reviews were written outside outputs; grades were not imported.

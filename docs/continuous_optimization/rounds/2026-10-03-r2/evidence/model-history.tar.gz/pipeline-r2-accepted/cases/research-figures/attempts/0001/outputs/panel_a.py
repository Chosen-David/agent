from style import *
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import json

def draw(ax):
    spec=json.loads((ROOT/'architecture.json').read_text())
    ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
    ax.text(0,1.02,'A',fontsize=13,fontweight='bold',transform=ax.transAxes)
    ax.text(.075,1.025,'Two-path logit combination',fontsize=11,fontweight='bold',transform=ax.transAxes)
    ax.text(0,.965,'PROPOSED  /  SYNTHETIC SPECIFICATION',fontsize=7.5,color='#677580')
    pos={'a':(.25,.80),'b':(.75,.80),'sum':(.5,.58),'softmax':(.5,.37),'v':(.80,.15),'output':(.29,.15)}
    sizes={'a':(.43,.13),'b':(.43,.13),'sum':(.40,.13),'softmax':(.47,.13),'v':(.37,.13),'output':(.41,.13)}
    labels={'a':'Path A logits a','b':'Path B logits b','sum':'z = a + b','softmax':'p = softmax(z)','v':'Fixed values V','output':'y = pᵀV'}
    for node in spec['nodes']:
        k=node['id'];x,y=pos[k];w,h=sizes[k]
        face='#E7F1F7' if k in ['a','b','sum','softmax','output'] else '#F0F2F3'
        p=FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=0.008,rounding_size=0.018',linewidth=1,edgecolor=BLUE if k!='v' else '#788793',facecolor=face)
        p.set_gid('node_'+k);ax.add_patch(p);ax.text(x,y,labels[k],ha='center',va='center',fontsize=9)
    endpoints={('a','sum'):((.25,.727),(.39,.653)),('b','sum'):((.75,.727),(.61,.653)),('sum','softmax'):((.5,.507),(.5,.443)),('softmax','output'):((.46,.297),(.34,.223)),('v','output'):((.607,.15),(.503,.15))}
    for s,t in spec['edges']:
        p,q=endpoints[(s,t)]
        arrow=FancyArrowPatch(p,q,arrowstyle='-|>',mutation_scale=10,lw=1.25,color=INK,connectionstyle='arc3',shrinkA=0,shrinkB=0)
        arrow.set_gid('edge_'+s+'_'+t);ax.add_patch(arrow)
    ax.text(0,.005,'Arrows: data flow • schematic; not implemented',fontsize=7.7,color='#677580')
    assert len(spec['nodes'])==6 and len(spec['edges'])==5
    assert set(endpoints)=={tuple(e) for e in spec['edges']}
if __name__=='__main__':
    fig=plt.figure(figsize=(4,3.6));draw(fig.add_axes([.055,.06,.9,.86]));export(fig,'panel_a')

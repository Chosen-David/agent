"""Analyze supplied measurements; this script performs no timing experiment."""
import csv
import json
from pathlib import Path
import sys

source = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("measurements.csv")
rows = []
with source.open(newline="") as stream:
    for row in csv.DictReader(stream):
        baseline = float(row["baseline_ms"])
        candidate = float(row["candidate_ms"])
        rows.append(dict(row, speedup=baseline/candidate if baseline > 0 and candidate > 0 else None,
                         latency_reduction_pct=100*(baseline-candidate)/baseline if baseline > 0 else None))
print(json.dumps({"source":str(source), "measurement_origin":"supplied CSV, not measured in this execution",
                  "rows":rows, "aggregation":"None: workload weights and repetitions are unspecified."}, indent=2))

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253341','text.color':'#253341','xtick.color':'#253341','ytick.color':'#253341','axes.edgecolor':'#9CA7AF','savefig.facecolor':'white'})
BLUE='#2876A5'; ORANGE='#C16A31'; INK='#253341'
def export(fig,name):
    fig.savefig(ROOT/(name+'.svg'))
    fig.savefig(ROOT/(name+'.png'),dpi=300)

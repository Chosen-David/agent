from style import *
import csv
import numpy as np

def draw(ax):
    rows=list(csv.DictReader((ROOT/'measurements.csv').open()))
    y=np.arange(len(rows)); base=np.array([float(r['baseline_ms']) for r in rows]);candidate=np.array([float(r['candidate_ms']) for r in rows])
    ax.set_ylim(3.75,-.7);ax.set_xlim(0,252)
    ax.axhspan(2.55,3.55,color='#F0F2F3',zorder=0)
    ax.barh(y-.16,base,height=.26,color=BLUE,label='Baseline',zorder=3)
    ax.barh(y+.16,candidate,height=.26,color=ORANGE,label='Candidate',hatch='///',edgecolor='white',linewidth=.3,zorder=3)
    for j,(b,c) in enumerate(zip(base,candidate)):
        ax.text(b+3,j-.16,f'{b:g}',va='center',fontsize=8)
        ax.text(c+3,j+.16,f'{c:g}',va='center',fontsize=8)
    ax.set_yticks(y,['Small','Medium','Large','Kernel only'])
    ax.tick_params(axis='y',length=0,pad=7)
    ax.set_xticks([0,50,100,150,200,250]);ax.set_xlabel('Runtime (ms) • lower is better',labelpad=7)
    ax.spines['left'].set_visible(False);ax.grid(axis='x',color='#E4E8EB',lw=.6,zorder=0)
    ax.text(-.21,1.165,'B',fontsize=13,fontweight='bold',transform=ax.transAxes)
    ax.text(-.11,1.17,'Provided runtime results',fontsize=11,fontweight='bold',transform=ax.transAxes)
    ax.text(-.21,1.105,'Small–large: end-to-end; kernel: kernel only',fontsize=7.6,color='#677580',transform=ax.transAxes)
    ax.legend(loc='lower left',bbox_to_anchor=(-.03,-.37),frameon=False,ncol=2,fontsize=8.3,handlelength=1.5,columnspacing=1.8)
    return {'rows':rows,'plotted_baseline_ms':base.tolist(),'plotted_candidate_ms':candidate.tolist(),'candidate_change_percent':((candidate/base-1)*100).tolist(),'missing_cells':sum(v=='' for row in rows for v in row.values())}
if __name__=='__main__':
    fig=plt.figure(figsize=(4,3.6));draw(fig.add_axes([.22,.25,.70,.57]));export(fig,'panel_b')

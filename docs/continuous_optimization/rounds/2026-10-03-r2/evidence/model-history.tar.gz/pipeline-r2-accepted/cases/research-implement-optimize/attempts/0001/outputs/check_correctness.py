"""Independent CPU oracle: streaming windows and exact rational arithmetic."""
from collections import deque
from fractions import Fraction
import importlib.util
from pathlib import Path
import random
import sys
import unittest

MODULE = Path(sys.argv.pop(1)) if len(sys.argv) > 1 else Path(__file__).with_name("buggy.py")
spec = importlib.util.spec_from_file_location("subject", MODULE)
subject = importlib.util.module_from_spec(spec)
spec.loader.exec_module(subject)
moving_average = subject.moving_average


def oracle(values, window):
    queue = deque()
    result = []
    for value in values:
        queue.append(Fraction(value))
        if len(queue) > window:
            queue.popleft()
        if len(queue) == window:
            result.append(float(sum(queue, Fraction(0)) / window))
    return result


class Checks(unittest.TestCase):
    def check_case(self, values, window, expected):
        before = list(values)
        actual = moving_average(values, window)
        self.assertEqual(actual, expected)
        self.assertEqual(list(values), before, "input was mutated")
        self.assertIsNot(actual, values)
        self.assertEqual(len(actual), max(0, len(values) - window + 1))

    def test_boundaries_and_hand_computed(self):
        for values, window, expected in [
            ([], 1, []), ([], 10, []), ([5], 1, [5.0]),
            ([1, 2, 3], 2, [1.5, 2.5]), ([1, 2, 3], 3, [2.0]),
            ([1, 2, 3], 4, []), ([1, 2, 3], 1, [1.0, 2.0, 3.0]),
            ([-3, 0, 9, -6], 2, [-1.5, 4.5, 1.5]),
            ([0, 0, 0], 2, [0.0, 0.0]),
            ([0.25, 0.5, 0.75], 2, [0.375, 0.625]),
            ((2, 4, 8), 2, [3.0, 6.0]),
        ]:
            with self.subTest(values=values, window=window):
                self.check_case(values, window, expected)

    def test_random_against_exact_streaming_reference(self):
        rng = random.Random(20261003)
        count = 0
        for n in range(51):
            values = [rng.randint(-10000, 10000) for _ in range(n)]
            for window in range(1, n + 3):
                with self.subTest(n=n, window=window):
                    self.check_case(values, window, oracle(values, window))
                count += 1
        self.assertEqual(count, 1377)

    def test_invalid_windows_and_no_mutation(self):
        for window, error in [(0, ValueError), (-1, ValueError), (-100, ValueError),
                              (1.5, TypeError), (2.0, TypeError), ("2", TypeError),
                              (None, TypeError), (True, TypeError), (False, TypeError)]:
            for values in ([], [1, 2, 3]):
                with self.subTest(window=window, values=values):
                    before = values.copy()
                    with self.assertRaises(error):
                        moving_average(values, window)
                    self.assertEqual(values, before)

    def test_integer_index_protocol(self):
        class Window:
            def __index__(self):
                return 2
        self.assertEqual(moving_average([2, 4, 8], Window()), [3.0, 6.0])


if __name__ == "__main__":
    unittest.main(verbosity=2)

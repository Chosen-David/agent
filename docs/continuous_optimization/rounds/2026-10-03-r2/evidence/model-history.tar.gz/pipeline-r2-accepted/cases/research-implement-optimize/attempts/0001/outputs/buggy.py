"""Corrected moving-average implementation, retaining the public signature."""
import operator


def moving_average(values, window):
    """Return all full consecutive-window means; positive integer window required.
    A window longer than the input returns []; never mutate values.

    Non-integer windows (including bool) raise TypeError; nonpositive integers
    raise ValueError. Integer-like objects implementing __index__ are accepted.
    Values must support len() and slicing, as in the original interface.
    """
    if isinstance(window, bool):
        raise TypeError("window must be a positive integer")
    window = operator.index(window)
    if window <= 0:
        raise ValueError("window must be a positive integer")
    return [sum(values[i:i + window]) / window
            for i in range(len(values) - window + 1)]

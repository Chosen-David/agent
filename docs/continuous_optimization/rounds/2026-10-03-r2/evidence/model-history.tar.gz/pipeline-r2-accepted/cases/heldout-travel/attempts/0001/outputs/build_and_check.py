from pathlib import Path
import json,datetime,copy
O=Path(__file__).resolve().parent
P=O.parents[2]/'inputs/travel_revision.json'
x=json.loads(P.read_text()); now=datetime.datetime.now(datetime.timezone.utc).isoformat()
def stamp(t):return x['date']+'T'+t+':00+08:00'
def mins(t):return int(t[:2])*60+int(t[3:])
def write(n,v): (O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def price(lo,hi,unit,q=1,original=None):
 d={'min':lo,'max':hi,'currency':'CNY','unit':unit,'quantity':q,'includes':[],'excludes':[],'source_status':'reference','checked_at':now}
 if original:d['original_unit']=original
 return d
entities={'hotel':('Hotel K','11 Fiction Lane'),'lunch':('Bistro M','29 Fiction Lane'),'photo':('Studio N','8 Example Avenue')}
common=[('out_lunch','transfer','10:20','10:35',None,[]),('wait_lunch','buffer','10:35','10:45',None,[]),('lunch','activity','10:45','11:35','lunch',['lunch']),('exit_lunch','buffer','11:35','11:40',None,[]),('back_lunch','transfer','11:40','11:55',None,[])]
schedules={1:common+[('settle_rest','buffer','11:55','12:00',None,[]),('rest','rest','12:00','13:30','hotel',['hotel rest']),('hotel_free','buffer','13:30','15:40',None,[]),('out_photo','transfer','15:40','16:00',None,[]),('entry_photo','buffer','16:00','16:20',None,[]),('photo','activity','16:20','17:05','photo',['photo']),('exit_photo','buffer','17:05','17:10',None,[]),('back_photo','transfer','17:10','17:30',None,[]),('finish_margin','buffer','17:30','17:50',None,[])],2:common+[('hotel_free','buffer','11:55','12:40',None,[]),('out_photo','transfer','12:40','13:00',None,[]),('entry_photo','buffer','13:00','13:20',None,[]),('photo','activity','13:20','14:05','photo',['photo']),('exit_photo','buffer','14:05','14:10',None,[]),('back_photo','transfer','14:10','14:30',None,[]),('settle_rest','buffer','14:30','14:35',None,[]),('rest','rest','14:35','16:05','hotel',['hotel rest']),('finish_margin','buffer','16:05','17:50',None,[])]}
unknowns=[{'unknown_id':'u-weather','content':'城市和天气未提供；无户外必需活动，未作真实天气核查。','owner':'future traveler confirmation'}, {'unknown_id':'u-operations','content':'实际等位、叫车候车、拥堵、上下客点和楼层未知；合成路线分钟数的包含项未说明。日程另加缓冲，不将其称为实测全程。','owner':'future traveler confirmation'}, {'unknown_id':'u-photo-extras','content':'摄影45分钟是否含额外化妆换装、附加收费/改约费均未给；按输入预约全时段和188元双人套餐排程，额外项不当作零。','owner':'future traveler confirmation'}, {'unknown_id':'u-paid','content':'除酒店已预付外，午餐和摄影是否已付款未知；预算为消费口径而非确定待付款余额。','owner':'user'}, {'unknown_id':'u-budget','content':'预算上限未提供；可核算但不能判断是否超预算。','owner':'user'}]
facts=[]
for k,val in [('hotel',x['hotel']),('lunch',x['lunch']),('routes',x['routes']),('rest',x['rest'])]:
 facts.append({'fact_id':'f-'+k,'entity_id':k,'claim':'用户提供的合成事实','value':val,'applies_on':x['date'],'timezone':x['timezone'],'source_ids':['input'],'checked_at':now,'status':'user_confirmed'})
for r in (1,2):
 appointment=x['photo']['appointment'] if r==1 else x['amendment']['photo_appointment']
 b={'schema_version':'local-travel/v1','trip_id':'heldout-travel-synthetic-20261108','revision':r,'as_of':now}
 b['request_contract']={'trip_brief':{'destination':'Synthetic locations; city unspecified','timezone':x['timezone'],'dates':{'start':x['date'],'end':x['date']},'people':2,'anchor':{'kind':'hotel','entity_id':'hotel'},'arrival':stamp('10:20'),'departure':stamp('17:50'),'budget':{'min':None,'max':None,'currency':'CNY','scope':x['budget_scope']},'rest_preferences':{'default_enabled':True,'midday_minutes':90,'needs_room':True,'walking_tolerance':'Both travelers have knee discomfort; taxi for every transfer'},'assumptions':['仅合成输入；无真实营业核验或预订','预约45分钟作为摄影完整活动；候车和入场等未给，另设规划缓冲']},'hard_constraints':[{'constraint_id':'hc-'+k,'content':v,'source':'input','user_confirmed':True} for k,v in [('time','10:20从Hotel K开始，17:50前返回'),('photo',appointment),('taxi',x['transport_constraint']),('rest',x['rest']),('meal','午餐50分钟在10:45–12:15单一窗口内，11:30前下单')]],'desired_intents':[{'intent_id':k,'goal':k,'must_do':True,'acceptance':'完整独立时间块、符合输入窗口'} for k in x['must_do']],'soft_preferences':[],'unknowns':unknowns,'acceptance_criteria':['无重叠','每段出租车按输入分钟数','独立连续90分钟酒店午休','原版/改版预约准确','双人费用单位不重复乘人','17:50前回酒店']}
 b['research_queries']=[{'query_id':'q-input','owner':'single planner','intent_id':None,'entity_scope':list(entities),'required_fields':['service_windows','appointment','rest','routes','prices'],'preferred_sources':['input'],'fallback_sources':[],'done_when':'输入范围已读取并标未知','status':'COMPLETED','input_revision':r}]
 b['capabilities']=[{'name':'local Python and file tools','verified':'read fixture and execute arithmetic/time assertions','permissions':'read relevant local inputs; write outputs only','limits':'no network, real bookings or backend'}]
 b['sources']=[{'source_id':'input','url':None,'source_type':'user_provided_synthetic_fixture','path':str(P),'published_at':None,'checked_at':now,'access_scope':'full','scope':'synthetic task only'}]
 b['facts']=copy.deepcopy(facts)+[{'fact_id':'f-photo-r'+str(r),'entity_id':'photo','claim':'用户确认摄影预约','value':{'appointment':[stamp(t) for t in appointment],'price':188,'original_unit':'per_group'},'applies_on':x['date'],'timezone':x['timezone'],'source_ids':['input'],'checked_at':now,'status':'user_confirmed'}]
 b['experiences']=[];b['weather']=[]
 b['candidates']=[]
 for k,(name,addr) in entities.items():
  pr=price(78,78,'per_person',2) if k=='lunch' else price(188,188,'per_package',1,'per_group') if k=='photo' else None
  c={'candidate_id':k,'entity_id':k,'kind':k,'name':name,'navigable_address':addr,'intent_ids':['hotel rest' if k=='hotel' else k],'fact_ids':['f-'+k if k!='photo' else 'f-photo-r'+str(r)],'price':pr,'duration_minutes':90 if k=='hotel' else 50 if k=='lunch' else 45,'admission':'admitted','unknowns':['u-operations'],'scope':'admitted only against synthetic supplied facts'}
  if k=='lunch':c.update(service_windows=[{'open':stamp(a),'close':stamp(z)} for a,z in x['lunch']['service_windows']],break_windows=[{'open':stamp('12:15'),'close':stamp('17:30')}],last_order=stamp('11:30'))
  b['candidates'].append(c)
 b['selection_plan']=[{'intent_id':i,'primary':k,'alternatives':[],'fallbacks':[],'basis':'用户指定唯一候选，不凑其他商家','conditions':'限合成事实'} for i,k in [('lunch','lunch'),('photo','photo'),('hotel rest','hotel')]]
 b['itinerary']=[{'slot_id':a,'kind':k,'candidate_id':c,'intent_ids':ints,'start':stamp(s),'end':stamp(e),'conditions':'规划缓冲非实测' if k=='buffer' else '按合成输入','fact_dependencies':['f-routes'] if k=='transfer' else ['f-photo-r'+str(r)] if c=='photo' else ['f-'+c] if c else []} for a,k,s,e,c,ints in schedules[r]]
 b['commutes']=[]
 for cid,route in zip(['out_lunch','back_lunch','out_photo','back_photo'],x['routes']):
  def location(n):return next({'name':name,'address':addr,'entrance':None} for name,addr in entities.values() if name==n)
  b['commutes'].append({'commute_id':cid,'from':location(route['from']),'to':location(route['to']),'mode':'one shared taxi','route':'按指定地址点对点；道路、门口上下客点未提供，不虚构','duration_minutes':{'min':route['minutes'],'max':route['minutes']},'duration_scope':'输入固定转场时长；候车包含情况未知，缓冲另列','price':price(*route['price_cny_range'],'per_car',1,'per_vehicle'),'people':2,'source_ids':['input'],'status':'user_confirmed','reason':'两人膝部不适且要求所有转场共乘一辆出租车','alternatives':[]})
 b['budget']={'currency':'CNY','scope':x['budget_scope'],'items':[{'item':'lunch','price':price(78,78,'per_person',2),'subtotal':[156,156]},{'item':'photo','price':price(188,188,'per_package',1,'per_group'),'subtotal':[188,188]}]+[{'item':c['commute_id'],'price':c['price'],'subtotal':[c['price']['min'],c['price']['max']]} for c in b['commutes']], 'transport_subtotal':[72,92],'base_total':[416,436],'contingency':{'rate':0.10,'range':[41.6,43.6],'status':'planning assumption; not a supplied fee'},'with_contingency':[457.6,479.6],'suggested_rounded_reserve':[458,480],'prepaid_excluded':['Hotel K room; amount unknown'],'unknown_not_zero':['possible additional services or fees not supplied'],'paid_status':'Only hotel known prepaid; other payment status unknown'}
 b['intent_coverage']=[{'intent_id':i,'slot_ids':[k],'outcome':'satisfied','evidence':'符合输入完整时段；仅合成范围'} for i,k in [('lunch','lunch'),('photo','photo'),('hotel rest','rest')]]
 b['open_questions']=[{'unknown_id':u['unknown_id']} for u in unknowns]
 b['change_log']=[] if r==1 else [{'amendment_id':'amend-photo','from_revision':1,'to_revision':2,'changed_fields':['request_contract.hard_constraints.hc-photo'],'source':'input.amendment','affected_ids':['f-photo-r1','photo','out_photo','entry_photo','back_photo','rest','finish_margin','itinerary','budget','intent_coverage','deliverables'],'reason':'摄影16:20–17:05改为13:20–14:05；12:00–13:30午休冲突','invalidated_before_rebuild':['photo selection timing','photo commutes schedule','rest placement','itinerary','budget aggregation','intent gate','delivery'],'reused_after_review':['lunch windows and price','four taxi route times and fares','room availability','90-minute rest requirement','finish deadline'],'action':'重排摄影和午休；四段路线与价格无变化，重算总额相同'}]
 b['derived_state']=[{'artifact':a,'built_from_revision':r if a not in ['lunch_facts','route_facts'] else 1,'validated_for_revision':r,'depends_on':d,'validity':'current'} for a,d in [('lunch_facts',['input.lunch']),('route_facts',['input.routes']),('itinerary',['appointment','rest','routes','lunch']),('budget',['prices','people','commutes']),('intent_coverage',['request_contract','itinerary'])]]
 b['deliverables']=[{'format':'json','path':str(O/f'delivery_bundle_r{r}.json'),'bundle_revision':r,'validity':'current','QA':'passed','checked_pages':None,'total_pages':None,'limits':'local arithmetic/time assertions; no real-world fact verification'}]
 b['run_state']={'stages':[{'stage_id':a,'status':'COMPLETED','input_revision':r,'depends_on':[],'outputs':[str(O/f'delivery_bundle_r{r}.json')],'error':None,'blocked_reason':None} for a in ['contract','synthetic facts admission','selection','composition','CPU check','delivery']]}
 write(f'delivery_bundle_r{r}.json',b)
checks=[]
for r,slots in schedules.items():
 by={a:(mins(s),mins(e)) for a,k,s,e,c,i in slots}
 assert all(mins(s)<mins(e) for a,k,s,e,c,i in slots)
 assert all(slots[i][3]==slots[i+1][2] for i in range(len(slots)-1))
 assert slots[0][2]=='10:20' and slots[-1][3]=='17:50'
 assert by['lunch'][1]-by['lunch'][0]==50
 assert by['lunch'][0]>=mins('10:45') and by['lunch'][1]+5<=mins('12:15') and by['lunch'][0]<=mins('11:30')
 assert by['rest'][1]-by['rest'][0]==90 and mins('11:45')<=by['rest'][0]<=mins('14:45')
 a=x['photo']['appointment'] if r==1 else x['amendment']['photo_appointment']
 assert by['photo']==tuple(map(mins,a))
 for k,d in zip(['out_lunch','back_lunch','out_photo','back_photo'],[15,15,20,20]):assert by[k][1]-by[k][0]==d
 b=json.loads((O/f'delivery_bundle_r{r}.json').read_text())
 sums=[sum(item['subtotal'][i] for item in b['budget']['items']) for i in [0,1]]
 assert sums==[416,436]
 assert len(b['commutes'])==4 and all(c['price']['quantity']==1 and c['people']==2 for c in b['commutes'])
 assert all(c['price']['unit']=='per_car' for c in b['commutes'])
 assert all(s['candidate_id'] in [None,'hotel','lunch','photo'] for s in b['itinerary'])
 checks.append({'revision':r,'nonoverlap':True,'lunch_window_last_order_exit':True,'rest_90_min_start_window':True,'photo_appointment':True,'four_taxi_legs':True,'deadline':True,'budget_total':sums})
write('checks.json',{'executed_at':now,'method':'Python assertions on emitted bundle values and schedule','checks':checks,'scope':'synthetic facts only; not real-world validation'})
print(json.dumps(checks,ensure_ascii=False))

from pathlib import Path
import csv,json,hashlib,platform
import os
os.environ['MPLCONFIGDIR']=str(Path(__file__).resolve().parent/'mpl_cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
O=Path(__file__).resolve().parent
I=O.parents[2]/'inputs'
rows=list(csv.DictReader((I/'measurements.csv').open()))
assert len(rows)==4 and len({r['workload'] for r in rows})==4
for r in rows:
    r['baseline_ms']=float(r['baseline_ms']);r['candidate_ms']=float(r['candidate_ms'])
    assert r['baseline_ms']>0 and r['candidate_ms']>0
    assert r['scope'] in ['end_to_end','kernel_only']
    r['speedup']=r['baseline_ms']/r['candidate_ms']
    r['latency_change_pct']=(r['candidate_ms']/r['baseline_ms']-1)*100
with (O/'analysis.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(O/'measurements_v2.csv').write_bytes((I/'measurements.csv').read_bytes())
(O/'input_manifest.json').write_text(json.dumps({'inputs':[{'file':p.name,'version':'v2' if p.name=='measurements.csv' else ('v1 (project metadata; prior bytes unavailable)' if p.name=='concept.txt' else 'supplied snapshot'),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(I.iterdir()) if p.is_file()], 'python':platform.python_version(),'matplotlib':matplotlib.__version__},indent=2))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'svg.fonttype':'none'})
fig,ax=plt.subplots(1,2,figsize=(7.2,3.3),gridspec_kw={'width_ratios':[3,1.5]},layout='constrained')
for a,rs,title in zip(ax,[rows[:3],rows[3:]],['End-to-end latency','Kernel only']):
    for j,r in enumerate(rs):
        a.plot([r['baseline_ms'],r['candidate_ms']],[j,j],color='#b6bec9',lw=2,zorder=1)
        a.scatter(r['baseline_ms'],j,s=55,c='#4c627a',marker='o',label='Baseline' if j==0 else None,zorder=2)
        a.scatter(r['candidate_ms'],j,s=58,c='#bd6338',marker='s',label='Candidate' if j==0 else None,zorder=2)
        a.text(max(r['baseline_ms'],r['candidate_ms'])+5,j,f"{r['latency_change_pct']:+.1f}%",va='center',fontsize=9)
    a.set_yticks(range(len(rs)),[r['workload'] for r in rs]);a.set_ylim(len(rs)-.5,-.6)
    a.set_xlim(0,285 if len(rs)>1 else 42);a.set_xlabel('Latency (ms)');a.set_title(title,fontsize=11,loc='left',weight='bold')
    a.grid(axis='x',color='#e6e9ed',lw=.6);a.set_axisbelow(True)
    a.spines[['top','right','left']].set_visible(False);a.tick_params(axis='y',length=0)
ax[0].legend(loc='upper right',frameon=False,fontsize=9)
fig.savefig(O/'figure_v2.svg');fig.savefig(O/'figure_v2.png',dpi=160)
Image.open(O/'figure_v2.png').convert('L').save(O/'figure_v2_grayscale.png')
page=Image.new('RGB',(1323,1871),'white');im=Image.open(O/'figure_v2.png').convert('RGB');page.paste(im,((1323-im.width)//2,250));page.save(O/'figure_page_preview.png')
assert abs(rows[0]['speedup']-1.25)<1e-12
assert abs(rows[1]['speedup']-1.2)<1e-12
assert abs(rows[2]['speedup']-10/11)<1e-12
assert rows[3]['speedup']==2
(O/'numeric_checks.json').write_text(json.dumps({'rows':len(rows),'missing_values':0,'duplicate_workloads':0,'repeat_count':'unknown','checks':'positive timing, unique workload, allowed scope, direct numeric assertions passed','no_pooling':True,'new_experiments':0},indent=2))
print(json.dumps(rows,indent=2))

from fractions import Fraction as F
import json
rows = []
for xs in [(2, 8, 14), (14, 8, 2), (8, 8, 8)]:
    full = sum(map(F, xs)) / 3
    recent = sum(map(F, xs[1:])) / 2
    difference = recent - full
    assert difference == F(xs[1] + xs[2] - 2 * xs[0], 6)
    rows.append(dict(input=xs, full=str(full), recent=str(recent), difference=str(difference)))
assert [r['difference'] for r in rows] == ['3', '-3', '0']
print(json.dumps(rows, indent=2))

# Selective execution：通用工作稿

材料为合成测试材料，并非已发表论文。本稿仅改写所提供的结果与摘要，不新增实验或文献。

## 中文结果段落

在所报告的同一 CPU 进程和输入配置下，替换选定内核后的端到端性能随工作负载变化。小工作负载的耗时由 100 ms 降至 80 ms，降低 20.0%，对应 1.25 倍加速；中等工作负载由 120 ms 降至 100 ms，降低约 16.7%，对应 1.20 倍加速。相比之下，大工作负载的耗时由 200 ms 增至 220 ms，增加 10.0%，表现为性能退化。独立计时的内核耗时由 20 ms 降至 10 ms，降低 50.0%，对应 2.00 倍内核加速。该内核已经包含在端到端路径中，因此内核计时不能与端到端计时相加，内核收益也不能直接表述为端到端收益。每个数值仅来自一次运行，没有独立重复测量；材料未提供方差或质量测量，也没有 GPU 测量。因此，这些结果仅描述当前 CPU 配置下的单次观测，不能据此判断统计显著性、稳定性、质量是否保持或 GPU 性能，也不支持“所有工作负载均达到 2 倍端到端加速且无退化”的原始表述。

## English abstract

We examine selective execution through replacement of a selected kernel using a synthetic CPU measurement fixture. Under the reported common CPU process and input configuration, end-to-end latency decreases from 100 to 80 ms for the small workload and from 120 to 100 ms for the medium workload, corresponding to speedups of 1.25× and 1.20×, respectively. For the large workload, latency increases from 200 to 220 ms, a 10.0% regression. Independently timed kernel latency decreases from 20 to 10 ms, yielding a 2.00× kernel-only speedup. This kernel is already included in the end-to-end paths; its timing is not additive to end-to-end latency. The observed benefit is therefore workload-dependent and does not establish a universal 2× end-to-end speedup. Each reported value comes from a single run without independent repetitions. Variance and quality were not measured, and no GPU measurements were performed. These observations do not establish statistical significance, repeatability, quality preservation, or performance beyond the measured CPU configuration.

## 主张证据表

版本由 `input_versions.json` 的 SHA-256 锁定。CSV 行号计入表头。加速比 = baseline_ms / candidate_ms；耗时降低比例 = (baseline_ms − candidate_ms) / baseline_ms × 100%。耗时增加比例采用相同基线分母。

| 主张 ID | 主张与支持状态 | 证据 ID 与来源位置 | 指标及适用范围 | 反证、限制与稿内位置 |
| --- | --- | --- | --- | --- |
| WRITE-C001 | 小工作负载耗时降低 20.0%，加速 1.25×；有支持 | WRITE-E001：measurements.csv 第 2 行 | 100→80 ms；CPU、端到端、单次测量 | 不能推广到所有工作负载；中文结果与英文摘要 |
| WRITE-C002 | 中等工作负载耗时降低约 16.7%，加速 1.20×；有支持 | WRITE-E002：measurements.csv 第 3 行 | 120→100 ms；CPU、端到端、单次测量 | 不能推断显著性；中文结果与英文摘要 |
| WRITE-C003 | 大工作负载耗时增加 10.0%；有支持 | WRITE-E003：measurements.csv 第 4 行；WRITE-E005：manuscript.md Appendix A | 200→220 ms；CPU、端到端、单次测量 | 直接反驳“无退化”；中文结果与英文摘要 |
| WRITE-C004 | 内核加速 2.00×，耗时降低 50.0%；有支持但范围有限 | WRITE-E004：measurements.csv 第 5 行；WRITE-E005：manuscript.md Results | 20→10 ms；独立内核计时 | 已包含在端到端路径，不相加，不外推为端到端 2×；中文结果与英文摘要 |
| WRITE-C005 | 当前观测的端到端收益依赖工作负载；有限支持 | WRITE-E001–003 | 仅涵盖三个给定 CPU 工作负载 | 无独立重复测量，不能建立普适性；中文结果与英文摘要 |
| WRITE-C006 | 无法确定统计显著性、稳定性、质量保持或 GPU 性能；证据边界 | WRITE-E005：manuscript.md Method、Results、Appendix A | 单次运行，无方差/质量测量，无 GPU 测量 | 不把未知写成质量下降或无差异；中文结果与英文摘要 |
| WRITE-C007 | 原稿“所有工作负载均有 2× 端到端收益且无退化”；不支持，已替换 | WRITE-E005：manuscript.md Abstract；WRITE-E001–004 | 原稿主张与给定计时比较 | 三个端到端比值均未达 2×，且 large 退化；正文指出并在摘要纠正 |

本表中的“有支持”表示数值可追溯到输入，不表示经过独立重复实验或科学审稿。

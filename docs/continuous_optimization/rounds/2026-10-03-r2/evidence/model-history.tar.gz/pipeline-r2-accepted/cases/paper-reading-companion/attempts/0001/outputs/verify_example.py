"""CPU arithmetic check for the provided synthetic example, not a RoPE experiment."""
import json, math
from pathlib import Path

def weights(a,b):
    z=[x+y for x,y in zip(a,b)]
    e=[math.exp(x-max(z)) for x in z]
    return [x/sum(e) for x in e]

def case(b):
    p=weights([0.,0.],b)
    return {'b':b,'weights':p,'output':sum(w*v for w,v in zip(p,[0.,10.]))}

r={'baseline':case([0.,0.]),'changed':case([0.,math.log(3)]),'shared_shift':case([math.log(3),math.log(3)]),'scope':'Arithmetic teaching example only; no RoPE implementation or model evaluation.'}
assert math.isclose(r['baseline']['output'],5)
assert math.isclose(r['changed']['output'],7.5)
assert math.isclose(r['shared_shift']['output'],5)
Path(__file__).with_name('numeric_check.json').write_text(json.dumps(r,indent=2))
print(json.dumps(r,indent=2))

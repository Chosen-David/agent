# CODE-READ synthetic-selector-01

仅作只读源码分析；目标未导入、未执行，以下没有运行实测结论。范围为 `inputs/synthetic_selector.py` 全部 30 行，入口 `run`，追踪至返回的 `full_score`。本次实际文件 SHA-256：`6fc687e85d2c169c5dc88d7dc126b970036f22b822c00c9f8f0d8b628a6e8ea1`。输入未提供绑定 commit、分支或工作区差异记录，因此 commit/branch/dirty 状态为 unknown；不把外层评估仓库 HEAD 当成输入版本。所有行号均对应此 SHA 的文件。

## 结论与模块叙述对照

| ID | 模块叙述（L1–2） | 源码事实与修正 | 状态与证据 |
| --- | --- | --- | --- |
| C1 | near 是 forced window | `boundary=max(0,n-near_len)` 只划分远近候选域；强制集合独立为末尾 `forced_len` 个位置。near 候选仍需排序并按剩余容量截取。 | source_fact；`select` L19–25 |
| C2 | skip 意味着不评分 | `qsmall` 与所有 key 的低维分数在 skip 分支之前生成；`skip_far` 为真只令 `far=[]`，不执行远端排序/截取；near 排序、拼接及最终评分仍执行。 | source_fact；`select` L21–25、`run` L29–30 |
| C3 | projector 是 query-trained | 默认 `basis=None` 固定取第 0、2 维。可选 basis 对输入向量与每个 column 作 zip 点积；没有学习、拟合或根据当前 query 更新 basis 的代码。query 经同一表示函数，不证明 projector 经 query 训练。外部 basis 是否经训练未知。 | source_fact / unknown（外部来源）；`represent` L6–9、`select` L21–22 |
| C4 | 最终评分使用 reduced keys | 低维 scores 只用于排序选择 positions。`run` 将原始 query、原始 keys 和 positions 传给 `full_score`；最终返回原始向量的 zip 点积。 | source_fact；`select` L22–25、`run` L29–30、`full_score` L12–13 |
| C5 | 总预算限制全部选择数量（潜在误读） | `budget` 只决定 near 的剩余截取数，far 与 forced 均不会为遵守 budget 被削减，因此不是硬上限。 | static_inference；`select` L20、23–25 |

C4 的“原始维度”有精确限制：`zip(query, keys[i])` 截到两者较短长度。只有长度一致时才可称全 D 点积；它也不是对全部 token 评分，而是只对 positions 中的位置重新评分。没有 softmax、归一化或加权聚合（L12–13、L30）。

## 可达调用边

所有边为源码 `syntactic_call`，函数名在本模块直接定义，按未被外部重绑定的普通调用假设解析为 `resolved_target`；没有 `observed_call`。

| Caller → callee | 调用行 | 条件与消费 |
| --- | --- | --- |
| `run → select` | L29 | 传 query、keys、`**options`；返回值赋给 positions |
| `select → represent(query,basis)` | L21 | 无条件，在 far 跳过判断之前；返回 qsmall |
| `select → represent(k,basis)` | L22 | 对每个 key；结果参与该 key 的低维点积 |
| `select → sorted(far-domain)` | L23 | `skip_far` 为假才调用；排序键 `-scores[i]` 后按 far_budget 切片 |
| `select → sorted(near-domain)` | L24 | 无条件求值；排序后由 L25 按剩余容量切片 |
| `run → full_score` | L30 | select 成功返回后，无 skip 分支；返回列表与 positions 组成二元组 |

`full_score` 内 L13 遍历 positions 并以 `keys[i]` 取原始 key，没有调用 represent。普通 Python 的 sorted 为稳定排序：相同候选分数在各候选域内保持 range 的升序位置顺序；最终列表是 far、near、forced 三段拼接，不按最终分数全局排序。对于 NaN 或不支持数值比较的输入，不作数值排序正确性保证。

## 数据边与表示

假设常规输入为可索引的数值 query 向量、长度 n 的 key 列表；源码没有声明或验证 shape/dtype。

| 数据生产 → 转换 → 消费 | 表示、索引及状态 |
| --- | --- |
| query → represent → qsmall → scores | 默认选择坐标 0、2，长度 2；可选 basis 含 r 个 column 时输出长度 r（以可重复遍历 basis 为前提） |
| keys 的每个 k → represent → 与 qsmall 点积 → scores[i] | scores 为长度 n 的 Python 列表，i 始终是原 keys 的位置；先为全部 keys 生成分数，包括之后强制保留的位置 |
| n、near_len → boundary → far/near 候选域 | boundary 是位置分界，不是远近配额；range 产生逻辑列表位置，没有物理槽映射 |
| n、forced_len → forced → positions | 强制位置直接追加，不依赖其分数；没有去重、mask 或过滤 |
| scores → 两次排序/切片 → positions | scores 只服务候选排序；positions 保持分段顺序 |
| positions + 原始 query/keys → full_score → `run` 返回 | 返回 `(positions, score_list)`；score_list 与 positions 一一对应，重复位置会重复评分 |

可选 basis 的公式是每个 column 上的 `sum(vector[j]*column[j])`，j 仅遍历 zip 的共同长度；不要求矩阵正交、维度匹配或 r 小于原维度。因此“可选线性表示”有源码依据，“保证降维的正交投影”没有。basis 若是一次性迭代器，会被 query 表示先消费；后续 key 表示可能为空，这是未校验输入类型造成的额外路径，不可泛化正常矩阵假设。

## 默认值、覆盖与实际消费

覆盖来源仅在可见源码内确认：`run(..., **options)` 透传至 select，select 也可直接按参数调用；没有 CLI、环境变量或配置文件读取。当前实际运行值全部 unknown，因为没有执行记录。

| 参数 | 默认值 | 消费处与含义 |
| --- | --- | --- |
| near_len | 4 | L19、23–24：末端近域分界；不是强制数或必选数 |
| forced_len | 1 | L20、24–25：尾部强制集合，同时排除普通 near 域并占用其容量 |
| budget | 3 | L25：仅近域余量 `max(0,budget-len(forced)-len(far))` |
| far_budget | 1 | L23：远域有序列表切片；正常非负整数时是 far 数量上限，不会自动补足 |
| skip_far | False | L23：仅禁止 far 候选入选及其排序 |
| basis | None | L21–22 经 L6–9 消费：默认固定取维，可选外部列向量点积 |

对非负整数参数，令 b=max(0,n-near_len)，F=range(max(0,n-forced_len),n)。远候选是 `[0,b)`；近候选是 `[b,max(b,n-forced_len))`。取出的 far 数量为 f，near 容量为 max(0,budget−|F|−f)，最终列表长度为 f+min(near候选数,near容量)+|F|（含重复次数）。这些是静态推导，不是运行数据。

默认参数下，F 为最后一个位置（n>0），near 是此前最多 3 个位置，far 是剩余更早的位置；当 n>=5 时取 1 个 far、1 个 near、最后 1 个 forced。设置 skip_far=True 后 far 为空，near 最多取 2 个，forced 仍保留。

## 边界与反例（全部为静态推断，未运行）

1. **预算不是硬上限。** 取 n=6、budget=1，其余默认：far 长度为 1、forced 长度为 1，near 容量为 0，最终长度为 2（L20、23–25）。不依赖具体排名即可得出。
2. **强制集合可能与 far 重叠。** 若 forced_len>near_len，则 forced 起点可能位于 far 域。例 n=6、near_len=2、forced_len=4、far_budget=4：far 候选是 0–3，forced 是 2–5；最终拼接含重复 2、3。near 为空，没有去重（L19–25）。
3. **空池与短向量。** keys=[] 时仍执行 represent(query)，默认 query 长度至少 3 才能到达返回空 positions/空最终分数；短 query 或任一短 key 可在 L8 抛 IndexError。空 keys 不自动跳过 query 表示。
4. **短输入。** 正常默认参数且 query/keys 维度满足 L8 时，n<=4 没有 far；forced 数量被 n 截断。forced_len>n 时全部位置强制，可能超 budget。
5. **异常参数未校验。** 负 far_budget 使用 Python 负切片，不能解释成“零个”或合法配额；near_len<0 可令远候选越过 n，使 L23 的 scores[i] 越界；forced_len<0 可使 near 域越过 n。非整数长度/预算也可能导致 range 或切片 TypeError。无需执行即可定位失败表达式，但具体异常依调用值确定。
6. **表示空值/长度不齐。** basis=[] 时所有近似分数为 0，按稳定排序选择候选，但最终仍用原始向量评分；长短不齐的 basis 列、query/key 均由 zip 静默截断。默认表示不能提供全维分数的上界或下界证明，源码也没有此保证。

## 覆盖、未知与检查记录

| 路径 | 状态 | 覆盖证据/边界 |
| --- | --- | --- |
| run，默认 basis，skip_far=False | inspected | L6–30，闭合至最终 score_list |
| run，可选 basis | inspected | L9、L21–22、L29–30；basis 训练来源 unknown |
| run，skip_far=True | inspected | L21–25、L30；前置与最终评分仍可达 |
| 直接调用 select / full_score | inspected | L16–25 / L12–13；它们分别只返回 positions / 分数，不等同 run 的返回二元组 |
| 空输入、预算超额、强制重叠、非法参数 | inspected（静态） | 上述边界表达式；没有运行覆盖 |
| 外部调用者、basis 生成、运行配置、实际向量 dtype/shape | unresolved | 本案例仅一个文件，没有外部调用日志或实现 |
| GPU、批处理、模型集成、性能/准确率 | not_applicable 于当前单文件结论 | 本文件无对应实现；不声称外部系统不存在 |

实际执行仅包括协议/技能/任务读取、源文件逐行读取、SHA-256 计算、相关 AGENTS.md 与 .agents/skills 存在性检查及产物写入。授权输入目录与已检视 snapshot 祖先中，相关 AGENTS.md / .agents/skills 均不存在。没有运行或导入 synthetic_selector.py，没有执行测试、源码证据脚本或覆盖检查器，没有独立审阅者；进行了作者自查。固定内容 SHA 替代不可得的 Git commit，不声称 Git blob 证据。

交付前复读 L6–30 的关键条件，并核对默认/可选表示、范围/预算、跳过/评分、选择/最终原始向量计算。若将来授权运行，最小判别可分别使用：默认与非空 basis、skip_far 真/假、budget=1、forced_len>near_len、空 keys 与短 query；应记录明确输入和返回值，此建议不表示本次已经测试。

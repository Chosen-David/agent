from pathlib import Path
import json
p=Path(__file__).resolve().parent
def write(n,s): (p/n).write_text(s.strip()+'\n')
write('research_brief.md','''# RES：Selective execution 方向判断

建议 **pivot：仅继续一轮最小判别验证，暂停“所有负载端到端 2× 且无回退”的主张及完整系统扩展**。输入是合成材料，不是论文实证；未查新，不判断首创。机制状态 inconclusive。

问题：替换 kernel 能否在保持输出正确的前提下，稳定降低各负载端到端时延？大负载回退来自规模相关开销，还是单次测量波动？

| 输入行 | baseline→candidate (ms) | baseline/candidate | 时延变化 |
|---|---:|---:|---:|
| small / end_to_end | 100→80 | 1.25× | 降低 20% |
| medium / end_to_end | 120→100 | 1.20× | 降低 16.67% |
| large / end_to_end | 200→220 | 0.909× | 增加 10% |
| kernel / kernel_only | 20→10 | 2.00× | 降低 50% |

以上仅描述每行一次观测，不是可重复性、显著性或总体均值结论。大负载回退在 Appendix A 明示，不能指控作者隐藏结果。摘要与所给结果不符，应修订。相同 CPU 进程和输入配置控制部分条件，不控制执行顺序、缓存、频率和系统噪声。质量、方差未知；无 GPU 测量。

kernel 时间已包含在端到端路径中，不可加到总时间；独立 kernel pair 也不能当作每个负载的同轮 phase 时间。small/medium 各省 20 ms 与 kernel pair 省 10 ms 的差异仅提示需查测量口径，不能由此确定额外优化或伪造。若纯替换仅将某占比 f 的阶段加速 2×，其他成本不变，端到端加速上限为 1/(1-f/2)；当前没有每个负载的 f，不能数值套用。

每个负载调用一次的描述性总和为 420→400 ms，即 1.05×、降低 4.76%；真实工作负载权重未知，此数不能掩盖 large 的回退或代表部署收益。

候选路线：①优先验证规模相关集成成本，并考虑有边界的调度/回退；②若效应由噪声解释，停止新机制开发，先重建测量基线。暂不开发更多模块。部署收益和质量要求、CPU 型号及可执行代码均未提供。
''')
write('research_plan.md','''# 预先约定的最小判别实验（尚未执行）

这里的 5% 实用收益、2% 回退容忍和预算均为分析者提出的探索性决策阈值，不是从当前四行数据估计的置信阈值。实际质量容差必须在跑实验前由应用契约固定。新实验启动前锁定配置、脚本、阈值与分析方案，不在看到结果后换主要指标。

## E1：先排除最强替代解释——单次时序/缓存/频率噪声
在相同 CPU、配置、输入和二进制版本上，baseline/candidate 各预热 5 次；每个 workload 运行 30 个配对块，在每块中随机 AB/BA 顺序。每块使用匹配的新进程，固定线程数和可用 CPU 亲和性，记录顺序、wall-clock 时间、机器负载和错误；三负载交错测试。分析单位是独立进程配对块，不把 kernel 调用次数当重复。禁止事后删除慢样本；仅按预先列出的计时/执行失败规则标为 invalid，并保留原始记录。有效块不足 30 则 inconclusive。

主要指标为每负载配对端到端时间节省率 d=1-Tcandidate/Tbaseline 的中位数，报告配对块 bootstrap 95% 区间（固定种子、10000 次重采样），同时原样报告各负载数据；不采用事后权重合并。辅助指标为 kernel phase、非 kernel phase、分配/拷贝/同步成本和输出正确性。

控制：相同 timer 和计时边界；计入所有选择/转换/分配/同步开销；结果必须与可信 baseline 比较。离散输出要求完全一致；浮点容差需在启动前固定，材料未提供，缺失时阻塞质量验收。不要把“未显著”解释为等效。

若 large 的节省率上界小于 -2%，支持稳定回退；若下界大于 -2%，才支持在此容忍下无实质回退；跨界则不确定。small/medium 的收益下界均大于 5% 才进入有价值候选。E1 中效应随顺序翻转或无法稳定重现，支持噪声解释但仍需保留混杂可能。

## E2：区分 kernel 收益与集成开销（仅 E1 出现稳定效应后）
先取 5 个探索性块验证分段计时可加和、工具开销可接受；主时延用无插桩独立运行。固定相同输入的四臂：A 原始 baseline；B baseline kernel 加候选包装/选择/转换路径；C 候选 kernel 加完整包装；D 候选 kernel 加可安全预计算/复用的包装。每负载 30 个独立进程随机顺序块，每块跑四臂，记录真实 in-path kernel 与包装成本。D 若不保持同等语义则不可作为收益证据，最多作诊断。

RES-H001 预测：C 相比 B 的 kernel phase 更快；B 相比 A 的非 kernel 成本在 large 增长；D 在语义等价前提下降低该成本并恢复 large 端到端收益。若 C 的 in-path kernel 在 large 自身变慢而包装不增长，转向缓存/访存或分支行为解释；不要坚持“包装开销”机制。若包装消融不改变回退且 kernel 收益不能重现，RES-H001 的核心机制不被支持。

## 预算与停止路线
当前已执行：纯 CPU 的 CSV 重算，未执行 E1/E2；缺少实现、原始计时日志、输入生成器、质量契约和可控性能机器。资源：建议一名实现负责人，最多 4 人时准备与分析；同一 CPU 机器最多 2 小时 wall time，无 GPU、网络或付费资源。E1 为 180 次测量 + 30 次预热；E2 最多 360 次主测量 + 60 次探索计时，另预热按实际记录计入预算。运行成本依据单次 80–220 ms 粗估为数十到数百秒纯计时，进程启动/复位和插桩成本未知；以硬预算为准，不承诺完成时间。E1 与 E2 各只一批，不持续抽样到显著。

Go：正确性全部通过，且三个负载收益下界均>5%，机制预测获得分段支持；仅对测试条件成立。Pivot：small/medium 稳定有收益且 large 稳定回退，设计一条可解释的尺寸路由/回退策略后另立新确认实验（包含决策开销），不能直接宣布成功。Stop：任何正确性错误先停候选；或在 E1/E2 后所有负载收益上界≤5%，停止本轮性能开发；成本消融证伪机制则停止该机制路线。Inconclusive：缺资源、方差跨阈值、计时不可靠或预算耗尽，暂停并保留数据，不自动加样。

最先执行 RES-T002：获取最低限度可复现实现与质量契约，然后 E1；它用最低代价区分真实回退与单次噪声，决定是否值得做 E2。
''')
evidence=[{'id':'EVD-001','source':'inputs/manuscript.md','location':'Abstract, Method, Results, Appendix A','kind':'provided synthetic text','supports':['CPU only; same process/config','each value is one run','kernel pair independent and included in end-to-end','large regression explicitly disclosed; quality and variance unmeasured'],'limits':['not a published study','no independent repeats','no novelty evidence']},{'id':'EVD-002','source':'inputs/measurements.csv','location':'all four data rows','kind':'provided synthetic observations','supports':['small 1.25x; medium 1.2x; large 0.909x end-to-end; kernel 2x'],'limits':['n=1 each','no confidence intervals','kernel timing not workload-matched in-path timing']},{'id':'EVD-003','source':'analysis.json; analyze.py','kind':'executed deterministic CPU arithmetic','supports':['unweighted one-each total 420 to 400 ms','end-to-end universal 2x claim contradicted by supplied observations'],'limits':['not a rerun of optimization','not deployment weighting']}]
write('evidence_map.yaml',json.dumps({'evidence':evidence,'search':{'status':'not_performed','reason':'Task forbids network and external novelty search','queries':[],'coverage':'provided synthetic materials only','novelty':'not assessed'}},ensure_ascii=False,indent=2))
hyp=[{'hypothesis_id':'RES-H001','question':'Does a faster replacement kernel yield workload-dependent end-to-end gains limited by integration cost?','mechanism':'Kernel work shrinks; selection/copy/allocation/synchronization overhead grows with input size and erases savings on large workload.','scope':'provided CPU workloads and unchanged output contract','current_evidence':['EVD-001','EVD-002'],'assumptions':['timings comparable','candidate semantics equivalent; unverified'],'alternative_explanations':['RES-H002','in-path kernel slows at large scale due to locality; independent microbenchmark does not transfer'],'predictions':['in-path kernel C faster than B','B-A non-kernel cost increases for large','semantics-preserving D recovers large loss'],'support_criteria':['E1 effect reproducible','E2 predicted component and ablation effects with correct outputs'],'falsification_criteria':['reliable phase timings show no in-path kernel gain','semantics-preserving overhead removal does not remove loss and overhead does not grow'],'minimal_test':'E1 then four-arm E2 in research_plan.md','controls':['same inputs/config/timer','random order','baseline wrapper arm','quality gate'],'metrics_and_analysis':['paired end-to-end reduction; all three workloads reported','phase timings diagnostic only'],'resources':{'status':'not available as runnable benchmark','budget':'4 person-hours and 2 CPU wall-hours proposed'},'failure_modes':['instrumentation perturbation','non-equivalent ablation','no independent repeats'],'status':'inconclusive'},{'hypothesis_id':'RES-H002','question':'Are observed differences primarily single-run measurement artifacts?','mechanism':'Order, warm cache, frequency or OS interference varies between measurements.','scope':'single-run synthetic timing comparison','current_evidence':['EVD-001: one run per value; no variance'],'assumptions':['uncontrolled runtime state can affect timing'],'alternative_explanations':['RES-H001','large-specific kernel locality loss'],'predictions':['randomized paired effects shrink, change sign or track order','stable gains and stable regression persist if this explanation is insufficient'],'support_criteria':['effects not stable across independent randomized blocks and associate with execution state'],'falsification_criteria':['effects persist consistently with balanced order and matched runtime state; rules out noise as primary explanation only'],'minimal_test':'E1','controls':['warmup','new process pairs','random AB/BA','all observations retained'],'metrics_and_analysis':['paired per-workload E2E ratios and uncertainty','order effect secondary exploratory'],'resources':{'budget':'E1 180 measured calls within shared CPU budget'},'failure_modes':['persistent confounding','underpowered run'],'status':'inconclusive'}]
write('hypotheses.yaml',json.dumps({'hypotheses':hyp},ensure_ascii=False,indent=2))
tasks=[]
def t(i,stage,dep,owner,ins,action,outs,done,failure,budget,status): tasks.append(dict(task_id=i,stage=stage,depends_on=dep,owner=owner,inputs=ins,action=action,outputs=outs,done_when=done,on_failure=failure,resource_budget=budget,status=status))
t('RES-T001','evidence audit',[],'research-explore',['manuscript.md','measurements.csv'],'Recompute descriptive timings; separate kernel and E2E',['analysis.json','research_brief.md'],'All four rows accounted for, regression retained','Report parse/arithmetic blocker','local CPU seconds','done')
t('RES-T002','baseline readiness',['RES-T001'],'implementation owner',['original code/config/input generators/quality contract: missing'],'Obtain runnable baseline and candidate; lock quality and measurement protocol',['version manifest','quality contract','E1 runner'],'Missing inputs supplied and baseline/candidate equivalent on all three workloads','Remain blocked; do not fabricate rerun','within 4 person-hours total','blocked')
t('RES-T003','minimum discriminating experiment',['RES-T002'],'implementation owner',['version manifest','E1 runner','research_plan.md'],'Run E1 once with fixed budget',['raw paired timings','correctness records','E1 analysis'],'30 valid independent pairs/workload, report all results and intervals','Stop correctness failure; inconclusive on budget/validity shortfall','180 measured calls; shared 2 CPU hours','todo')
t('RES-T004','mechanism discrimination',['RES-T003'],'implementation owner',['E1 results','four equivalent experimental arms'],'If stable effect warrants, run E2 and assess alternatives',['E2 raw data','component analysis'],'Overhead-vs-kernel-vs-noise predictions assessed','Skip if E1 supports stop; retain inconclusive if ablation invalid','360 main calls + 60 pilot; shared budget','todo')
t('RES-T005','decision and claims',['RES-T003','RES-T004'],'research-explore',['all raw results','locked thresholds'],'Apply go/pivot/stop/inconclusive rules and correct abstract',['decision update','supported-claims list'],'Evidence IDs tied to every claim; skipped E2 reason recorded','Keep mechanism inconclusive and pause expansion','remaining shared 4 person-hours','todo')
write('task_chain.yaml',json.dumps({'run_id':'pipeline-r2-accepted/research-explore/0001','tasks':tasks,'blocked_recovery':'RES-T002 resumes only after code, configs, inputs and predeclared quality tolerance are supplied; T004 may be skipped with documented E1 stop decision.'},ensure_ascii=False,indent=2))
write('handoff.md','''# 交接

当前决策 pivot；机制 inconclusive。可写成结果的只有合成输入单次描述：small 1.25×、medium 1.20×、large 0.909×、独立 kernel 2.00×；应保留 large 的 +10% 时延和无重复/质量未知限制。不能写成“所有负载 2×”“无回退”“已证实规模开销机制”“GPU 加速”“首创”。

下一负责人：实现/性能测量负责人，按 RES-T002 补齐代码、输入、配置、计时方法、质量契约，然后执行 research_plan.md 的 E1；CPU 上只替换目标 kernel，保留语义和完整端到端开销，不添加未定义优化。可信基线为原方法相同配置版本，并记录源码/二进制哈希。质量门限在运行前冻结；当前材料未给，禁止擅自放宽。E1 的独立配对块为分析单位；只在 E1 支持稳定效应时做 E2。

输入版本 SHA256 和完整本地路径见 loaded.json；描述性计算源为 analyze.py，结果 analysis.json；方案和阈值见 research_plan.md；假设、证据、依赖交接分别见 hypotheses.yaml、evidence_map.yaml、task_chain.yaml。三个 YAML 文件用合法 JSON 子集表达。

已执行 CPU 算术并验证总和和回退行；未运行待优化实现、未测量质量/方差、未联网、未使用 GPU 或子代理。4 人时 / 2 CPU 小时只是建议上限，硬件和原实现可用性未知。任务完成不代表机制被支持。
''')
write('skill_selection.md','''# 能力记录

模式 offline_fallback。使用固定 snapshot 的 research-explore/SKILL.md、references/execution.md、references/workflow.md（全部已读）；精确路径和 SHA256 见 loaded.json，未修改。已知本地 terminal 与 Python 标准库足以重算 CSV、生成版本记录和实验计划。没有运行领域 benchmark 的代码/数据生成器，故不宣称实现已验证。

外部候选发现、文献查新和安装均未执行，原因是本次用户明确限定仅分析合成输入、禁止网络与嵌套代理。没有宣称选择当前最佳工具或方法；不产生虚构引用和 BibTeX。角色选型、版本和限制合并记录于此及 loaded.json。
''')
print('Wrote core reports, hypothesis/evidence/task records and handoff.')

from style import *
import panel_a,panel_b,json,hashlib,sys
from PIL import Image
fig=plt.figure(figsize=(8.4,3.8))
panel_a.draw(fig.add_axes([.03,.10,.43,.80]))
checks=panel_b.draw(fig.add_axes([.60,.26,.37,.565]))
export(fig,'figure')
fig.savefig(ROOT/'figure_final_size.png',dpi=120)
im=Image.open(ROOT/'figure_final_size.png');im.convert('L').save(ROOT/'figure_grayscale.png')
# A portrait-page embedding is a viewing context, not a publication template.
page=Image.new('RGB',(1120,1450),'white');page.paste(im,(56,400));page.save(ROOT/'figure_page_preview.png')
checks['input_hashes']={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['architecture.json','measurements.csv']}
checks['python']=sys.version;checks['matplotlib']=matplotlib.__version__;checks['node_count']=6;checks['edge_count']=5
checks['png_pixels']=Image.open(ROOT/'figure.png').size
import xml.etree.ElementTree as ET
root=ET.parse(ROOT/'figure.svg').getroot();ids=[e.attrib['id'] for e in root.iter() if 'id' in e.attrib];assert len(ids)==len(set(ids));checks['svg_unique_ids']=len(ids)
assert not any(e.tag.endswith('image') for e in root.iter()),'Raster embedded in SVG'
checks['svg_raster_images']=0
(ROOT/'checks.json').write_text(json.dumps(checks,indent=2))
print(json.dumps(checks,indent=2))

# Project state

Project: synthetic-window-cache; current evidence version: synthetic-v3.
Decision: EXECUTE. Scope: analysis and handoff only; downstream writing remains todo.

Completed: CPU aggregation of 18 supplied synthetic latency records into three workload rows; actual SHA256 lineage in analysis.json; serialized interface and arithmetic checks in cpu_checks.json. No row excluded. Historical WRITE-OLD (synthetic-v2) is invalidated because its all-workload ≥1.8× claim conflicts with every v3 aggregate. BACKGROUND-1 retains only the latency-independent definition scope stated in project metadata. Its absent physical artifact is not marked newly verified; RETAIN-1 records the applicability check separately.

Current results: small 32→24 ms, 1.333333×, 25% reduction; medium 56→58 ms, 0.965517×, −3.571429% reduction; large 96→80 ms, 1.2×, 16.666667% reduction. These are descriptive summaries of synthetic inputs, not new benchmark outcomes.

Next owner: research-write. Consume the actual analysis.json and aggregate.csv copied by the host. Check aggregate SHA256 before dependent writing. Missing or mismatched files block writing until exact matching files are restored. Deliver Chinese Results paragraph and English abstract; no full submission paper requested. Quality, hardware, statistical significance and generalization remain unsupported.

Task dependencies are present and acyclic; completed nodes have actual outputs. No historical skipped task is used to satisfy current dependencies. No experiment or new writing is required from this node.

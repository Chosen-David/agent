# moving_average 修复与测量分析

本轮 CODE-T001 已完成接口保持的局部修复及 CPU 正确性检查。输入文件不变；修复版为 `buggy.py`，差异见 `fix.patch`。采用固定角色和 Python 标准库的 offline_fallback；未联网、安装运行时、调用 GPU 或执行性能计时。

## 功能契约与根因

保持 `moving_average(values, window)` 和返回列表；values 仍为支持长度和切片的数值序列。完整窗口起点为 0 到 n-window（含端点），故结果长度是 max(0,n-window+1)。原来的 range(n-window) 少了最后一个窗口：例如 [1,2,3], window=2 原结果 [1.5]，应为 [1.5,2.5]；窗口等长及单元素也受影响。

保留原来的逐窗口 sum 和除法，避免未经许可改动浮点归约顺序。新增正整数窗口验证：支持 __index__ 的整数对象；非正整数抛 ValueError，非整数和 bool 抛 TypeError。原文未定义具体异常类别和 bool 语义，此处明确为上述契约。窗口超过输入长度和空输入返回 []，但非法窗口始终先报错。不修改 values。

## 实际验证

`python -B check_correctness.py` 运行 4 个 unittest 测试方法，全部通过（退出码 0）。覆盖 11 个手算边界案例、1377 个固定种子整数数据/窗口组合、18 个非法窗口与空/非空输入组合，以及 __index__ 支持。逐例核对输入未修改，正常输入核对输出数目；覆盖 window=1、window=n、window>n、空输入、单元素、负数、零、元组及可精确表达的小数。

独立参考采用 deque 逐元素形成窗口，用 Fraction 精确有理数求平均，最后转 float；不依赖被测实现、不复用切片起点表达式。整数范围和长度控制在精确可表示的求和范围，因此精确等值比较有依据，无需放宽误差。浮点测试仅覆盖手算的二进制精确小数，未声称穷尽任意数值类型或极端浮点情况。

同一手算边界测试实际运行原始代码，观察到 8 个失败（退出码 1），表明检查可检出原错误。原始复现、失败与成功日志分别见 baseline_reproduction.json、baseline_checks.txt、correctness_results.txt。

## 已提供测量的可支持结论

下表仅复算 measurements.csv，不是本轮性能实测。speedup = baseline/candidate；延迟降幅 = (baseline-candidate)/baseline。

| workload | 范围 | baseline ms | candidate ms | speedup | 延迟降幅 |
|---|---|---:|---:|---:|---:|
| small | end_to_end | 100 | 80 | 1.25× | 20% |
| medium | end_to_end | 120 | 100 | 1.20× | 16.67% |
| large | end_to_end | 200 | 220 | 0.9091× | −10% |
| kernel | kernel_only | 20 | 10 | 2.00× | 50% |

候选在 small/medium 的给定观测中更快；large 延迟增加 10%，不能声称全面提速。kernel 的 2× 仅适用于该 kernel_only 行，不能外推端到端。若其占端到端 baseline 比例为 f，且其他耗时不变，理论整体 speedup 为 1/((1-f)+f/2)；CSV 未给出相应 f 或 kernel 与端到端行的关联，不能代入得出系统收益。

数据缺少重复次数、原始样本分布、计时协议、同步边界、输入规模/内容、硬件、软件版本及与修复代码的关联。因此只能描述这四行数值；不能证明统计显著性、收益原因、可重复性、GPU 性能或此次修复的速度。未给工作负载权重，不合成总体提速，也不把 kernel 行混入端到端汇总。

## 方案、复杂度与限制

令 n 为输入长度，w 为正窗口长度，m=max(0,n-w+1)。保留方案时间 O(mw)，临时切片辅助空间 O(w)，返回结果 O(m)；w>n 时 O(1) 返回。按定长机器数操作计，超大 Python 整数的位复杂度另计。滑动总和可把时间降至 O(n)、额外状态 O(1)，但会改变浮点累积误差、NaN/Inf 恢复行为；前缀和额外占 O(n) 且有减法消差风险。这次目标是修复与分析已有测量，未选择无实测收益证据的算法替换。

Python 标准库足以完成本任务，未调用 ISA 专用原语或声称找到最新/最快方案。来源是本地代码、固定工作流和独立推导；没有网络文献检索或成熟第三方库基准。环境与输入/技能哈希见 environment.json、loaded.json。仅输出副本完成修复，未对其他仓库入口进行集成改写；如要发表性能结论，下一负责人需补充可追溯且重复的端到端测量。

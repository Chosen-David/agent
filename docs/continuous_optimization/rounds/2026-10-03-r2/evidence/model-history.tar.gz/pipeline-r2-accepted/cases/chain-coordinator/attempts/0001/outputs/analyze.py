from pathlib import Path
import csv, json, hashlib, statistics, math, sys
from collections import defaultdict

OUT=Path(__file__).resolve().parent
INPUT=OUT.parents[2]/'inputs'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
project=json.loads((INPUT/'chain_project.json').read_text())
contract=json.loads((INPUT/'handoff_fields.json').read_text())
rows=list(csv.DictReader((INPUT/'chain_latencies.csv').open(newline='')))
groups=defaultdict(list); seen=set(); workloads=[]
for r in rows:
    assert r['input_version']==project['input_version']
    assert r['scope']=='end_to_end'
    assert r['variant'] in ('baseline','candidate')
    key=(r['workload'],r['variant'],r['repeat'])
    assert key not in seen; seen.add(key)
    x=float(r['latency_ms']); assert math.isfinite(x) and x>0
    groups[key[:2]].append(x)
    if r['workload'] not in workloads: workloads.append(r['workload'])
aggregates=[]
for w in workloads:
    b=groups[(w,'baseline')]; c=groups[(w,'candidate')]
    assert len(b)==len(c)==project['measurement_conditions']['repeats_per_variant']
    bm=statistics.median(b);cm=statistics.median(c)
    aggregates.append(dict(workload=w,n_baseline=len(b),n_candidate=len(c),baseline_median_ms=bm,candidate_median_ms=cm,speedup_ratio=bm/cm,latency_reduction_pct=100*(bm-cm)/bm))
with (OUT/'aggregate.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=contract['aggregate_csv_columns'],lineterminator='\n');writer.writeheader();writer.writerows(aggregates)
findings=[]
for i,r in enumerate(aggregates,2):
    w=r['workload']; delta=r['candidate_median_ms']-r['baseline_median_ms']
    findings.append({'workload':w,'aggregate_csv_row':i,'evidence_file':'aggregate.csv','evidence_type':'derived_from_synthetic_inputs','baseline_median_ms':r['baseline_median_ms'],'candidate_median_ms':r['candidate_median_ms'],'speedup_ratio':r['speedup_ratio'],'latency_reduction_pct':r['latency_reduction_pct'],'direction':'lower_latency' if delta<0 else 'higher_latency','claim':f"在提供的 synthetic-v3 合成端到端延迟中，{w} 的 baseline/candidate 中位数为 {r['baseline_median_ms']:g}/{r['candidate_median_ms']:g} ms；speedup ratio={r['speedup_ratio']:.6f}，延迟降幅={r['latency_reduction_pct']:.6f}%。"})
analysis={'schema_version':contract['schema_version'],'project_id':project['project_id'],'input_version':project['input_version'],'source_files':[{'path':str(INPUT/name),'sha256':sha(INPUT/name)} for name in ('chain_project.json','chain_latencies.csv','handoff_fields.json')],'aggregate_file':{'path':'aggregate.csv','sha256':sha(OUT/'aggregate.csv')},'findings':findings,'limitations':['所有值均为给定的合成测量；本节点只在 CPU 上复算，未进行真实模型、GPU 或新 benchmark 实验。','每个工作负载每个版本仅有 3 次记录；重复值独立性和跨版本配对关系未知，未推断统计显著性、置信区间或总体性能。','硬件未指定，质量指标缺失；不能声称质量保持、硬件加速效果、因果机制或推广到其他工作负载。','speedup ratio 是两版本中位数的比值，不是逐次比值的中位数；延迟降幅以 baseline 中位数为分母，负值表示变慢。','BACKGROUND-1 仅有输入项目中的完成状态与描述，未提供其实体产物；保留的是与延迟无关定义的适用范围，不代表已读取或重新验收旧产物。'],'invalidated_work':['WRITE-OLD'],'retained_work':['BACKGROUND-1'],'invalidated_work_details':[{'id':'WRITE-OLD','previous_input_version':'synthetic-v2','reason':'依赖旧延迟数据的文本必须按 synthetic-v3 重写；当前三个工作负载均未达到 1.8x，medium 的 ratio 小于 1，直接否定“每个工作负载至少 1.8x”。','evidence_rows':[2,3,4]}],'retained_work_details':[{'id':'BACKGROUND-1','input_version':'literature-outline-v1','scope':'baseline/candidate 比较的定义不依赖延迟数值，可保留其定义性范围。','verification':'仅检查项目元数据说明与当前指标契约的适用性；旧实体产物未提供，未认定已重新验收。'}],'methods':{'unit':'ms','scope':'end_to_end','statistic':'median within workload and variant, including all supplied rows','formulas':contract['formulas'],'n_input_rows':len(rows),'filtering':'none','numerical_precision':'CSV retains Python float round-trip precision; prose decimals are rounded.'},'overall_conclusion':'在该合成快照内，small 与 large 的候选中位延迟下降，medium 上升，收益依工作负载而异；不支持所有工作负载至少 1.8x 的旧结论。','handoff':{'next_owner':'research-write','next_task':'依据经过哈希验证的 analysis.json 与 aggregate.csv，撰写中文 Results 段落及英文摘要。','scope':'本节点仅分析与交接，尚未代写 Results 或摘要。','preconditions':['analysis.json 与 aggregate.csv 两个实际文件均存在。','writer 复算 aggregate.csv 的 SHA256，须等于 aggregate_file.sha256；失败则阻塞依赖写作。'],'on_missing_input':'blocked; request the actual missing or matching-version handoff files','do_not_claim':['real GPU/model benchmarking','quality preserved','statistical significance','universal speedup','at least 1.8x on every workload']}}
(OUT/'analysis.json').write_text(json.dumps(analysis,ensure_ascii=False,indent=2)+'\n')
# Verify serialized handoff, exact CSV column order, counts and a separately expressed arithmetic identity.
reloaded=json.loads((OUT/'analysis.json').read_text())
assert all(k in reloaded for k in contract['analysis_json_required'])
assert sha(OUT/'aggregate.csv')==reloaded['aggregate_file']['sha256']
with (OUT/'aggregate.csv').open(newline='') as f:
    reader=csv.DictReader(f);assert reader.fieldnames==contract['aggregate_csv_columns'];serialized=list(reader)
assert len(serialized)==len(workloads)==3
for r in serialized:
    b=float(r['baseline_median_ms']);c=float(r['candidate_median_ms'])
    assert math.isclose(float(r['speedup_ratio']),b/c,rel_tol=1e-14)
    assert math.isclose(float(r['latency_reduction_pct']),100*(1-c/b),abs_tol=1e-12)
assert next(float(r['speedup_ratio']) for r in serialized if r['workload']=='medium')<1
print(json.dumps({'python':sys.version.split()[0],'input_rows':len(rows),'groups':len(groups),'duplicate_keys':len(rows)-len(seen),'checks':'schema keys, CSV header, versions, scopes, positive finite values, unique keys, counts, hash and formulas verified','aggregate_sha256':sha(OUT/'aggregate.csv'),'aggregates':aggregates},ensure_ascii=False,indent=2))

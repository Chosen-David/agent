from pathlib import Path
import json,hashlib,subprocess,datetime
O=Path(__file__).parent
manifest=json.loads((O/'render_manifest.json').read_text()); H=manifest['pdf_sha256']
def dump(name,obj): (O/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
# JSON syntax is a YAML 1.2 subset, used to avoid a runtime dependency.
findings=[
{'finding_id':'READ-F001','snapshot_id':H,'category':'evidence','severity':'major','confidence':'high','assertion_type':'reporting_gap','status':'open','location':{'physical_page':2,'printed_page':'1','anchor':'Claim: this proves RoPE always amplifies error in every real model.','related_location':{'physical_page':3,'printed_page':'A1','anchor':'Appendix: scope; both scope sentences'}},'evidence':['Page 2 concludes a universal result about RoPE and real models from two scalar outputs.','Page 3 explicitly says this is an invented teaching example, not empirical evidence; no RoPE-specific model, data or experiment was studied.','Visual evidence: alternate/page-0002.png and alternate/page-0003.png, same PDF snapshot.'],'why_it_matters':'The stated scope of the evidence cannot establish the universal conclusion. The appendix does not retroactively justify the body claim. This is a claim/evidence mismatch, not proof that the scientific claim is itself false.','verification':'Main AI should check whether a valid RoPE-specific theorem or independently applicable evidence exists; the supplied final PDF presents none. Verify the exact claim and appendix together. Do not treat lack of experiments alone as disproving a possible theoretical result.','resolution_options':['Restrict the conclusion to this invented example: changing one logit component changes the shared normalized weights and output.','If preserving a RoPE claim, provide a precise model mapping, quantified assumptions and an adequate proof; real-model experiments may support bounded empirical claims but not by themselves prove every model.'],'acceptance':['The final PDF claim matches the stated evidence scope and no longer asserts an unsupported universal result.','Any retained RoPE result is linked to explicit assumptions and supporting evidence visible in the final PDF.'],'related_findings':['READ-F002']},
{'finding_id':'READ-F002','snapshot_id':H,'category':'figure_semantics','severity':'major','confidence':'high','assertion_type':'reader_confusion','status':'open','location':{'physical_page':2,'printed_page':'1','anchor':'Output is 5; Output is 7.5; amplifies error','related_location':{'physical_page':1,'printed_page':'i','anchor':'y = softmax(a + b) V'}},'evidence':['The two outputs and the formula define a response to changing b, but the three-page PDF never specifies a target output, an error metric, or an amplification baseline.','CPU arithmetic check confirms outputs 5.0 and 7.5 and absolute change 2.5; arithmetic is not the defect.','Visual evidence: alternate/page-0001.png and alternate/page-0002.png.'],'why_it_matters':'A larger output is not necessarily a larger error. The reader cannot tell whether the example illustrates sensitivity, error, or amplification, nor infer the claimed mechanism.','verification':'Specify the intended target/reference and error or perturbation norm. Recompute the two errors and the amplification comparison. Establish how a and b correspond to the claimed RoPE mechanism if that interpretation is retained.','resolution_options':['Describe the demonstrated effect as output sensitivity and remove unsupported error-amplification terminology.','For an error claim, define the target, metric and comparator before the example, then show the calculation and its limited scope.'],'acceptance':['A reader can reproduce every retained error/amplification value from definitions visible before or next to the example, or the text consistently describes output change only.'],'related_findings':['READ-F001']}
]
dump('findings.yaml',{'schema_version':'1.0','agent':'reader','snapshot':{'id':H,'pdf':manifest['pdf']},'findings':findings})
rows=[json.loads(x) for x in (O/'page_coverage.jsonl').read_text().splitlines()]
for row in rows:
 row['finding_ids']={1:['READ-F002'],2:['READ-F001','READ-F002'],3:['READ-F001']}[row['physical_page']]
 row['alternate_image']=f"alternate/page-{row['physical_page']:04d}.png"
 row['alternate_opened']=True
 row['rendering_note']='Initial Poppler spacing distortion disappeared in separately opened PyMuPDF rendering; not classified as an intrinsic visual defect.'
(O/'page_coverage.jsonl').write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in rows)+'\n')
dump('alternate_render_manifest.json',{'pdf_sha256':H,'renderer':'PyMuPDF','version':'1.26.6','scale':2,'dpi':144,'pages':[{'physical_page':n,'image':f'alternate/page-{n:04d}.png','sha256':hashlib.sha256((O/f'alternate/page-{n:04d}.png').read_bytes()).hexdigest(),'opened':True,'visual_result':'Clean text; no overlap or clipping observed.'} for n in range(1,4)]})
dump('figure_coverage.yaml',{'snapshot_id':H,'figures':[],'tables':[],'algorithms':[],'note':'No figures, tables, algorithm boxes or reference list appear in the three-page PDF. All three physical pages, including Appendix, were visually read.','equations':[{'id':'unnumbered-equation-page-1','physical_page':1,'anchor':'y = softmax(a + b) V','read_complete':True,'interpretation':'Both logits jointly determine one normalization and hence the output.','relation_to_claim':'Provides the formula for the numerical example; does not establish a RoPE or error-amplification claim.'},{'id':'numerical-example-page-2','physical_page':2,'read_complete':True,'interpretation':'Uniform weights give 5; b=(0,log(3)) gives weights 1/4 and 3/4 and output 7.5.','numeric_check':'numeric_check.py','finding_ids':['READ-F001','READ-F002']}]})
tasks=[]
for i,f in enumerate(findings):
 for j,stage in enumerate(['verify','resolve','recheck']):
  num=i*3+j+1;tid=f'READ-T{num:03d}'
  tasks.append({'task_id':tid,'finding_ids':[f['finding_id']],'stage':stage,'depends_on':[] if j==0 else [f'READ-T{num-1:03d}'],'owner':'main_ai' if j<2 else 'original_reader','preconditions':['Matching snapshot and stated evidence available'] if j==0 else ['Preceding task record available'],'action':f['verification'] if j==0 else 'On confirmation, apply a minimal evidence-supported wording/definition fix; on rejection, retain justification; unresolved claims must not be silently repaired by invented evidence.' if j==1 else 'Read the revised PDF and test this finding’s acceptance conditions. Check affected and adjacent pages and appendix, bind a new hash; unchanged PDF requires review of rejection evidence.','outputs':[f'{stage}/{tid}.md'],'done_when':['Assign confirmed/rejected/unresolved with cited evidence'] if j==0 else ['Record supported edits or justified non-edit decision'] if j==1 else f['acceptance'],'on_missing_input':'blocked; state missing evidence/new PDF and recovery requirement, continue independent tasks','status':'todo'})
dump('task_chain.yaml',{'schema_version':'1.0','snapshot_id':H,'tasks':tasks})
(O/'task_chain.md').write_text('核验 → 处理 → 复查\n\nREAD-F001: READ-T001 → READ-T002 → READ-T003。核对第二页的普遍主张与第三页范围限制；限制主张或补入合格论证；随后重读新 PDF。\n\nREAD-F002: READ-T004 → READ-T005 → READ-T006。明确误差定义与比较基准；改为输出变化或展示误差计算；随后核对读者能否复算。\n\n两条核验可独立进行；同一段落的修订应协调，避免两个改动互相覆盖。所有任务为 todo，本次仅审读，没有修改论文。若修改，生成新 PDF/hash 并重读全部三页后才能声明新版本全页完成。\n')
report=f'''# 最终 PDF 逐页审读记录

审读状态：complete_review，3/3 个物理页已渲染、实际打开并读完（包括附录）。这表示阅读覆盖完成，不表示论文主张已获验证。目标读者为相关领域研究生或相邻领域研究者。

PDF SHA-256：`{H}`。

|物理页|印刷标签|本页新增信息|发现|
|---|---|---|---|
|1|i|定义共享 softmax 的两条 logit 路径与输出公式|READ-F002 的上下文|
|2|1|给出输出 5→7.5 的例子，再作 RoPE 的普遍误差主张|READ-F001、READ-F002|
|3|A1|附录明确为虚构教学例子，且没有 RoPE 专门模型、数据或实验|READ-F001 的范围反证|

核心问题是证据范围与结论不匹配。教学算例说明 b 改变时共享权重和输出可以改变；它没有建立“RoPE 在每个真实模型中总会放大误差”。附录说明降低了误读空间，却与正文强断言不协调。该观察不等于本审读证明该科学命题为假。

READ-F002 是独立的术语/理解缺口：文中未定义目标值、误差度量与放大比较基准。输出从 5 增到 7.5 是输出变化，不能直接读成误差变大。CPU 复算两值正确，详见 numeric_check.py 与 numeric_result.json。

版面与渲染：最初 Poppler 的文本字距畸变伴随 Fontconfig 无可写缓存警告。pdffonts 显示 Helvetica 未嵌入。为排除工具误报，另用 PyMuPDF 1.26.6 渲染并再次打开三页，文本干净、无重叠或裁切；因此没有登记“PDF 字距/乱码缺陷”。原始及替代渲染均保留，以便复核。无图、表、算法框或参考文献段落；唯一公式和数值算例另记于 figure_coverage.yaml。

只读了最终 PDF；未查看 make_pdf.py、作者源文件或其他输入。没有外网查询，也没有验证关于 RoPE 的外部事实；只报告 PDF 内部可见的证据缺口。无需补读页，未修改论文。发现状态均为 open，核验任务均为 todo：resolved=0，rejected=0，blocked=0，remaining=2。

下一负责人：主 AI 按 task_chain.yaml 核验、协调修订并提交新 PDF；复查必须绑定新 hash，不能用这些旧页图关闭改稿后的问题。
'''
(O/'reader_report.md').write_text(report)
result=subprocess.run(['python','-B',str(O/'numeric_check.py')],capture_output=True,text=True,check=True)
(O/'numeric_result.json').write_text(result.stdout)
(O/'skill_selection.md').write_text('选择 pinned research-read-pdf 角色及其 execution/workflow 规范；版本由 loaded.json 中实际读取路径和 SHA-256 固定。offline_fallback：按宿主限制不联网、不安装，不声称找到当前最佳工具。当前已有 pdfinfo、pdftoppm、pdffonts、PyMuPDF 与实际图像查看能力足够。Poppler 的环境相关字距问题使用独立 PyMuPDF 渲染交叉检查。没有加载同名已安装替代 skill。\n')
# Verify ledger, immutable input hash, image existence and acyclic task dependencies.
assert hashlib.sha256(Path(manifest['pdf']).read_bytes()).hexdigest()==H
assert [r['physical_page'] for r in rows]==[1,2,3]
assert all(r['opened'] and r['read_complete'] for r in rows)
assert all((O/r['image']).is_file() for r in rows)
seen=set()
for t in tasks:
 assert all(p in seen for p in t['depends_on'])
 seen.add(t['task_id'])
(O/'verification.json').write_text(json.dumps({'input_hash_unchanged':True,'physical_pages':3,'rendered':3,'opened':3,'read_complete':3,'unread_pages':[],'task_dependencies_exist_and_acyclic':True,'numeric_check':'outputs 5.0 and 7.5 confirmed','limitation':'Mechanical checks do not prove visual reading; visual observations recorded separately.'},indent=2))
print('Created review artifacts; hash/coverage/dependency/numeric checks complete.')

import csv,json
from pathlib import Path
root=Path(__file__).resolve().parent
source=root.parents[2]/'inputs/measurements.csv'
rows=list(csv.DictReader(source.open()))
results=[]
for r in rows:
 b,c=float(r['baseline_ms']),float(r['candidate_ms'])
 results.append(dict(workload=r['workload'],scope=r['scope'],baseline_ms=b,candidate_ms=c,speedup=b/c,time_reduction_pct=100*(b-c)/b,delta_ms=c-b,n=1))
e2e=[r for r in results if r['scope']=='end_to_end']
summary={'rows':results,'unweighted_once_per_workload_total':{'baseline_ms':sum(r['baseline_ms'] for r in e2e),'candidate_ms':sum(r['candidate_ms'] for r in e2e)},'warning':'Descriptive synthetic single runs; totals assume one invocation per workload and are not a deployment weighting. Kernel is already included; no additive kernel total.'}
a=summary['unweighted_once_per_workload_total'];a['speedup']=a['baseline_ms']/a['candidate_ms'];a['time_reduction_pct']=100*(a['baseline_ms']-a['candidate_ms'])/a['baseline_ms']
assert len(e2e)==3 and len(results)==4
assert next(r for r in results if r['workload']=='large')['delta_ms']==20
assert a['baseline_ms']==420 and a['candidate_ms']==400
(root/'analysis.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))

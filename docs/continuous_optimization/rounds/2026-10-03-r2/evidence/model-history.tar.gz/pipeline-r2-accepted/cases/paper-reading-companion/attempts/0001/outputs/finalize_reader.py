"""Apply observed printed-page labels and saved starting location to generated HTML."""
from pathlib import Path
import json,re,hashlib
p=Path(__file__).with_name('paper.html')
s=p.read_text()
m=re.search(r'(<script id="reader-data" type="application/json">)(.*?)(</script>)',s,re.S)
d=json.loads(m[2])
d['title']='Synthetic paper: Two logit paths'
for page in d['pages']:
    page['label']={1:'i',2:'1',3:'A1'}[page['number']]
encoded=json.dumps(d,ensure_ascii=False).replace('&','\\u0026').replace('<','\\u003c').replace('>','\\u003e').replace('\u2028','\\u2028').replace('\u2029','\\u2029')
s=s[:m.start(2)]+encoded+s[m.end(2):]
s=s.replace('<title>paper.pdf · 论文伴读</title>','<title>Synthetic paper: Two logit paths · 论文伴读</title>')
s=s.replace('let index=0,zoom=100,textMode=false;','let index=data.pages.findIndex(p=>p.number===2),zoom=100,textMode=false;')
p.write_text(s)
checks={'embedded_pages':[x['number'] for x in d['pages']],'printed_labels':[x['label'] for x in d['pages']],'notes_hash_match':d['sha256']==json.loads(p.with_name('notes.json').read_text())['paper_sha256'],'card_ids':[c['id'] for c in d['cards']],'default_page':2,'network_backend':False,'browser_validation':'not performed; browser unavailable to worker','page_image_validation':'All 3 PNGs actually opened using view_image','html_size_bytes':p.stat().st_size}
assert checks['notes_hash_match'] and checks['card_ids']==['EXPL-001']
assert '__READER_DATA__' not in s
assert all(x['image'] for x in d['pages'])
p.with_name('artifact_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
print(json.dumps(checks,ensure_ascii=False,indent=2))

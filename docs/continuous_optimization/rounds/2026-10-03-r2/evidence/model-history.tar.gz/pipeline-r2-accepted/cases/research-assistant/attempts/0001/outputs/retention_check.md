# 背景分支保留范围检查

已实际读取 project.json 和 concept.txt。project.json 将 background 的唯一输入记为 concept.txt@v1；此次明确变化仅为 measurements.csv@v2。因此在项目所声明的依赖图上，background 不属于此次更新的失效闭包。保留历史完成声明，不重启该分支。

限制：没有 concept.txt 的旧哈希，不能证明字节与 v1 完全相同；没有 background@v1 正文，不能核验其内容。当前 concept.txt 是 softmax 量化教学例子，不是性能测量，不用于证明 CSV 收益。本轮也没有将其内嵌问题扩展成额外教学交付。

本检查完成的对象是“依赖与适用范围判定”，证据为上述实际输入及 input_manifest.json。历史背景正文复验独立 blocked，恢复条件为提供 background@v1 及其绑定的 concept 版本。最终交付依赖本检查，不依赖 skipped 的历史重做任务。

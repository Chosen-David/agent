import json, math

def output(a,b,v):
    z=[x+y for x,y in zip(a,b)]
    e=[math.exp(x-max(z)) for x in z]
    return sum(x*y for x,y in zip(e,v))/sum(e)
base=output([0,0],[0,0],[0,10])
changed=output([0,0],[0,math.log(3)],[0,10])
assert abs(base-5)<1e-12 and abs(changed-7.5)<1e-12
print(json.dumps({'base':base,'changed':changed,'absolute_output_change':abs(changed-base),'claim_limit':'Output change is not error amplification without a target, error definition, and comparator.'},indent=2))

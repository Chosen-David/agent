# Figure QA — FIG-MIXED-01

Owner: /root/s02_figures. Route: mixed; panel A uses the pinned diagram workflow and panel B the pinned data-visualization workflow, executed sequentially in this worker. No external agent/tool invocation is claimed.

Design: left-to-right A then B, provisional 8.4 × 3.8 inches. DejaVu Sans; 11 pt titles, 9 pt labels, 7.5–8.3 pt secondary text. Blue structural outlines identify computation; neutral gray identifies fixed V. Data series use blue solid baseline and orange hatched candidate; color is reinforced by hatch, position and legend. Bar lengths start at zero and preserve ms. Kernel-only scope has its own gray band and explicit label. A semantic color identity across panels is not implied: the diagram is not identified as the candidate implementation.

| Check | Status | Observed evidence |
|---|---|---|
| Evidence preservation | pass | Six nodes and exactly five directed data-flow edges match architecture.json; source copies match original input bytes. All eight runtime values are shown, including 200→220 ms regression. No added experiments or nodes. |
| Numerical | pass | checks.json records arrays [100,120,200,20] and [80,100,220,10]; four rows, no missing cells. Bar coordinates use these arrays directly without aggregation. |
| Semantic | pass | Parallel A/B merge, sum→softmax→output, V→output only. No A→B edge, feedback, V→softmax or measured-accuracy claim. |
| Hierarchy and typography | pass | Final composite reopened after title alignment adjustment. Titles align; all node text, values, axis labels and superscript T are legible in the 1008×456 nominal-size preview. |
| Layout and whitespace | pass | Five arrows land at their correct boxes; no crossings or label collisions. Data values lie beyond bars with right margin; legend lies below axes. |
| Accessibility | pass for grayscale | Actually opened grayscale image: solid and hatched bars remain distinguishable; diagram relies on labels and connectors. Color-vision simulation was not performed. |
| Final size / page embedding | pass at provisional size | Opened figure_final_size.png at 120 dpi and figure_page_preview.png at unchanged 1008 px figure width; no clipping in full composition. Screen display is not a physical print proof. |
| Standalone panels | pass | Opened both PNGs; standalone panel B initially clipped its title, corrected its axes height and reopened corrected panel_b.png. |
| Technical | pass | SVG XML parses; IDs unique; diagram IDs match all six nodes and five edges. No raster image tags in SVG. Text remains editable; local fonts are named, not bundled. Final PNG 2520×1140 at 300 dpi. |
| Reproducibility | pass | Separate panel scripts, shared style, compositor, input snapshots and hashes are included; commands in execution.md. |
| Submission specification | unverified | No venue or required physical width supplied. |

Visual inspection is this worker's actual image-tool review, not an independent model quality assessment. Data provenance, hardware, repeat unit and uncertainty remain unspecified; those limits do not prevent faithful plotting of the supplied table.

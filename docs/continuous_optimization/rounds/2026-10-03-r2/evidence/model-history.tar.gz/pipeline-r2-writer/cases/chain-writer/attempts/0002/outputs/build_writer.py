from pathlib import Path
import csv, hashlib, json, math, datetime
run=Path('/workspace/scratch/643bcb955317/agent/.agent-runs/pipeline-r2-writer')
case=run/'cases/chain-writer'
out=case/'attempts/0002/outputs'
inputs=case/'inputs'
a=json.loads((inputs/'analysis.json').read_text())
aggregate=(inputs/'aggregate.csv').read_bytes()
sha=hashlib.sha256(aggregate).hexdigest()
assert sha==a['aggregate_file']['sha256'], 'blocked: aggregate hash mismatch'
assert a['input_version']=='synthetic-v3', 'blocked: unexpected input version'
rows=list(csv.DictReader(aggregate.decode().splitlines()))
assert [r['workload'] for r in rows]==[f['workload'] for f in a['findings']]
checks=[]
for number,(r,f) in enumerate(zip(rows,a['findings']),2):
    assert f['aggregate_csv_row']==number
    for key in ['baseline_median_ms','candidate_median_ms','speedup_ratio','latency_reduction_pct']:
        assert math.isclose(float(r[key]),f[key],rel_tol=1e-12,abs_tol=1e-12)
    b,c=float(r['baseline_median_ms']),float(r['candidate_median_ms'])
    assert math.isclose(b/c,float(r['speedup_ratio']),rel_tol=1e-12)
    assert math.isclose(100*(b-c)/b,float(r['latency_reduction_pct']),rel_tol=1e-12)
    assert int(r['n_baseline'])==int(r['n_candidate'])==3
    checks.append({'workload':r['workload'],'csv_row':number,'analysis_consistent':True,'ratio_formula_checked':True,'reduction_formula_checked':True})
proxy_path=run/'host/chain-writer-attempt2-proxy.json'
proxy=json.loads(proxy_path.read_text())
assert proxy['result']['exit_code']==0
assert 'AGGREGATE_SHA256='+sha in proxy['result']['output']
(out/'tool_proxy_observation.json').write_text(json.dumps({'actor':'/root/s11_writer_recovery','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(proxy_path),'source_sha256':hashlib.sha256(proxy_path.read_bytes()).hexdigest(),'requested_command':proxy['cmd'],'raw_result':proxy['result'],'interpretation':'The aggregate_file.sha256 field matches the actual aggregate bytes. source_files hashes describe different upstream files and are not aggregate hash failures. Upstream files were not opened.'},ensure_ascii=False,indent=2)+'\n')
versions={name:hashlib.sha256((inputs/name).read_bytes()).hexdigest() for name in ['analysis.json','aggregate.csv']}
verification={'input_version':a['input_version'],'input_sha256':versions,'aggregate_hash_match':True,'checks':checks,'scope':'CPU consistency and arithmetic checks only; no new experiments'}
(out/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
zh='''# 结果（合成数据工作稿）

在 synthetic-v3 提供的合成端到端延迟数据中，每个工作负载的 baseline 与 candidate 各有 3 条记录，以各自的中位数进行比较。small 工作负载的中位延迟由 32 ms 降至 24 ms，下降 25.00%，中位数比值（baseline/candidate）为 1.3333；medium 由 56 ms 升至 58 ms，增加 3.57%，比值为 0.9655；large 由 96 ms 降至 80 ms，下降 16.67%，比值为 1.2000。因此，该合成快照中的收益依赖工作负载，medium 的退化表明不能声称普遍加速。延迟降幅以 baseline 中位数为分母，比值为两版本中位数之比。记录的独立性及跨版本配对关系未知，且未提供硬件配置和质量指标；这些描述性结果不支持统计显著性、质量保持、因果机制或其他工作负载上的性能结论。本稿仅重述交接数据，未运行新实验或真实模型/GPU 基准测试。
'''
en='''# Abstract (working draft based on synthetic data)

We summarize the supplied synthetic-v3 end-to-end latency data using the median of three records per workload and variant. Baseline/candidate medians were 32/24 ms for small, 56/58 ms for medium, and 96/80 ms for large. Candidate latency decreased by 25.00% and 16.67% for small and large, respectively, but increased by 3.57% for medium. The corresponding baseline-to-candidate median ratios were 1.3333, 0.9655, and 1.2000. These descriptive results show workload-dependent outcomes within this synthetic snapshot and do not establish universal acceleration. Record independence and cross-variant pairing are unknown, while hardware and quality metrics are unspecified. Statistical significance, quality preservation, causal mechanisms, and performance beyond the supplied workloads are therefore not established. No new experiments or real model/GPU benchmarks were conducted for this draft.
'''
claims=[]
for number,r in enumerate(rows,2):
    w=r['workload']
    claims.append({'claim_id':'WRITE-'+w.upper(),'kind':'descriptive_synthetic','status':'supported_within_supplied_snapshot','workload':w,'quantitative_values':{k:float(r[k]) for k in ['baseline_median_ms','candidate_median_ms','speedup_ratio','latency_reduction_pct']},'prose_values':{'small':'32/24 ms; 25.00% decrease; ratio 1.3333','medium':'56/58 ms; 3.57% increase; ratio 0.9655','large':'96/80 ms; 16.67% decrease; ratio 1.2000'}[w],'source_locations':[{'file':'inputs/aggregate.csv','csv_row_including_header':number,'workload':w},{'file':'inputs/analysis.json','json_pointer':'/findings/'+str(number-2),'workload':w}],'manuscript_locations':['results_zh.md paragraph 1','abstract_en.md paragraph 1'],'scope':'Supplied synthetic-v3 end-to-end latency; ratio of variant medians, not median of paired ratios'})
claims.append({'claim_id':'WRITE-N','text':'Three records per workload and variant','quantitative_values':{r['workload']:{'n_baseline':int(r['n_baseline']),'n_candidate':int(r['n_candidate'])} for r in rows},'source_locations':[{'file':'inputs/aggregate.csv','csv_row_including_header':i,'workload':r['workload'],'columns':['n_baseline','n_candidate']} for i,r in enumerate(rows,2)]+[{'file':'inputs/analysis.json','json_pointer':'/limitations/1'}],'manuscript_locations':['results_zh.md paragraph 1','abstract_en.md paragraph 1']})
ledger={'schema_version':1,'status':'draft_complete','project_id':a['project_id'],'input_version':a['input_version'],'input_sha256':versions,'aggregate_hash_verified':True,'metric_definitions':a['methods']['formulas'],'rounding':'Percentages rounded to two decimal places; ratios to four. medium increase is negative latency_reduction_pct with sign reversed.','claims':claims,'qualitative_scope_sources':[{'file':'inputs/analysis.json','json_pointers':['/limitations','/methods','/overall_conclusion','/handoff/do_not_claim']}],'limitations':a['limitations'],'prior_work_disposition':{'WRITE-OLD':'Invalidated according to current analysis metadata; no old outputs read or reused.','BACKGROUND-1':'Only metadata supplied; no background content imported or claimed revalidated.'},'tool_observation':'tool_proxy_observation.json'}
# Establish the evidence ledger before emitting prose.
(out/'claim_evidence.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
(out/'results_zh.md').write_text(zh)
(out/'abstract_en.md').write_text(en)
print(json.dumps(verification,indent=2))
print('Drafts and claim evidence written from verified inputs.')

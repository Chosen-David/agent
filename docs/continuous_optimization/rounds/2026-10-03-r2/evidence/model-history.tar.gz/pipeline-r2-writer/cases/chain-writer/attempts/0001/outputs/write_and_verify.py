from pathlib import Path
import csv, json, hashlib, math, datetime
out=Path(__file__).resolve().parent
inputs=out.parents[2]/'inputs'
analysis_path=inputs/'analysis.json'
aggregate_path=inputs/'aggregate.csv'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads(analysis_path.read_text())
actual=sha(aggregate_path)
assert actual==a['aggregate_file']['sha256'], 'BLOCKED: aggregate hash mismatch'
assert a['input_version']=='synthetic-v3'
rows=list(csv.DictReader(aggregate_path.open()))
assert [r['workload'] for r in rows]==[f['workload'] for f in a['findings']]
for line,(r,f) in enumerate(zip(rows,a['findings']),2):
 assert f['aggregate_csv_row']==line
 for key in ['baseline_median_ms','candidate_median_ms','speedup_ratio','latency_reduction_pct']:
  assert math.isclose(float(r[key]),f[key],rel_tol=1e-12,abs_tol=1e-12)
 b,c=float(r['baseline_median_ms']),float(r['candidate_median_ms'])
 assert math.isclose(float(r['speedup_ratio']),b/c,rel_tol=1e-12)
 assert math.isclose(float(r['latency_reduction_pct']),100*(b-c)/b,rel_tol=1e-12)
 assert int(r['n_baseline'])==3 and int(r['n_candidate'])==3
zh='''本文段为基于 synthetic-v3 合成数据的工作稿。比较采用各工作负载、各版本的端到端延迟中位数；每个工作负载的 baseline 与 candidate 均包含 3 条记录。速度比定义为 baseline 中位数除以 candidate 中位数，延迟降幅以 baseline 中位数为分母。small 的中位延迟从 32 ms 降至 24 ms，速度比为 1.333×，延迟下降 25.00%；large 从 96 ms 降至 80 ms，速度比为 1.200×，延迟下降 16.67%。medium 则从 56 ms 升至 58 ms，速度比为 0.966×，延迟增加 3.57%。因此，该合成快照显示的收益随工作负载变化，不能据此声称所有工作负载均获加速。

这些描述仅归纳已交接的合成端到端延迟，不构成真实模型或 GPU 基准测试。重复记录的独立性与跨版本配对关系未知，未作统计显著性或总体性能推断；输入也未给出硬件与质量指标，因而不能据此认定质量保持、特定硬件加速效果或因果机制。当前结果不外推至其他工作负载。
'''
en='''Working draft based on synthetic data. We summarize end-to-end latency medians for baseline and candidate variants in the synthetic-v3 snapshot, with three records per variant for each workload. For small, median latency decreases from 32 to 24 ms, corresponding to a baseline-to-candidate median ratio of 1.333× and a 25.00% reduction. For large, latency decreases from 96 to 80 ms (1.200×; 16.67% reduction). For medium, latency instead increases from 56 to 58 ms (0.966×; 3.57% increase). These descriptive results indicate workload-dependent behavior within the supplied synthetic snapshot and do not support a universal speedup. Record independence and pairing are unknown, and hardware and quality metrics are unavailable. No statistical significance, quality preservation, causal mechanism, or real-model or GPU benchmarking result is established.
'''
(out/'results_zh.md').write_text(zh)
(out/'abstract_en.md').write_text(en)
claims=[]
for idx,(r,f) in enumerate(zip(rows,a['findings'])):
 w=r['workload']; increase=w=='medium'
 claims.append({'claim_id':f'WRITE-C00{idx+1}','kind':'descriptive_synthetic','status':'supported_within_snapshot','workload':w,'values':{k:float(r[k]) for k in ['baseline_median_ms','candidate_median_ms','speedup_ratio','latency_reduction_pct']},'display':{'baseline_median_ms':f"{float(r['baseline_median_ms']):.0f}",'candidate_median_ms':f"{float(r['candidate_median_ms']):.0f}",'speedup_ratio':f"{float(r['speedup_ratio']):.3f}",'latency_change_pct':f"{abs(float(r['latency_reduction_pct'])):.2f}",'direction':'increase' if increase else 'decrease'},'evidence':[{'file':'inputs/aggregate.csv','sha256':actual,'row':idx+2,'row_counting':'1-based physical CSV lines; header is row 1','workload':w,'columns':['baseline_median_ms','candidate_median_ms','speedup_ratio','latency_reduction_pct']},{'file':'inputs/analysis.json','sha256':sha(analysis_path),'json_pointer':f'/findings/{idx}','workload':w}],'manuscript_locations':[{'file':'results_zh.md','paragraph':1,'workload_sentence':w},{'file':'abstract_en.md','paragraph':1,'workload_sentence':w}],'scope':'synthetic-v3 supplied end-to-end latency medians; no real benchmark or inferential claim'})
claims.append({'claim_id':'WRITE-C004','text':'Each workload has three records for each variant.','kind':'descriptive_synthetic','status':'supported_within_snapshot','evidence':[{'file':'inputs/aggregate.csv','sha256':actual,'row':i+2,'workload':r['workload'],'columns':['n_baseline','n_candidate'],'values':[int(r['n_baseline']),int(r['n_candidate'])]} for i,r in enumerate(rows)],'manuscript_locations':[{'file':'results_zh.md','paragraph':1,'phrase':'均包含 3 条记录'},{'file':'abstract_en.md','paragraph':1,'phrase':'three records per variant for each workload'}]})
ledger={'project_id':a['project_id'],'input_version':a['input_version'],'status':'draft_complete','evidence_type':'synthetic_only','input_files':[{'path':str(p),'sha256':sha(p)} for p in [analysis_path,aggregate_path]],'aggregate_hash_check':{'expected':a['aggregate_file']['sha256'],'actual':actual,'match':True},'metric_definitions':a['methods'],'claims':claims,'qualitative_claims':[{'claim_id':'WRITE-C005','text':'Benefits depend on workload; universal speedup is unsupported.','derived_from':['WRITE-C001','WRITE-C002','WRITE-C003'],'counterevidence_to_universal_speedup':'medium has higher candidate median latency','manuscript_locations':['results_zh.md paragraph 1','abstract_en.md paragraph 1']}],'limitations_source':{'file':'inputs/analysis.json','json_pointer':'/limitations','sha256':sha(analysis_path)},'lineage':{'invalidated_work':a['invalidated_work'],'retained_work':a['retained_work'],'retained_scope':'BACKGROUND-1 definition scope only; original artifact not supplied or inspected'},'unverified':['raw-input medians were not recomputed; only supplied aggregate arithmetic and analysis consistency were checked','no real experiments, external literature, PDF generation, or independent review']}
(out/'claim_evidence.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
verification={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'aggregate_hash_match':True,'input_version':a['input_version'],'workload_rows_checked':len(rows),'analysis_aggregate_numeric_consistency':True,'speedup_and_percentage_formula_checks':True,'sample_counts_checked':True,'drafts_nonempty':all((out/p).stat().st_size>0 for p in ['results_zh.md','abstract_en.md']),'artifacts':[{'file':p,'sha256':sha(out/p)} for p in ['results_zh.md','abstract_en.md','claim_evidence.json']]}
(out/'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(verification,ensure_ascii=False,indent=2))

from style import *
import panel_a,panel_b
from PIL import Image
fig=plt.figure(figsize=(180/25.4,142/25.4))
panel_a.draw(fig.add_axes([.02,.565,.96,.42]))
panel_b.draw(fig,[.02,.015,.96,.535])
export(fig,'figure')
# A 100% physical-size raster at 150 dpi and a page-sized embedding preview.
fig.savefig(ROOT/'figure_final_size.png',dpi=150)
Image.open(ROOT/'figure_final_size.png').convert('L').save(ROOT/'figure_grayscale.png')
page=plt.figure(figsize=(210/25.4,297/25.4))
ax=page.add_axes([15/210,140/297,180/210,142/297]);ax.axis('off');ax.imshow(Image.open(ROOT/'figure.png'))
page.text(15/210,128/297,'Figure 1. Proposed logit combination and supplied timing values.',fontsize=8)
page.savefig(ROOT/'figure_page_preview.png',dpi=120)

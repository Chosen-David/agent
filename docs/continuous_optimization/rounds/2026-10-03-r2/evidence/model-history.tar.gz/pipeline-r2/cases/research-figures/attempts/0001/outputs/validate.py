import csv,hashlib,json,platform,xml.etree.ElementTree as ET
import matplotlib,numpy,PIL
from style import *
import panel_a,panel_b
out={}
# Verify original snapshots remain byte-identical, and record provenance.
out['inputs']={n:{'sha256':hashlib.sha256((ROOT/n).read_bytes()).hexdigest(),'identical_to_original':(ROOT/n).read_bytes()==(ROOT.parents[2]/'inputs'/n).read_bytes()} for n in ('architecture.json','measurements.csv')}
fig=plt.figure();ax=panel_b.draw(fig,[.02,.02,.96,.96])
expected_b=[float(r['baseline_ms']) for r in panel_b.DATA]; expected_c=[float(r['candidate_ms']) for r in panel_b.DATA]
actual_b=ax.collections[0].get_offsets()[:,0].tolist();actual_c=ax.collections[1].get_offsets()[:,0].tolist()
assert actual_b==expected_b and actual_c==expected_c
out['numerical']={'baseline_plotted_ms':actual_b,'candidate_plotted_ms':actual_c,'exact_match':True,'rows':len(panel_b.DATA),'missing_values':sum(v=='' for r in panel_b.DATA for v in r.values()),'aggregation':'none','normalization':'none','error_bars':'none supplied; none drawn','large_candidate_regression_ms':actual_c[2]-actual_b[2]}
svg=ET.parse(ROOT/'panel_a.svg').getroot();ids=[el.attrib['id'] for el in svg.iter() if 'id' in el.attrib]
node_ids=sorted(i for i in ids if i.startswith('node-'));edge_ids=sorted(i for i in ids if i.startswith('edge-'))
assert node_ids==sorted('node-'+n['id'] for n in panel_a.ARCH['nodes'])
assert edge_ids==sorted('edge-'+a+'-'+b for a,b in panel_a.ARCH['edges'])
out['semantic']={'node_ids':node_ids,'edge_ids':edge_ids,'exact_topology_match':True,'edge_kind':panel_a.ARCH['edge_kind'],'provided_status':panel_a.ARCH['status']}
out['svg']={}
for name in ('panel_a','panel_b','figure'):
    root=ET.parse(ROOT/(name+'.svg')).getroot();all_ids=[e.attrib['id'] for e in root.iter() if 'id' in e.attrib]
    refs=[v for e in root.iter() for k,v in e.attrib.items() if k.endswith('href')]
    external=[r for r in refs if not r.startswith('#')]
    assert len(all_ids)==len(set(all_ids));assert not external
    texts=[e for e in root.iter() if e.tag.endswith('}text')]
    out['svg'][name]={'xml_valid':True,'unique_ids':True,'external_resources':external,'editable_text_elements':len(texts),'width':root.attrib['width'],'height':root.attrib['height'],'viewBox':root.attrib['viewBox']}
out['versions']={'python':platform.python_version(),'matplotlib':matplotlib.__version__,'numpy':numpy.__version__,'Pillow':PIL.__version__}
(ROOT/'validation.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))

# synthetic-window-cache / pipeline-r2

本节点只做分析与交接。已使用 CPU 聚合 synthetic-v3 的 18 条合成测量，并复核旧工作的适用性。WRITE-OLD 失效；BACKGROUND-1 仅保留已提供描述的独立比较定义。没有独立子 Agent，按阶段执行。

当前决策：EXECUTE，沿用输入规定的中位数、比值与降幅公式。写作未开始；下一负责人 writer 须先核验交接文件存在与 aggregate.csv 的 SHA256。哈希不符或文件缺失时暂停写作，恢复条件为重新取得当前真实产物并核验。未访问历史原文，未验收其未知内容。

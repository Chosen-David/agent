import json
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from style import *
ARCH=json.loads((ROOT/'architecture.json').read_text())
# Positions are layout only; arrows are generated only from the supplied edges.
POS={'a':(.13,.61),'b':(.13,.27),'sum':(.40,.44),'softmax':(.65,.44),'v':(.88,.79),'output':(.88,.44)}
LABEL={'a':'Path A logits a','b':'Path B logits b','sum':'z = a + b','softmax':'p = softmax(z)','v':'Fixed values V','output':r'$y = p^{T}V$'}
def draw(ax):
    ax.set(xlim=(0,1),ylim=(0,1)); ax.axis('off')
    ax.text(.015,.98,'A',weight='bold',fontsize=11,va='top')
    ax.text(.060,.98,'Two-path logit combination',weight='bold',fontsize=9,va='top')
    ax.text(.060,.87,'PROPOSED · SYNTHETIC SPECIFICATION · NOT IMPLEMENTED',fontsize=6.8,color=MUTED,va='top')
    w,h=.19,.16
    for node in ARCH['nodes']:
        nid=node['id']; x,y=POS[nid]
        color=BLUE if nid in ('sum','softmax','output') else MUTED
        patch=FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=0.005,rounding_size=0.025',facecolor='#F0F7FA' if color==BLUE else '#F7F8FA',edgecolor=color,lw=.85)
        patch.set_gid('node-'+nid); ax.add_patch(patch)
        ax.text(x,y,LABEL[nid],ha='center',va='center',fontsize=7.4)
    for source,target in ARCH['edges']:
        x1,y1=POS[source]; x2,y2=POS[target]
        if source=='v': start=(x1,y1-h/2-.008); end=(x2,y2+h/2+.008)
        else: start=(x1+w/2+.008,y1); end=(x2-w/2-.008,y2)
        edge=FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=8,color=INK,lw=.9,connectionstyle='arc3,rad=0')
        edge.set_gid('edge-'+source+'-'+target); ax.add_patch(edge)
    ax.text(.015,.055,'Arrows: data flow. A and B are parallel; V enters only the output.',fontsize=7,color=MUTED)
if __name__=='__main__':
    fig=plt.figure(figsize=(180/25.4,62/25.4)); draw(fig.add_axes([.02,.04,.96,.94])); export(fig,'panel_a')

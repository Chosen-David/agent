# Figure routing, provenance and whole-figure QA

Figure ID: pipeline-r2/research-figures/FIG-01. Route: mixed. Unique owner: current research-figures executor. The two specialist workflows were executed sequentially by the same executor using the fixed snapshot, offline. No independent agent, external skill, web source, GPU or paid operation was used.

| Panel | Route | Evidence | Editable main source | State |
|---|---|---|---|---|
| A | diagram | Proposed synthetic specification, explicitly not implemented | panel_a.py; editable text/objects in panel_a.svg | ready-for-review |
| B | data_visualization | Supplied timing table; acquisition method and measured/synthetic origin unspecified | panel_b.py; editable text/objects in panel_b.svg | ready-for-review within supplied evidence |
| Full figure | mixed | Panel evidence remains separate | figure.py plus both panel modules and style.py; figure.svg | ready-for-review |

Input versions and exact SHA-256 values are in `loaded.json` (recorded before rendering) and `validation.json`. The delivered architecture.json and measurements.csv are byte-identical copies of the read-only input files. No missing CSV fields or rows were found; there are four workloads and eight timing values. Panel A uses all six supplied nodes and exactly the five directed data-flow edges. The V bypass, parallel A/B inputs, and absence of feedback/A-to-B edges are preserved. Implementation status is not inferred from the diagram.

Design: read A then B, in two full-width rows. Provisional physical size 180 × 142 mm; standalone A is 180 × 62 mm, B is 180 × 80 mm. DejaVu Sans, 11 pt panel identifiers, 9 pt panel titles, approximately 7–8 pt labels. Diagram node fills distinguish computational operations from sources without implying performance. Chart identity is stable: baseline blue open circle; candidate orange filled diamond, with explicit numeric labels. Faint gridlines support reading on an untruncated 0–250 ms axis. Kernel-only scope has an explicit text label, a shaded row and separation from end-to-end rows. The pale computational fill in A is not a method identity encoding or a mapping to baseline in B.

The whole figure is redrawn from editable vector primitives and panel functions, not assembled from screenshots. PNG outputs are 300 dpi. SVGs retain text, six stable node IDs and five stable edge IDs; no external resources. Fonts are referenced as editable text rather than embedded; other systems need DejaVu Sans for exact text metrics. The page preview alone uses a raster image to demonstrate physical placement; it is not the editable deliverable.

| QA dimension | Result | Evidence / concrete observation |
|---|---|---|
| Scientific / evidence preservation | pass within provided inputs | Proposed synthetic architecture visibly labeled; timings described as supplied values, no implementation or significance claim |
| Numerical | pass | validate.py compares actual scatter coordinates to every original timing; all eight match exactly; 220 ms regression preserved |
| Semantic | pass | Exported SVG contains exactly six node IDs and five input-defined edge IDs; opened figure shows V entering output and no feedback |
| Hierarchy / reading order | pass | A and B identifiers and concise titles align; upper method precedes lower comparison |
| Typography / target-size preview | pass for this draft | figure_final_size.png at 150 dpi opened; node labels, numeric labels, ms unit and scope labels readable; no visible clipping or overlap |
| Palette / gray accessibility | pass for grayscale; color-vision simulation unverified | Actual grayscale preview opened: open circles and filled diamonds remain distinguishable; text and shapes preserve identities |
| Whitespace / layout | pass | Both panels align on a common canvas; arrow routes avoid labels; legend sits above data; large and kernel rows remain visible |
| Legends / annotations | pass | Legend includes both markers, explicit lower-is-better axis, separate kernel scope; annotations do not obscure values |
| Technical | pass with font portability caveat | SVG XML parses, IDs unique, no external resources; PNGs opened; text remains editable but fonts are not embedded |
| Reproducibility | pass for local execution | panel_a.py, panel_b.py and figure.py actually ran with exit 0; validation.json includes versions and exact inputs; no manual drawing steps |
| Whole-page context | pass for provisional layout | figure_page_preview.png opened as 180 mm figure on 210 × 297 mm page, both panels visible; no venue template supplied |
| Submission requirements | unverified | No journal, conference, size/font mandate or submission template supplied |

Visual inspection round 1: used the actual view_image tool on figure_final_size.png, figure_grayscale.png and figure_page_preview.png, then figure.png, panel_a.png and panel_b.png. No clipping, missing glyph, line crossings, legend/data overlap or unreadable core labels was observed. No visual revision was needed. These are direct executor observations, not an independent model score or a claim of peer review. Physical dimensions are encoded and inspected in raster previews; no physical printer/display calibration was performed.

Rebuild from this folder:

```bash
MPLCONFIGDIR=/tmp/research-figures-mpl python panel_a.py
MPLCONFIGDIR=/tmp/research-figures-mpl python panel_b.py
MPLCONFIGDIR=/tmp/research-figures-mpl python figure.py
MPLCONFIGDIR=/tmp/research-figures-mpl python validate.py
```

Limits: the table does not specify independent repetitions, uncertainty, hardware or provenance of measurement generation. The architecture specification is not an implemented or tested model. No additional statistical claim, architecture edge or experimental value has been added. Color-vision simulation and external venue compliance were not verified.

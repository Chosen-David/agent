from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
BLUE='#237A96'
ORANGE='#C06C32'
INK='#243340'
MUTED='#667580'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'text.color':INK,'axes.labelcolor':INK,'xtick.color':MUTED,'ytick.color':INK,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':0.65,'savefig.facecolor':'white'})
def export(fig,name):
    for ext in ('svg','png'):
        fig.savefig(ROOT/f'{name}.{ext}',dpi=300)

import csv
import numpy as np
from style import *
DATA=list(csv.DictReader((ROOT/'measurements.csv').open()))
def draw(fig,rect):
    # Dedicated header and footnote space; one shared linear axis for both scopes.
    x,y,w,h=rect
    head=fig.add_axes([x,y+h*.86,w,h*.14]); head.axis('off')
    head.text(.015,.83,'B',weight='bold',fontsize=11,va='top')
    head.text(.060,.83,'Provided timing results',weight='bold',fontsize=9,va='top')
    ax=fig.add_axes([x+w*.17,y+h*.22,w*.72,h*.61])
    yy=np.array([3,2,1,-.45]); baseline=np.array([float(r['baseline_ms']) for r in DATA]); candidate=np.array([float(r['candidate_ms']) for r in DATA])
    ax.axhspan(-.9,.03,color='#F5F6F7',zorder=0)
    ax.axhline(.3,color='#C1C9CE',lw=.6,ls=(0,(3,3)))
    ax.scatter(baseline,yy+.13,s=29,marker='o',facecolor='white',edgecolor=BLUE,lw=1.2,label='Baseline',zorder=3)
    ax.scatter(candidate,yy-.13,s=26,marker='D',color=ORANGE,label='Candidate',zorder=3)
    for b,c,yi in zip(baseline,candidate,yy):
        ax.text(b+5,yi+.13,f'{b:g}',va='center',fontsize=7,color=BLUE)
        ax.text(c+5,yi-.13,f'{c:g}',va='center',fontsize=7,color=ORANGE)
    ax.set_yticks(yy,[r['workload'].capitalize() for r in DATA]); ax.set_ylim(-.95,3.65);ax.set_xlim(0,250)
    ax.set_xticks([0,50,100,150,200,250]);ax.set_xlabel('Time (ms) · lower is better',fontsize=8,labelpad=5)
    ax.tick_params(axis='y',length=0,pad=8); ax.tick_params(axis='x',length=3,labelsize=7)
    ax.spines['left'].set_visible(False); ax.grid(axis='x',color='#E4E8EB',lw=.5);ax.set_axisbelow(True)
    ax.text(.0,1.03,'END-TO-END',transform=ax.transAxes,fontsize=6.8,color=MUTED)
    ax.text(245,-.48,'KERNEL ONLY',ha='right',va='center',fontsize=6.8,color=MUTED)
    ax.legend(loc='upper right',bbox_to_anchor=(1.0,1.21),frameon=False,ncol=2,fontsize=7,handletextpad=.4,columnspacing=1.3)
    foot=fig.add_axes([x,y,w,h*.10]);foot.axis('off')
    foot.text(.015,.55,'All supplied rows shown; kernel-only timing is a separate scope.',fontsize=7,color=MUTED)
    return ax
if __name__=='__main__':
    fig=plt.figure(figsize=(180/25.4,80/25.4)); draw(fig,[.02,.02,.96,.96]); export(fig,'panel_b')

from pathlib import Path
import csv, json, hashlib, statistics, math
from collections import defaultdict
OUT=Path(__file__).resolve().parent
IN=OUT.parents[2]/'inputs'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
project=json.loads((IN/'chain_project.json').read_text())
contract=json.loads((IN/'handoff_fields.json').read_text())
rows=list(csv.DictReader((IN/'chain_latencies.csv').open(newline='')))
groups=defaultdict(list); keys=set()
for r in rows:
    assert r['input_version']==project['input_version']
    assert r['scope']=='end_to_end'
    assert r['variant'] in ('baseline','candidate')
    key=(r['workload'],r['variant'],r['repeat'])
    assert key not in keys; keys.add(key)
    x=float(r['latency_ms']); assert math.isfinite(x) and x>0
    groups[(r['workload'],r['variant'])].append(x)
workloads=list(dict.fromkeys(r['workload'] for r in rows))
aggregate=[]
for w in workloads:
    a=groups[w,'baseline']; b=groups[w,'candidate']
    assert len(a)==len(b)==project['measurement_conditions']['repeats_per_variant']
    am=statistics.median(a); bm=statistics.median(b)
    aggregate.append(dict(zip(contract['aggregate_csv_columns'],[w,len(a),len(b),am,bm,am/bm,100*(am-bm)/am])))
with (OUT/'aggregate.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=contract['aggregate_csv_columns']);writer.writeheader();writer.writerows(aggregate)
findings=[]
for i,r in enumerate(aggregate,2):
    w=r['workload']; red=r['latency_reduction_pct']
    findings.append({'id':f'LATENCY-{w.upper()}','evidence_type':'derived_from_supplied_synthetic_measurements','workload':w,'aggregate_row':i,'aggregate_ref':f'aggregate.csv:row={i};workload={w}','baseline_median_ms':r['baseline_median_ms'],'candidate_median_ms':r['candidate_median_ms'],'speedup_ratio':r['speedup_ratio'],'latency_reduction_pct':red,'statement':f"在所提供的 synthetic-v3 合成端到端延迟数据中，{w} 的基线/候选中位数分别为 {r['baseline_median_ms']:g}/{r['candidate_median_ms']:g} ms，speedup ratio 为 {r['speedup_ratio']:.6f}；"+(f'候选延迟降低 {red:.6f}%。' if red>=0 else f'候选延迟上升 {-red:.6f}%（延迟降幅为负）。')})
findings.append({'id':'OLD-CLAIM-REFUTED','evidence_type':'arithmetic_comparison','workloads':workloads,'aggregate_rows':[2,3,4],'statement':'synthetic-v3 三个工作负载均未达到 1.8×；medium 的 speedup ratio 小于 1。旧文每个工作负载至少 1.8× 的结论不适用于当前数据。'})
limitations=['输入为离线评测的合成数据，不是真实模型、CPU 或 GPU 性能实验；本次仅使用 CPU 进行算术聚合。','每个版本每个工作负载只有 3 条重复记录；独立实验单位与配对设计未说明，不据此声称统计显著性或计算置信区间。','硬件未指定，不能推断实际硬件性能、机制原因、其他工作负载或更大规模的表现。','质量指标为空，无法支持精度不变、质量不退化或质量与延迟权衡的结论。','结论仅针对 end_to_end 延迟和 synthetic-v3；未进行新 benchmark、联网、GPU 或安装外部运行时。','BACKGROUND-1 的历史原文未提供：仅核查项目描述中的比较定义仍适用，未独立验收未见历史文档。']
analysis={'schema_version':contract['schema_version'],'project_id':project['project_id'],'input_version':project['input_version'],'source_files':[{'path':str(IN/n),'sha256':sha(IN/n)} for n in ['chain_project.json','chain_latencies.csv','handoff_fields.json']],'aggregate_file':{'path':'aggregate.csv','sha256':sha(OUT/'aggregate.csv')},'findings':findings,'limitations':limitations,'invalidated_work':['WRITE-OLD'],'retained_work':['BACKGROUND-1'],'formulas':contract['formulas'],'aggregation':{'group_by':['workload','variant'],'statistic':'median','unit':'ms','scope':'end_to_end','raw_rows':len(rows),'discarded_rows':0,'missing_values':0,'duplicate_measurement_keys':0,'csv_numeric_precision':'Python float round-trip representation; explanatory prose rounded to 6 decimal places','ratio_semantics':'baseline median / candidate median; <1 indicates candidate slowdown; negative latency_reduction_pct indicates increased latency'},'previous_work_assessment':{'WRITE-OLD':'依赖 synthetic-v2 的性能表述失效；v3 所有工作负载 ratio 均小于 1.8，且 medium 回退。下一位写作者必须以本次数据重写相关主张。','BACKGROUND-1':'可保留项目描述中的 baseline/candidate 比较定义，因为不依赖延迟值。以本次 BACKGROUND-CHECK 的适用性检查记录为依据；不冒充已读原历史产物。'},'handoff':{'next_owner':'writer','delivery_requested':'Chinese Results paragraph and English abstract','status':'analysis_complete; writing_not_started','required_files':['analysis.json','aggregate.csv'],'rule':'Host copies actual files unchanged. Writer must verify aggregate sha256 and required files before dependent writing; missing files or hash mismatch blocks writing.','path_semantics':'aggregate_file.path is relative to the directory containing analysis.json; source_files identify original provenance and need not be present at the writer stage.'}}
(OUT/'analysis.json').write_text(json.dumps(analysis,ensure_ascii=False,indent=2)+'\n')
# Actual task graph: separate applicability check from absent historical execution.
def task(id,depends,inputs,action,outputs,status,done_when):
 return {'task_id':id,'stage':'analysis' if id!='WRITE-NEXT' else 'writing','depends_on':depends,'owner':'coordinator' if id!='WRITE-NEXT' else 'writer','inputs':inputs,'action':action,'outputs':outputs,'done_when':done_when,'on_failure':'Block only dependent work; preserve outputs and report recovery condition.','resource_budget':'Current node: CPU arithmetic only, total 6 minutes, no network/new experiments/GPU/subagents.','status':status}
tasks=[task('BACKGROUND-CHECK',[],['chain_project.json#previous_work/BACKGROUND-1'],'Check applicability of the supplied description without claiming access to missing historical text.',['analysis.json#previous_work_assessment/BACKGROUND-1'],'done','Description is independent of latency; actual applicability assessment saved.'),task('LATENCY-ANALYSIS',[],['chain_latencies.csv','handoff_fields.json'],'Validate 18 rows, group medians, evaluate formulas and old claim.',['aggregate.csv','analysis.json'],'done','Required schema, arithmetic and hashes verified.'),task('HANDOFF',['BACKGROUND-CHECK','LATENCY-ANALYSIS'],['analysis.json','aggregate.csv'],'Validate analysis-to-writer contract and provenance.',['validation.json'],'done','Files, schema, SHA256 and task dependency checks pass.'),task('WRITE-NEXT',['HANDOFF'],['analysis.json','aggregate.csv'],'Writer verifies copied hashes, then writes bounded Chinese Results and English abstract.',['Next-stage writing outputs'],'todo','Next writer delivers requested text based on verified files.')]
(OUT/'task_chain.yaml').write_text(json.dumps({'run_id':'pipeline-r2','case':'chain-coordinator','decision':'EXECUTE','tasks':tasks},ensure_ascii=False,indent=2)+'\n')
(OUT/'project_state.md').write_text('# synthetic-window-cache / pipeline-r2\n\n本节点只做分析与交接。已使用 CPU 聚合 synthetic-v3 的 18 条合成测量，并复核旧工作的适用性。WRITE-OLD 失效；BACKGROUND-1 仅保留已提供描述的独立比较定义。没有独立子 Agent，按阶段执行。\n\n当前决策：EXECUTE，沿用输入规定的中位数、比值与降幅公式。写作未开始；下一负责人 writer 须先核验交接文件存在与 aggregate.csv 的 SHA256。哈希不符或文件缺失时暂停写作，恢复条件为重新取得当前真实产物并核验。未访问历史原文，未验收其未知内容。\n',encoding='utf-8')
# Reload actual serialized outputs and validate contract, provenance and graph.
loaded=json.loads((OUT/'analysis.json').read_text())
assert all(k in loaded for k in contract['analysis_json_required'])
assert isinstance(loaded['schema_version'],int)
assert all(isinstance(loaded[k],list) for k in ['source_files','findings','limitations','invalidated_work','retained_work'])
assert loaded['aggregate_file']['sha256']==sha(OUT/loaded['aggregate_file']['path'])
assert all(sha(Path(s['path']))==s['sha256'] for s in loaded['source_files'])
with (OUT/'aggregate.csv').open(newline='') as f:
    reader=csv.DictReader(f);assert reader.fieldnames==contract['aggregate_csv_columns'];actual=list(reader)
assert len(actual)==3
for r in actual:
    w=r['workload'];a=sorted(groups[w,'baseline'])[1];b=sorted(groups[w,'candidate'])[1]
    assert float(r['baseline_median_ms'])==a and float(r['candidate_median_ms'])==b
    assert math.isclose(float(r['speedup_ratio']),a/b,rel_tol=1e-14)
    assert math.isclose(float(r['latency_reduction_pct']),100*(a-b)/a,rel_tol=1e-14)
seen=set()
for t in tasks:
    assert t['task_id'] not in seen and set(t['depends_on'])<=seen
    seen.add(t['task_id'])
assert all(float(r['speedup_ratio'])<1.8 for r in actual)
verification={'checks_passed':['18 input rows with correct version and scope; positive finite latencies; no duplicate measurement keys','3 repeats for each workload/variant; all rows retained','Exact requested CSV column order and JSON required fields','Serialized medians independently checked by middle of sorted triplets; formulas checked to relative tolerance 1e-14','Source and aggregate SHA256 re-read and verified','Dependencies exist and graph is acyclic; next writing stage remains todo'],'aggregate_sha256':sha(OUT/'aggregate.csv'),'analysis_sha256':sha(OUT/'analysis.json'),'new_experiments':False,'independent_agents':False,'limitations':'No end-to-end writer execution or real-world benchmarking; no visual artifacts requested.'}
(OUT/'validation.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'aggregate':aggregate,'validation':verification},ensure_ascii=False,indent=2))

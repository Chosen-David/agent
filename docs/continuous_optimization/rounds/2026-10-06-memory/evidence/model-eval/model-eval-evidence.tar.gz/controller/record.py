import sys,json,pathlib,importlib.util,datetime,uuid
base=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('pipeline',base/'pipeline.py'); p=importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
run=base/sys.argv[1]; kind=sys.argv[2]; case=sys.argv[3]; actor=sys.argv[4]; attempt=int(sys.argv[5])
host=run/'host'; host.mkdir(exist_ok=True)
body={'event_id':f'{kind}-{case}-{attempt}-{uuid.uuid4()}','kind':kind,'actor':actor,'adapter':'host','case_id':case,'attempt':attempt,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
if kind=='start':
 body['spawn_response']={'task_name':actor}; body['isolation']='Actual collaboration.spawn_agent fork_turns=none'; body['cost']='unknown'; body['model']='inherited host model; identifier unknown'
else:
 body['status']=sys.argv[6]; body['observed_completion']=sys.stdin.read()
path=host/(case+f'-{attempt}-{kind}.json'); p.write(path,body)
result=p.record_start(run,case,actor,path) if kind=='start' else p.collect(run,case,attempt,path)
print(json.dumps(result,ensure_ascii=False,indent=2,default=str))

import json, pathlib, shutil, subprocess, sys
repo=pathlib.Path('/workspace/scratch/c12f3d9f92bd/agent'); dest=pathlib.Path('/workspace/scratch/c12f3d9f92bd/role-eval-controller'); sha=sys.argv[1]
read=lambda path:json.loads(subprocess.check_output(['git','-C',str(repo),'show',sha+':'+path]))
catalog=read('evals/tasks.json'); rubric=read('evals/rubric.json'); smoke=read('evals/pipeline_smoke/tasks.json'); sr=read('evals/pipeline_smoke/rubric.json')
roles=read('config/role_registry.json')['roles']; assert {r['id'] for r in roles}=={r['id'] for r in catalog['cases']}
include={'smoke-main-general','chain-coordinator'}
extra=[c for c in smoke['cases'] if c['id'] in include]; catalog['cases']+=extra; rubric['criteria'].update({k:v for k,v in sr['criteria'].items() if k in include})
for name,obj in [('tasks.json',catalog),('rubric.json',rubric),('adapter.json',{'name':'host','model':'inherited host model; exact identifier unavailable','model_observability':'unknown','cost':'unknown','tools':['functions.exec','exec_command','view_image','collaboration agents; process proxy by controller'],'max_attempts':2,'worker_target_wall_seconds':360,'concurrency':3,'worker_context':'fork_turns=none','grader':'/root/role_eval_controller'})]:
 (dest/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
f=dest/'fixtures'; f.mkdir(exist_ok=True)
for case in catalog['cases']:
 for name in case.get('fixtures',[]):
  source=('evals/pipeline_smoke/fixtures/' if case['id'] in include else 'evals/fixtures/')+name
  target=f/name; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(subprocess.check_output(['git','-C',str(repo),'show',sha+':'+source]))
(dest/'pipeline.py').write_bytes(subprocess.check_output(['git','-C',str(repo),'show',sha+':scripts/agent_eval_pipeline.py']))
print('catalog',len(catalog['cases']),'roles',len(roles),'revision',sha)

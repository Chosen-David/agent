"""Read-only analysis of supplied v2 values. No measurements or experiments run."""
from pathlib import Path
import csv, json, hashlib, platform
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
OUT=Path(__file__).resolve().parent
SOURCE=OUT.parents[2]/'inputs'/'measurements.csv'
rows=list(csv.DictReader(SOURCE.open()))
assert len(rows)==4
assert len({r['workload'] for r in rows})==len(rows)
for r in rows:
    assert r['scope'] in ('end_to_end','kernel_only')
    b,c=float(r['baseline_ms']),float(r['candidate_ms'])
    assert b>0 and c>0
    r.update(baseline_ms=b,candidate_ms=c,delta_ms=c-b,latency_reduction_pct=100*(b-c)/b,speedup=b/c)
(OUT/'analysis.json').write_text(json.dumps({'input_version':'v2','input_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'source_kind':'provided synthetic fixture','interpretation':'descriptive; no repetitions or statistical evidence supplied','formula':{'delta_ms':'candidate-baseline','latency_reduction_pct':'100*(baseline-candidate)/baseline','speedup':'baseline/candidate'},'rows':rows,'environment':{'python':platform.python_version(),'matplotlib':matplotlib.__version__}},indent=2))
with (OUT/'analysis.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9})
fig,axes=plt.subplots(1,2,figsize=(7.2,3.4),sharex=True,gridspec_kw={'width_ratios':[2,1]})
for ax,scope,title in zip(axes,['end_to_end','kernel_only'],['End-to-end','Kernel only']):
    rs=[r for r in rows if r['scope']==scope]
    for y,r in enumerate(rs):
        b,c=r['baseline_ms'],r['candidate_ms']
        ax.plot([b,c],[y,y],color='#b6bbc3',lw=2,zorder=1)
        ax.scatter(b,y,c='#50565f',marker='o',s=42,label='Baseline' if y==0 else None,zorder=3)
        ax.scatter(c,y,c='#0072b2',marker='s',s=40,label='Candidate' if y==0 else None,zorder=3)
        ax.annotate(f'{b:g}',(b,y),xytext=(0,9),textcoords='offset points',ha='center',fontsize=9)
        ax.annotate(f'{c:g}',(c,y),xytext=(0,-16),textcoords='offset points',ha='center',fontsize=9,color='#005c91')
    ax.set_yticks(range(len(rs)),[r['workload'] for r in rs]);ax.set_ylim(len(rs)-0.5,-0.6)
    ax.set_xlim(0,250);ax.set_xticks([0,100,200]);ax.set_xlabel('Latency (ms)');ax.set_title(title,fontsize=11,loc='left')
    ax.grid(axis='x',alpha=.18);ax.set_axisbelow(True)
    for edge in ['top','right','left']:ax.spines[edge].set_visible(False)
    ax.tick_params(axis='y',length=0)
handles,labels=axes[0].get_legend_handles_labels()
fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,1.00),ncol=2,frameon=False)
fig.subplots_adjust(left=.12,right=.97,bottom=.25,top=.80,wspace=.70)
fig.text(.12,.06,'Provided v2 values; repeats and uncertainty unavailable.',fontsize=8,color='#50565f')
fig.savefig(OUT/'figure-v2.png',dpi=180)
fig.savefig(OUT/'figure-v2.svg')
Image.open(OUT/'figure-v2.png').convert('L').save(OUT/'figure-v2-gray.png')
print(json.dumps({'rows':rows,'outputs':['analysis.json','analysis.csv','figure-v2.png','figure-v2.svg','figure-v2-gray.png']}))

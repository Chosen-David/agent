"""Descriptive arithmetic only; this does not collect timings."""
import csv
from pathlib import Path
source = Path(__file__).resolve().parent.parents[2] / "inputs/measurements.csv"
with source.open(newline="") as handle:
    for row in csv.DictReader(handle):
        baseline = float(row["baseline_ms"])
        candidate = float(row["candidate_ms"])
        print(f'{row["workload"]},{row["scope"]},speedup={baseline/candidate:.6f},latency_reduction_pct={100*(baseline-candidate)/baseline:.6f}')

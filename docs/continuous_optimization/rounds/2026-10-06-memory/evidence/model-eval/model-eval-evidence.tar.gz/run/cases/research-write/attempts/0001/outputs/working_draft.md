# Selective execution：通用工作稿

本文依据合成材料撰写，不代表已发表研究。范围仅为结果段落与摘要；主张来源见同目录 `claim_evidence.md`。

## 中文结果段落

在相同 CPU 进程和输入配置下，替换所选内核后，不同工作负载的端到端耗时呈现不同变化。small 工作负载的耗时由 100 ms 降至 80 ms，减少 20.0%，对应 1.25× 加速；medium 由 120 ms 降至 100 ms，减少约 16.7%，对应 1.20× 加速。large 则由 200 ms 增至 220 ms，耗时增加 10.0%，对应约 0.91× 的基线与候选耗时比，表现为性能退化。独立计时的内核耗时由 20 ms 降至 10 ms，对应 2.00× 加速和 50.0% 的耗时减少，但这一收益仅针对内核，不能表述为所有工作负载均有 2× 端到端加速。该内核已包含在端到端执行路径中，因此两类计时不能相加。以上每个数值均来自单次运行，未进行独立重复，也未测量方差或质量；这些结果只能描述当前配置下的观测差异，不能据此声称统计显著、收益稳定或质量不变。此外，未进行 GPU 测量，当前证据不支持外推至 GPU。

## English abstract

We examine the measured runtime effects of replacing a selected kernel using a synthetic measurement set obtained in the same CPU process and input configuration. End-to-end latency decreases from 100 to 80 ms for the small workload and from 120 to 100 ms for the medium workload, corresponding to speedups of 1.25× and 1.20×, respectively. However, latency increases from 200 to 220 ms for the large workload, a 10.0% regression. Independently timed kernel latency decreases from 20 to 10 ms, yielding a 2.00× kernel-only speedup. The kernel is already included in the end-to-end paths, so these timings must not be added. These observations show workload-dependent runtime changes rather than a uniform end-to-end benefit. Each reported value is from a single run without independent repeats; variance and quality have not been measured, and no GPU measurements are available. The evidence therefore supports descriptive comparisons for the measured configuration, but does not establish statistical significance, repeatable gains, preserved quality, or GPU performance.

不能。**独立计算两条 logit 路径，不等于它们独立影响输出**：它们先相加，再共同进入 softmax。分别测量量化误差可以，但仅凭“独立评分”不能保证输出不变。

给定教学例子保持 (a,V) 不变，只量化 (b)：
\[
p=\operatorname{softmax}(0,0)=(1/2,1/2),\qquad y=5;
\]
\[
p'=\operatorname{softmax}(0,\log3)=(1/4,3/4),\qquad y'=7.5.
\]
所以即使 (a) 完全无误差，输出仍改变 (2.5)。量化改变了两个位置的相对 logit，因而重新分配了对 (V=(0,10)^T) 的权重。

局部推导：令 (z=a+b\in\mathbb R^n)，(V\in\mathbb R^{n\times d}) 固定。用列向量约定写成 (p=\operatorname{softmax}(z))、(y=V^Tp\in\mathbb R^d)（即题中行向量输出的转置）。由
\[
\frac{\partial p_i}{\partial z_j}=p_i(\delta_{ij}-p_j)
\]
得到
\[
J_{y,a}=J_{y,b}=J_{y,z}
=V^T\left[\operatorname{diag}(p)-pp^T\right]\in\mathbb R^{d\times n}.
\]
因此小扰动满足
\[
\Delta y=J_{y,z}(\Delta a+\Delta b)
+O\!\left(\|\Delta a+\Delta b\|^2\right).
\]
两条路径的敏感度都依赖共同的 (p=\operatorname{softmax}(a+b))。本例原点的 (J=(-2.5,2.5))，中心差分核验为约 ((-2.49999999946,2.49999999946))。一阶预测 (2.5\log3\approx2.74653)，并非精确变化 (2.5)：有限扰动不能把局部线性化当恒等式。

边界也很重要：若 (\Delta a+\Delta b=c\mathbf1)，softmax 和输出**精确不变**；例如两路误差相互抵消，或总误差为公共平移。若 (V) 各行相同，权重改变也不会改变输出。所以非零 logit 误差既不必然改变输出，误差大小本身也不足以判定其影响；应结合误差方向、共同权重和 (V) 检查。

这只是 `inputs/concept.txt` 给定模型的推导与数值验算，足以反驳“独立评分就保证输出不变”。它不能证明真实模型的量化误差分布、误差相关性、任务精度损失或某种量化方法优劣，也不是任何论文的实测结果。

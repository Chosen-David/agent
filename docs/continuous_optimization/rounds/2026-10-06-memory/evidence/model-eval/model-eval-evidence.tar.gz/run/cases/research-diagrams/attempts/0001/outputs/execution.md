# Execution record

Input: cases/research-diagrams/inputs/architecture.json. The input is a proposed, synthetic specification, not an implemented or experimentally validated model.

Read the role snapshot SKILL.md, execution.md, workflow.md and figure_shared.md; exact SHA-256 hashes are recorded in loaded.json. No network, package installation, model execution, or child agents.

Editable master: diagram.svg. Stable node and edge IDs map to the original specification. Six nodes and precisely the five declared directed data-flow edges. A and B have equal-sized parallel boxes; neither connects to the other. V has one outgoing edge into output and no edge into softmax. No semantic grouping containers were added. Geometry is schematic, without quantitative meaning.

Rendering route: installed PyMuPDF opens SVG directly; Pillow produces a grayscale companion. No CairoSVG dependency. SVG uses editable text, rectangles, polylines and explicit arrowhead polygons, without raster assets or external resources. Display size is provisionally 180 × 66.86 mm, not a claim of venue compliance.

Reproduction command:

```sh
python /workspace/scratch/c12f3d9f92bd/role-eval-controller/run/cases/research-diagrams/attempts/0001/outputs/render.py
```

Render is requested through the controller. Actual runtime results and visual observations will be appended after execution; source construction alone does not establish visual completion.

No failed render or revision yet. Submission specifications and color-vision simulation are unverified. Tensor shapes and experimental results are unspecified and have not been invented.

## First render and revision

Controller executed render.py with exit code 0 and actually opened diagram.png and diagram-grayscale.png. Observations: six nodes and five directed edges correspond to the specification; V bypass is clear; no overall clipping. A visible issue occurred in the output formula: SVG superscript T overlapped adjacent glyphs in PNG, making the formula look like pIV.

Preserved first-round SVG, PNG, grayscale PNG, semantic contract and render evidence as before-* files. Replaced only the output formula text with the input’s literal `y = p^T V`; node placement and all edges remain unchanged. Second render and viewing requested.

## Final render and actual visual observations

Controller reran the exact reproduction command with exit code 0 (controller record: host/research-diagrams-render-2.json), then actually opened the final color and grayscale PNGs (controller record: host/research-diagrams-visual-after.json, including hashes and observations). Returned observations: `y = p^T V` is readable without overlap; six nodes and five directed edges are unchanged; V enters output directly and bypasses softmax; arrow endpoints are clear; no clipping; color and grayscale contrast are sufficient; proposed, synthetic and not-implemented status is explicit.

Technical evidence is in render-evidence.json; node/edge mapping, source hash, dimensions and actual runtime versions are in semantic_contract.json. Caption corresponds to this same version. Exact textual output label now matches the specification. No numerical/model evaluation was performed or implied.

Final artifacts frozen after the second render and these observations. Remaining limitations: provisional dimensions only; no venue compliance verification, no color-vision simulation, and no full manuscript embedding supplied.

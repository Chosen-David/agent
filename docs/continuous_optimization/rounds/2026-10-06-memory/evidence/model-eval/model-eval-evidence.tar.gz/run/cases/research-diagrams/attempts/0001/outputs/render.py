"""Render the editable SVG master using installed PyMuPDF, offline."""
from pathlib import Path
import json, hashlib, sys
import xml.etree.ElementTree as ET
import fitz
from PIL import Image

out = Path(__file__).resolve().parent
source = out / 'diagram.svg'
spec_path = out.parents[2] / 'inputs' / 'architecture.json'
spec = json.loads(spec_path.read_text())
root = ET.parse(source).getroot()
ids = {e.attrib.get('id') for e in root.iter()}
expected_nodes = {n['id'] for n in spec['nodes']}
actual_edges = [(e.attrib['data-source'], e.attrib['data-target']) for e in root.iter() if 'data-source' in e.attrib]
assert expected_nodes <= ids
assert sorted(actual_edges) == sorted(map(tuple, spec['edges']))
assert len(actual_edges) == 5
doc = fitz.open(source)
page = doc[0]
pix = page.get_pixmap(matrix=fitz.Matrix(3,3), alpha=False)
pix.save(out / 'diagram.png')
img = Image.open(out / 'diagram.png')
img.convert('L').save(out / 'diagram-grayscale.png')
contract = {
 'figure_id':'FIG-two-path-logits', 'status':spec['status'], 'evidence_type':spec['evidence_type'],
 'source':{'path':str(spec_path),'sha256':hashlib.sha256(spec_path.read_bytes()).hexdigest()},
 'nodes':[{**n,'type':{'a':'input logits','b':'input logits','sum':'addition','softmax':'normalization','v':'fixed input','output':'weighted output'}[n['id']], 'svg_id':n['id'], 'basis':f'architecture.json nodes[{i}]'} for i,n in enumerate(spec['nodes'])],
 'edges':[{'source':s,'target':t,'direction':'source to target','kind':spec['edge_kind'],'label':None,'svg_id':f'edge-{s}-{t}','basis':f'architecture.json edges[{i}]'} for i,(s,t) in enumerate(spec['edges'])],
 'groups':[], 'invariants':spec['constraints'],
 'label_changes':{'output':'No change: explicit plain-text y = p^T V matches the input label'},
 'unknowns':['tensor shapes','model implementation','empirical performance','submission venue specifications'],
 'checks':{'node_ids_found':sorted(expected_nodes),'edge_pairs':actual_edges,'extra_semantic_edges':0},
 'design':{'provisional_size_mm':[180,66.86],'reading_order':'parallel A/B at left, addition, softmax, output at right; V enters output vertically from below','font':'DejaVu Sans','colors':'blue inputs; teal operations; dark output; warm neutral fixed V; redundant explicit labels','arrows':'solid directed data flow; explicit polygon heads; no external resources'},
 'render':{'tool':'PyMuPDF','version':fitz.VersionBind,'python':sys.version,'pixels':list(img.size),'source':'diagram.svg','png':'diagram.png'}
}
(out/'semantic_contract.json').write_text(json.dumps(contract,indent=2,ensure_ascii=False))
(out/'caption.txt').write_text('图：双路径 logit 合并（拟议示意）。路径 A 和 B 并行提供 logits a 和 b，相加得到 z = a + b，再经 softmax 得到 p。固定值 V 绕过 softmax，仅与 p 一起进入输出运算 y = pᵀV。箭头表示数据流。依据 architecture.json 的合成规范绘制；方法尚未实现，此图不表示性能或模型准确率的实验结果。\n')
(out/'render-evidence.json').write_text(json.dumps({'svg_xml_parse':'completed','semantic_edge_comparison':'exact match','render_completed':True,'image_size':list(img.size),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'png_sha256':hashlib.sha256((out/'diagram.png').read_bytes()).hexdigest()},indent=2))
print(json.dumps({'rendered':str(out/'diagram.png'),'pixels':img.size,'edges':actual_edges}))

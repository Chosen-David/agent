"""Independent streaming/exact-rational oracle; run with Python standard library."""
import importlib.util
import math
import platform
import random
from collections import deque
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.moving_average

moving_average = load(ROOT / "buggy.py", "candidate")
baseline = load(ROOT.parents[2] / "inputs/buggy.py", "baseline")

def reference(values, window):
    pending = deque()
    means = []
    for value in values:
        pending.append(Fraction(value))
        if len(pending) == window:
            total = Fraction(0)
            for item in pending:
                total += item
            means.append(float(total / window))
            pending.popleft()
    return means

print("Python:", platform.python_version())
print("Baseline minimal reproduction:", baseline([1, 2, 3], 3), "expected [2.0]")
assert baseline([1, 2, 3], 3) != [2.0]
checks = 0
fixtures = [([], 1, []), ([7], 1, [7.0]), ([1, 2, 3], 3, [2.0]),
            ([1, 2, 3], 2, [1.5, 2.5]), ([1, 2], 4, []),
            ([-4, 0, 4], 1, [-4., 0., 4.]), ([0.25, 0.5, 0.75], 2, [0.375, 0.625])]
for values, window, expected in fixtures:
    before = values.copy()
    assert moving_average(values, window) == expected
    assert values == before
    checks += 1
rng = random.Random(713)
for n in range(41):
    for repetition in range(5):
        values = [rng.randint(-10000, 10000) for _ in range(n)]
        for window in range(1, n + 3):
            expected = reference(values, window)
            for container in (values, tuple(values)):
                before = tuple(container)
                actual = moving_average(container, window)
                assert isinstance(actual, list)
                assert len(actual) == max(0, n - window + 1)
                assert actual == expected, (values, window, actual, expected)
                assert tuple(container) == before
                checks += 1
for values in ([], [1, 2, 3]):
    for invalid in (0, -1, -100):
        try:
            moving_average(values, invalid)
        except ValueError:
            pass
        else:
            raise AssertionError(("expected ValueError", invalid))
        checks += 1
    for invalid in (1.0, 2.5, "2", None, True, False):
        try:
            moving_average(values, invalid)
        except TypeError:
            pass
        else:
            raise AssertionError(("expected TypeError", invalid))
        checks += 1
assert moving_average([float("inf"), 1.0, 2.0], 2) == [float("inf"), 1.5]
a = moving_average([float("nan"), 1.0, 2.0], 2)
assert math.isnan(a[0]) and a[1] == 1.5
checks += 2
print(f"PASS: {checks} checks; exact independent rational oracle, boundaries, validation, lists/tuples, input immutability, non-finite locality; seed=713")

| Experiment | Conclusion | Script | Data | Result | Citation |
|---|---|---|---|---|---|
| HIST-0 | unknown | archived/missing.py | unknown | unknown | unknown |
| ALPHA | recorded: inconclusive; execution/acceptance unknown | experiments/alpha.py | synthetic-x (synthetic fixture; input file absent) | results/alpha.json (observed snapshot) | experiments/alpha.py:1; results/alpha.json:1 |
| BETA | recorded: rejected; execution/acceptance unknown | experiments/beta.py | synthetic-y (synthetic fixture; input file absent) | results/beta.json (running path; observed snapshot only) | experiments/beta.py:1; results/beta.json:1 |

# Incremental mapping

Historical HIST-0 row and its order are unchanged. Paths refer to the supplied `inputs/organization/` tree, not to this output directory. This is a documentary proposal for adoption, not an edit of that tree. No target script was executed. Labels ALPHA/BETA are source experiment IDs; no root TASK or formal task IDs were supplied. A coordinator must bind these IDs to its existing root TASK; do not create a second task list.

| Entry / evidence anchor | Producer | Consumers / references | Status and limits |
|---|---|---|---|
| HIST-0: original CODEMAP.md:3 | unknown | original CODEMAP.md | archived/missing.py is absent from the supplied inventory; no provenance or result known |
| ALPHA: experiments/alpha.py:1; results/alpha.json:1 | declared experiments/alpha.py; actual execution producer unknown | results/alpha.json declares the script; script declares the result; external readers unknown | script active per active_tasks.json:1; result exists, run status unknown; no raw input, run receipt, parameters or acceptance evidence |
| BETA: experiments/beta.py:1; results/beta.json:1 | declared experiments/beta.py; actual execution producer unknown | reciprocal script/result declarations; external readers unknown | script active and result running per active_tasks.json:1; preserve both paths; no run receipt or acceptance evidence |
| orphan: notes/orphan.txt:1; active_tasks.json:1 | unknown | active_tasks.json protects this path; no experimental consumer supplied | note says unreferenced historical; protected, provenance unknown; not disposable |
| inventory: active_tasks.json:1 | unknown | this map and reorganization proposal | supplied activity declaration, not live process inspection |

The two active scripts both have explicit result mappings (2/2 in this finite inventory). This is path coverage only, not scientific validation. Data are synthetic fixtures, not measured results. `synthetic-x` and `synthetic-y` are labels, not verified file paths. No citation to a paper or external consumer is supplied. Git metadata, live jobs, external references and a canonical TASK are unavailable; unknown does not mean stopped.

## Source snapshot registry

All seven observed files are listed below; hashes come from the parent read-only proxy. BETA's running output can change after the snapshot. These hashes identify observed bytes and do not prove execution or provenance.

| Path | Kind | SHA256 |
|---|---|---|
| CODEMAP.md | historical map | `9f473ed7d66475ff105fed73dc280a1297f8b24f636a0c555618d8075a49eb24` |
| active_tasks.json | activity/protection declaration | `162eaff45eff8cb6003f338e954b8911dc1270b02c20c4bf6206813def362c9e` |
| experiments/alpha.py | active documentation-only script fixture | `f601040b09b6e6451ffa7cce2a316a2ecb1a6d5d2b8c18fd2ebd1e4b221cafbc` |
| experiments/beta.py | active documentation-only script fixture | `b539dc67e56f43f92c40d5dd08ed708e22c29f2a87003083a828fc8492f9abc0` |
| notes/orphan.txt | protected historical note | `1e9f45e92d92c740069c6baa092f8e605eeeb4b919c74c43cbb1133a5135704e` |
| results/alpha.json | synthetic result snapshot, run status unknown | `259e32ece539419d3bc1cd7176881f22942b0f5445c0c395ac7da0961aad4897` |
| results/beta.json | synthetic result snapshot, running | `45b7c1b50849a8b6e5a901cee9bdda7c9d322d1e5e7ff762725b9bc7e4b9e03d` |

# Results
Proposed directory note for inputs/organization/results/.
alpha.json and beta.json contain synthetic fixture records, not measurements.
alpha.json records inconclusive; beta.json records rejected.
These values are unvalidated records, not accepted research conclusions.
beta.json is a running output path; alpha.json runtime status is unknown.
Preserve both paths and use snapshot hashes in ../CODEMAP.md.
Input labels synthetic-x/y have no supplied input files or run receipts.

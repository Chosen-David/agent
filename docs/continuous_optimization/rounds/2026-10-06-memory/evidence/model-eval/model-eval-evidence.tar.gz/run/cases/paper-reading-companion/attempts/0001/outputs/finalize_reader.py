"""Task-local reader adjustments. Run only via authorized controller proxy."""
from pathlib import Path

target = Path(__file__).parent / "reader.html"
text = target.read_text(encoding="utf-8")
old = "const el=id=>document.getElementById(id);let index=0,zoom=100,textMode=false;"
new = """data.title='Synthetic paper: Two logit paths';
for(const p of data.pages){p.label=p.number===1?'i':p.number===2?'1':p.label}
const el=id=>document.getElementById(id);let index=Math.max(0,data.pages.findIndex(p=>p.number===2)),zoom=100,textMode=false;"""
assert old in text
text = text.replace(old, new)
old = "for(const source of card.sources||[]){try{const url=new URL(source.url);"
new = """for(const source of card.sources||[]){const local=source.url.match(/^page-([12])\\.png$/);if(local){const ref=document.createElement('button');ref.textContent=source.label;ref.style.marginTop='10px';ref.onclick=()=>go(data.pages.findIndex(p=>p.number===Number(local[1])));node.append(ref);continue}try{const url=new URL(source.url);"""
assert old in text
text = text.replace(old, new)
old = "<div id=\"cards\"></div>"
new = """<p class="notice">当前位置：物理第 2 页／印刷第 1 页。已独立查看原页：物理 1、2；未读：物理 3。本次是聚焦伴读，未开展全文审稿或外部文献核验。此文为合成材料；已看页面未给出作者、日期、版本。<br>卡片中的 log 按自然对数解释；原页数值由独立算术检查复核。</p><div id="cards"></div>"""
assert old in text
text = text.replace(old, new)
target.write_text(text, encoding="utf-8")
print("Updated reader.html: default page 2, printed labels, embedded-page source navigation, scope notice.")

# Project state — research-assistant-0001

目标：按 v2 可用数值判断后续优化方向，完成有边界的结果段落与图；只做现有数据能支持的工作。
意图 ID：intent-v2，source=task.txt 与 project.json 的 goal/change；状态 active。数据 measurements@v2 固定哈希见 loaded.json。旧 measurements@v1 及 figure@v1 仅存在历史声明，未获文件，不能恢复或数值对比。

已完成：版本影响清单 impact.md；4行描述性分析 analysis.json/csv；配对延迟图和灰度预览；结果段落与图注 results.md。task_chain.json 保留原 ID 的版本衔接并列出动作、依赖、验收、失败恢复与预算。
决策：保留 baseline 作为尚未被全面替代的方案；当前数据给出 large 退化信号，未来优先诊断该分支，但本轮不启动新优化/实验。端到端总体收益、稳定性与退化机制仍未知。
保留：collect@v1 历史声明，concept@v1，background@v1 独立完成声明；本轮只验证后者不受该版本更新影响，未验收缺失背景产物。
阻塞：后续代码诊断缺代码、计时配置和正确性契约；正式统计判断缺重复测量和研究单位。若需复用旧背景正文，还需取得 background@v1 文件。独立新图文无需等待该背景文件。
运行限制：本地有界前台执行；无持久监督器、无后台 Agent、无 GPU、无网络、无新增测量。专业角色由同一工作者分阶段执行；CPU运行及实际图像打开由控制器代理并保留收据，不冒充独立科学审稿。

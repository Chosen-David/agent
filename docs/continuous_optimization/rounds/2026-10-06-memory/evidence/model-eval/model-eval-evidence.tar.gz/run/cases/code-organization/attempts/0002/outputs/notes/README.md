# Notes
Proposed directory note for inputs/organization/notes/.
orphan.txt is protected by ../active_tasks.json and must remain in place.
Its experimental provenance and owner are unknown.
An unreferenced note is not permission to move or delete it.
Resolve ownership through the coordinator; see ../CODEMAP.md.

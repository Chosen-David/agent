# CODE-READ synthetic-selector-0001

本报告为只读静态分析，没有执行、导入或修改目标。目标为合成单文件 `synthetic_selector.py`，版本以 SHA-256 `6fc687e85d2c169c5dc88d7dc126b970036f22b822c00c9f8f0d8b628a6e8ea1` 固定。以下所有行号均属于该哈希；文件没有独立 Git 元数据，commit 不适用。源码全文通过父代理提供的 `source-proxy.json` 阅读；没有直接读取目标。代理确认 inputs 内无 AGENTS、TASK 或 .git；没有据此宣称检查过外部仓库指令。

## 结论与叙述核对

`run` 先用较小表示为所有 key 打候选分，再按远区配额、近区余量与强制尾部集合组成索引，最后将这些索引传给使用原 query/keys 的 `full_score`（L28–30）。模块叙述 L1–2 的四项机制均不成立，具体适用条件如下。

| 模块叙述 | 函数体证据与修正 | 类型 |
|---|---|---|
| near 是强制窗口（L1） | `boundary=max(0,n-near_len)` 决定分区（L19）；强制集由独立的 `forced_len` 决定（L20）。正常非负长度且 forced_len≤near_len 时，near 候选是 `[boundary,n-forced_len)`，还需排序和截断（L24–25）。强制尾部索引无条件追加。 | source_fact；范围解释为 static_inference |
| skip 意味不打分（L1） | `skip_far` 只使 far 列表为空，省去远区排序/选取（L23）。它不绕过 L21–22 的 query 表示和所有 keys 的候选评分，不绕过近区排序，也不绕过 L30 最终评分。 | source_fact |
| projector 是 query-trained（L2） | 默认 `represent` 仅抽 vector 的第 0、2 维（L6–8），没有训练或基于 query 选维。可选 basis 来自调用者，L9 对每一列做点积；同一个 basis 参数用于 query 和每个 key（L21–22）。文件内没有训练/更新 basis 的逻辑。basis 在外部如何生成未知，不能据本文件否认外部训练的可能。 | source_fact；外部来源 unknown |
| 最终评分用 reduced keys（L2） | reduced 表示只用于 L22 候选分。L30 传入原 query、keys；L13 取 `keys[i]` 与 query 做点积。常规同维向量时，这是原始全维点积，而非 reduced 点积。`zip` 会在较短向量处结束，所以本函数不保证异长输入也覆盖所有维度。 | source_fact；同维结论 static_inference |

## 调用边与数据边

| Caller → callee / 消费者 | 调用点和条件 | 数据及结果 |
|---|---|---|
| run → select | L29，无条件，透传 **options | query、keys、覆盖参数 → positions |
| select → represent(query,basis) | L21，无条件 | 默认原向量→长度 2 列表；basis 路径→每列一个点积，若 basis 有 r 列则长度 r |
| select → represent(k,basis) | L22，对每个 key | 每个表示和 qsmall 经 zip 点积→长度 n 的 scores，索引沿用 keys 的逻辑位置 |
| scores → far / near | L23–24；far 由 skip_far 决定，near 总计算 | 分区索引按分数降序排列；无物理槽映射、归一化、mask 或去重 |
| far、near、forced → positions | L25 | 远区列表 + 近区按剩余预算截断 + 强制集，返回顺序不一定是全局分数顺序 |
| run → full_score | L30，select 正常返回后 | 原 query、原 keys、positions → 与 positions 同序的点积列表；run 返回二元组 (positions, scores) |

这些直接调用边均已由函数体闭合；输入类型及外部调用方未给出，不声称运行时已观察到这些值。

## 配置、预算和范围

配置默认值位于 `select` L16–17，`run` 的 **options 在 L29 覆盖默认值；文件内无 CLI、环境变量或配置文件读取。没有运行日志，任何一次实际调用的参数值均 unknown。

| 配置 | 默认 | 消费点与含义 |
|---|---:|---|
| near_len | 4 | L19：分界 boundary；决定候选范围，不是入选数量或强制数量 |
| forced_len | 1 | L20：尾部强制集 `[max(0,n-forced_len),n)`；L24 将正常位于近区的强制尾部排除；L25 原样追加 |
| budget | 3 | L25：只限制 near 份额 `max(0,budget-len(forced)-len(far))`；不是全局硬上限 |
| far_budget | 1 | L23：远区降序列表的切片上限；远区不足时没有补齐远区的保证，空余可转为近区份额 |
| skip_far | False | L23：只跳远区选取，远区 key 的 reduced 分仍在 L22 计算 |
| basis | None | L7–9、L21–22：默认抽第 0/2 维；可选外部列基线性映射；没有 query-aware 学习的实现 |

在 n≥4、合法同维输入、默认配置下：forced 为最后一个索引；near 候选为此前最多三个尾部索引；n>4 才有非空 far 池。n=4 时 far 为空、near 可取 2 个；n≥5 时 far 取 1 个、near 取 1 个，再追加 forced，共 3 个。这里都是代入源码的静态推断，不是样例实测。n=0、1、2、3 时默认选取数量分别为 0、1、2、3，但即使 keys 为空，L21 仍先表示 query，因此默认 query 至少需支持索引 0 和 2。

对于普通非负整数配置且 forced_len≤near_len，两个排序池与 forced 不相交，数量为 `len(far)+min(len(near),max(0,budget-len(forced)-len(far)))+len(forced)`。若 far 加 forced 已超过 budget，near 只能降到 0；超额仍保留。预算没有硬裁剪 forced，也没有用 budget 裁剪 far。

`sorted` 默认稳定：分数相等且可正常比较时，原 range 顺序使较小索引优先；forced 保持升序。代码没有随机选择或去重。

## 边界、反证及未知项

- **强制集与远区可能重叠**：没有配置校验。若 `forced_len>near_len`，forced 可以进入远区；例如 n=6、near_len=2、forced_len=4 时 forced={2,3,4,5}、far 池={0,1,2,3}。远区若挑中 2 或 3，L25 会重复索引；L13 也会重复计算/返回对应分数。不能泛称算法总返回去重集合。
- **非法/非典型参数不受保护**：负 far_budget 使用 Python 负切片，不代表零配额；负 near_len 可使 boundary>n，在未跳远区且访问该池时出现 scores 越界；负 forced_len 可让 near 范围超过 n。非整数长度/配额也可能在 range/切片处报错。没有失败回退。
- **维度限制与截断**：默认表示需要每个实际处理向量至少三项，否则 L8 索引失败；basis 路径和最终点积的 zip 都静默截短，未验证列长、向量维度、dtype、数值合法性。basis=[] 时 reduced 分数为 0，排序只靠原序；最终仍消费原向量。
- **basis 外部行为未知**：函数只接收对象，没有类型或可复用性验证；若传入一次性迭代器，L21 消费后 L22 不保证可再次遍历，不能把“r 维表示”泛化到任意 Python 对象。
- **未覆盖/未知**：没有外部调用者、具体输入、运行参数、运行日志或性能测量；无法判断外部 basis 的训练方法、业务上的分数质量或耗时收益。本任务不执行目标，也不将静态推导称实测。

所有任务关心的入口、默认/可选表示、范围/预算、跳过行为、强制集合及最终消费者均有上述源行证据。交付自查复核了 L19–25 和 L29–30 的条件；没有独立审阅或动态验证。若未来需要执行验证，最小候选是空 keys/短 query、skip_far 对最终评分的影响、超预算强制集、forced/far 重叠和异长向量；这些仅为建议，本次未运行。

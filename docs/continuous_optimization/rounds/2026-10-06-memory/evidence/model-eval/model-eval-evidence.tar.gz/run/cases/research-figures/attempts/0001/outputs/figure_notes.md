# Mixed figure: routing, design and evidence

Owner: `/root/role_eval_controller/eval_figures`; one staged author, no independent sub-agents. Mode: offline fallback using local SVG authoring and PyMuPDF rendering through the controller's required execution proxy. Initial CairoSVG rendering failed because that module was unavailable, retained in render-attempt1.log. No external source or exemplar was supplied; no exemplar was retrieved or represented as read. The explicit supplied-materials-only constraint governs this standalone figure.

| Panel | Route | Source | Evidence | Editable source | State |
|---|---|---|---|---|---|
| A | diagram | architecture.json | synthetic proposed specification, explicitly not implemented | panel_A.svg; build_figures.py A section | rendered and visually reviewed |
| B | data_visualization | measurements.csv | supplied synthetic task fixture, not a new measurement | panel_B.svg; build_figures.py B section | rendered and visually reviewed |
| Whole | mixed | both panel sources | different evidence scopes kept separate | figure.svg; build_figures.py assembly section | rendered and visually reviewed; typography limitation disclosed |

## Design brief

Reader questions: How do the two logit paths merge? How do supplied baseline/candidate timings compare within each scope? No link between the proposed architecture and the timing data is supplied and none is claimed.

Provisional final size 180 × 88.714 mm, independent of any venue. A reads left to right then downward; parallel A/B have the same geometry and color. Softmax and output share the method color; neutral V has its own bypass arrow into output. No module/edge is added. All five arrows denote data flow. B uses paired horizontal bars with common zero baseline and common 0–250 ms scale; baseline is neutral gray and candidate purple, with identical top/bottom series ordering and exact value labels. End-to-end rows remain separate from the kernel-only row by a labeled divider. Workloads are categories, not interpolated points. Full data retained; no normalization, aggregation, exclusions or uncertainty estimation. The large row visibly keeps 200 vs 220 ms. No significance or general superiority claim.

Typography uses live DejaVu Sans text, 26 px panel headings, 21 px body, 19 px notes/ticks in the 1400 px assembly (about 9.5, 7.7, 7.0 pt at the proposed physical width). Color has redundant placement and exact value labels; grayscale preview is exported for inspection. Light gridlines support value comparison without competing with bars. Legend has reserved space above the plot. Panel margins and a light central separator prevent cross-panel visual confusion.

## Sources and reproduction

Input snapshots and plotting arrays are retained beside the outputs; loaded.json records original input hashes and actual pinned skill reads. `python build_figures.py` regenerates all vector and PNG exports from the original case inputs. Panel SVGs and full SVG are editable vector masters with live text and stable IDs; the combined file does not embed panel screenshots. The build script is the programmatic source for each panel and assembly. No network or installation is required when PyMuPDF and Pillow are present. Rendering is executed only by the controller proxy, with actual version information in render.log.

Scientific/numerical/semantic checking: code asserts exact edge-set and node-ID equality with architecture.json; each CSV row is rendered without alteration, recorded in plotted_values.json, and scope labels preserve kernel-only isolation. SVG XML parses, IDs are unique per file and no external resource link is present. Final full, exact-size screen and grayscale previews were actually opened by worker and controller; see qa.md for concrete observations. PyMuPDF visibly substitutes a consistent serif font in PNG; font embedding and exact cross-renderer text matching are unverified. Venue/submission compliance and color-vision simulation are unverified. No PDF was requested or exported.

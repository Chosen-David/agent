from pathlib import Path
import csv, json, hashlib, sys, xml.etree.ElementTree as ET
from html import escape
OUT = Path(__file__).resolve().parent
CASE = OUT.parents[2]
ROOT = CASE.parents[1]
SRC = CASE / 'inputs'
SNAP = ROOT / 'snapshot/plugins/research-assistant/skills/research-figures'
reads = ['SKILL.md','references/execution.md','references/workflow.md','references/figure_shared.md','references/data_visualization_workflow.md','references/diagram_workflow.md','references/data_visualization_learning.md','references/paper_exemplar_learning.md']
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
loaded = {'actor':'/root/role_eval_controller/eval_figures','snapshot_reads':[{'path':str(SNAP/r),'sha256':sha(SNAP/r),'read_scope': 'section 7 onward' if r.endswith('paper_exemplar_learning.md') else 'full'} for r in reads], 'input_reads':[{'path':str(SRC/n),'sha256':sha(SRC/n)} for n in ['architecture.json','measurements.csv']]}
(OUT/'loaded.json').write_text(json.dumps(loaded,indent=2))
arch=json.loads((SRC/'architecture.json').read_text())
rows=list(csv.DictReader((SRC/'measurements.csv').open()))
for name in ['architecture.json','measurements.csv']:
    (OUT/name).write_bytes((SRC/name).read_bytes())
font='DejaVu Sans, sans-serif'
style=f'''<style>text {{font-family:{font};fill:#182b3a}} .title{{font-size:26px;font-weight:700}} .body{{font-size:21px}} .note{{font-size:19px;fill:#526473}} .tick{{font-size:19px;fill:#526473}}</style>'''
def text(x,y,s,cls='body',anchor='start',extra=''):
    return f'<text x="{x}" y="{y}" class="{cls}" text-anchor="{anchor}" {extra}>{escape(s)}</text>'
def svg(content,w=680,h=690):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">{style}<rect width="100%" height="100%" fill="white"/>{content}</svg>'
def box(id,x,y,w,h,label,fill='#edf4fa',stroke='#3f769c'):
    return f'<g id="node-{id}"><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="{fill}" stroke="{stroke}" stroke-width="2"/>'+text(x+w/2,y+h/2+7,label,anchor='middle')+'</g>'
def edge(a,b,path):
    # Explicit vector arrowheads work in renderers that omit SVG markers.
    points={('a','sum'):'251,228 240,222 240,234',('b','sum'):'251,255 240,249 240,261',('sum','softmax'):'463,242 452,236 452,248',('softmax','output'):'562,387 556,376 568,376',('v','output'):'463,420 452,414 452,426'}
    return f'<path id="edge-{a}-{b}" data-source="{a}" data-target="{b}" d="{path}" fill="none" stroke="#3b5265" stroke-width="2.5"/><polygon id="arrowhead-{a}-{b}" points="{points[(a,b)]}" fill="#3b5265"/>'
A='<defs><marker id="arrowA" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 Z" fill="#3b5265"/></marker></defs>'
A+=text(20,38,'A  Two-path logit combination','title')+text(20,71,'Proposed schematic · not implemented','note')
A+=text(108,128,'Parallel paths','note','middle')
A+=box('a',25,153,175,64,'Path A logits a')+box('b',25,267,175,64,'Path B logits b')
A+=box('sum',252,210,155,64,'z = a + b')+box('softmax',464,210,196,64,'p = softmax(z)')
A+=box('v',252,388,155,64,'Fixed values V',fill='#f3f5f7',stroke='#8b99a4')+box('output',464,388,196,64,'y = pᵀ V')
A+=edge('a','sum','M200 185 H225 V228 H249')+edge('b','sum','M200 299 H225 V255 H249')
A+=edge('sum','softmax','M407 242 H460')+edge('softmax','output','M562 274 V384')+edge('v','output','M407 420 H460')
A+=text(548,337,'weights p','note','end')
A+=text(20,529,'V bypasses softmax; arrows denote data flow.','note')
A+=text(20,561,'Six specified nodes and five specified edges.','note')
A+=text(20,627,'Architecture does not specify measured performance.','note')
(OUT/'panel_A.svg').write_text(svg(A))
B=text(20,38,'B  Supplied latency comparison','title')+text(20,71,'Synthetic fixture · lower latency is better','note')
B+='<rect x="20" y="94" width="20" height="16" fill="#7c8995"/>'+text(48,110,'Baseline','note')
B+='<rect x="193" y="94" width="20" height="16" fill="#7057a3"/>'+text(221,110,'Candidate','note')
B+=text(20,147,'END-TO-END','note')
x0=154; scale=1.88
for tick in [0,50,100,150,200,250]:
    x=x0+tick*scale
    B+=f'<line x1="{x}" x2="{x}" y1="170" y2="559" stroke="#e6ebef" stroke-width="1"/>'
    B+=text(x,590,str(tick),'tick','middle')
ys=[200,294,388,513]
plotted=[]
for row,y in zip(rows,ys):
    w=row['workload']; baseline=float(row['baseline_ms']); candidate=float(row['candidate_ms'])
    B+=text(136,y+7,w,'body','end')
    for name,val,dy,color in [('baseline',baseline,-19,'#7c8995'),('candidate',candidate,8,'#7057a3')]:
        B+=f'<rect id="bar-{w}-{name}" data-value="{val:g}" x="{x0}" y="{y+dy}" width="{val*scale}" height="20" fill="{color}"/>'
        B+=text(x0+val*scale+8,y+dy+18,f'{val:g}','note')
        plotted.append({'workload':w,'series':name,'ms':val,'scope':row['scope']})
B+='<line x1="20" x2="659" y1="446" y2="446" stroke="#aab7c1" stroke-dasharray="5 5"/>'
B+=text(20,479,'KERNEL ONLY','note')+text(389,626,'Latency (ms)','body','middle')
B+=text(20,666,'No repeats or uncertainty supplied; no error bars.','note')
(OUT/'panel_B.svg').write_text(svg(B))
# Retain vector groups and live text in the assembly, rather than rasterizing panels.
combined=style+'<rect width="1400" height="690" fill="white"/>'+'<g id="panel-A">'+A+'</g><line x1="700" x2="700" y1="20" y2="674" stroke="#d8e0e7"/><g id="panel-B" transform="translate(720 0)">'+B+'</g>'
(OUT/'figure.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="180mm" height="88.714mm" viewBox="0 0 1400 690">{combined}</svg>')
(OUT/'plotted_values.json').write_text(json.dumps(plotted,indent=2))
# Check source mappings before rendering, not just that XML parses.
root=ET.parse(OUT/'panel_A.svg').getroot(); ns={'s':'http://www.w3.org/2000/svg'}
edges={(e.attrib['data-source'],e.attrib['data-target']) for e in root.findall('.//s:path',ns) if 'data-source' in e.attrib}
assert edges==set(map(tuple,arch['edges']))
assert {e.attrib['id'][5:] for e in root.findall('.//s:g',ns) if e.attrib.get('id','').startswith('node-')}=={n['id'] for n in arch['nodes']}
rootb=ET.parse(OUT/'panel_B.svg').getroot()
assert len(rootb.findall('.//s:rect',ns))==11
assert rows[2]['candidate_ms']=='220' and rows[3]['scope']=='kernel_only'
for name in ['panel_A.svg','panel_B.svg','figure.svg']:
    rt=ET.parse(OUT/name).getroot(); ids=[e.attrib['id'] for e in rt.iter() if 'id' in e.attrib]
    assert len(ids)==len(set(ids))
    assert not any('href' in k for e in rt.iter() for k in e.attrib)
import fitz
# Inline text style for SVG renderers with limited CSS support; masters remain live text.
ET.register_namespace('', 'http://www.w3.org/2000/svg')
for name in ['panel_A','panel_B','figure']:
    rt=ET.parse(OUT/(name+'.svg')).getroot()
    for el in rt.findall('.//s:text',ns):
        cl=el.attrib.get('class','body')
        el.set('font-family','DejaVu Sans')
        el.set('font-size',str({'title':26,'body':21,'note':19,'tick':19}[cl]))
        el.set('fill','#526473' if cl in ['note','tick'] else '#182b3a')
        if cl=='title': el.set('font-weight','bold')
    ET.ElementTree(rt).write(OUT/(name+'.svg'),encoding='unicode')
    doc=fitz.open(OUT/(name+'.svg'))
    page=doc[0]; width=2800 if name=='figure' else 1360
    page.get_pixmap(matrix=fitz.Matrix(width/page.rect.width,width/page.rect.width),alpha=False).save(OUT/(name+'.png'))
    if name=='figure':
        page.get_pixmap(matrix=fitz.Matrix(680/page.rect.width,680/page.rect.width),alpha=False).save(OUT/'figure_180mm_preview.png')
from PIL import Image
im=Image.open(OUT/'figure.png').convert('L'); im.save(OUT/'figure_grayscale.png')
print(json.dumps({'renderer':'PyMuPDF '+fitz.VersionBind,'python':sys.version,'assertions':'passed','output':str(OUT),'files':{p.name:sha(p) for p in OUT.iterdir() if p.suffix in ['.svg','.png'] }},indent=2))

# results/
本目录保存合成结果声明，不是已验收的实测证据。
alpha.json 声明 inconclusive，来源字段指向 experiments/alpha.py。
beta.json 声明 rejected，来源字段指向 experiments/beta.py。
beta.json 是运行中输出路径；禁止移动、覆盖或删除。
其余路径未列为运行中不代表已停止；现阶段一并保留。
CODEMAP.md 记录读取快照哈希；运行中结果变化后需重新核对。

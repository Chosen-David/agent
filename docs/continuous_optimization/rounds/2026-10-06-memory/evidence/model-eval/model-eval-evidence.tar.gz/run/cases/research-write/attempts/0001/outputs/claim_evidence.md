# 主张—证据表

范围：通用工作稿；没有新增文献或实验。所有经验结果仅指输入材料中的单次观测。CSV 行号含表头；版本以 SHA-256 锁定。

## 输入与指标

| 证据 ID | 来源及位置 | SHA-256 / 版本 |
| --- | --- | --- |
| E-METHOD | `inputs/manuscript.md`，Method | `712dd94ef8f5ad0c1a6f5f36bb3735901fc6bce564a96381cf6e4cfdc68ce88e` |
| E-LIMIT | 同一稿件，Results、Appendix A | 同上 |
| E-SMALL | `inputs/measurements.csv`，第 2 行，small/end_to_end | `57201d75a6e7ea0b7581c2d94f4bf46c2b9a66e37b5df94c8e6b4c5ef3924248` |
| E-MEDIUM | 同一 CSV，第 3 行，medium/end_to_end | 同上 |
| E-LARGE | 同一 CSV，第 4 行，large/end_to_end | 同上 |
| E-KERNEL | 同一 CSV，第 5 行，kernel/kernel_only | 同上 |
| E-CALC | `run/host/research-write-numeric.json`，请求后由主控实际计算，exit code 0；输入为上述 CSV | 本轮 proxy 执行记录；完整命令与结果均在该文件 |

耗时单位为 ms。加速比定义为 baseline_ms / candidate_ms；耗时变化率定义为 (candidate_ms − baseline_ms) / baseline_ms × 100%。正变化率表示耗时增加。百分比保留一位小数，加速比保留两位；约 0.91× 表示候选更慢，不是加速收益。没有汇总不同工作负载，也没有将内核耗时加到端到端耗时。

| 主张 ID | 工作稿主张 | 类型 / 状态 | 证据与定位 | 适用范围、反证或限制 | 稿内位置与处理 |
| --- | --- | --- | --- | --- | --- |
| WRITE-C001 | 替换所选内核；测量使用相同 CPU 进程和输入配置 | 方法描述 / 输入材料支持 | E-METHOD | 只复述给定设置；未独立验证实施细节或控制变量充分性 | 中文首句；英文首句 |
| WRITE-C002 | small：100→80 ms；耗时减少 20.0%；1.25× | 经验 / 单次观测支持 | E-SMALL、E-CALC | 仅 small 的端到端路径；不可视为稳健收益或推广至其他配置 | 中文结果、英文摘要 |
| WRITE-C003 | medium：120→100 ms；耗时减少约 16.7%；1.20× | 经验 / 单次观测支持 | E-MEDIUM、E-CALC | 仅 medium 的端到端路径；无显著性结论 | 中文结果、英文摘要 |
| WRITE-C004 | large：200→220 ms；耗时增加 10.0%；基线/候选约 0.91× | 经验 / 单次观测支持 | E-LARGE、E-CALC；Appendix A 同时记录退化 | 直接反驳“without any regression”；未测量退化原因 | 中文结果、英文摘要均明确保留 |
| WRITE-C005 | kernel：20→10 ms；2.00×；耗时减少 50.0% | 经验 / 范围受限支持 | E-KERNEL、E-CALC | kernel_only；不能当作端到端收益 | 中文结果、英文摘要明确标注 kernel-only |
| WRITE-C006 | 内核已在端到端路径内，独立内核计时与端到端计时不能相加 | 计时口径 / 输入材料支持 | E-LIMIT，Results | 独立计时不是额外执行开销；没有做加总或据此推断其他开销 | 中文结果、英文摘要 |
| WRITE-C007 | 收益随工作负载变化，当前记录不支持所有工作负载均有 2× 端到端加速 | 比较 / 当前记录支持 | E-SMALL、E-MEDIUM、E-LARGE、E-KERNEL | large 为反例；2× 只在内核独立计时中出现 | 删除原摘要的普遍收益断言，改为有边界的描述 |
| WRITE-C008 | 每值单次运行，无独立重复，未测量方差或质量，无 GPU 测量 | 局限 / 输入材料支持 | E-LIMIT；E-METHOD | 不能推断显著性、稳定收益、质量无损或 GPU 性能；也不能将未测质量写为质量退化 | 两种语言均明确陈述 |

## 尚未验证的事项

现有材料不含独立重复、方差、质量评估或 GPU 结果，也未给出退化机制证据。本轮不新增实验或文献，故这些事项保留为限制；没有给出置信区间、显著性、因果解释、最先进性或投稿合规结论。

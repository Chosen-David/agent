from pathlib import Path
import hashlib
import json
out = Path(__file__).resolve().parent
expected_png = 'd0010c0f3cd6edc9c451ca1a090eccf2e0e6c607df0eaf817113923859b646c4'
assert hashlib.sha256((out/'figure.png').read_bytes()).hexdigest() == expected_png
manifest = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file() and p.name != 'artifact-hashes.json'}
(out/'artifact-hashes.json').write_text(json.dumps(manifest, indent=2)+'\n')
print('Final manifest refreshed; visually reviewed figure unchanged.')

# 重组提案（仅文档；没有输入变更）

当前沿用 experiments/、results/、notes/，无需为两个实验强制重排目录。CODEMAP.md 与三个短 README 是拟应用于同名项目位置的文档版本，当前只落在授权 outputs/。不复制输入、结果或原始数据。

| 条目 | 引用/限制证据 | 当前决定 | 后续责任人及条件 |
|---|---|---|---|
| experiments/alpha.py、experiments/beta.py | active_tasks.json 声明活跃；各自结果 script 字段引用对应脚本 | 保留准确路径；登记映射 | 主 AI 确认生产者与消费者；技术 owner 补运行来源。若未来重构，须先停止作业并核对所有引用 |
| results/beta.json | running_output_paths 明确列入 | 运行中保护；不移动、不改写 | 运行 owner 完成任务后提供固定 run 标识及新哈希，再由主 AI 决定归档 |
| results/alpha.json | 脚本注释指向结果；结果为 inconclusive | 保留负面/不确定结果；停止状态 unknown | 生产者补运行日志、输入路径与数据类型；不能因结果不理想删除 |
| notes/orphan.txt | 自述来源不可考，但 active_tasks.json 中明确 protected | 仅标 unknown/backlog；保留原位 | 主 AI 联系记录持有人，确定来源和私人/历史用途；保护解除前不提执行移动 |
| HIST-0 / archived/missing.py | CODEMAP 历史引用，清单中缺失 | 保留历史行与顺序，标缺口 | 主 AI/历史 owner 定位来源；不创建伪脚本或假结果 |
| 根 TASK.md / manifest / git | 输入目录均未提供 | 不新建替代总任务；当前仅提案 | 主 AI 提供唯一根任务索引，串行合并 task_refs、生产者、消费者与状态 |

未来新增输出可由主 AI 分配唯一 owner，采用 results/<task_id>/<run_id>/ 与 reports/<task_id>/runs/<run_id>/，并在产物清单记录实际输入、脚本版本、配置、类型、哈希和消费者。该命名仅是计划，当前未生成这些路径，且不把现有结果迁入。

全部七个文件全文已通过只读代理核对：已存在的内部交叉引用如 CODEMAP 所列；未发现重复内容哈希（七者各异），没有证据支持删除或合并文件。外部引用未知且无项目 git 回滚证据，因此当前不具备历史迁移条件。若后续提出迁移，需停止相关作业、核对外部消费者及所有代码/文档/任务引用、具备授权与回滚点；删除不自动执行。

本轮未执行目标脚本、未移动或删除任何输入、未验证研究结果。文档盘点完成不等于科研任务完成。

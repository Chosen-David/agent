# measurements v1 → v2 的影响

依据 project.json 的 change，当前 CSV 视为 v2；未提供 v1 字节或旧产物，不能逐数值比较 v1/v2，也不能声称已验证原始采集过程。输入 SHA256 见 loaded.json。

| 原任务 / 产物 | 处置 | 依据与当前状态 |
|---|---|---|
| collect / measurements.csv@v1 | 保留历史采集声明，不重跑采集；新增 collect-v2 验收现有文件 | v1 原文件缺失，仅 project.json 声称 done；v2 已提供，重采集无授权也无必要；不能把旧 collect done 当新数据验收 |
| figure / figure@v1 | stale，保留历史记录；重画 figure-v2 | 直接依赖 measurements@v1，旧图也未提供，不能就地覆盖或复用验收 |
| write / 尚未生成 | superseded，不派发旧 v1 任务；改为 write-v2 | 直接依赖旧测量且经 figure 间接依赖；需与新图及新分析保持版本一致 |
| background / background@v1 | 依赖关系仍有效；保留而不重做 | 仅依赖 concept.txt@v1，与测量版本无依赖；background@v1 文件缺失，历史 done 未经本轮产物验收，不宣称已经打开它 |
| concept.txt@v1 | 保留现有输入 | 文本为教学概念示例；未要求回答该示例，不将其冒充本项目性能证据 |

新增 RES-retain-v2 完成“保留适用性检查”并以本文件为证据；它只证明独立分支不受当前数据更新影响，不能证明缺失 background@v1 的内容正确。当前结果段落和图不需要消费旧背景产物，因此该缺口不阻塞它们。

已知依赖传播：measurements@v1 → figure@v1 → write；measurements@v1 → write。没有可验证的其它旧文件引用清单，隐藏依赖审计范围仅限 project.json。旧产物未删除、未覆盖，历史状态与当前验收分离。

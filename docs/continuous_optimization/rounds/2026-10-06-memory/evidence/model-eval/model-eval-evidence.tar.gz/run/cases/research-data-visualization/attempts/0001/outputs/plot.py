#!/usr/bin/env python3
"""Rebuild FIG-DV-1: python plot.py. All writes stay beside this script."""
from pathlib import Path
import csv
import hashlib
import io
import json
import platform
import shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from PIL import Image

OUT = Path(__file__).resolve().parent
CASE = OUT.parents[2]
RUN = CASE.parents[1]
SOURCE = CASE / 'inputs/measurements.csv'
SKILL = RUN / 'snapshot/plugins/research-assistant/skills/research-data-visualization'
read_paths = [CASE/'task.txt', SOURCE, SKILL/'SKILL.md'] + [SKILL/'references'/name for name in ['execution.md', 'workflow.md', 'figure_shared.md', 'data_visualization_learning.md']]
loaded = []
for path in read_paths:
    raw = path.read_bytes()
    loaded.append({'path':str(path), 'sha256':hashlib.sha256(raw).hexdigest(), 'bytes':len(raw), 'actually_read':True})
(OUT/'loaded.json').write_text(json.dumps({'actor':'/root/role_eval_controller/eval_dataviz', 'files':loaded}, indent=2)+'\n')
raw = SOURCE.read_bytes()
(OUT/'measurements.csv').write_bytes(raw)
rows = list(csv.DictReader(io.StringIO(raw.decode())))
assert len(rows) == 4
assert list(rows[0]) == ['workload','baseline_ms','candidate_ms','scope']
assert [r['workload'] for r in rows] == ['small','medium','large','kernel']
assert len({(r['scope'], r['workload']) for r in rows}) == 4
for r in rows:
    for key in ['baseline_ms','candidate_ms']:
        r[key] = float(r[key])
        assert r[key] >= 0
assert [(r['baseline_ms'],r['candidate_ms']) for r in rows] == [(100,80),(120,100),(200,220),(20,10)]
(OUT/'plot_data.json').write_text(json.dumps(rows, indent=2)+'\n')

plt.rcParams.update({'font.family':'DejaVu Sans', 'font.size':9, 'axes.labelsize':9,
                     'svg.fonttype':'none', 'axes.linewidth':0.6, 'hatch.linewidth':0.6})
fig, axes = plt.subplots(2, 1, figsize=(7.1,4.1), sharex=True,
                         gridspec_kw={'height_ratios':[3,1]})
fig.subplots_adjust(left=.15, right=.95, top=.82, bottom=.18, hspace=.65)
colors = ['#667580', '#087F8C']
hatches = ['', '////']
all_bars = []
plotted = []
for ax, scope, title in zip(axes, ['end_to_end','kernel_only'], ['a  End-to-end', 'b  Kernel only']):
    subset = [r for r in rows if r['scope'] == scope]
    for mi, (field, method) in enumerate([('baseline_ms','Baseline'), ('candidate_ms','Candidate')]):
        y = [i + (-.19 if mi == 0 else .19) for i in range(len(subset))]
        values = [r[field] for r in subset]
        bars = ax.barh(y, values, height=.32, color=colors[mi], edgecolor='white',
                       linewidth=.4, hatch=hatches[mi], zorder=3)
        for bar, value, r in zip(bars, values, subset):
            ax.text(value+3, bar.get_y()+bar.get_height()/2, f'{value:g}', va='center', ha='left', fontsize=9, color='#17242C')
            plotted.append({'workload':r['workload'], 'scope':scope, 'method':method, 'source_ms':value, 'bar_width_ms':float(bar.get_width())})
            all_bars.append(bar)
    ax.set_yticks(range(len(subset)), [r['workload'] for r in subset])
    ax.set_ylim(len(subset)-.55, -.55)
    ax.set_xlim(0,250)
    ax.set_title(title, loc='left', fontsize=10, fontweight='bold', pad=8)
    ax.set_axisbelow(True)
    ax.grid(axis='x', color='#E1E6E9', linewidth=.6)
    for side in ['top','right','left']:
        ax.spines[side].set_visible(False)
    ax.spines['bottom'].set_color('#ADB8BE')
    ax.tick_params(axis='both', length=0, pad=5)
axes[-1].set_xticks([0,50,100,150,200,250])
axes[-1].set_xlabel('Elapsed time (ms)', labelpad=7)
fig.legend(handles=[Patch(facecolor=colors[i], edgecolor='white', hatch=hatches[i], label=label) for i,label in enumerate(['Baseline','Candidate'])],
           loc='upper center', bbox_to_anchor=(.55,.995), ncol=2, frameon=False, handlelength=2, columnspacing=2)
fig.text(.15,.035,'Synthetic input; no uncertainty information supplied.', fontsize=8, color='#56626B')
fig.savefig(OUT/'figure.png', dpi=300, facecolor='white')
fig.savefig(OUT/'figure.svg', facecolor='white')
fig.savefig(OUT/'final-size-preview.png', dpi=100, facecolor='white')
Image.open(OUT/'final-size-preview.png').convert('L').save(OUT/'grayscale-preview.png')
assert len(all_bars)==8
assert all(x['source_ms']==x['bar_width_ms'] for x in plotted)
assert all(ax.get_xlim()==(0.,250.) for ax in axes)
assert all(bar.get_x()==0 for bar in all_bars)
svg = (OUT/'figure.svg').read_text()
assert '<text' in svg and '<image' not in svg
with Image.open(OUT/'figure.png') as im:
    assert im.size == (2130,1230)
checks = {'source_sha256':hashlib.sha256(raw).hexdigest(), 'row_count':len(rows), 'plotted_value_count':len(plotted),
          'plotted_values':plotted, 'missing_values':0, 'duplicate_scope_workload':0,
          'data_transforms':'none; only split by scope; original order preserved',
          'uncertainty':'not supplied; not drawn', 'axis_limits_ms':[0,250],
          'all_bar_widths_equal_source':True,'all_bar_baselines_zero':True,
          'svg_has_editable_text':True, 'svg_has_raster_image':False, 'png_pixels':[2130,1230],
          'tools':{'python':platform.python_version(),'matplotlib':matplotlib.__version__},
          'visual_inspection':'pending controller pixel inspection'}
(OUT/'numerical-checks.json').write_text(json.dumps(checks, indent=2)+'\n')
manifest = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'artifact-hashes.json'}
(OUT/'artifact-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'outputs':str(OUT),'rows':len(rows),'values_plotted':len(plotted),'numeric_checks':'passed','png_pixels':[2130,1230],'visual':'pending'},ensure_ascii=False))

| Experiment | Conclusion | Script | Data | Result | Citation |
|---|---|---|---|---|---|
| HIST-0 | unknown | archived/missing.py | unknown | unknown | unknown |
| ALPHA | inconclusive（文件声明；未技术验收） | experiments/alpha.py | synthetic-x：合成输入标识；数据文件未提供 | results/alpha.json：实际存在 | experiments/alpha.py:1；results/alpha.json:1；active_tasks.json:1 |
| BETA | rejected（运行中路径当前快照；未技术验收） | experiments/beta.py | synthetic-y：合成输入标识；数据文件未提供 | results/beta.json：实际存在，运行中保护 | experiments/beta.py:1；results/beta.json:1；active_tasks.json:1 |

## 范围与增量说明

前三行保留既有 CODEMAP 内容与历史顺序，仅追加 ALPHA/BETA。本表所有路径相对输入项目 organization/，并非相对本交付目录。输入只读，未执行脚本；本文件是待合并的文档版本。证据来自父控制器只读代理 source-proxy.json 的七文件清单与带行号全文，不声称访问了其他仓库。

项目根无 TASK.md；ALPHA/BETA 是源文件中的实验标识，不冒充已获分配的根 TASK ID。主 AI 后续建立/提供唯一根任务索引，本角色不另建 TASK.md。活跃脚本 2/2 映射，存在结果 2/2 登记；此比例仅覆盖所提供合成目录，不代表历史脚本或科研验收。HIST-0 的脚本缺失且无可验证锚点，历史缺口保持 unknown。

## 生产者、来源与消费者

| 实验/条目 | task_refs | 已核对的来源关系 | 生产者身份 | 消费者/引用 | 状态与缺口 |
|---|---|---|---|---|---|
| ALPHA | 根 TASK 缺失；暂引 experiments/alpha.py:1 | alpha.py 注释指向 alpha.json；结果 script 字段反向指回 alpha.py；输入标识一致 | unknown；仅能确定声明脚本，不能证明实际执行者 | alpha.json 引用 alpha.py；下游消费者 unknown | active_scripts 声明活跃；结果非运行中名单不等于已停止/已验收；无原始数据、调用参数、运行日志、版本提交 |
| BETA | 根 TASK 缺失；暂引 experiments/beta.py:1 | beta.py 注释指向 beta.json；结果 script 字段反向指回 beta.py；输入标识一致 | unknown；实际执行与产出因果未验证 | beta.json 引用 beta.py；下游消费者 unknown | 脚本 active，results/beta.json 在 running_output_paths；哈希仅当前读取快照 |
| HIST-0 | 既有 CODEMAP.md:3 | archived/missing.py 未在清单中；其余 unknown | unknown | 既有 CODEMAP 历史引用 | 缺失脚本，结果与输入 unknown；保留历史行，不捏造来源 |
| notes/orphan.txt | 根 TASK 缺失；实验归属 unknown | 注记自称历史来源不明；active_tasks.json:1 保护引用确实存在 | unknown | 实验下游 unknown；运行清单明确保护 | 不是完全无引用文件；protected，禁止搬移或删除 |

## 文件登记与快照校验

以下为代理读取时真实 SHA-256；运行中产物可变化。所有文件均实际存在；没有把计划文件标为已生成。合成结果是文档 fixture 中声明的结果，不能当成实测数据。

| 路径 | 类型/状态 | SHA-256 |
|---|---|---|
| CODEMAP.md | 历史索引原版（本交付增量版哈希不同） | `9f473ed7d66475ff105fed73dc280a1297f8b24f636a0c555618d8075a49eb24` |
| active_tasks.json | 运行声明与保护清单；不等于进程核验 | `162eaff45eff8cb6003f338e954b8911dc1270b02c20c4bf6206813def362c9e` |
| experiments/alpha.py | 活跃脚本；纯注释 fixture；未执行 | `f601040b09b6e6451ffa7cce2a316a2ecb1a6d5d2b8c18fd2ebd1e4b221cafbc` |
| experiments/beta.py | 活跃脚本；纯注释 fixture；未执行 | `b539dc67e56f43f92c40d5dd08ed708e22c29f2a87003083a828fc8492f9abc0` |
| notes/orphan.txt | 保护的历史注记；来源 unknown | `1e9f45e92d92c740069c6baa092f8e605eeeb4b919c74c43cbb1133a5135704e` |
| results/alpha.json | 合成结果声明；存在/未验收 | `259e32ece539419d3bc1cd7176881f22942b0f5445c0c395ac7da0961aad4897` |
| results/beta.json | 合成结果声明；运行中快照/未验收 | `45b7c1b50849a8b6e5a901cee9bdda7c9d322d1e5e7ff762725b9bc7e4b9e03d` |

未在代理范围内发现 README、manifest、git 元数据或根 TASK.md；没有同一路径多作者的正面证据，但作者未知，不能证明不存在覆盖。引用核对覆盖所供全部文本，不覆盖未知外部消费者。未验证真实进程、文件动态变化或实验正确性。

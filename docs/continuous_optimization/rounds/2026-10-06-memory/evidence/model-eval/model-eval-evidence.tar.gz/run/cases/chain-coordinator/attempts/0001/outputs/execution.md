# chain-coordinator / attempt 0001

## 本轮范围与入口

目标是消费所给 synthetic-v3 数据，交付下一位写作者可直接使用的 analysis.json 与 aggregate.csv。本节点不生成 Results 或 abstract，不新增实验。任务、chain_project.json、handoff_fields.json 和原始 CSV 均已读取；先读取了本次 start.json，再创建产物。

加载科研助手固定快照的 SKILL.md、execution.md、orchestrator.md、task_supervision_workflow.md、project_memory_workflow.md。实际路径与字节 SHA256 由宿主 CPU 代理生成在 loaded.json。未读取其他 case、隐藏验收材料、控制器脚本或仓库评测。未联网、安装依赖、使用 GPU 或派生 Agent。

## 执行方式

采用当前会话中的有界分阶段工作。宿主负责实际 CPU 算术与 SHA256；执行者编写 outputs/calculate.py 后发送精确代理请求，结果落在 proxy_result.json。脚本按 workload 与 variant 分组，对全部重复取中位数，然后依 handoff_fields.json 计算 baseline/candidate 中位数比值及相对 baseline 的延迟降幅。CSV 负降幅必须保留；不挑样本、不以各次 ratio 中位数替代中位数的 ratio。

最小依赖为 INPUT-V3 → ANALYSIS-V3 → HANDOFF-V3 → WRITE-V3；另有 BACKGROUND-SCOPE-CHECK → HANDOFF-V3。WRITE-V3 属于下一位写作者。旧 WRITE-OLD 为 stale，不能作为本轮写作依赖。BACKGROUND-1 仅依据输入提供的比较定义描述保留；旧全文未提供，不假称重新验收该旧产物。

未启动后台监督器、定时器、tmux 或 runtime。当前提供的明确范围是只读输入、CPU 算术和交接文件；没有已授权的后台适配器，本次短节点无需扩大运行边界。

## 检查及恢复

calculate.py 检查所有输入版本和 scope、正有限延迟、每组重复数与 repeat ID、交接必需字段、精确 CSV 列顺序、写回数值以及 source/aggregate SHA256。该检查是数据与接口复核，不是科学同行评审或角色评分。实际退出状态和宿主返回另记于本文件末尾。

若缺文件、解析失败、schema 不匹配或 SHA 不一致，阻塞 HANDOFF-V3/WRITE-V3，保留原始输入，修复此节点并重新生成全部依赖的聚合及哈希。Host 必须将真实 analysis.json 与 aggregate.csv 原样复制到 writer inputs；聚合相对路径按 analysis.json 所在目录解析，并核对 aggregate_file.sha256。analysis.json 的最终哈希见 proxy_result.json，避免自引用哈希。

## 证据边界与交接

该数据明确为合成样本。只描述所给工作负载的端到端样本中位延迟差异，不推断真实 GPU 性能、机制因果、统计显著性、质量保持、生产可用性或整体统一收益。未提供质量、硬件、跨负载权重；不能补写这些事实。下一位写作者需交付中文 Results 段落和英文摘要，明确负结果及合成数据边界。

历史 synthetic-v2 主张的本轮适用性失效不代表旧观测从未存在；保留历史材料及独立背景定义，更新所有依赖延迟主张的下游文字。复核结果、失效 ID、保留 ID、限制均在 analysis.json 供下游消费。

## 宿主实际返回与收尾

宿主代理报告 calculate.py 已真实完成，exit 0。本节点随后读取实际 proxy_result.json、loaded.json、aggregate.csv 与 analysis.json。CPU 聚合得到：small 32→24 ms，1.3333333333333333x，降幅 25%；medium 56→58 ms，0.9655172413793104x，降幅 -3.5714285714285716%；large 96→80 ms，1.2x，降幅 16.666666666666668%。每种版本每组 n=3。medium 是负结果；不支持“每个负载至少 1.8x”。

源文件三项真实哈希保存在 analysis.json。宿主返回的 aggregate.csv SHA256 为 ecdd7ddb5671baf99449eba1336b559f40a3fef08fe3b785cd60a85d0557cb7b；analysis.json SHA256 为 5d46012c4e0c8561ae9e67905ad7bad9c62b396a4fd06b8019b57ae5c437d8af。计算之后未编辑这两份文件。

本节点分析与交接已完成；输入/schema/数值/哈希的脚本检查通过。独立宿主下游验收和写作者消费仍是后续节点，本记录不代为宣称完成。下一负责人为 host（原样复制及核对）→ writer（中文 Results 与英文摘要）。不在此节点撰写下游文字或继续实验。

# experiments/
保留现有脚本路径，不执行这些文档 fixture。
alpha.py 对应 ALPHA / synthetic-x / results/alpha.json。
beta.py 对应 BETA / synthetic-y / results/beta.json。
两脚本均在 active_tasks.json 的 active_scripts 中，禁止因整理搬移。
来源、哈希与缺口见根 CODEMAP.md；实际生产者身份 unknown。

import csv, hashlib, json, math, statistics
from pathlib import Path

OUT = Path(__file__).resolve().parent
RUN = OUT.parents[4]
INPUT = RUN / 'cases/chain-coordinator/inputs'
SNAPSHOT = RUN / 'snapshot/plugins/research-assistant/skills/research-assistant'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name, data):
    (OUT/name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
project = json.loads((INPUT/'chain_project.json').read_text())
contract = json.loads((INPUT/'handoff_fields.json').read_text())
with (INPUT/'chain_latencies.csv').open(newline='') as f:
    raw = list(csv.DictReader(f))
groups = {}
for row in raw:
    assert row['input_version'] == project['input_version']
    assert row['scope'] == 'end_to_end'
    assert row['variant'] in ('baseline', 'candidate')
    value = float(row['latency_ms'])
    assert math.isfinite(value) and value > 0
    groups.setdefault((row['workload'], row['variant']), []).append((int(row['repeat']), value))
rows = []
for workload in dict.fromkeys(r['workload'] for r in raw):
    variants = [groups[(workload,v)] for v in ('baseline','candidate')]
    for values in variants:
        assert len(values) == project['measurement_conditions']['repeats_per_variant']
        assert sorted(r for r,v in values) == [1,2,3]
    b, c = [statistics.median(v for r,v in values) for values in variants]
    rows.append(dict(zip(contract['aggregate_csv_columns'], [workload, len(variants[0]), len(variants[1]), b, c, b/c, 100*(b-c)/b])))
with (OUT/'aggregate.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=contract['aggregate_csv_columns'], lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
findings = []
for line, row in enumerate(rows, 2):
    findings.append({
        'id': 'ANALYSIS-V3-'+row['workload'].upper(),
        'kind': 'derived_from_synthetic',
        'workload': row['workload'],
        'aggregate_row': line,
        'evidence': 'aggregate.csv: workload='+row['workload'],
        'baseline_median_ms': row['baseline_median_ms'],
        'candidate_median_ms': row['candidate_median_ms'],
        'speedup_ratio': row['speedup_ratio'],
        'latency_reduction_pct': row['latency_reduction_pct'],
        'conclusion': '在所给合成端到端延迟样本中，candidate 中位延迟'+('低于' if row['speedup_ratio']>1 else '高于' if row['speedup_ratio']<1 else '等于')+' baseline；仅为样本描述性比较。'
    })
findings.append({'id':'ANALYSIS-V3-OLD-CLAIM', 'kind':'derived_from_synthetic', 'workloads':[r['workload'] for r in rows], 'evidence':'aggregate.csv: all workload rows', 'conclusion':'v3 数据不支持每个工作负载至少 1.8x 端到端加速的旧结论；存在 candidate 中位延迟更高的工作负载。', 'all_workloads_at_least_1_8x':all(r['speedup_ratio']>=1.8 for r in rows)})
analysis = {
    'schema_version': contract['schema_version'],
    'project_id':project['project_id'], 'input_version':project['input_version'],
    'source_files':[{'path':str(INPUT/name), 'sha256':sha(INPUT/name)} for name in ('chain_project.json','chain_latencies.csv','handoff_fields.json')],
    'aggregate_file':{'path':'aggregate.csv','sha256':sha(OUT/'aggregate.csv')},
    'findings':findings,
    'limitations':[
        '这些数据是所给合成测量，不是真实模型、GPU 或新运行的 benchmark 结果。',
        '每个 workload 每版本仅 3 个重复；此处只报告中位数及其比值，没有推断显著性、总体效应或稳定性。',
        '硬件未指定，无法外推到真实硬件、生产负载、其他数据规模或未测配置。',
        '未提供质量指标，不能主张质量保持、精度无损或质量与延迟的权衡。',
        '只支持端到端延迟样本比较，不能据此断言加速机制、组件耗时、吞吐量、内存或能耗改善。',
        '没有提供跨工作负载的权重，未计算或声称统一总体 speedup。',
        'BACKGROUND-1 只提供描述，未提供旧背景全文；保留的是其独立比较定义的适用性，不代表重新验收缺失的旧产物。'
    ],
    'invalidated_work':['WRITE-OLD'], 'retained_work':['BACKGROUND-1'],
    'previous_work_disposition':[
        {'id':'WRITE-OLD','status':'stale','reason':'旧文本依赖 synthetic-v2 延迟结论。v3 聚合不支持其全工作负载至少 1.8x 的主张；该主张及依赖它的总结应停止复用。旧历史文本/记录保留，不删除、不改写为新证据。'},
        {'id':'BACKGROUND-1','status':'retained_scope_checked','reason':'所给描述是 baseline/candidate 比较定义，独立于具体延迟值；本轮可沿用该定义。此检查只覆盖输入描述所述范围。'}
    ],
    'method':{'unit':'ms','scope':'end_to_end','aggregation':'Within each workload and variant, median of all supplied repeats. Ratio of medians, not median of per-repeat ratios.', 'formulas':contract['formulas'],'rounding':'CSV stores Python float representations; format only for prose, retaining these calculation values.'},
    'handoff':{'next_owner':'writer','deliverables':'Chinese Results paragraph and English abstract only; no full submission paper.', 'copy_rule':'Host copies analysis.json and aggregate.csv byte-for-byte into writer inputs. Resolve aggregate_file.path relative to analysis.json. Missing files or SHA256 mismatch block dependent writing.', 'limits':'Use v3 evidence, explicitly include the medium regression and synthetic-data limits; do not reuse WRITE-OLD claims.', 'analysis_hash_location':'proxy_result.json; analysis.json cannot contain its own final SHA256.'}
}
save('analysis.json',analysis)
loaded = [{'path':str(SNAPSHOT/p), 'sha256':sha(SNAPSHOT/p)} for p in ('SKILL.md','references/execution.md','references/orchestrator.md','references/task_supervision_workflow.md','references/project_memory_workflow.md')]
save('loaded.json',{'snapshot_files':loaded})
# Contract/round-trip checks of produced files, separate from any role evaluation.
read_analysis=json.loads((OUT/'analysis.json').read_text())
for key in contract['analysis_json_required']:
    assert key in read_analysis
assert isinstance(read_analysis['schema_version'],int)
assert all(isinstance(read_analysis[k],list) for k in ('source_files','findings','limitations','invalidated_work','retained_work'))
with (OUT/'aggregate.csv').open(newline='') as f:
    reader=csv.DictReader(f)
    assert reader.fieldnames==contract['aggregate_csv_columns']
    reread=list(reader)
assert len(reread)==len(rows)
for actual,expected in zip(reread,rows):
    assert actual['workload']==expected['workload']
    for key in contract['aggregate_csv_columns'][1:]:
        assert float(actual[key])==expected[key]
assert sha(OUT/read_analysis['aggregate_file']['path'])==read_analysis['aggregate_file']['sha256']
for source in read_analysis['source_files']:
    assert sha(Path(source['path']))==source['sha256']
result={'operation':'CPU arithmetic and SHA256; no benchmark execution','rows':rows,'checks':'input version/scope/positive latency/repeat IDs; required keys; exact CSV columns; numeric CSV round trip; source and aggregate hashes', 'files':[{ 'path':str(OUT/name),'sha256':sha(OUT/name)} for name in ('aggregate.csv','analysis.json','loaded.json','calculate.py')]}
save('proxy_result.json',result)
print(json.dumps(result,ensure_ascii=False,indent=2))

# FIG-T-v2 设计与证据

目的：对照四项已提供延迟，区分 end_to_end 与 kernel_only，保留负结果。
数据：measurements.csv@v2；来源为任务提供的 synthetic fixture，不是本轮新测量。每行只有单个汇总值；重复数、硬件、配置、分布未知。
设计：paired horizontal point plot，两面板分 scope，共享从零开始的 ms 线性轴。灰色圆点 baseline、蓝色方点 candidate，连线仅表示同行配对而非连续趋势；直接数值与 legend 冗余编码。7.2×3.4 inch，DejaVu Sans，标题11pt、数据标签9pt，网格轻于数据。按输入顺序展示全部4行，无剔除、无聚合、无误差棒；kernel 面板不会当端到端第四个样本。英文图内文字避免未验证中文字库，中文图注在 results.md。
替代：分组柱图也有效；点图使时延差距可见且节省空间，零轴和共享范围保留绝对量级。
范图：离线、输入未提供范例，无外部图实际阅读，不声称已完成范文学习；本图为独立项目描述性工作图，不主张投稿规范验收。
可编辑主源：analyze_plot.py。输入哈希由代理独立计算，脚本也记录；图像实际打开请求另行保存。PDF 未请求也不导出，不宣称 PDF 字体或整篇嵌入验收。

最终预览验收：控制器实际打开彩色与灰度 PNG 并回报：四对值正确，毫秒轴、两计时范围面板、图例和页脚清晰，无裁切或重叠，灰度圆/方可分。图像收据 run/host/research-assistant-visual.json；彩色SHA256=8cee68d627ade247091d784ce4f4aac51b4bab27e309df150f54ce9c632606ac，灰度SHA256=3bc07c9a7174c973cb025213a298c47299e92af6002bc85f0d742028bcf0a4ef。预览通过，但论文最终尺寸嵌入、PDF与SVG独立渲染未验收；未宣称投稿完成。

# Experiments
Proposed directory note for inputs/organization/experiments/.
alpha.py and beta.py are documentation fixtures; do not execute them.
Both are listed active in ../active_tasks.json; preserve their paths.
Declared outputs: ../results/alpha.json and ../results/beta.json.
These declarations do not establish actual execution provenance.
See ../CODEMAP.md for source anchors and observed hashes.

# Whole-figure QA record

This is artifact QA, not a model/role score. Final assembly reviewed as a whole; individual-panel completion was not used as a substitute.

## Executed checks

The controller executed build_figures.py through the CPU proxy. Initial CairoSVG attempt failed (render-attempt1.log); second attempt with PyMuPDF 1.26.6 rendered but lacked visible SVG-marker arrowheads and had a weights-label overlap. These were real observed issues, retained in revision-before/. Explicit vector triangle arrowheads and a shifted label address them. Current render.log reports successful source assertions and records exact final file hashes.

Worker actual visual read: opened figure.png, figure_180mm_preview.png and figure_grayscale.png with view_image after corrected rendering. Final figure.svg SHA-256: `8ce524b9503cda1845df4f6804c8eafc14c84f2ca2e00daa70faff8232608b84`; final figure.png SHA-256: `cdd32a145a111b6acb0c8cd4fd656c1d7714ba7b1416b55618c8ef744c811c7e`.

| Dimension | Observation / evidence | Status |
|---|---|---|
| Scientific evidence | A prominently says proposed / not implemented. B says synthetic fixture. Caption separates architecture from timings and makes no attribution. | checked |
| Numerical preservation | Four rows/eight bars match 100/80, 120/100, 200/220 and 20/10 ms. Large candidate bar extends beyond baseline. Scope divider isolates kernel-only. Common zero and same ms scale retained. | checked |
| Topology | Six nodes, five arrows; A and B enter the sum separately; sum enters softmax; softmax and V enter output. No A→B, feedback or V→softmax arrow. Script compares node and edge sets to JSON. | checked |
| Arrow readability | Final full-size image visibly has five arrow tips. Weights p label is left of the downward arrow with clear gap; no line crosses that text. | checked |
| Hierarchy / layout | A/B headings align; central divider and white margins separate panels. Legend sits above data. Bar value labels lie outside bars without cropping. Text fits node interiors. | checked |
| Final size | 680px preview represents the proposed 180mm width at 96 CSS px/in; labels remain discernible and no overlap/crop is visible. Physical print and paper embedding are not tested. | screen checked; print unverified |
| Palette / grayscale | Color assigns method nodes blue, fixed V neutral, baseline gray and candidate purple. Grayscale export keeps candidate darker and retains ordered pairs/direct values; topology remains readable without color. No color-vision simulation executed. | grayscale checked; simulation unverified |
| Typography | Final PNG visibly uses a consistent serif substitution although SVG requests DejaVu Sans. Math z, softmax and superscript T are visible. Font embedding and exact cross-renderer matching are unverified; source remains live text and may render with sans-serif elsewhere. | readable; portability limitation |
| Vector / export | Valid SVG XML, stable unique IDs and no external resources. Editable panel and whole SVG masters; PNG exports actually generated. Explicit triangles avoid unsupported marker rendering. | checked |
| Reproduction | Script, exact input copies, plotted values, hashes, renderer versions and failure/revision evidence retained. No installation/network. | checked |
| Submission | No venue specification supplied, no PDF requested, no real manuscript embedding available. | unverified |

Completion is a reviewable standalone figure with the disclosed typography/print limitations, not a claim of submission compliance. Controller final image read receipt is appended below after receipt.

Controller final receipt (actual host image review, delivered in task message): third render exited 0; opened full final image, 680px preview and grayscale. Observed five clear correctly directed arrows; weights label no longer crosses the edge; six nodes and V bypass preserved; values/scopes unchanged; final-size preview small but readable without crop/overlap; grayscale series distinguishable. Raw render receipt is run/host/research-figures-render-3.json, observation/hash receipt is run/host/research-figures-visual-after.json (controller-owned; worker did not read those files). This record quotes the received concrete observations rather than claiming access to host-only records.

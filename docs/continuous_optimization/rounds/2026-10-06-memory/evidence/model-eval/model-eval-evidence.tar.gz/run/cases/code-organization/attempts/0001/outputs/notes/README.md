# notes/
保留历史注记及其原路径。
orphan.txt 无实验来源，实验归属与下游消费者 unknown。
该文件被 active_tasks.json 明确列为 protected，并非完全无引用。
仅登记待办；不因 orphan 文件名移动或删除。
来源补充由主 AI 联系记录持有人，状态见根 CODEMAP.md。

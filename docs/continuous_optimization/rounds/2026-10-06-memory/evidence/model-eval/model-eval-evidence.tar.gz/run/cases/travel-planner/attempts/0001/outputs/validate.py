from pathlib import Path
import json,time
p=Path(__file__).parent
f=json.loads((p/'plans.json').read_text())
t0=time.process_time()
def mins(t):
 h,m=map(int,t.split(':')); return 60*h+m
checks=[]
for plan in f['versions']:
 s=plan['schedule']; rev=plan['revision']; leg=20 if rev==1 else 35
 assert mins(s[0]['start'])==660 and mins(s[-1]['end'])==1080
 for i,x in enumerate(s):
  assert mins(x['end'])>mins(x['start'])
  if i: assert x['start']==s[i-1]['end']
 trans=[x for x in s if x['kind']=='transfer']
 assert len(trans)==4
 assert all(mins(x['end'])-mins(x['start'])==leg for x in trans)
 lunch=next(x for x in s if x['id']=='lunch')
 assert mins(lunch['end'])-mins(lunch['start'])==60
 assert any(mins(a)<=mins(lunch['start']) and mins(lunch['end'])<=mins(b) for a,b in f['service_windows'])
 assert mins(lunch['order_at'])<=mins('14:00')
 rest=next(x for x in s if x['id']=='rest'); assert mins(rest['end'])-mins(rest['start'])==75
 photo=next(x for x in s if x['id']=='photo'); assert [photo['start'],photo['end']]==['16:00','17:00']
 expected=[2*80+300+4*15,2*100+300+4*25]
 assert plan['budget']['subtotal']==expected==[520,600]
 assert plan['budget']['contingency']==[v*0.1 for v in expected]
 assert plan['budget']['total']==[v*1.1 for v in expected]
 checks.append({'revision':rev,'transfer_minutes':4*leg,'return_to_hotel':trans[-1]['end'],'last_order_ok':True,'single_service_window_ok':True,'rest_minutes':75,'photo_preserved':True,'subtotal':expected,'total_with_10_percent':[572,660]})
report={'scope':'Supplied synthetic facts; arithmetic and schedule consistency only','result':'pass','checks':checks,'cpu_seconds':time.process_time()-t0,'unknown_costs_excluded':['hotel/rest room fee','additional photo services','extra meals/drinks'],'currency_assumption':'CNY not specified in input'}
(p/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False))

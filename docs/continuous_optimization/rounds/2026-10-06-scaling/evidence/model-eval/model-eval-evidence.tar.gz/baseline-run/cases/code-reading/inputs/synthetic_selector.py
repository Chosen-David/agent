"""Claim: every layer can skip all attention and the index is query-trained."""
def project(k, dims=(1,3)):
    return [k[i] for i in dims]
def score(q,k):
    return sum(a*b for a,b in zip(q,k))
def run(q,keys,near_ids,skip_far=False,forced_ids=()):
    # skip_far changes candidate range; it does not skip near scoring.
    candidates=list(near_ids) if skip_far else list(range(len(keys)))
    ranked=sorted(candidates,key=lambda i:score(project(q),project(keys[i])),reverse=True)[:2]
    chosen=sorted(set(ranked)|set(forced_ids))
    return [(i,score(q,keys[i])) for i in chosen]

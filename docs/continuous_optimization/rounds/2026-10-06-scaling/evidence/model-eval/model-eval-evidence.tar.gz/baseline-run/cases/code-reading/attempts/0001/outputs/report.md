# CODE-READ-0001：只读机制核查

结论：模块第 1 行叙述不受实现支持。`skip_far` 只缩小候选范围；非空候选仍做投影评分，入选项仍做原始向量评分。投影是固定坐标 `(1,3)`，不是 query-trained index。代码没有 layer、训练过程或 attention 输出。下文是源码事实与静态推断，未运行 `synthetic_selector.py`。

## 范围与版本

- 决策：EXECUTE，原任务只读分析及显式授权的 handoff completion 验证；没有实施替代方案。
- 目标源码：`cases/code-reading/inputs/synthetic_selector.py`，完整 11 行；验证器：`snapshot/scripts/validate_handoff.py`，完整 240 行。读过 handoff/request 原始 JSON，但它们较长，终端显示被截断；本报告不据此推断所有任务细节。
- 控制者提供 snapshot 来源 commit `cb3e133ded7f2c878b3eddb10a0e7876fe6cac2b`；snapshot 内 `.git` 缺失，未自行证明 HEAD/分支/工作区差异。该 commit 是 snapshot 来源，不能冒充外部 synthetic 输入的 Git commit。实际文件 SHA 见 `provenance-summary.json`。
- 只写本 attempt 的 outputs；输入、receipt、request、evidence、snapshot 保持只读。未联网、未用 GPU、未运行目标、未启动子 Agent。独立执行通过控制者的真实工具代理；没有独立语义审阅者，仅自查。
- 精确模型、token 数、成本：unknown。

## 核心机制与叙述对照

| ID / 类型 | 结论与适用条件 | 源码证据（synthetic_selector.py） |
|---|---|---|
| C1 source_fact | `project(k,dims=(1,3))` 返回索引 1、3 对应值；调用者可直接给 `project` 指定其他 dims，但 `run` 没有 dims 参数，内部两次调用均使用默认值。没有配置文件、环境、CLI 覆盖代码。 | `project` L2–3；`run` L6、9 |
| C2 static_inference | 固定维度选择不随 q、keys 数据学习；q 会参与排序分数，但这不等于 query-trained 投影或训练过的索引。第 1 行后半句错误。 | 模块 L1；`project` L2–3；`score` L4–5；`run` L9 |
| C3 source_fact | 默认 `skip_far=False`，候选是所有 `range(len(keys))`；可选真值路径候选是 `list(near_ids)`。near 是调用者提供的索引标签，不从距离计算出来。默认路径不使用 near_ids。 | `run` L6、8 |
| C4 source_fact | 候选全部先按二维投影内积降序排序，再截前 2 个。这是候选数上限，不是近/远分组配额，不是维度预算，也不是强制近邻保留。没有预算参数。 | `run` L9；`score` L4–5 |
| C5 source_fact | `chosen=sorted(set(ranked) | set(forced_ids))`：强制集合可以来自候选范围外、可以绕过二维前 2 截断；去重后按索引升序。默认强制集合为空；非空强制集合可使最终数量超过 2。它不参加排序预算，也不是预算下限。 | `run` L6、10 |
| C6 source_fact | 最终每个 chosen 索引调用 `score(q,keys[i])`，未投影，返回 `(i,score)` 列表。输出按索引升序，不按最终分数排序。没有名为 full_score 的函数/字段；任务所称 full_score 对应 L11 的原始向量评分。 | `run` L10–11；`score` L4–5 |
| C7 static_inference | `skip_far=True` 仍对 near_ids 内每个候选做二维评分，仍对 chosen 做原始向量评分。只有候选和强制集合都空时没有评分调用；因此第 1 行“每层能跳过所有 attention”不能由此推出。实现没有 layer、softmax、value 聚合或 attention 输出。 | 模块 L1；`run` L7–11 |
| C8 source_fact | `score` 是 zip 后乘积求和；等长数值序列时是内积。长度不等时 zip 截到短者，所以“全维”只表示使用原始向量、不等于总是覆盖两者全部坐标。没有 scaling/归一化。 | `score` L4–5；`run` L11 |

二维近似分数既没有校准误差声明，也没有上下界保证。未选中的坐标可能改变全分数排序；不能将二维 top-2 称为全分数 top-2，更不能称为 full_score 的 lower bound。此为根据 L2–5、9、11 的静态推断，不是实测结论。

## 实际调用边与数据边

| 边 | 调用点/条件 | 数据与消费 |
|---|---|---|
| `run → list/range/len` | L8；skip_far 真值选择 near 分支，否则全域 | near_ids 的迭代项或 `[0,N)` 索引 → candidates；索引域由 Python keys 索引解释 |
| `run → sorted → lambda → project(q), project(keys[i]) → score` | L9；每个 candidate 执行 key 回调 | 原始 q、key_i → 两元素 `[x[1],x[3]]` → 二维标量内积 → 降序排名；取前 2 |
| `run → set union → sorted` | L10；两条候选路径都执行 | ranked 索引与 forced_ids → 去重并集 → 升序 chosen；强制项不经过投影排序 |
| `run → score` | L11；每个 chosen 执行 | 原始 q、原始 key_i → zip 内积 → `(i,分数)` 输出列表；这条边不调用 project |

这些边在源码内均 resolved；外部 `run` 调用者、具体数据、实际形状/dtype、layer 接入和消费者不存在于给定文件，均 unresolved/unknown。这里只能假设可迭代、可索引、支持乘法/求和的数据；不是 tensor 接口，也没有明确单位。

## 边界与未知项

- q 和候选 key 至少需要索引 1、3 可用，否则 L3 会失败；L11 本身可接受不同长度，但会静默截短。没有输入检查、padding、mask 或 fallback。
- near_ids 可以空、重复、负数或越界：空候选时 ranked 空，forced 仍可能产生最终评分；负数遵循 Python 索引语义；非法索引会在 L9 或 L11 失败。forced_ids 同样未经范围检查，可在 skip_far 路径重新引入“远”项。
- `[:2]` 在候选少于 2 时保留现有数量；重复候选可能占用两个排名槽，随后 set 去重导致少于两个唯一候选。排序相等时按 Python 稳定排序保留候选相对顺序；实际 numeric ties/NaN 未测。最终索引排序还要求元素可比较。
- `skip_far` 未做 bool 类型检查，实际上按真值分支；当前运行参数、q/keys、近邻有效性、误差/性能全部 unknown。无目标运行日志，不作 correctness/GPU/e2e/性能认证。

## handoff 验证器：源码解释

`main` L211–228 解析 positional record、必须的 `--root`、`--require-complete`、独立 `--request`，读取 JSON 后调用 validate。`_load_json` L11–22 拒绝重复键及非有限 JSON 数值。`_consumer_contract` L25–53 解析 consumer 的 schema/version/完整 task 列表，allow_skip 默认 false。`validate` L71–88 以独立 consumer 输入固定版本，不能由 producer 自行授权；L168–175 比对 task 集合并拒绝未授权跳过。`done` 对证据引用及依赖状态要求见 L187–196。`completed` 状态和检查门禁见 L89–105、139–153、183–186。

**没有 streaming hash。** L117–128 先要求相对路径、resolve 后限制在 root 内且为文件，再执行 `hashlib.sha256(path.read_bytes()).hexdigest()`，一次性把整个证据文件读进 bytes 后哈希。L132–133 对比 producer 摘要。大证据文件内存占用随文件大小增长；不能因为用了 SHA-256 就声称 streaming。JSON 同样用 `read_text` 全量读取（L21），不是流式解析。没有授权修改它，本报告未修复。

**cycle handling 是迭代拓扑消除。** L176–182 构建 graph；L200–207 以 pending 节点集合开始，每轮 ready 是依赖均不在 pending 内的节点，消除 ready；若 pending 非空而 ready 空，报 `task dependency cycle` 后退出。无需递归，所以避免长 DAG 的递归深度风险；反复扫描长链可有二次时间开销，未测性能。未知依赖另在 L187–189 报错；缺失节点并不单独证明 cycle。环与依赖环后的下游阻塞均可剩在 pending；代码只报整体 cycle，不给具体环路径。

运行及实际结果见 `validator-invocation.txt`、`validator-result.json`、`validator-stderr.txt`、`validator-exit-code.txt`。实际 CLI 结果只认证局部字节完整性与显式 consumer 契约，不证明报告机制、科学真实性、LLM 遵循、视觉正确性或运行任务真的发生（验证器 L2、231–235）。

## 实际验收记录

控制者已真实执行上述 completion CLI，并将 stdout/stderr/exit code 保存到本 outputs；本阅读角色随后读回实际文件。exit code 为 **0**，stdout 的 `errors=[]`，`integrity_valid`、`completion_verified`、`consumer_version_checked`、`consumer_scope_verified` 均为 **true**；stderr 为空（控制者执行回报）。这是本次验证器 executed 证据，不是对 synthetic selector 的执行。独立 request 和 handoff 各有 1800 个 task（实际 provenance-summary 计算）；长链成功只是此输入执行观察，不能据此宣称所有 DAG 情况均正确或有 streaming hash。

关键文件实际 SHA-256：

| 文件 | SHA-256 |
|---|---|
| synthetic_selector.py | `17692fa95b63a037417abd3fae567cbc75b7fb6a1ad2de5ec0d1875ec6936d14` |
| validate_handoff.py | `142433ec0876f1d78c96b887534c4259e49b5cfa62bc40001c6757ec487ee262` |
| handoff.json | `e06a63ac63b8590e35017293a07987ebbe5162b6b106ffafd571d353eb715bf6` |
| consumer_request.json | `8a542abd61b2dd8cdfd5f85bdd934d1e08f08676d1fbf63c69ae03d3d7756a1b` |

自查重新定位了 selector L2–11 及 validator L117–133、168–207、211–240，默认/可选、候选预算/强制集合、静态阅读/实际 validator 执行分别记录。目标未执行；后续 owner 可根据 report 中边界添加真实输入测试，但本任务未授权该目标运行。

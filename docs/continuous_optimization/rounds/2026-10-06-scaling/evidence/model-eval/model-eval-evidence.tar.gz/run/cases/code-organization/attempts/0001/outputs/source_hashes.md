# Source snapshot hashes

These SHA-256 values were actually returned by the parent controller's read-only observable proxy (`sha256sum`, exit 0). Working directory: `/workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/code-organization/inputs/organization`. They identify supplied bytes, not generation correctness, task acceptance, immutable experiment versions or current process liveness. The mutable/protected log was hashed only as a supplied snapshot.

| Supplied path | SHA-256 | Status |
|---|---|---|
| CODEMAP.md | 7041bda953c1d71c218d602341980e6a85a1fca7882962c2419e3082b4e3cf6f | present; historical row retained in output copy |
| active_tasks.json | fb79b7dd4e9e0a1dc0cffab9491a65a41cb20969c2805476f99794e43b4739af | present; declared state only |
| experiments/sweep.py | 6d450901126b5a0e56d9ae19bbd0a7a29f264c2ffa5acba9d66081923b7bbce3 | present; not executed |
| results/near.json | 5f022724219adabef75d40ebea599e5f6e3ea060aae27bd59535032af74b7b78 | present; synthetic result |
| results/both.json | 5d0a41f5db8b35b0eddce5780a70efaeffe95eba8475bb5b4130c9b2452ea9b4 | present; synthetic result |
| results/live.log | 0937d08f54e653261262e49243a613b39e2ef3260551b2f6bd8f302f7dbbc6b4 | declared running/protected; liveness unknown |
| notes/orphan.txt | 312931e9c7c861d927c31be4da0f46cb02ab20c3828cf3756964cdd99afa6f84 | present; attribution unknown |
| experiments/legacy.py | unknown — missing from supplied inventory | historical anchor only |

No producer manifest, measured-run source, task ID, consumer identity or code commit was supplied. These hashes do not fill those gaps. This delivery was authored solely by code-organization under the parent controller's assigned output path; all input author identities remain unknown.

# Bounded solution landscape and provenance

Offline task materials only: `inputs/buggy.py` defines len/slicing plus built-in
max semantics, and the task explicitly defines window validity and complete windows.
The frozen skill execution/workflow and measurement evidence contract require
independent correctness and separation of measurement scopes. They are procedural
sources, not empirical proof of performance.

The delivered exhaustive per-window reduction is simple and preserves the existing
generic interface. The independent reference is a manually indexed exhaustive scan.
For totally ordered numbers, monotonic deque is a classic O(n) amortized alternative;
its invariant and complexity reasoning are stated in candidate_matrix.md. It remains
an unimplemented candidate, with no current literature/library verification or benchmark.
NaNs and arbitrary Python comparison objects prevent asserting generic equivalence
without additional contract work. No current state-of-the-art survey was possible
within the explicit no-network constraint; no citations, library tests or best-method
claims are invented. Hardware-specific work is unnecessary for the requested repair.

Input and implementation checksums are recorded by the executed verifier; timing
input checksum is recorded by the arithmetic script. These exact sources distinguish
observed proxy execution, supplied measurement summaries, mathematical derivation,
static implementation reasoning and unknown hardware/measurement provenance.

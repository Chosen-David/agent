# CODEMAP
| item | source |
|---|---|
| historical baseline | experiments/legacy.py (historical, missing now) |
| shared parameterized entry | experiments/sweep.py (present; argument parser only) |
| near synthetic result | results/near.json → experiments/sweep.py; mode=near, k=8 |
| both synthetic result | results/both.json → experiments/sweep.py; mode=both, k=16 |
| protected output | results/live.log ← active_tasks.json declaration; actual process status unknown |
| unattributed report | notes/orphan.txt (present; origin unknown) |
| declared activity index | active_tasks.json (present; declaration only) |

## Scope and evidence

Paths above are relative to the supplied project root, `/workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/code-organization/inputs/organization`. This is an incremental documentation copy; the original CODEMAP and every input remain untouched. The historical row retains its original wording and position. This output's sole writer is `code-organization`; project-file authors are unknown unless explicitly supplied.

The supplied directory contains no root TASK.md, producer artifact manifest, consumer documentation, git status, or process readback. No replacement TASK.md was created. Stable task references, producer identities, consumer identities and run IDs remain unknown; the main controller owns resolution and any TASK update. No scripts were executed.

| Task reference | Status/conclusion | Producer | Script/source anchor | Data and units | Artifact/version | Consumers/references |
|---|---|---|---|---|---|---|
| unknown | Historical baseline missing; preserve historical index | unknown | experiments/legacy.py absent; original CODEMAP row | unknown | historical script unavailable | original CODEMAP; other consumers unknown |
| unknown | Present; reusable argument entry, generation not established | unknown | experiments/sweep.py line 2 | `--mode` accepts near/both; `--k` integer; units unknown | present supplied script; commit/version unknown | results/near.json and results/both.json declare this source |
| unknown | Present synthetic record; technical acceptance unverified | unknown | results/near.json; source declaration experiments/sweep.py | mode=near; k=8; latency_ms=12 ms; synthetic | present supplied JSON; run/version unknown | no downstream reference found in supplied scope; external consumers unknown |
| unknown | Present synthetic record; technical acceptance unverified | unknown | results/both.json; source declaration experiments/sweep.py | mode=both; k=16; latency_ms=15 ms; synthetic | present supplied JSON; run/version unknown | no downstream reference found in supplied scope; external consumers unknown |
| unknown | Declared running and protected; actual liveness unknown | unknown | active_tasks.json declared_running/protected_paths | log text only; no measured result established | results/live.log; mutable activity unknown | active_tasks.json references this exact path; other consumers unknown |
| unknown | Unattributed report; backlog only | unknown | notes/orphan.txt explicitly forbids run attribution | unknown; report text only | present supplied note; version unknown | no other in-scope reference found; external consumers unknown |
| unknown | Activity/protection declaration supplied | unknown | active_tasks.json scope: no process status access | declared state, not verified runtime evidence | present supplied JSON; version unknown | code-organization inventory; external consumers unknown |

## Provenance limits and coverage

Both result records explicitly identify the existing sweep script, and their declared arguments match its parser choices/types. However, the script only parses arguments: it contains no latency calculation or JSON writer. These references establish declared source linkage, not verified generation, experiment correctness or reproducibility. The two records differ in both mode and k; their synthetic latency values cannot establish a controlled performance improvement.

All seven supplied files are registered here or in the original CODEMAP anchor. The one present script is mapped; the one historical script is explicitly missing. No completeness claim is made for unavailable historical or external scripts, consumers or tasks. Source hashes are recorded in `source_hashes.md` when returned by the controller's read-only proxy; the declared-running log hash is only a snapshot and does not establish liveness.

No input was moved, renamed, rewritten or deleted. Protection is applied to results/live.log regardless of unavailable process readback. See `reorganization_proposal.md` for pending ownership/source questions and proposal-only paths, and the brief directory READMEs for supplied-directory semantics.

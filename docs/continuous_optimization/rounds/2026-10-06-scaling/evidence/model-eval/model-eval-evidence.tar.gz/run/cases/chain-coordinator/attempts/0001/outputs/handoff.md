# Coordinator handoff — latency-v3 / v3

This node produced `analysis.json` and `aggregate.csv` from the supplied synthetic input. `calculate.py` is the reusable CPU calculation and integrity-check script. The controller executed the requested command through its actual tool proxy and reported exit code 0; the coordinator subsequently read the persisted analysis and aggregate. The controller retains the observable execution record. This is not a claim that the coordinator directly executed arithmetic or hashing.

| Workload | Samples baseline/candidate | Baseline median (ms) | Candidate median (ms) | Speedup ratio | Latency reduction (%) |
| --- | --- | --- | --- | --- | --- |
| small | 3 / 3 | 42 | 30 | 1.4 | 28.571428571428573 |
| medium | 3 / 3 | 80 | 80 | 1.0 | 0 |
| large | 3 / 3 | 120 | 150 | 0.8 | -25 |

These are descriptive results for the supplied synthetic samples. Small improves, medium is unchanged, and large regresses: the negative reduction denotes a 25% latency increase. The results do not support a universal improvement, statistical significance, real deployment performance, or any accuracy/quality claim. No network, GPU, new experiment, figure, or writer draft was used or produced.

`figure-v2` and `write-v2` are invalidated as current interpretations by the v3 input change. `raw-v2` remains historical evidence and `background` remains reusable context under the project directive. Neither historical artifact was supplied for inspection, so numeric applicability to v3 has not been independently accepted. Preserve old files; rebuild downstream interpretations against the v3 handoff.

Controller-observed SHA256 values:

- `aggregate.csv`: `bb09702e3ab4fbbfc96d1b33613946d93ec6478b766e62a421c0e57117296281`
- `analysis.json`: `28e87980607bc7a6194bfa03848e83ae98a76f6fe2fc921a1f0e27d05197e327`

All three full input hashes are embedded in `analysis.json`. The script checks positive finite inputs, version presence, required schema fields and basic types, exact CSV columns, persisted numeric round-trip, aggregate hash correspondence, and unchanged input bytes. These are producer checks; they do not replace host acceptance or writer ingestion checks.

The next owner is the writer. The host must copy the actual two required files unchanged to writer inputs and verify both against the hashes above. The writer must verify the aggregate hash against analysis and block on any missing file or mismatch. Current decision is EXECUTE for analysis only; dependent writing remains gated by this verified file transfer. No alternative plan, new permissions, or new experiment is authorized by this handoff.

Reproduction command (executed by controller):

```bash
python /workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/chain-coordinator/attempts/0001/outputs/calculate.py --inputs /workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/chain-coordinator/inputs --outputs /workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/chain-coordinator/attempts/0001/outputs
```

Workdir: `/workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/chain-coordinator/attempts/0001/outputs`.

Model identity, token usage, and execution cost were not observable. No monitor was installed or claimed; task orchestration and independent acceptance remain with the controller.

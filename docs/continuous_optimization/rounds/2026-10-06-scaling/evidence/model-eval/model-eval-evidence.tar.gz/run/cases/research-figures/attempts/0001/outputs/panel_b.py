from svg_tools import el,text,INK,MUTED,BLUE,GRAY

def draw_b(root,rows):
    text(root,25,39,'B',26,'bold')
    text(root,60,39,'Supplied latency results',23,'bold')
    text(root,60,72,'Baseline',17,fill=GRAY)
    el(root,'rect',x=40,y=60,width=12,height=12,fill=GRAY)
    text(root,210,72,'Candidate',17,fill=BLUE)
    el(root,'rect',x=190,y=60,width=12,height=12,fill=BLUE)
    text(root,650,72,'Lower is faster',16,fill=MUTED,anchor='end')
    left,right=162,620
    scale=(right-left)/250
    for tick in range(0,251,50):
        x=left+tick*scale
        el(root,'line',x1=x,x2=x,y1=95,y2=471,stroke='#dce2e8',stroke_width=1)
        text(root,x,494,str(tick),16,fill=MUTED,anchor='middle')
    el(root,'line',x1=left,x2=right,y1=471,y2=471,stroke='#7d8893',stroke_width=1)
    text(root,(left+right)/2,521,'Latency (ms)',18,anchor='middle')
    for i,r in enumerate(rows):
        y=117+i*62
        scope='kernel' if r['scope']=='kernel' else 'end-to-end'
        text(root,147,y-1,r['workload'].capitalize(),17,anchor='end')
        text(root,147,y+20,scope,16,fill=MUTED,anchor='end')
        for j,(field,color) in enumerate([('baseline_ms',GRAY),('candidate_ms',BLUE)]):
            val=float(r[field]); yy=y-12+j*17
            el(root,'rect',id=f"B-{r['workload']}-{r['scope']}-{field}",x=left,y=yy,width=val*scale,height=12,fill=color,data_value=val,data_units='ms')
            text(root,left+val*scale+7,yy+12,f'{val:g}',16,fill=color)
    text(root,35,550,'One replicate per row; uncertainty unavailable.',16,fill=MUTED)
    text(root,35,574,'CSV provenance unverified; no statistical superiority claim.',16,fill=MUTED)

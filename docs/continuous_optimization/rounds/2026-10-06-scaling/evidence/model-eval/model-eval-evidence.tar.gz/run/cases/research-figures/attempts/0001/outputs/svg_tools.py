from xml.etree import ElementTree as ET
NS='http://www.w3.org/2000/svg'
INK='#253343'; MUTED='#536170'; BLUE='#267da8'; GRAY='#78828e'
def el(p,tag,**attrs): return ET.SubElement(p,f'{{{NS}}}{tag}',{k.replace('_','-'):str(v) for k,v in attrs.items()})
def text(p,x,y,value,size=18,weight='normal',fill=INK,anchor='start'):
    t=el(p,'text',x=x,y=y,font_family='DejaVu Sans',font_size=size,font_weight=weight,fill=fill,text_anchor=anchor)
    t.text=value
    return t

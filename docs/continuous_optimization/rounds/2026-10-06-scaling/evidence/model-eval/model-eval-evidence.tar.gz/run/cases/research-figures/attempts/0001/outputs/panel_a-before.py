from svg_tools import el,text,INK,MUTED

def draw_a(root,arch):
    text(root,25,39,'A',26,'bold')
    text(root,60,39,'Fixed-value aggregation',23,'bold')
    text(root,60,72,'Proposed · synthetic specification · unimplemented',16,fill=MUTED)
    defs=el(root,'defs')
    m=el(defs,'marker',id='A-arrow',viewBox='0 0 10 10',refX='9',refY='5',markerWidth='7',markerHeight='7',orient='auto',markerUnits='strokeWidth')
    el(m,'path',d='M 0 0 L 10 5 L 0 10 z',fill=INK)
    # Coordinates are layout only; topology is validated against the input.
    boxes={'a':(35,135,170,60),'b':(35,260,170,60),'sum':(260,198,120,60),'softmax':(420,198,150,60),'v':(260,375,120,60),'output':(420,375,150,60)}
    paths={('a','sum'):'M205 165 H232 V228 H260',('b','sum'):'M205 290 H232 V228 H260',('sum','softmax'):'M380 228 H420',('softmax','output'):'M495 258 V375',('v','output'):'M380 405 H420'}
    for a,b in arch['edges']:
        el(root,'path',id=f'edge-{a}-{b}',d=paths[(a,b)],fill='none',stroke=INK,stroke_width=2,marker_end='url(#A-arrow)',data_source=a,data_target=b)
    for n in arch['nodes']:
        x,y,w,h=boxes[n['id']]
        g=el(root,'g',id=f"node-{n['id']}",data_node_id=n['id'])
        fill='#eaf3f8' if n['id'] in ('sum','softmax','output') else '#f2f4f6'
        el(g,'rect',x=x,y=y,width=w,height=h,rx=7,fill=fill,stroke='#7f97a7',stroke_width=1.4)
        label={'softmax':'p = softmax(z)','output':'y = pᵀ V'}.get(n['id'],n['label'])
        text(g,x+w/2,y+36,label,18,anchor='middle')
    text(root,35,503,'Six nodes; five directed edges.',17,fill=MUTED)
    text(root,35,531,'V bypasses softmax; no feedback or a → b edge.',17,fill=MUTED)
    text(root,35,559,'No measured accuracy or speedup specified.',17,fill=MUTED)

"""Reproducible SVG panels and composition; only Python stdlib + CairoSVG render."""
from pathlib import Path
import csv, json, hashlib, platform
from xml.etree import ElementTree as ET
import importlib.metadata
from panel_a import draw_a
from panel_b import draw_b

OUT = Path(__file__).resolve().parent
INPUT = OUT.parents[2] / 'inputs'
SVG = 'http://www.w3.org/2000/svg'
ET.register_namespace('', SVG)

def root(w,h):
    r=ET.Element(f'{{{SVG}}}svg', {'width':str(w),'height':str(h),'viewBox':f'0 0 {w} {h}'})
    ET.SubElement(r,f'{{{SVG}}}rect', {'width':str(w),'height':str(h),'fill':'white'})
    return r

def save(name,r):
    ET.indent(r)
    p=OUT/f'{name}.svg'
    ET.ElementTree(r).write(p,encoding='utf-8',xml_declaration=True)
    import cairosvg
    cairosvg.svg2png(url=str(p),write_to=str(OUT/f'{name}.png'))

def main():
    architecture=json.loads((INPUT/'architecture.json').read_text())
    with (INPUT/'measurements.csv').open() as f: rows=list(csv.DictReader(f))
    assert [(r['workload'],r['scope']) for r in rows]==[(w,s) for w in ('small','medium','large') for s in ('kernel','end_to_end')]
    assert len(architecture['nodes'])==6 and len(architecture['edges'])==5
    a=root(600,590); draw_a(a,architecture); save('panel_A',a)
    b=root(700,590); draw_b(b,rows); save('panel_B',b)
    combined=root(1300,590)
    draw_a(combined,architecture)
    g=ET.SubElement(combined,f'{{{SVG}}}g',{'transform':'translate(600 0)'})
    draw_b(g,rows)
    ET.SubElement(combined,f'{{{SVG}}}line',{'x1':'600','x2':'600','y1':'25','y2':'555','stroke':'#e2e6ea'})
    save('figure',combined)
    import cairosvg
    cairosvg.svg2png(url=str(OUT/'figure.svg'),write_to=str(OUT/'figure_grayscale.png'))
    # Grayscale proof image only; vector master remains editable.
    from PIL import Image
    with Image.open(OUT/'figure_grayscale.png') as im: im.convert('L').save(OUT/'figure_grayscale.png')
    hashes={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='manifest.json'}
    inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(INPUT.iterdir())}
    audit={'source_rows':rows,'excluded_rows':[], 'scale':'linear latency_ms, bars from zero; range 0..250', 'uncertainty':'not available; replicates=1 for every comparison', 'edges_expected':architecture['edges'], 'architecture_status':architecture['status'], 'architecture_evidence_type':architecture['evidence_type'], 'rendered_node_ids':[n['id'] for n in architecture['nodes']], 'rendered_edge_ids':[f"edge-{a}-{b}" for a,b in architecture['edges']]}
    (OUT/'data_semantic_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    hashes['data_semantic_audit.json']=hashlib.sha256((OUT/'data_semantic_audit.json').read_bytes()).hexdigest()
    manifest={'input_sha256':inputs,'output_sha256':hashes,'python':platform.python_version(),'cairosvg':importlib.metadata.version('CairoSVG'),'pillow':importlib.metadata.version('Pillow'),'figure_pixels':[1300,590],'provisional_physical_width_mm':180,'font':'DejaVu Sans; editable SVG text','execution':'controller proxy; see render.log'}
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'rendered':['panel_A.svg','panel_A.png','panel_B.svg','panel_B.png','figure.svg','figure.png','figure_grayscale.png'],'input_sha256':inputs,'audit':'all 6 CSV rows and all 6 nodes / 5 directed edges preserved'},indent=2))

if __name__=='__main__': main()

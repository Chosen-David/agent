# Source and input provenance

Root: `/workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/`.

The controller attests that the frozen snapshot binds repository revision `4ee5f7f2b1e189514c876b2290e368aff0899c7a`. The snapshot intentionally contains no `.git`; this agent did not establish an intrinsic snapshot Git HEAD or working-tree status. The provided synthetic selector is an input fixture, so the snapshot revision must not be misrepresented as the selector's Git commit. File hashes below pin the actual analyzed bytes. They were computed by the controller's observable tool proxy using the command below, and returned as actual output.

| File relative to root | SHA-256 |
| --- | --- |
| `cases/code-reading/inputs/synthetic_selector.py` | `17692fa95b63a037417abd3fae567cbc75b7fb6a1ad2de5ec0d1875ec6936d14` |
| `snapshot/scripts/validate_handoff.py` | `d182adfa0d118d6245f0a58623114d8fbeb70dd6ab8fa3ea4c1d93754bcedf9d` |
| `cases/code-reading/inputs/handoff.json` | `e06a63ac63b8590e35017293a07987ebbe5162b6b106ffafd571d353eb715bf6` |
| `cases/code-reading/inputs/consumer_request.json` | `8a542abd61b2dd8cdfd5f85bdd934d1e08f08676d1fbf63c69ae03d3d7756a1b` |

Hash command, working directory `/workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/snapshot`:

```bash
sha256sum /workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/code-reading/inputs/synthetic_selector.py /workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/snapshot/scripts/validate_handoff.py /workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/code-reading/inputs/handoff.json /workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/code-reading/inputs/consumer_request.json
```

Evidence fixture: receipt names `large-evidence.bin`, SHA-256 `4ea22663915e910e8ca6d2952f48a7e84fd4195483ca07282eca3a9f6b22fc4a`. Actual authorized validator execution returned no digest mismatch. Listing showed 12,582,912 bytes. This is byte-integrity evidence only; it does not prove the receipt's task claims. Handoff run ID/input version visible in the supplied receipt are `large-chain-v3` / `v3`; the consumer version is independently checked by the actual validator result.

Read coverage: full 11-line selector, full 263-line validator, supplied task, initial receipt/request content (the long concatenated print was truncated; the validator independently parsed the complete files), frozen `AGENTS.md`, decision-review protocol, and code-reading SKILL/workflow/execution/coverage. No other cases, rubric, or evaluations were read. No target import, network, GPU, modification of inputs/snapshot, or sub-agent spawn was performed. Report line references were self-checked against the displayed source; no independent reviewer was started.

Exact model / tokens / cost: **unknown / unknown / unknown**.

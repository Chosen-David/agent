# v3 合成计时分析与后续任务交接

本轮目标来自 `project.json`：分析更新后的 v3 synthetic timings，规划图与写作。决策为 **EXECUTE**，限定于现有输入的分析与依赖规划。没有新实验、网络检索、GPU、服务或新 Agent；本角色分阶段执行，不声称独立审稿或后台监督已运行。

输入：`project.json`、`measurements.csv`、`concept.txt`。CSV 本身没有版本列，v3 身份来自 project 的 goal/change，不能假称从 CSV 独立验证了版本。完整输入 SHA-256 和实际 CPU 复算结果见 `validation.json`；复算程序为 `analyze.py`。本报告是分析与规划交付，不是已完成的 figure@v3 或 write@v3。

## 现有数据的结论

定义 speedup = baseline_ms / candidate_ms；大于 1 表示候选更快。运行时间变化 = (candidate_ms / baseline_ms − 1) × 100%；负值表示省时。不能把二者的百分比口径互换。

| workload | scope | baseline (ms) | candidate (ms) | speedup | 候选运行时间变化 | 省时 (ms) |
|---|---|---:|---:|---:|---:|---:|
| small | kernel | 30 | 10 | 3.000× | −66.67% | 20 |
| small | end_to_end | 60 | 45 | 1.333× | −25.00% | 15 |
| medium | kernel | 60 | 30 | 2.000× | −50.00% | 30 |
| medium | end_to_end | 100 | 100 | 1.000× | 0.00% | 0 |
| large | kernel | 120 | 60 | 2.000× | −50.00% | 60 |
| large | end_to_end | 180 | 225 | 0.800× | +25.00% | −45 |

六个单元格均为合成数据、replicates=1。kernel 在三个已给 workload 上均更快，但端到端只在 small 更快；medium 持平；large 更慢。因此“普遍加速”已被提供的数据反例否定。large 的 0.8× speedup 对应运行时间增加 25%，不能写成增加 20%。

没有实测重复方差、置信区间或显著性证据。不计算跨 workload 的平均加速作为结论，也不由 scope 差异推断具体瓶颈或真实硬件因果。输入未给环境、代码、采样协议和真实实验日志，故结论仅限该合成教学表。

## 版本变更影响与保留

| 原 task / 产物 | 本轮处理 | 依据与验收限制 |
|---|---|---|
| collect / measurements.csv@v2，project 中标为 done | 保留历史原始字节；不改写、不删除、不重跑 v2；新建 v3 ingest 与分析记录 | v2 文件未随输入提供，不能声称已校验或恢复其字节；由 artifact custodian 检查实际路径与哈希 |
| “universal speedup” 的旧解释 | 标记 superseded；引用其结论的当前报告不能复用 | project.change 明确更正，且 v3 large end_to_end 构成反例；保留旧解释作为历史，不恢复为 active |
| figure / figure@v2，project 中标为 done | 对当前 v3 使用标记 stale；保留历史图，生成独立 figure@v3 | 原依赖 figure ← collect；计时输入更新使图的数据/解释依赖失效；原图未提供，不声称视觉验收完成 |
| write，project 中标为 todo | 更新到 v3 输入和已验收 figure@v3；旧下游依赖不能满足新稿验收 | 没有已给 write 产物，故这是待执行任务的重规划，而不是声称修改过历史稿件 |
| background / background@v1，project 中标为 done | 不受计时变更影响，保留；不安排背景重写 | 唯一声明输入是 concept.txt@v1，与 measurements 更新无依赖路径；实际 background@v1 文件未提供，只有历史完成声明，不能标为本轮已验收 |
| concept.txt@v1 | 保持原输入字节；仅核对独立适用范围 | 复算用于输入概念的适用性检查，不等于重新生成或独立审读 background@v1 |

受影响路径为：measurements@v3 → 新分析 → figure@v3 → 图验收 → write@v3 → 写作验收。独立路径 concept@v1 → background@v1 不因计时更新而失效。历史原始数据与错误解释要分别管理，不能因解释更正删除原始观测。未提供历史产物只阻塞它们的真实性/保留验收，不阻塞现有 v3 分析与规划。

## 独立背景的适用性核对

这部分使用给定 concept，不新增 RoPE 实验或外部文献。

令 p=softmax(z)，y=pᵀV，固定 V=(2,14)。z=(0,0) 时 p=(1/2,1/2)、y=8；z′=(0,log 3) 时 p′=(1/4,3/4)、y′=11，有限输出差为 3。

softmax 的 Jacobian 为 J=diag(p)−ppᵀ。固定 V 的输出导数是 ∂y/∂z_j=p_j(V_j−y)，因此原点导数为 (−3,3)，扰动后为 (−9/4,9/4)。对应概率 Jacobian 分别为 [[1/4,−1/4],[−1/4,1/4]] 和 [[3/16,−3/16],[−3/16,3/16]]。导数是局部量，不能直接替代这一有限扰动的精确输出差。

反例一：V=(5,5) 时任意 logits 的输出恒为 5，输出导数为零。反例二：给所有 logits 加相同常数不变更 softmax 或输出；例如 z′+(7,7) 仍给出 y=11。因此该特定 logit/value 玩具变化不是“普遍 RoPE amplification”的证据。没有提供从 RoPE 旋转、Q/K 和位置到这些 logits 的映射，也没有普遍界或实测；不能由该例推出 RoPE 总会增强输出扰动。

## 可执行依赖与验收

机器可读计划在 `task_dag.json`，保留原任务名的对应关系与新证据 ID。CPU 复算命令（在 run 根目录运行）：

```bash
python /workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/research-assistant/attempts/0001/outputs/analyze.py
```

| ID | 依赖 | 下一动作 / owner | 完成条件 |
|---|---|---|---|
| RES-V3-INGEST | 无 | 当前分析阶段读取三份输入，检查格式与哈希 | 六条唯一正计时、单位 ms、每条 n=1；输入未修改；哈希和版本来源入记录 |
| RES-V3-ANALYSIS | INGEST | 当前分析阶段生成 timing_analysis.csv 和本报告 | 六行比值/变化可复算；small E2E 改善、medium 平、large 回退；范围/不确定性正确 |
| RES-V2-RETENTION | 无 | controller/custodian 核对历史 v2 原始文件与图 | 历史字节/哈希保留；旧解释和图的当前用途 stale；缺文件时保留 blocked 与恢复条件 |
| RES-BACKGROUND-APPLICABILITY | 无 | 当前阶段记录独立性，保留背景不重写 | 概念计算通过；无计时依赖；不以缺失历史 background 自述 done 当作本轮验收 |
| FIG-V3-REFRESH | ANALYSIS | 后续 figure 阶段据 CSV 作图 | 两面板分别展示 kernel/E2E，三个 workload baseline/candidate 成对条形；ms 轴、精确数据、速度比标签；合成 n=1，无误差棒；medium 平与 large E2E 回退可见 |
| REV-FIG-V3 | FIG-V3-REFRESH | 后续指定 checker 检查数值和渲染 | 每个 mark 与 CSV 对齐，scope/版本/单位正确；在最终尺寸检查可读性；记录 editable/rendered 文件版本与哈希 |
| WRITE-V3 | ANALYSIS、REV-FIG-V3、BACKGROUND-APPLICABILITY | 后续 writing 阶段引用新图和新证据 | 更正普遍加速主张；所有数值追到 v3；合成 n=1、局限与背景保留明确；不新增机制/显著性/真实硬件主张 |
| REV-WRITE-V3 | WRITE-V3 | 后续指定 checker 逐主张核验 | 数值/图/版本一致；stale v2 结论不被恢复；历史保留证据缺口公开；报告剩余未执行任务 |

作图设计仅为后续可执行规格；本轮不声称已渲染或视觉检查。建议图题为“Workload-specific synthetic timing comparison”，避免 universal speedup。图注必须写明 baseline/candidate、ms、六个单元格各一次、合成教学数据、speedup 定义；分别验收数据保真与可读性。

写作可复用的受限结果段落草稿：

> 在所提供的合成计时表中，候选方案对 small、medium、large 的 kernel 分别表现为 3.00×、2.00×、2.00× 加速；对应端到端加速比为 1.33×、1.00×、0.80×。small 的端到端运行时间下降 25%，medium 持平，large 增加 25%。因此这些数据支持 workload 和 scope 相关的表现，不能支持普遍端到端加速。每个单元格仅有一次合成计时，不能据此估计测量方差、统计显著性或真实部署性能。

该段是计划输入草稿；待 figure@v3 与图验收完成后才可绑定新图编号，不能提前标 write@v3 done。

## 当前交接状态

本轮已交付源数据范围内的分析报告、复算程序与依赖计划。Controller 实际执行上述 CPU 命令，退出码 0，stdout 为 status=passed、rows=6、dag_nodes=8；随后本角色读取了生成的 `timing_analysis.csv` 和 `validation.json`，核对本报告六行数字。六个计时单元格、概念数值反例、输入前后哈希一致、依赖 ID 完整与无环检查均通过。RES-V3-INGEST、RES-V3-ANALYSIS、RES-BACKGROUND-APPLICABILITY 已完成本轮本地检查；这不代表历史产物独立验收。静态计划不是 runtime 数据库，未来节点维持 planned，历史保留验收维持 blocked。没有真实后台监督 ID 或 readback，故没有启动监督器。

还需 controller 处理历史 v2/figure/background 产物证据缺口，并执行 figure@v3、图验收、write@v3、写作验收。后续不得把 artifact 存在或 DAG 无环当作科学/视觉验收；本轮单角色复算也不等于独立审查。模型、token 与成本不可观测，记录为 unknown。

"""CPU checks of the supplied synthetic model; no paper/performance claims."""
import json
import math
from pathlib import Path

OUT = Path(__file__).resolve().parent
VALUES = (2.0, 14.0)


def softmax(z):
    peak = max(z)
    terms = [math.exp(x - peak) for x in z]
    total = sum(terms)
    return [x / total for x in terms]


def output(z, values=VALUES):
    return sum(p * v for p, v in zip(softmax(z), values))


def check_point(z):
    p = softmax(z)
    y = output(z)
    jac = [[p[i] * ((1.0 if i == j else 0.0) - p[j])
            for j in range(2)] for i in range(2)]
    analytic = [p[i] * (VALUES[i] - y) for i in range(2)]
    h = 1e-5
    finite_difference = []
    softmax_fd = [[0.0, 0.0], [0.0, 0.0]]
    for j in range(2):
        plus, minus = list(z), list(z)
        plus[j] += h
        minus[j] -= h
        finite_difference.append((output(plus) - output(minus)) / (2 * h))
        p_plus, p_minus = softmax(plus), softmax(minus)
        for i in range(2):
            softmax_fd[i][j] = (p_plus[i] - p_minus[i]) / (2 * h)
    error = max(abs(a - b) for a, b in zip(analytic, finite_difference))
    softmax_error = max(abs(jac[i][j] - softmax_fd[i][j])
                        for i in range(2) for j in range(2))
    assert error < 1e-8
    assert softmax_error < 1e-8
    return {"logits": z, "probabilities": p, "output": y,
            "softmax_jacobian": jac, "output_jacobian": analytic,
            "output_finite_difference": finite_difference,
            "softmax_finite_difference": softmax_fd,
            "step": h, "max_output_error": error,
            "max_softmax_error": softmax_error}


base = check_point([0.0, 0.0])
changed = check_point([0.0, math.log(3.0)])
assert math.isclose(base["output"], 8.0, abs_tol=1e-12)
assert math.isclose(changed["output"], 11.0, abs_tol=1e-12)
assert all(math.isclose(a, b, abs_tol=1e-12)
           for a, b in zip(changed["probabilities"], [0.25, 0.75]))
equal_values = {"base": output([0.0, 0.0], (7.0, 7.0)),
                "changed": output([0.0, math.log(3.0)], (7.0, 7.0))}
assert equal_values["base"] == equal_values["changed"] == 7.0
common_shift = {"base": output([0.0, 0.0]),
                "changed": output([math.log(3.0), math.log(3.0)])}
assert common_shift["base"] == common_shift["changed"] == 8.0
report = {"scope": "provided synthetic teaching model; CPU arithmetic only",
          "points": [base, changed], "finite_output_change": 3.0,
          "linear_prediction_at_base": 3.0 * math.log(3.0),
          "counterexamples": {"equal_values": equal_values,
                              "common_logit_shift": common_shift},
          "passed": True}
(OUT / "numeric_check.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))

# 能力选择

使用任务提供的 research-read-pdf 角色快照与本地 PyMuPDF 渲染、view_image 真正查看图片。离线执行（offline_fallback）；禁止联网、安装、GPU 和新增子 Agent。版本绑定见 skill-sources.lock.json；不宣称检索了当前最佳工具。实际渲染通过控制器代理执行。

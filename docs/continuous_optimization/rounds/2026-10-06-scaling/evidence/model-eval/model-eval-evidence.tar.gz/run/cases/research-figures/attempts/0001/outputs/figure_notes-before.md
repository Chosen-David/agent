# FIG-0001: mixed figure

Decision: EXECUTE within the provided input-only scope. No network, GPU, extra experiments, or independent sub-agents. The research-figures instructions were applied sequentially, using diagram and data-visualization workflow references as offline fallbacks. This is a synthetic role task; the input CSV filename does not establish measured provenance.

Routing: A → diagram; B → data_visualization; whole figure → mixed. Single source/assembly owner: current research-figures context. No independent role collaboration is claimed. No exemplar assets were provided; no external exemplar learning or external skill invocation is claimed.

Editable masters: panel_a.py and panel_A.svg; panel_b.py and panel_B.svg. Composition master: build_figure.py and figure.svg. Shared primitives/font: svg_tools.py. SVG text remains editable and bars/nodes/edges have stable IDs. Data are read directly from the original inputs without filtering, normalization, aggregation, or interpolation. The superscript transpose is a typographic rendering of input p^T, not a formula change.

Design brief: provisional 180 mm figure width, 1300 × 590 SVG units/pixels. A and B share DejaVu Sans, dark ink, compact header hierarchy, and reserved footer space. A uses aligned neutral input blocks, lightly tinted computation blocks and orthogonal directed connectors. B uses gray baseline/blue candidate bars with consistent top/bottom positions, direct exact values, zero-origin length encoding and a shared 0–250 ms linear axis. Workload/scope labels are repeated to preserve all groups. Color is redundant with ordering and direct values. No decorative icons or images are used. Target venue, embedding scale and publication specifications were not supplied; submission compliance is unverified.

Reproduction (controller execution proxy): run `python build_figure.py` from this outputs directory, requiring Python, CairoSVG and Pillow already available in the environment. This generates panels, composed SVG/PNG, a grayscale PNG, numerical/semantic audit and a hash/version manifest. No dependencies are installed. See render.log for the actual run outcome. Input/output SHA256 values are in manifest.json; data_semantic_audit.json retains every input row and expected edge.

Scientific QA: all six nodes/five directed edges and six comparisons are preserved by source-driven loops; topology assertion prevents accidental extra nodes/edges. Proposed/synthetic/unimplemented labeling is explicit in A; unknown CSV provenance and single replicates are explicit in B. All unfavorable and equal results retained. No error bars, statistical inference or architecture-to-latency causal claim.

Numerical QA: every bar width equals input milliseconds × common linear scale, beginning at zero. Direct labels are generated from the same CSV values. No missing/negative values are present in supplied rows; each replicates value is 1. No exclusions.

Visual and technical QA: pending actual controller render and final image opening. Source parsing/build checks alone cannot establish visual quality. The final review receipt will document actual whole-image observations and any unresolved item. Grayscale proof is generated for redundant ordering/labels; it also requires actual opening. SVG contains no raster embedding or external links; only local font substitution is possible. No PDF is requested or claimed.

Status: draft pending render and final whole-image review. Remaining publication check: venue-specific dimensions/fonts and final paper embedding, outside this input-only task.

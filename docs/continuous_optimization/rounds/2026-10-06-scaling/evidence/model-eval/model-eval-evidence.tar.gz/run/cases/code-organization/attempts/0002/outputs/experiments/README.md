# experiments
对应原项目实验源码目录；本交付目录只放说明草稿。
`sweep.py` 仅见参数解析：mode=near/both，k 为整数。
两个合成 JSON 声明引用它，源码未见生成或计时代码。
历史 `legacy.py` 已缺失，保留索引，不伪造恢复文件。
调用配置、日志与真实生产者待主控制器核实，禁止执行目标脚本。
路径与哈希见 [CODEMAP](../CODEMAP.md)。

# CODE-READ-0001: selector mechanism and handoff validation

`synthetic_selector.py` selects candidates using a fixed two-coordinate dot product, unions forced IDs, and recomputes scores from the original vectors for the chosen IDs. The module claim that “every layer can skip all attention and the index is query-trained” (line 1) is unsupported by this implementation: there are no layers or training/index construction, and `skip_far` only changes the candidate range. The selector was **read, never imported or executed**. All selector behavior below is source fact or static inference, not a measured result.

The separately authorized handoff validator was actually executed through the controller's observable tool proxy. Its saved output reports all four integrity/completion/consumer flags true, with no errors. That verifies the local byte and explicit consumer contract checks implemented by the validator; it does not prove the truth of receipt claims or selector behavior. See `validator-result.json` and `execution.md`.

## Scope and evidence notation

S = `cases/code-reading/inputs/synthetic_selector.py`; V = `snapshot/scripts/validate_handoff.py`, both under `/workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/`. Line numbers refer to the supplied file bytes, read using `nl -ba`. Version identifiers and SHA-256 evidence are in `provenance.md`. This is a provided synthetic file, not evidence of a production attention system. No network, GPU, target execution, input modification, or independent agent review was performed. Review is a source self-check. The frozen code-reading skill and its workflow/execution/coverage guidance were read.

## Claims, defaults, and conditions

| ID / kind | Source-supported conclusion | Evidence |
| --- | --- | --- |
| C1 / source_fact | `project(k, dims=(1,3))` selects zero-based coordinates 1 and 3 in that order. This is coordinate selection, with no learned matrix, calibration, or training state. | S `project`, 2–3; complete file 1–11 |
| C2 / source_fact | `dims` can be overridden by a direct caller of `project`; `run` supplies no override and exposes no projection parameter, so both query and candidate keys use `(1,3)` on this entry path. | S `run`, 6,9; `project`, 2–3 |
| C3 / source_fact | `run` defaults to `skip_far=False`, `forced_ids=()`. `near_ids` is required, but is ignored for candidate formation in the default branch. Default candidates are all positions `0..len(keys)-1`. | S `run`, 6,8 |
| C4 / source_fact | Truthy `skip_far` changes candidates to `list(near_ids)`. There is no early return: projected scoring/ranking still runs for every candidate entry, then forced union and final scoring still run. It excludes far candidates only insofar as the supplied near IDs do so. | S `run`, 7–11 |
| C5 / source_fact | The budget is a hard-coded slice `[:2]` of ranked candidate **entries**, not a two-near/two-far quota or a cap on final IDs. No configurable budget, layer-specific budget, or reserved near quota exists. | S `run`, 8–10 |
| C6 / static_inference | Duplicate candidate IDs can occupy both top entries; the later set then leaves fewer than two distinct ranked IDs. The candidate range and number selected are different concepts. Assumes sortable scalar scores and valid indices. | S `run`, 9–10 |
| C7 / source_fact | `forced_ids` are unioned after ranking; they bypass projected ranking and may lie outside the candidate range. They need not be in `near_ids`, and their union may exceed two final IDs. They are deduplicated against ranked IDs and one another. | S `run`, 10 |
| C8 / source_fact | Final output is ordered by ascending chosen ID (`sorted(set(...))`), not by descending projected score or final score. Ranking ties retain candidate order under Python's stable sort; default order is ascending candidate positions and optional order is the supplied near iterable order. | S `run`, 8–11 |
| C9 / source_fact | Every chosen ID is rescored by `score(q,keys[i])` using original, unprojected vectors. There is no function literally named `full_score`: this line is the final score stage requested by the task. Selection is low-dimensional, final scoring is unprojected, and only chosen keys receive that final score. | S `run`, 11; `score`, 4–5 |
| C10 / static_inference | “Full-dimensional dot product” holds only if query and key lengths match. `zip` silently stops at the shorter length; mismatched lengths yield a truncated dot product. Neither shape nor type is checked. | S `score`, 4–5 |
| C11 / source_fact | The output is a list of `(id, score)` tuples. No softmax, normalization, value aggregation, attention output, layer dispatch, or persistent index appears. The query influences ranking through the score, which is query-dependent computation, not query-trained projection. | S complete file 1–11 |

For ordinary numeric vectors with equal length D≥4, the projected ranking score for key i is `q[1]*keys[i][1] + q[3]*keys[i][3]`; the final score sums products over all D original coordinates. The projection score is neither an established lower bound nor an upper bound on that final score. Missing coordinates may contribute either sign, and no error guarantee is implemented (S 2–5,9,11). All of this is static inference under the stated numeric-vector assumptions.

## Resolved call edges and data edges

These are syntactic calls resolved to the local function definitions, not observed runtime traces.

| Caller → callee | Call site / condition | Data produced and consumer |
| --- | --- | --- |
| `run` → `project(q)` | S 9, ranking each candidate; no custom dims | Original query → length-2 list `[q[1], q[3]]` → ranking `score`. Recomputed per candidate. |
| `run` → `project(keys[i])` | S 9, each candidate i | Candidate ID → key lookup → length-2 coordinate list → ranking `score`. |
| `run` ranking lambda → `score` | S 9 | Two projected lists → scalar sum of pairwise products via S 5 → descending sort key. |
| `run` final comprehension → `score` | S 11, each chosen i | Original query and key → sum over `min(len(q),len(key))` pairs → output tuple. |

The complete data chain is: `skip_far` + `near_ids` + `len(keys)` → candidate list (S 8) → projected query/key scores and descending ranking → first two entries (S 9) → set union with forced IDs → deduplicated ascending IDs (S 10) → original-vector scores → returned tuples (S 11). Candidate IDs index the input `keys` sequence directly; no logical-to-physical mapping or layer state is present. Dtype and numeric units are inherited from input objects and not declared. The two-coordinate projection does not change the vectors consumed by final scoring.

## Boundary checks and unknowns

| Boundary / configuration | Static result and evidence |
| --- | --- |
| Empty candidate list | Ranking has no calls to its key function; chosen IDs come only from `forced_ids`. With no forced IDs the return list is empty. S 9–11. This data-dependent emptiness does not implement a general layer attention skip. |
| One candidate entry | At most one ranked entry; forced union can add IDs. S 9–10. |
| `skip_far=True`, forced ID outside near range | Forced ID is included and receives final unprojected scoring if its lookup is valid; no projected score is required for it. S 8–11. |
| Repeated near IDs | Repeated projected scoring is possible; repetitions can consume the two-entry ranking slice before deduplication. S 8–10. |
| Short query/key during candidate ranking | Indexing coordinates 1 and 3 can raise `IndexError`; no fallback. If candidates are empty, projection is never evaluated. S 3,9. |
| Invalid forced ID | No range validation; it reaches `keys[i]` at final scoring. Ordinary Python negative IDs index from the end; sufficiently out-of-range or invalid types can fail. S 10–11. The same lookup issue exists for near IDs at S 9. |
| Nonhashable/mixed-order IDs or unsuitable arithmetic | Set construction, sorting, indexing, multiplication, or summation may fail; the file contains no exception recovery. S 3,5,9–11. |
| Runtime configuration and performance | Actual q/keys, lengths, types, near/forced sets, current skip value, output, speed, memory, accuracy, and any layer integration are unknown because selector execution is forbidden and no run log was supplied. |

For numeric vectors, a static illustration can falsify equivalence of projected and full scores: with `q=[1,1,1,1]`, key A `[100,0,100,0]` has projected score 0 and unprojected score 200; key B `[0,1,0,1]` has projected score 2 and unprojected score 2. This is a hand-derived example, **not executed evidence**. A future authorized runtime check could inspect this ranking difference and empty/duplicate/forced cases, but none was run here.

## Validator: actual gate versus semantic truth

The completion CLI accepts receipt path, required `--root`, `--require-complete`, and independently supplied `--request` (V `main`, 234–251). It loads both JSON files rather than deriving consumer intent from the producer (V 81–98). `_load_json` rejects duplicate object keys and non-finite JSON constants (V 21–32). Completion needs matching expected version, completed status, artifacts, acceptance checks, consumer task scope, permitted skips, and valid task/evidence/dependency structure (V 76–209).

The saved actual result has `integrity_valid=true`, `completion_verified=true`, `consumer_version_checked=true`, `consumer_scope_verified=true`, and `errors=[]`. These flags are computed from absence of validator errors and supplied CLI switches, not external semantic review (V 254–258). The receipt's evidence bytes and recorded hash match under the validator; that is not proof that the evidence supports its claimed checks or that task statuses are truthful. No receipt, request, or evidence was changed to obtain this result.

### Streaming hash

`_sha256_file` opens the evidence in binary mode, repeatedly reads up to 1 MiB, updates SHA-256 for every nonempty chunk, and ends only at an empty read (V 12–18). Thus a positive short read is included and does not end the loop; a final partial chunk is hashed. Time is O(B) for B evidence bytes, and hash-loop allocation is bounded by chunk size rather than the entire artifact size. It does not use `read_bytes` or retain all chunks. Path checking resolves the root and artifact, requires a root-relative path that resolves within root and exists as a file, then hashes it and compares the receipt digest (V 71–73,127–143).

This bounded-memory claim applies to evidence hashing, **not the entire validator**: JSON is loaded with `read_text`/`json.loads` (V 31), and artifact/task/graph structures remain in memory. The implementation assumes stable local artifacts; it does not lock a file or certify that a concurrently mutated file represented one coherent point-in-time snapshot. No such mutation was induced or claimed observed.

### Cycle handling

Before cycle detection, task IDs, dependency types, unknown dependencies, completion ordering, evidence references, and skip/block reasons are checked (V 165–209). Kahn elimination then creates `remaining` known indegrees and reverse `dependents` adjacency (V 213–219), queues zero-indegree nodes (V 220), removes them iteratively, decrements their dependents, and enqueues new zero-indegree nodes (V 222–228). If removed vertex count differs from graph size it emits `task dependency cycle` (V 229–230).

Known dependencies are set-deduplicated before indegree and reverse-edge construction (V 216), so repeated dependencies count once. Unknown dependencies are excluded from this cycle graph but already produce their own diagnostic (V 197–199). A self-loop or multi-node cycle leaves nodes unremoved; descendants of a cycle may also remain, so the diagnostic detects existence of a cycle rather than listing precisely which nodes form it. No recursive DFS or repeated whole-DAG elimination is used. The elimination is O(V+E) with O(V+E) graph memory under ordinary constant-time dictionary/set operations; E here counts supplied dependency processing, including duplicates before deduplication. This is source-derived complexity, **not a benchmark**.

The observed successful invocation covers only the supplied receipt/request/evidence. It is not a run of a cyclic fixture, short-read mock, adversarial path test, or selector. Cycle and short-read claims are source analysis. Minimum further validation, if separately desired, would supply fixtures for duplicate dependencies, self/multi-node cycles, unknown dependencies, partial reads, and unauthorized skips in isolated outputs; such tests are outside this task's executed evidence.

Exact model identity, tokens, and cost: **unknown**. No synthetic estimate is reported.

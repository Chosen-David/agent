"""Bounded CPU build/check for the supplied offline reading task."""
import base64
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import subprocess
import sys

out = Path(__file__).resolve().parent
root = out.parents[4]
pdf = root / "cases/paper-reading-companion/inputs/paper.pdf"
builder = root / "snapshot/plugins/research-assistant/skills/paper-reading-companion/scripts/build_reader.py"
digest = hashlib.sha256(pdf.read_bytes()).hexdigest()
result = subprocess.run([sys.executable, str(builder), str(pdf), "--out", str(out / "reader.html"), "--pages", "1,3-4", "--notes", str(out / "notes.json")], check=True, capture_output=True, text=True)
html = (out / "reader.html").read_text()
match = re.search(r'<script id="reader-data" type="application/json">(.*?)</script>', html, re.S)
data = json.loads(match.group(1))
data["title"] = "Synthetic attention teaching note"
encoded = json.dumps(data, ensure_ascii=False).replace("&", "\\u0026").replace("<", "\\u003c").replace(">", "\\u003e")
html = html[:match.start(1)] + encoded + html[match.end(1):]
html = html.replace("<title>untitled · 论文伴读</title>", "<title>Synthetic attention teaching note · 论文伴读</title>")
html = html.replace("let index=0,zoom=100,textMode=false;", "let index=data.pages.findIndex(p=>p.number===3),zoom=100,textMode=false;")
# The bundled template writes a literal backslash-n; the delivered copy uses real newlines.
html = html.replace(".join('\\\\n')", ".join('\\n')")
(out / "reader.html").write_text(html)
assert data["sha256"] == digest == json.loads((out / "notes.json").read_text())["paper_sha256"]
assert [p["number"] for p in data["pages"]] == [1, 3, 4]
assert data["cards"][0]["page"] == 3
images = []
for page in data["pages"]:
    image = base64.b64decode(page["image"], validate=True)
    assert image[:8] == b"\x89PNG\r\n\x1a\n"
    width, height = struct.unpack(">II", image[16:24])
    assert width > 0 and height > 0
    images.append({"physical_page": page["number"], "png_bytes": len(image), "width": width, "height": height})
assert "data:image/png;base64," in html
assert not re.search(r'<(?:script|link)[^>]+(?:src|href)=', html)
assert not re.search(r'\b(?:fetch|XMLHttpRequest|WebSocket)\s*\(', html)
assert "尚未发送给模型" in html
assert ".join('\\n')" in html
arith = {}
for name, logits, values in [
    ("baseline", (0, 0), (2, 14)),
    ("changed", (0, math.log(3)), (2, 14)),
    ("equal_values", (0, math.log(3)), (8, 8)),
    ("decrease_example", (math.log(3), 0), (2, 14)),
]:
    exps = [math.exp(z) for z in logits]
    weights = [x / sum(exps) for x in exps]
    arith[name] = {"weights": weights, "y": sum(p * v for p, v in zip(weights, values))}
for name, expected in [("baseline", 8), ("changed", 11), ("equal_values", 8), ("decrease_example", 5)]:
    assert math.isclose(arith[name]["y"], expected)
assert hashlib.sha256(pdf.read_bytes()).hexdigest() == digest
check = {"status": "passed", "checks": ["input PDF hash matches notes and embedded HTML", "physical pages 1,3,4 embedded as actual PNG data", "current default position is physical page 3", "single-file HTML has no external script/style assets or network calls", "copy prompt uses newline delimiters; no live-backend claim", "four numerical examples verified", "input PDF unchanged"], "paper_sha256": digest, "images": images, "arithmetic": arith, "builder_stdout": json.loads(result.stdout), "browser_interaction_test": "not performed; checks are structural and arithmetic"}
(out / "validation.json").write_text(json.dumps(check, indent=2))
print(json.dumps(check, indent=2))

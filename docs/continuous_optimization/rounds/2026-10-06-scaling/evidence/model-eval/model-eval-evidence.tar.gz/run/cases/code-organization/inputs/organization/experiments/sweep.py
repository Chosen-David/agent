import argparse
p=argparse.ArgumentParser();p.add_argument("--mode",choices=["near","both"]);p.add_argument("--k",type=int);p.parse_args()

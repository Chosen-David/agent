# rolling_max repair — attempt 0001

Decision: EXECUTE within the requested interface and isolated output directory.
The original inputs are read-only; the delivered replacement is `rolling_max.py`.

## Change and contract

The original `range(len(values)-window)` omits the final complete window: for
`[1,3,2], window=2`, it returns `[3]` instead of `[3,3]`; a window equal to
input length produces no result. The corrected stop is `len(values)-window+1`.
The original also accepts bool and lacks deliberate validation of the window.

The replacement retains `rolling_max(values, window)`, list output, len/slicing
input requirements, and Python built-in max semantics for each complete window.
Positive `int` subclasses are accepted; bool and non-int values raise TypeError,
and nonpositive ints raise ValueError. Oversize windows and empty inputs with
valid windows return `[]`. Invalid windows are rejected even for empty input.
Input values are not mutated. Ties preserve built-in max's first winning object;
NaN handling is unchanged because each window still uses built-in max.

Complexity, assuming O(window) slicing/comparison: O((n-window+1)*window) time
for window<=n, O(window) transient space plus O(n-window+1) output. For oversize
windows, no window is sliced. This is a correctness repair, not a measured speed
optimization. No new dependency or hardware-specific primitive is introduced.

## Independent verification

`verify_rolling_max.py` uses nested indexed traversal with `>` comparisons, no
slices, no `max()`, and no calls to production code in the oracle. It reproduces
three failures of the original implementation, checks boundary cases and error
types, tests tuples/strings, NaNs, duplicates, negative and monotonic values,
oversize integer windows, int subclasses, custom comparison objects and tie
identity. Seed 20261006 drives 1000 random arrays, each tested at several widths;
each check verifies exact output and unchanged input. It records SHA-256 for the
original before and after, candidate, and verifier, plus the actual Python host.

Actual parent-proxy execution passed with exit code 0: 43 boundary checks and
3,897 randomized checks, plus three original-failing regression reproductions.
`correctness_results.json` records Python 3.12.14 on Linux x86_64 and unchanged
original SHA-256 `768c27c2e3058f2a7902fbcecc197e1e483bbcf8c0111a80d771f51c2308cc49`.
Candidate SHA-256 is `fcdba54c8a965be4409b5d1c52c7111dec7b2c90665c8d01c14e3b29b64c3ddb`.
This role read back the saved execution JSON; it did not self-execute tests.

Reproduce from this output directory, without writing bytecode into input paths:

```bash
PYTHONDONTWRITEBYTECODE=1 python verify_rolling_max.py --original /workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/research-implement-optimize/inputs/buggy.py
python analyze_timings.py /workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/research-implement-optimize/inputs/measurements.csv
```

The controller executes these commands on behalf of this role. Tests provide
CPU correctness evidence only; they time no workload and execute no GPU work.
Source validation remains separate from analysis of supplied timing summaries.
The second command also completed with actual exit code 0 and produced
`timing_analysis.json`, whose six calculated rows match the table below. The
timing source SHA-256 is `c470d3b8248787cac887e8b3b6a935ecedbb0e26be28b1cf0230c0cd974525b5`.

## Supplied timing scope

`analyze_timings.py` preserves every supplied row, binds the source checksum,
and calculates speedup=baseline/candidate and latency reduction=(baseline−candidate)/baseline.
The following arithmetic describes supplied summaries, not newly measured data.

| Workload | Scope | Baseline ms | Candidate ms | Speedup | Latency reduction |
| --- | --- | ---: | ---: | ---: | ---: |
| small | kernel | 30 | 10 | 3.00x | 66.67% |
| small | end_to_end | 60 | 45 | 1.33x | 25.00% |
| medium | kernel | 60 | 30 | 2.00x | 50.00% |
| medium | end_to_end | 100 | 100 | 1.00x | 0.00% |
| large | kernel | 120 | 60 | 2.00x | 50.00% |
| large | end_to_end | 180 | 225 | 0.80x | -25.00% |

All kernels have lower reported latency. The reported end-to-end results improve
only for small, tie for medium, and regress by 25% latency for large. Kernel gains
therefore do not establish universal application gains. No aggregate is computed:
workload mixture/weights and an aggregation target were not supplied.

Each row has one replicate. Raw timing distributions, independence, hardware,
versions, warmup/cache strategy, timing nesting and synchronization are unknown;
no variance, confidence interval, significance or generalization is justified.
These rows are not linked to this repaired script and do not establish GPU use.
There is no new CPU performance benchmark, GPU benchmark, profiler trace or
hardware/ISA probe. No bottleneck cause is inferred from these summaries alone.

If kernel timing is a sequential component of the end-to-end timing and all other
work were unchanged, the conditional model is E_new=E_base−K_base+K_new. It predicts
45/70/120 ms for small/medium/large, versus supplied 45/100/225 ms. This is a
diagnostic model only: the component/nesting assumptions are unverified, so it
cannot attribute differences to transfer, launch, synchronization or other causes.

## Scope and handoff

Frozen local skill instructions were used via offline_fallback. No remote lookup,
dependency installation, Git modification, background service, subprocess agent,
or GPU access was requested or performed. Algorithm comparisons and source limits
are in `candidate_matrix.md`, `solution_landscape.md`, and `optimization_log.md`.
Exact model identity, token counts and cost are unknown and are not estimated.

Remaining performance research is optional and outside this repair's acceptance:
recover measurement provenance and raw paired timings; define workload/precision
and end-to-end nonregression requirements before any optimized implementation or
new benchmark. All mandatory repair checks and supplied timing arithmetic have
completed successfully, tracked in `task_chain.yaml`. The controller remains the
next owner for independent acceptance of this role's handoff.

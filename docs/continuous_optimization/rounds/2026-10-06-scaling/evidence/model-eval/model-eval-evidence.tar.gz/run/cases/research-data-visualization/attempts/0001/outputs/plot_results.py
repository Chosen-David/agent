"""Reproduce all reported timings; no inferential statistics or new measurements."""
from pathlib import Path
import csv
import hashlib
import json
import shutil
import sys
import platform

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from PIL import Image
import fitz

OUT = Path(__file__).resolve().parent
DEFAULT_INPUT = OUT.parents[2] / 'inputs' / 'measurements.csv'
INPUT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else DEFAULT_INPUT
raw = INPUT.read_bytes()
rows = list(csv.DictReader(raw.decode().splitlines()))
assert len(rows) == 6
workloads = ['small', 'medium', 'large']
scopes = ['kernel', 'end_to_end']
assert {(r['workload'], r['scope']) for r in rows} == {(w, s) for w in workloads for s in scopes}
assert all(int(r['replicates']) == 1 for r in rows)
assert all(float(r[k]) >= 0 for r in rows for k in ['baseline_ms', 'candidate_ms'])
shutil.copyfile(INPUT, OUT / 'measurements_snapshot.csv')
records = [{**r, 'baseline_ms': float(r['baseline_ms']), 'candidate_ms': float(r['candidate_ms']), 'replicates': int(r['replicates'])} for r in rows]
lookup = {(r['scope'], r['workload']): r for r in records}
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9,
                     'axes.labelsize': 9, 'axes.titlesize': 10,
                     'xtick.labelsize': 8, 'ytick.labelsize': 9,
                     'svg.fonttype': 'none', 'pdf.fonttype': 42,
                     'axes.edgecolor': '#8B9298', 'axes.linewidth': 0.6,
                     'hatch.linewidth': 0.65})
fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.65), sharex=True, sharey=True)
fig.subplots_adjust(left=0.095, right=0.975, bottom=0.19, top=0.77, wspace=0.32)
colors = {'baseline_ms': '#697781', 'candidate_ms': '#197B83'}
plot_values = []
for panel, (ax, scope, title) in enumerate(zip(axes, scopes, ['Kernel timing', 'End-to-end timing'])):
    for method, offset, hatch in [('baseline_ms', -0.18, None), ('candidate_ms', 0.18, '///')]:
        vals = [lookup[(scope, w)][method] for w in workloads]
        positions = [i + offset for i in range(3)]
        ax.barh(positions, vals, height=0.29, color=colors[method], edgecolor='white',
                linewidth=0.55, hatch=hatch, zorder=3)
        for w, y, value in zip(workloads, positions, vals):
            ax.text(value + 3.5, y, f'{value:g}', va='center', ha='left', fontsize=8, color='#263238')
            plot_values.append({'scope': scope, 'workload': w, 'method': method, 'time_ms': value, 'y': y})
    ax.set_title(f'({chr(97 + panel)}) {title}', loc='left', pad=10, fontweight='semibold')
    ax.set_xlim(0, 250)
    ax.set_xticks([0, 50, 100, 150, 200, 250])
    ax.set_yticks(range(3), [w.capitalize() for w in workloads])
    ax.tick_params(axis='both', length=0, pad=5)
    ax.tick_params(axis='y', labelleft=True)
    ax.grid(axis='x', color='#E1E5E8', linewidth=0.55, zorder=0)
    ax.set_axisbelow(True)
    for edge in ['top', 'right', 'left']:
        ax.spines[edge].set_visible(False)
    ax.set_xlabel('Time (ms)', labelpad=8)
axes[0].set_ylim(2.55, -0.55)
fig.legend(handles=[Patch(facecolor=colors['baseline_ms'], label='Baseline'),
                    Patch(facecolor=colors['candidate_ms'], edgecolor='white', hatch='///', label='Candidate')],
           loc='upper center', bbox_to_anchor=(0.53, 0.965), ncol=2, frameon=False,
           handlelength=1.8, handleheight=1.1, columnspacing=2.5)
fig.text(0.095, 0.055, 'Synthetic supplied timings · one replicate per condition · no uncertainty estimates',
         fontsize=8, color='#515B62')
for suffix in ['svg', 'png', 'pdf']:
    fig.savefig(OUT / f'timing_results.{suffix}', dpi=300, facecolor='white')
fig.savefig(OUT / 'timing_results_final_size.png', dpi=100, facecolor='white')
plt.close(fig)
with Image.open(OUT / 'timing_results_final_size.png') as im:
    im.convert('L').save(OUT / 'timing_results_grayscale.png')
with fitz.open(OUT / 'timing_results.pdf') as doc:
    page = doc[0]
    page.get_pixmap(matrix=fitz.Matrix(100 / 72, 100 / 72), alpha=False).save(str(OUT / 'timing_results_pdf_render.png'))
    fonts = page.get_fonts(full=True)
    (OUT / 'pdf_fonts.json').write_text(json.dumps(fonts, indent=2))
    assert abs(page.rect.width - 7.2 * 72) < 0.01
    assert abs(page.rect.height - 3.65 * 72) < 0.01
page_preview = Image.new('RGB', (850, 1100), 'white')
with Image.open(OUT / 'timing_results_final_size.png') as im:
    page_preview.paste(im.convert('RGB'), (65, 185))
page_preview.save(OUT / 'timing_results_page_embed.png')
assert len(plot_values) == 12
assert all(v['time_ms'] == lookup[(v['scope'], v['workload'])][v['method']] for v in plot_values)
assert min(v['time_ms'] for v in plot_values) == 10
assert max(v['time_ms'] for v in plot_values) == 225
snapshot = {'input_path': str(INPUT), 'input_sha256': hashlib.sha256(raw).hexdigest(),
            'source_kind': 'synthetic', 'rows': records, 'plotted_values': plot_values,
            'transformations': 'None; categorical reordering small, medium, large only.',
            'axis': {'scale': 'linear', 'minimum_ms': 0, 'maximum_ms': 250, 'shared_across_scopes': True},
            'uncertainty': {'shown': False, 'reason': 'One replicate per condition; no uncertainty supplied.'},
            'dimensions_inches': [7.2, 3.65], 'png_dpi': 300, 'final_size_preview_dpi': 100,
            'versions': {'python': platform.python_version(), 'matplotlib': matplotlib.__version__, 'pymupdf': fitz.VersionBind}}
(OUT / 'numerical_audit.json').write_text(json.dumps(snapshot, indent=2))
hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.iterdir() if p.is_file() and p.name != 'output_hashes.json'}
(OUT / 'output_hashes.json').write_text(json.dumps(hashes, indent=2))
print(json.dumps({'status': 'rendered; awaiting actual visual review', 'input_sha256': snapshot['input_sha256'],
                  'rows': len(rows), 'plotted_values': len(plot_values), 'outputs': sorted(hashes)}, indent=2))

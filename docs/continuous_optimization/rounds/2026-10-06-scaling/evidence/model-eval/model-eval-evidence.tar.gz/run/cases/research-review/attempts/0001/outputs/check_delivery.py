from pathlib import Path
import csv
import hashlib
import json
import math

out = Path(__file__).resolve().parent
root = out.parents[4]
evidence = json.loads((out / 'evidence.json').read_text())
for rel, expected in evidence['input_sha256'].items():
    assert hashlib.sha256((root / rel).read_bytes()).hexdigest() == expected, rel

raw = list(csv.DictReader((root / 'cases/research-review/inputs/measurements.csv').open()))
assert len(raw) == len(evidence['observations']) == 6
for row, calc in zip(raw, evidence['observations']):
    b, c = float(row['baseline_ms']), float(row['candidate_ms'])
    assert math.isclose(calc['speedup_baseline_over_candidate'], b / c)
    assert math.isclose(calc['latency_delta_ms'], c - b)
    assert math.isclose(calc['relative_latency_change_percent'], 100 * (c - b) / b)
    assert calc['replicates'] == int(row['replicates']) == 1

findings = json.loads((out / 'findings.yaml').read_text())['findings']
tasks = json.loads((out / 'task_chain.yaml').read_text())['tasks']
by_id = {t['task_id']: t for t in tasks}
assert len(by_id) == len(tasks) == 15
finding_ids = {f['finding_id'] for f in findings}
assert len(finding_ids) == 5
visited, active = set(), set()
def visit(task_id):
    assert task_id not in active, 'cyclic dependency'
    if task_id in visited:
        return
    active.add(task_id)
    for dep in by_id[task_id]['depends_on']:
        assert dep in by_id, dep
        visit(dep)
    active.remove(task_id)
    visited.add(task_id)
for task in tasks:
    assert set(task['finding_ids']) <= finding_ids
    visit(task['task_id'])
for finding in findings:
    stages = [t['stage'] for t in tasks if finding['finding_id'] in t['finding_ids']]
    assert stages == ['verify', 'resolve', 'recheck']
assert next(f for f in findings if f['finding_id'] == 'REV-F005')['status'] == 'rejected'
assert '180 to 225' in (root / 'cases/research-review/inputs/manuscript.md').read_text()
assert not any(f['status'] == 'resolved' for f in findings)
receipt = {'status': 'passed', 'checks': ['input and selected-role hashes unchanged', 'six row arithmetic recomputed', '15 unique tasks with existing acyclic dependencies', 'five findings each have verify/resolve/recheck stages', 'Appendix A omission allegation rejected', 'no unperformed revisions marked resolved'], 'scope': 'local artifact consistency; not a real performance/quality experiment'}
(out / 'verification_receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))

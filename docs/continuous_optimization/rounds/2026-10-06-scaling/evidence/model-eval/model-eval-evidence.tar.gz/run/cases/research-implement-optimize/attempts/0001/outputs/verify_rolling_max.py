"""Independent deterministic boundary/random checks and baseline reproduction."""
import argparse
import hashlib
import importlib.util
import json
import math
import platform
import random
from pathlib import Path


def load_function(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.rolling_max


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def oracle(values, window):
    # Independent nested traversal: no slices, max(), or production call.
    result = []
    start = 0
    while start + window <= len(values):
        best = values[start]
        position = start + 1
        while position < start + window:
            if values[position] > best:
                best = values[position]
            position += 1
        result.append(best)
        start += 1
    return result


def assert_equal(actual, expected):
    assert len(actual) == len(expected), (actual, expected)
    for a, b in zip(actual, expected):
        if isinstance(b, float) and math.isnan(b):
            assert isinstance(a, float) and math.isnan(a), (actual, expected)
        else:
            assert a == b, (actual, expected)


def run(candidate_path, original_path):
    before = digest(original_path)
    candidate = load_function(candidate_path, "fixed_rolling_max")
    original = load_function(original_path, "original_rolling_max")
    repro = []
    for values, window in [([1, 3, 2], 2), ([9], 1), ([2, 7], 2)]:
        expected = oracle(values, window)
        actual = original(values, window)
        assert actual != expected, "regression fixture must fail original"
        assert_equal(candidate(values, window), expected)
        repro.append({"values": values, "window": window,
                      "original": actual, "expected": expected})

    boundary_count = 0
    cases = [([], 1), ([], 10), ([9], 1), ([9], 2),
             ([1, 3, 2], 1), ([1, 3, 2], 2), ([1, 3, 2], 3),
             ([1, 3, 2], 4), ([1, 3, 2], 10**30),
             ([-8, -2, -5, -1], 2), ([7, 7, 7, 7], 3),
             (list(range(9)), 4), (list(range(9, 0, -1)), 4),
             ((1, 5, 2), 2), ("cabd", 2),
             ([float("nan"), 2.0, 3.0], 2),
             ([2.0, float("nan"), 3.0], 2)]
    for values, window in cases:
        before_values = list(values)
        assert_equal(candidate(values, window), oracle(values, window))
        assert_equal(list(values), before_values)
        boundary_count += 1

    for invalid in [True, False, 1.0, 2.5, "2", None, [], {}, 1 + 0j]:
        for values in [[], [1, 2]]:
            try:
                candidate(values, invalid)
            except TypeError:
                pass
            else:
                raise AssertionError(("expected TypeError", invalid, values))
            boundary_count += 1
    for invalid in [0, -1, -10**30]:
        for values in [[], [1, 2]]:
            try:
                candidate(values, invalid)
            except ValueError:
                pass
            else:
                raise AssertionError(("expected ValueError", invalid, values))
            boundary_count += 1

    class PositiveInt(int):
        pass
    assert_equal(candidate([1, 3, 2], PositiveInt(2)), [3, 3])
    boundary_count += 1

    # Objects implement only >, and equal keys have distinct identities.
    class Item:
        def __init__(self, key):
            self.key = key
        def __gt__(self, other):
            return self.key > other.key
    objects = [Item(2), Item(2), Item(1)]
    actual = candidate(objects, 2)
    expected = oracle(objects, 2)
    assert all(a is b for a, b in zip(actual, expected))
    assert len(actual) == len(expected)
    boundary_count += 1

    seed = 20261006
    rng = random.Random(seed)
    randomized_count = 0
    for _ in range(1000):
        n = rng.randrange(101)
        values = [rng.randrange(-50, 51) for _ in range(n)]
        unchanged = values.copy()
        for window in sorted({1, max(1, n), n + 1, rng.randrange(1, n + 11)}):
            actual = candidate(values, window)
            assert_equal(actual, oracle(values, window))
            assert len(actual) == max(0, n - window + 1)
            assert values == unchanged
            randomized_count += 1
    after = digest(original_path)
    assert before == after, "original input changed"
    return {"status": "passed", "python": platform.python_version(),
            "platform": platform.platform(), "seed": seed,
            "boundary_checks": boundary_count,
            "randomized_checks": randomized_count,
            "baseline_reproductions": repro,
            "original_sha256_before": before,
            "original_sha256_after": after,
            "candidate_sha256": digest(candidate_path),
            "test_sha256": digest(__file__),
            "note": "Correctness checks; no performance benchmark or GPU execution."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate", default=str(Path(__file__).with_name("rolling_max.py")))
    parser.add_argument("--original", required=True)
    args = parser.parse_args()
    print(json.dumps(run(args.candidate, args.original), indent=2))

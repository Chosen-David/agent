# 核验 → 处理 → 复查任务链

本轮材料内核验已完成。处理和新稿复查均未执行；不得将todo写成已修复。YAML使用JSON兼容语法，可由YAML/JSON解析器读取。

| 发现 | 核验任务（本轮完成） | 处理任务 | 复查任务 | 下一负责人 |
| --- | --- | --- | --- | --- |
| REV-F001 confirmed | REV-T001 done | REV-T002 todo | REV-T003 todo | main_ai / author |
| REV-F002 confirmed | REV-T004 done | REV-T005 todo | REV-T006 todo | main_ai / author |
| REV-F003 confirmed | REV-T007 done | REV-T008 todo | REV-T009 todo | main_ai / author |
| REV-F004 confirmed | REV-T010 done | REV-T011 todo | REV-T012 todo | main_ai / author |
| REV-F005 rejected | REV-T013 done | REV-T014 skipped | REV-T015 done | 无修订；保留驳回记录 |

各处理任务依赖对应核验；各复查依赖对应处理。不同发现可独立推进，但作者若用一次范围澄清处理多个问题，仍须保留每个ID的验收。首先可执行REV-T002纠正摘要，REV-T005确认合成示例定位，REV-T008确定等价/近似约束，REV-T011说明计时范围。它们是交回主AI的建议，不代表本轮改稿授权。

新性能实验（只有作者保留真实系统收益主张时才需要）：先恢复已有日志；未恢复则冻结相同环境/工作负载、计时边界、warmup/同步、交错配对顺序、独立session层次。以独立pilot或可信历史方差选择目标CI精度与固定session数，在采集前确定实际意义阈值、完整比较族、异常值/失败处理及停止规则。排除计时漂移、冷启动/缓存差异和不匹配工作量等替代解释；成本依session数×单session时间计算，当前两项均未知，不能编造GPU预算或直接执行。单一工作负载的一次timer循环不能充当独立session。

新质量实验（仅近似剪枝且要保留有用优化主张时）：先冻结相同example的配对输出、数据与scorer版本、输入规模/seed层次、metric聚合、质量容忍界限；依据抽样层次选择配对或聚类分析。记录成本与固定停止规则，接受质量不达标或性能不改善的负结果；不跑到显著为止。严格等价路线可优先用可核验证明/不变量，不能把无准确率实验一律判失败。

未提供资源/协议/原始数据时，新实验支路blocked，恢复负责人为main_ai/author；范围澄清支路仍可推进。没有外部新颖性核验任务，因为本轮明确只做材料内审阅。

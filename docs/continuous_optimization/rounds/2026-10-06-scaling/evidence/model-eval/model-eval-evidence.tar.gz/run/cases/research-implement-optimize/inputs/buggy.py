def rolling_max(values, window):
    """Return maxima for all full windows. window must be positive int excluding bool."""
    return [max(values[i:i+window]) for i in range(len(values)-window)]

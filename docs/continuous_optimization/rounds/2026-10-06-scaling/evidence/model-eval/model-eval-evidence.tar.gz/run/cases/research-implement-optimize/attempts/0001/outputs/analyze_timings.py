"""Descriptive scope-aware arithmetic on supplied timing summaries."""
import argparse
import csv
import hashlib
import json
from pathlib import Path


def analyze(path):
    rows = []
    with open(path, newline="", encoding="utf-8") as stream:
        for record in csv.DictReader(stream):
            baseline = float(record["baseline_ms"])
            candidate = float(record["candidate_ms"])
            if baseline <= 0 or candidate <= 0:
                raise ValueError("positive timing summaries required")
            rows.append({**record, "baseline_ms": baseline,
                         "candidate_ms": candidate,
                         "replicates": int(record["replicates"]),
                         "speedup_baseline_over_candidate": baseline / candidate,
                         "latency_reduction_percent": 100 * (baseline - candidate) / baseline,
                         "delta_candidate_minus_baseline_ms": candidate - baseline})
    return {"source": str(Path(path).resolve()),
            "source_sha256": hashlib.sha256(Path(path).read_bytes()).hexdigest(),
            "evidence_type": "derived_from_supplied_summaries_not_new_measurements",
            "rows": rows,
            "limitations": ["One replicate per workload/scope; variability and confidence intervals unavailable.",
                            "Hardware, code versions, workload definitions and synchronization unspecified.",
                            "No linkage establishes these timings as measurements of rolling_max.py.",
                            "Kernel speedups do not establish end-to-end gains or GPU results."]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_path")
    args = parser.parse_args()
    print(json.dumps(analyze(args.csv_path), indent=2))

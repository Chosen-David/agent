# Why 8 becomes 11

The attention weights move toward the larger value, while the values stay fixed at **V=(2,14)** (physical page 1).

At physical page 3, §3 “Worked softmax example,” softmax normalizes exponentiated logits:

| Logits | Exponentials | Attention weights | Weighted output |
| --- | --- | --- | --- |
| (0,0) | (1,1) | (1/2,1/2) | (1/2)·2+(1/2)·14=8 |
| (0,log 3) | (1,3) | (1/4,3/4) | (1/4)·2+(3/4)·14=11 |

The change is **Δy=(-1/4)·2+(1/4)·14=3**. A quarter of the weight moves from value 2 to value 14.

**This does not establish universal RoPE amplification.** Page 3 labels that claim an “Incorrect draft claim.” Page 1 identifies the document as a synthetic teaching note rather than a published paper or experiment. The supplied note does not give a RoPE rotation, an error model, or a derivation linking RoPE errors to these logits; the calculation establishes only this chosen example.

Physical page 4 provides two limits: V=(8,8) gives y=8 with either probability vector, and adding the same constant to both logits leaves softmax unchanged. In the latter case, the factor exp(c) cancels in numerator and denominator.

For another explicit mathematical illustration, with V=(2,14) but logits (log 3,0), the weights become (3/4,1/4) and y=5. This is a derivation, not a reported experiment. For two fixed scalar values, Δy=(V₂−V₁)Δp₂, so the direction depends on which value receives more weight.

The original-page reader preserves physical page 3 beside this explanation. Context from physical pages 1 and 4 is included; page 2 is outside this question. Printed footer numbers match the physical page numbers. No whole-paper review or live chat backend is claimed.

Source identity: supplied `inputs/paper.pdf`, 4 physical pages; SHA-256 `3be305fd6724f111ec2a6763759fc80db1388bd06b92685938007fe54c33b294`. PDF metadata title is `untitled`, author is `anonymous`; the visible first-page heading is “Synthetic attention teaching note.” No external source or publication identity is inferred.

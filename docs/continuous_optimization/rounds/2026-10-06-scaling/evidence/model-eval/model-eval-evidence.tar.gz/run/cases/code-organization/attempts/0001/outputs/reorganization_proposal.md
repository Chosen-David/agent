# Reorganization proposal

Status: documentation delivered; source reorganization proposed only, not authorized or performed. Decision for this case: EXECUTE the requested read-only inventory and output documentation. Input paths remain fixed. The mapping was shown to the parent controller before these files were written.

## Goal and boundaries

Keep existing source/result links discoverable, preserve the historical CODEMAP row, protect active or unknown activity, and expose missing provenance. The supplied case is a synthetic fixture, not an experimentally verified project. No input moves, deletes, target execution, process checks or network operations are allowed. The controller owns root TASK.md updates; no root TASK.md was supplied and this role does not create one.

| Current item | Evidence | Proposal | Gate / next owner |
|---|---|---|---|
| experiments/sweep.py | One existing parser referenced by both JSONs; supports both modes and integer k | Keep the shared script and existing path; do not duplicate it into near/both scripts. Future configuration manifests may describe actual calls. | Implementation producer supplies real generation code/calls and versions; controller verifies task mapping. |
| results/near.json; results/both.json | Synthetic records declare different modes and k, with 12 and 15 ms respectively | Keep both exact paths. For future authorized runs use results/<task_id>/<run_id>/ plus a manifest identifying synthetic/raw/derived data. Current task/run IDs are unknown; do not retrofit invented IDs. | Producers supply source logs/configuration, code revision, environment and consumers; technical reviewer determines acceptance. |
| results/live.log | active_tasks.json declares running and protected; scope explicitly lacks process access | Preserve exact path; exclude from all relocation or archival. | Controller obtains real producer/readback and confirms quiescence before any separate future move proposal. Unknown status never implies stopped. |
| notes/orphan.txt | Explicitly unattributed; no other reference in supplied-scope rg scan | Keep in place and list as ownership backlog. Possible archive/<confirmed-date-or-run>/ only after attribution and reference review; do not assign a destination now. | Controller/source owner determines provenance and external consumers. Future move requires explicit scope, quiescence, rollback and reference repair. No automatic deletion. |
| experiments/legacy.py | Original CODEMAP says historical, missing now; absent from supplied inventory | Retain historical row. Ask source owner for immutable source/evidence if historical acceptance requires it. | Controller/source owner resolves missing baseline; do not recreate or claim it was executed. |
| active_tasks.json | Provided declaration protects live.log | Preserve declaration and path. Keep high-frequency future runtime evidence separate from stable task requirements. | Controller owns live status and task lifecycle; this documentation does not start a supervisor. |

## References and future handoff

Read-only `rg` across the entire supplied directory found the two script declarations in results, the historical path in CODEMAP, and live.log in the activity declaration. No supplied consumer code, paper, manifest or TASK.md exists. Absence of an in-scope reference does not establish lack of external consumers. No duplicate-content deletion or archival is proposed as an immediate action.

For new authorized outputs, the controller should assign one producer per exact path and supply project_root, stable task_refs, output_root, allowed_writes and consumers before generation. Producers return kind/status, data type and units, source/configuration/code version, actual hash and immutable run ID. Consumers must acknowledge the exact version; file existence alone does not pass technical acceptance. Suggested future reports follow reports/<task_id>/runs/<run_id>/ with a separate latest.json index, without relocating current files.

## Acceptance and remaining work

The documentation acceptance is bounded to all supplied files indexed, original historical row retained, known script declarations checked against parser text, protected path preserved, and unknowns explicit. README files each remain at most ten lines. Source hashes are snapshot evidence only. Technical acceptance, source generation, producer/consumer attribution, historical completeness, git rollback availability and process status remain unverified.

The main controller next resolves the missing TASK/task IDs, source owners, consumers and run evidence. Implementation/experiment owners must establish actual result generation before either synthetic record supports a measured claim. No target execution was performed and no migration was attempted; therefore executable relocation checks are inapplicable to this delivery. Cost/model-token usage is unknown.

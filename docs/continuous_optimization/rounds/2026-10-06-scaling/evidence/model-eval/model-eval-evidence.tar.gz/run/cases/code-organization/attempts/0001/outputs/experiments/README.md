# Experiments directory documentation
This README describes the supplied inputs/organization/experiments directory; no source is copied here.
Keep sweep.py as the shared --mode near/both, --k integer argument entry.
Its supplied code parses arguments only; result generation is not verified.
The historical legacy.py entry is missing and remains indexed rather than recreated.
New scripts require a stable task reference, one producer and explicit output paths.
See ../CODEMAP.md for source/result mapping and unresolved ownership.

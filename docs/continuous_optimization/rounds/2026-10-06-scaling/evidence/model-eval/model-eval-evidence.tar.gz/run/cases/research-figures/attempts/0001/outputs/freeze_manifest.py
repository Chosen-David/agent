"""Freeze final artifact hashes after the controller's render and actual image review."""
from pathlib import Path
import json,hashlib
out=Path(__file__).resolve().parent
manifest=json.loads((out/'manifest.json').read_text())
manifest['output_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file() and p.name!='manifest.json' and p.suffix!='.log'}
manifest['frozen_execution_log_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.glob('*.log')) if p.name!='freeze.log'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Final artifact and completed execution-log hashes frozen; manifest self-hash intentionally excluded.')

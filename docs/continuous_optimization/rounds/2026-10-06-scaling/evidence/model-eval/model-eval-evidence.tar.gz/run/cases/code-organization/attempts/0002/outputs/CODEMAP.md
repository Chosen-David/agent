# CODEMAP
| item | source |
|---|---|
| historical baseline | experiments/legacy.py (historical, missing now) |

## 本轮增量盘点（2026-10-06）

以上历史行原样保留，未重排。路径均相对于 `cases/code-organization/inputs/organization/`，不是本交付目录。仅静态读取，未运行脚本、移动或删除输入。根 TASK.md 未提供，真实 task_id 均 unknown；下表 item 是盘点标签，不是新建任务 ID。不存在可见 Git 元数据；未访问进程状态。正式科学验收未进行。

| item | 状态 / 数据类型 | 生产者 / 来源证据 | 脚本 / 数据 / 产物 | 消费者 / 引用 | 处理 / 下一责任人 |
|---|---|---|---|---|---|
| historical baseline 补注 | historical / missing | 历史 CODEMAP 行；生产者 unknown | `experiments/legacy.py` 实际缺失，不能计算哈希 | 原 CODEMAP 历史索引；其他消费者 unknown | 保留记录；主控制器确认是否需要恢复来源 |
| sweep parser | existing / 静态源码 | 文件内容只有 argparse 参数解析；执行者 unknown | `experiments/sweep.py` 接受 `--mode near/both` 与整数 `--k`；未见结果写入代码 | `results/near.json:2`、`results/both.json:2` 声明此脚本 | 保留原路径；生产者补真实调用/日志/环境证据 |
| near result | existing / synthetic（文件声明） | JSON 声明 sweep.py、mode=near、k=8；生成链未证明 | `results/near.json`；latency_ms=12（合成字段，不是实测结论） | 除本索引外，提供目录内未发现消费者；外部 unknown | 登记声明，主控制器索取真实来源；不重跑 |
| both result | existing / synthetic（文件声明） | JSON 声明 sweep.py、mode=both、k=16；生成链未证明 | `results/both.json`；latency_ms=15（合成字段，不是实测结论） | 除本索引外，提供目录内未发现消费者；外部 unknown | 单独登记；不同 mode/k，不能作为同条件性能比较 |
| protected live output | declared-running / 实际进程 unknown | `active_tasks.json` 的 declared_running 与 protected_paths；log 文本不证明进程存活 | `results/live.log`，内容 running-owned-pipeline；真实脚本、task/run unknown | `active_tasks.json:3,6`；其他消费者 unknown | 原位保护，生产者/主控制器确认作业状态；不得移走 |
| unattributed note | existing / unknown | 文件自述 Unattributed report；无任务、运行或数据来源 | `notes/orphan.txt` | 提供目录全文检索未发现链接；不证明外部无引用 | orphan/backlog，仅提案；主控制器取得归属与停用证据 |
| activity declaration | existing / 声明状态配置 | `active_tasks.json` 明示 No process status access; declared state only | `active_tasks.json` | 文件管理盘点使用；声明保护 live.log | 保留；主控制器负责状态核验，不修改声明 |
| historical index | existing / 索引 | 输入 `CODEMAP.md`，仅含历史 baseline 行 | 原索引及本增量副本 | 主控制器审阅；实际项目是否采纳尚未确定 | 本副本由 code-organization 唯一写入；主控制器串行采纳 |

## 原始文件 SHA-256

由主控制器只读哈希代理实际计算，7 个存在文件全部登记；不存在的 legacy.py 无哈希。哈希只绑定本次字节快照，不证明来源或运行状态。

| 路径 | SHA-256 |
|---|---|
| `CODEMAP.md` | `7041bda953c1d71c218d602341980e6a85a1fca7882962c2419e3082b4e3cf6f` |
| `active_tasks.json` | `fb79b7dd4e9e0a1dc0cffab9491a65a41cb20969c2805476f99794e43b4739af` |
| `experiments/sweep.py` | `6d450901126b5a0e56d9ae19bbd0a7a29f264c2ffa5acba9d66081923b7bbce3` |
| `notes/orphan.txt` | `312931e9c7c861d927c31be4da0f46cb02ab20c3828cf3756964cdd99afa6f84` |
| `results/both.json` | `5d0a41f5db8b35b0eddce5780a70efaeffe95eba8475bb5b4130c9b2452ea9b4` |
| `results/live.log` | `0937d08f54e653261262e49243a613b39e2ef3260551b2f6bd8f302f7dbbc6b4` |
| `results/near.json` | `5f022724219adabef75d40ebea599e5f6e3ea060aae27bd59535032af74b7b78` |

## 交付索引与缺口

本轮文档位于 `attempts/0002/outputs/`：`CODEMAP.md`（本文件）、`REORGANIZATION_PROPOSAL.md`、`README.md`、`experiments/README.md`、`results/README.md`、`notes/README.md`。均为实际交付文档，不代表输入目录已重组。唯一作者 code-organization；消费者主控制器。README 是目标目录说明草稿，不复制源码/结果。

存在脚本静态映射覆盖 1/1；这不证明它正在运行。声明活动输出映射 1/1，但生产脚本 unknown。全部 7 个现存输入登记，历史缺失脚本明确标缺失。缺口：根 TASK.md、实际任务 ID、两个 JSON 的生成日志/代码链、live 作业状态/生产者、孤儿归属、外部消费者、技术验收。主控制器负责取得证据及串行更新唯一 TASK；本轮不创建 TASK。整理删除项 0、输入移动项 0、目标执行项 0。

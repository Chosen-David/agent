#!/usr/bin/env python3
"""Reproducible, CPU-only analysis of supplied synthetic timings; no experiments."""
import csv
import hashlib
import json
import math
from pathlib import Path

ROOT = Path('/workspace/scratch/c12f3d9f92bd/scaling-role-controller/run')
INPUT = ROOT / 'cases/research-assistant/inputs'
OUTPUT = ROOT / 'cases/research-assistant/attempts/0001/outputs'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    assert OUTPUT.is_dir(), 'Authorized output directory must already exist'
    before = {p.name: digest(p) for p in INPUT.iterdir() if p.is_file()}
    project = json.loads((INPUT / 'project.json').read_text())
    with (INPUT / 'measurements.csv').open(newline='') as f:
        raw = list(csv.DictReader(f))
    assert len(raw) == 6
    seen = set()
    rows = []
    for item in raw:
        key = (item['workload'], item['scope'])
        assert key not in seen
        seen.add(key)
        baseline, candidate = float(item['baseline_ms']), float(item['candidate_ms'])
        replicates = int(item['replicates'])
        assert baseline > 0 and candidate > 0 and replicates == 1
        rows.append(dict(workload=key[0], scope=key[1], baseline_ms=baseline,
                         candidate_ms=candidate, replicates=replicates,
                         speedup_baseline_over_candidate=baseline/candidate,
                         candidate_runtime_change_pct=100*(candidate/baseline-1),
                         time_saved_ms=baseline-candidate))
    assert seen == {(w,s) for w in ('small','medium','large') for s in ('kernel','end_to_end')}
    with (OUTPUT / 'timing_analysis.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    dag = json.loads((OUTPUT / 'task_dag.json').read_text())
    nodes = {n['task_id']:n for n in dag['tasks']}
    assert len(nodes) == len(dag['tasks']), 'Duplicate task IDs'
    active, visited, order = set(), set(), []
    def visit(node):
        assert node in nodes, f'Missing dependency {node}'
        assert node not in active, f'Cycle at {node}'
        if node in visited:
            return
        active.add(node)
        for dep in nodes[node]['depends_on']:
            visit(dep)
        active.remove(node)
        visited.add(node)
        order.append(node)
    for node in nodes:
        visit(node)
    assert all(n['owner'] and n['acceptance'] and n['outputs'] for n in nodes.values())
    values = (2.0,14.0)
    def attention(logits, v=values):
        maximum = max(logits)
        exps = [math.exp(x-maximum) for x in logits]
        probs = [x/sum(exps) for x in exps]
        return probs, sum(p*x for p,x in zip(probs,v))
    p0, y0 = attention((0,0))
    p1, y1 = attention((0,math.log(3)))
    jacobian0 = [p*(v-y0) for p,v in zip(p0,values)]
    jacobian1 = [p*(v-y1) for p,v in zip(p1,values)]
    p_shift, y_shift = attention((7,7+math.log(3)))
    _, y_equal = attention((0,math.log(3)), (5,5))
    assert math.isclose(y0,8) and math.isclose(y1,11)
    assert all(math.isclose(a,b) for a,b in zip(jacobian0,(-3,3)))
    assert all(math.isclose(a,b) for a,b in zip(jacobian1,(-2.25,2.25)))
    assert math.isclose(y_shift,y1) and math.isclose(y_equal,5)
    after = {p.name: digest(p) for p in INPUT.iterdir() if p.is_file()}
    assert before == after, 'Inputs changed'
    result = {
        'run_id':'research-assistant-0001',
        'data_kind':'synthetic',
        'data_version':'v3 (project.json goal/change; CSV has no embedded version)',
        'inputs_sha256':before,
        'checks':{'rows':len(rows),'duplicate_keys':False,'positive_timings':True,
                  'replicates_each':1,'inputs_unchanged':True,'dag_acyclic':True,
                  'all_dependency_ids_exist':True},
        'topological_order':order,
        'timings':rows,
        'background_numeric_check':{'status':'source-level applicability check; not a recreation of background@v1',
                                    'p_original':p0,'output_original':y0,'p_perturbed':p1,
                                    'output_perturbed':y1,'fixed_V_jacobian_original':jacobian0,
                                    'fixed_V_jacobian_perturbed':jacobian1,
                                    'common_shift_output':y_shift,'equal_V_output':y_equal},
        'limitations':['one replicate per cell: no empirical variance, confidence interval, or significance',
                       'no v2 raw bytes or historical figure/background artifacts supplied',
                       'no hardware or execution provenance: no real-world performance claim',
                       'DAG check is structural and does not certify scientific acceptance or a live supervisor'],
        'model_tokens_cost':'unknown',
        'supervisor':'not started; no authorized persistent host backend in this task'
    }
    (OUTPUT / 'validation.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'status':'passed','rows':len(rows),'dag_nodes':len(nodes),
                      'outputs':['timing_analysis.csv','validation.json']}, ensure_ascii=False))

if __name__ == '__main__':
    main()

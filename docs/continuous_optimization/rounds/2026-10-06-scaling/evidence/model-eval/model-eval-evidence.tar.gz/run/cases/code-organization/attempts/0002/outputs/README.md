# 组织盘点交付
这是只读盘点产生的文档包，不是重组后的输入项目。
原始路径基准是 `cases/code-organization/inputs/organization/`。
[CODEMAP](CODEMAP.md) 保留历史索引，并登记全部输入与来源缺口。
[重组提案](REORGANIZATION_PROPOSAL.md) 说明保护路径、条件和可操作回滚。
子目录 README 是将来采纳的说明草稿，每份不超过 10 行。
文档唯一作者 code-organization；消费者与后续采纳责任人是主控制器。
本轮不移动、删除、执行输入，不创建另一份 TASK.md。

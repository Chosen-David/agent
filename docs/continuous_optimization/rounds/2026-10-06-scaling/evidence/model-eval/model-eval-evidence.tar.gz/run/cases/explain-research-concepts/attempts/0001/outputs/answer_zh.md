# EXPL-001：给定 logits 的变化如何影响输出

**短答案：权重从 (1/2,1/2) 变为 (1/4,3/4)，输出从 8 变为 11，增加 3。** 这说明此教学模型中的权重重分配改变了固定值的加权平均；它不能证明 RoPE 普遍放大扰动。

以下均由给定教学模型推导，不是论文实测。令 logits \(z\in\mathbb R^2\) 为无量纲量，\(p=\operatorname{softmax}(z)\)，固定标量值 \(V=(2,14)\)，输出 \(y=p^TV\in\mathbb R\)，其单位与 \(V\) 相同。

**精确计算。** 原始 \(z=(0,0)\) 时，

\[
p=(1/2,1/2),\qquad y=\tfrac12\cdot2+\tfrac12\cdot14=8.
\]

扰动后的向量记为 \(z'=(0,\ln3)\)，避免把它与第二个分量 \(z_2\) 混淆。因为 \(e^{\ln3}=3\)，

\[
p'=\frac{(1,3)}{1+3}=(1/4,3/4),\qquad
y'=\tfrac14\cdot2+\tfrac34\cdot14=11.
\]

因此 \(\Delta y=(p'_2-p_2)(14-2)=\tfrac14\cdot12=3\)。直觉上，是四分之一的权重从值 2 移到了值 14。

**固定 \(V\) 时的 Jacobian。** 保持 \(V\) 不变，仅改变 \(z\)。由 \(p_i=e^{z_i}/\sum_k e^{z_k}\)，

\[
\frac{\partial p_i}{\partial z_j}=p_i(\delta_{ij}-p_j),\quad
J_p=\operatorname{diag}(p)-pp^T,
\]

\[
\frac{\partial y}{\partial z_j}
=\sum_i V_i p_i(\delta_{ij}-p_j)
=p_j(V_j-y).
\]

此处 \(J_p\) 为 \(2\times2\) 矩阵，\(J_y=\partial y/\partial z\) 为 \(1\times2\) 行向量。两个位置分别为

\[
J_p(z)=\tfrac14\begin{pmatrix}1&-1\\-1&1\end{pmatrix},
\qquad J_y(z)=(-3,3),
\]

\[
J_p(z')=\tfrac3{16}\begin{pmatrix}1&-1\\-1&1\end{pmatrix},
\qquad J_y(z')=(-9/4,9/4).
\]

Jacobian 描述局部斜率，不能直接当作有限扰动的精确变化：初始点的一阶预测是 \(3\ln3\approx3.29584\)，实际变化是 3。进一步写成 \(d=z_2-z_1\)，则 \(y=2+12\sigma(d)\)，\(dy/dd=12\sigma(d)(1-\sigma(d))\le3\)。即便在本例中，局部敏感度也随 logits 改变。

**反例与边界。**

- 若固定 \(V=(7,7)\)，不论权重怎样变化，\(y=7(p_1+p_2)=7\)，输出变化和 Jacobian 都为零。
- 若两个 logits 同时加 \(c\)，指数中的公共因子 \(e^c\) 抵消，softmax 和输出均不变。例如 \((0,0)\to(\ln3,\ln3)\)，输出仍为 8；对应 \(J_y(1,1)^T=0\)。

本题只给出了 logits 的前后值，没有给出 RoPE 的旋转角、query/key 或它们到 logits 的映射。因此不能把该扰动归因为 RoPE，更不能推出任意位置、输入、值向量下都放大。若要谈“放大”，还需定义输入扰动、输出度量和比较基线；若 \(V\) 也变化，上述固定 \(V\) Jacobian 只是总变化的一部分。

CPU 验算已通过：步长 \(h=10^{-5}\) 的中心差分在两个点核对了上述 Jacobian，输出导数最大绝对误差约 \(2.48\times10^{-11}\)，softmax 导数最大绝对误差约 \(4.01\times10^{-12}\)；精确输出与两个反例也通过检查。数值检查支持算术与局部导数，不代替一般证明。

原材料锚点：`cases/explain-research-concepts/inputs/concept.txt` 的完整教学问题。可复核脚本与实际结果：`check_math.py`、`numeric_check.json`。没有外部文献主张，也未使用网络或 GPU。

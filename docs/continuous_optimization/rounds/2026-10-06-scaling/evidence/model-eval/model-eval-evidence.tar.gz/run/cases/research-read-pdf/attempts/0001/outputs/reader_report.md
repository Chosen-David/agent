# 最终 PDF 逐页读者报告

状态：complete_review（阅读覆盖完成；不表示所有建议已处置，也不是科学录用评定）。

目标读者：本领域研究生或相邻领域研究者。范围：最终 paper.pdf 的全部4个物理页，包括第4页附录。仅以最终PDF阅读，未访问生成脚本、源码或其它输入。

PDF SHA-256：`3be305fd6724f111ec2a6763759fc80db1388bd06b92685938007fe54c33b294`。渲染：PyMuPDF 1.26.6，180 dpi，全部4页由控制器代理实际执行；本角色使用 view_image 按1、2、3、4顺序分别打开整页，实际阅读率4/4（100%）。完整图片与校验和见 render_manifest.json；逐页读到的信息见 page_coverage.jsonl。

## 读者结论

这是明确限定的合成教学笔记，不是已发表论文或实验。版面文字清楚、页序连贯；未见乱码、黑块、遮挡、截断、未解析引用或缺图。全稿没有图表、算法框或参考文献页；行文数学例子已逐项登记和复算。大片留白不妨碍这份教学笔记的可读性，未作为缺陷。

第3页两组softmax及输出计算成立：等权输出8，(1/4,3/4)输出11，增量3由权重重新分配产生。第3页的“RoPE errors always amplify outputs”明确冠以Incorrect draft claim；不能把它当本稿有效结论。第4页的常量V反例与共同logit平移不变性反驳普遍放大。该笔记并未给出具体RoPE到logits扰动的机制，所以也不能从此例推出RoPE的普遍性质。

第2页Small 60→45 ms是25%延迟下降（速度比约1.33），Medium 100→100 ms持平，Large 180→225 ms是25%延迟上升（速度比0.80）。这组数值不支持所有规模都加速；页面也没有这样的断言。kernel timing与end-to-end被明确区分，不能混作同一指标。计算仅核对纸面数字，不验证真实实验或测量来源。

## 可定位建议

READ-F001（suggestion / optional_improvement，物理页2 Timing observations）：箭头两端的比较条件与Small/Medium/Large规模未定义。对独立讲义可补一行标签及计时范围；这属于可选表达改进，不是已确认科学或排版错误。详细证据、核验方式、最小修改和关闭条件见 findings.yaml。

## 逐页覆盖

| 物理页 | 印刷页标记 | 已打开/已读 | 新增信息 |
|---|---|---|---|
|1|Physical page 1|是/是|教学合成范围、固定V、普遍结论限制|
|2|Physical page 2|是/是|三种规模时序观察及kernel/end-to-end范围区别|
|3|Physical page 3|是/是|softmax数值与权重重分配解释、错误草稿断言|
|4|Physical page 4|是/是|附录常量V与共同logit平移反例，关闭普遍放大误读|

## 交接与限制

confirmed errors=0，resolved=0，rejected=0，blocked=0，remaining=1可选建议。核验→处理→复查任务READ-T001至T003均为todo，交主AI判断；未修改输入。没有未读页，没有需要额外源码才能完成的视觉检查。测量背景、真实实验、具体RoPE机制、外部文献不在此只读PDF任务证据范围内，未宣称验证。禁止联网下使用offline_fallback；角色实际版本由skill-sources.lock.json绑定，不宣称当前最佳工具。

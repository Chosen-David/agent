"""Bounded fixture checks; no network and no production/runtime claims."""
import json
from datetime import datetime
from decimal import Decimal
from pathlib import Path

root = Path(__file__).resolve().parent
p = json.loads((root / 'plans.json').read_text())
checks = []

def check(name, condition):
    checks.append({'check': name, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(name)

def clock(s):
    return datetime.fromisoformat(s)

for v in p['versions']:
    rev = v['revision']
    slots = v['itinerary']
    check(f'r{rev}: available bounds', slots[0]['start_local'] == '2026-10-07T10:30:00' and slots[-1]['end_local'] == '2026-10-07T18:00:00')
    check(f'r{rev}: contiguous positive nonoverlapping slots', all(clock(s['end_local']) > clock(s['start_local']) for s in slots) and all(a['end_local'] == b['start_local'] for a,b in zip(slots,slots[1:])))
    legs = [s for s in slots if s['kind'] == 'transfer']
    duration = 25 if rev == 1 else 40
    check(f'r{rev}: four matching transfer durations', len(legs) == 4 and all((clock(s['end_local']) - clock(s['start_local'])).total_seconds() == duration*60 for s in legs))
    check(f'r{rev}: all commutes linked', {s['commute_id'] for s in legs} == {c['commute_id'] for c in v['commutes']})
    entities = [s['candidate_id'] for s in slots if s['kind'] in ('activity','rest')]
    check(f'r{rev}: all must-do covered once', entities == ['L','H','P'])
    lunch = next(s for s in slots if s['candidate_id'] == 'L')
    check(f'r{rev}: lunch full duration and one window', (clock(lunch['end_local'])-clock(lunch['start_local'])).total_seconds() == 50*60 and clock(lunch['start_local']) >= clock('2026-10-07T11:00:00') and clock(lunch['end_local']) <= clock('2026-10-07T14:00:00'))
    check(f'r{rev}: order before last_order', lunch['start_local'] == v['order_at_local'] and clock(v['order_at_local']) <= clock('2026-10-07T13:00:00'))
    rest = next(s for s in slots if s['kind'] == 'rest')
    check(f'r{rev}: independent 80 minute room rest', rest['candidate_id'] == 'H' and (clock(rest['end_local'])-clock(rest['start_local'])).total_seconds() == 80*60 and p['source_fixture']['rest']['room_available'])
    photo = next(s for s in slots if s['candidate_id'] == 'P')
    check(f'r{rev}: unchanged confirmed appointment', photo['start_local'] == '2026-10-07T15:30:00' and photo['end_local'] == '2026-10-07T16:30:00' and p['source_fixture']['photo']['confirmed_by_user'])
    check(f'r{rev}: commute location chain', [(c['origin']['entity_id'],c['destination']['entity_id']) for c in v['commutes']] == [('H','L'),('L','H'),('H','P'),('P','H')])
    budget = v['budget']
    for item in budget['items']:
        check(f'r{rev}: unit arithmetic {item["id"]}', Decimal(str(item['min']))*item['quantity'] == Decimal(str(item['total_min'])) and Decimal(str(item['max']))*item['quantity'] == Decimal(str(item['total_max'])))
    for bound in ['min','max']:
        subtotal = sum(Decimal(str(i[f'total_{bound}'])) for i in budget['items'])
        contingency = subtotal * Decimal('0.10')
        check(f'r{rev}: {bound} subtotal', subtotal == Decimal(str(budget['subtotal'][bound])))
        check(f'r{rev}: {bound} contingency', contingency == Decimal(str(budget['contingency'][bound])))
        check(f'r{rev}: {bound} known item total', subtotal+contingency == Decimal(str(budget['known_items_with_contingency'][bound])))
    check(f'r{rev}: unknown currency and all-in costs not zero', budget['currency'] is None and budget['all_in_total'] is None and 'u-room-cost' in budget['excluded_unknown_items'])
    v['gate']['fixture_schedule'] = 'passed'

check('revision1 retained and revision2 current', len(p['versions']) == 2 and p['current_revision'] == 2 and p['versions'][0]['validity'] == 'historical' and p['versions'][1]['validity'] == 'current')
check('amendment only changes travel time; budget reviewed', p['versions'][0]['budget'] == p['versions'][1]['budget'])
p['verification'] = {'status':'passed_fixture_only','script':'verify.py','check_count':len(checks),'limits':['Synthetic schedule and arithmetic only','No live navigation, business, currency, budget cap or weather verification','Destination timezone missing; canonical offset-bearing timestamps unavailable']}
(root/'plans.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
(root/'verification.json').write_text(json.dumps({'status':'passed_fixture_only','checks':checks,'limits':p['verification']['limits']},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'passed_fixture_only','checks':len(checks),'outputs':str(root)},ensure_ascii=False))

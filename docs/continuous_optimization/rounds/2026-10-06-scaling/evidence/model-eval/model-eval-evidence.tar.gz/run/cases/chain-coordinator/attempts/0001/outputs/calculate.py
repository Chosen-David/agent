#!/usr/bin/env python3
"""Reproduce the v3 synthetic latency handoff; no external dependencies."""
import argparse
import csv
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path
from statistics import median


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--outputs', type=Path, required=True)
    args = parser.parse_args()
    source_paths = [args.inputs / name for name in
                    ('chain_project.json', 'chain_latencies.csv', 'handoff_fields.json')]
    initial_hashes = {str(path.resolve()): sha256(path) for path in source_paths}
    project = json.loads(source_paths[0].read_text())
    contract = json.loads(source_paths[2].read_text())
    samples = defaultdict(lambda: defaultdict(list))
    with source_paths[1].open(newline='') as handle:
        reader = csv.DictReader(handle)
        assert reader.fieldnames == ['workload', 'version', 'latency_ms']
        for row in reader:
            assert row['version'] in ('baseline', 'candidate')
            value = float(row['latency_ms'])
            assert math.isfinite(value) and value > 0
            samples[row['workload']][row['version']].append(value)
    aggregates = []
    for workload, versions in samples.items():
        assert set(versions) == {'baseline', 'candidate'}
        base, candidate = median(versions['baseline']), median(versions['candidate'])
        aggregates.append({
            'workload': workload,
            'n_baseline': len(versions['baseline']),
            'n_candidate': len(versions['candidate']),
            'baseline_median_ms': base,
            'candidate_median_ms': candidate,
            'speedup_ratio': base / candidate,
            'latency_reduction_pct': 100 * (base - candidate) / base,
        })
    assert aggregates, 'No measurements'
    args.outputs.mkdir(parents=True, exist_ok=True)
    aggregate_path = args.outputs / 'aggregate.csv'
    with aggregate_path.open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=contract['aggregate_csv_columns'])
        writer.writeheader()
        writer.writerows(aggregates)
    findings = []
    for index, row in enumerate(aggregates, start=2):
        reduction = row['latency_reduction_pct']
        status = 'lower' if reduction > 0 else 'higher' if reduction < 0 else 'unchanged'
        findings.append({
            'finding_id': 'RES-v3-' + row['workload'],
            'workload': row['workload'],
            'aggregate_csv_row': index,
            'evidence_file': str(aggregate_path.resolve()),
            'evidence_kind': 'descriptive computation from supplied synthetic samples',
            'baseline_median_ms': row['baseline_median_ms'],
            'candidate_median_ms': row['candidate_median_ms'],
            'speedup_ratio': row['speedup_ratio'],
            'latency_reduction_pct': reduction,
            'conclusion': (
                f"In these supplied synthetic samples, candidate median latency is {status} "
                f"for {row['workload']}: {row['baseline_median_ms']:g} ms baseline versus "
                f"{row['candidate_median_ms']:g} ms candidate; ratio "
                f"{row['speedup_ratio']:.6g}, reduction {reduction:.6g}%."
            ),
        })
    analysis = {
        'schema_version': contract['schema_version'],
        'project_id': project['project_id'],
        'input_version': project['input_version'],
        'source_files': [{'path': str(path.resolve()), 'sha256': initial_hashes[str(path.resolve())]}
                         for path in source_paths],
        'aggregate_file': {'path': str(aggregate_path.resolve()), 'sha256': sha256(aggregate_path)},
        'findings': findings,
        'limitations': [
            'All observations are explicitly synthetic; these are descriptive calculations, not real hardware or production benchmark measurements.',
            'There are three supplied samples per version per workload. No uncertainty interval or significance test was performed; no statistical or population-level superiority claim is supported.',
            'No hardware, runtime configuration, implementation, measurement protocol, sample pairing, or randomization metadata is supplied. Causal explanation and fair real-system performance claims cannot be established.',
            'No accuracy, quality, throughput, tail latency, resource usage, or new experiment is measured. No conclusion about those metrics is supported.',
            'Results differ by workload; a universal candidate improvement is contradicted by medium parity and large regression. No workload weights justify a pooled overall benefit.',
            'Retention of raw-v2 and background follows chain_project.json. Their actual historical artifacts were not supplied or independently revalidated for v3 numeric reuse.',
        ],
        'invalidated_work': project['invalidated_work'],
        'retained_work': project['retained_work'],
        'work_disposition': {
            'changed_from': project['changed_from'],
            'invalidated_reason': 'figure-v2 and write-v2 are downstream interpretations tied to v2; they must be regenerated or revised against the v3 aggregate rather than reused as current conclusions.',
            'retained_reason': 'Keep raw-v2 as an immutable historical record and background as reusable contextual material per the project directive; neither supplies current v3 measurements without a separate applicability check.',
            'history_preserved': True,
        },
        'metric_definitions': {
            'median': 'Per workload and version, median of the supplied latency_ms values; for even sample counts use the arithmetic mean of the two central values.',
            'latency_unit': 'ms',
            'speedup_ratio': contract['formulas']['speedup_ratio'],
            'latency_reduction_pct': contract['formulas']['latency_reduction_pct'],
            'negative_reduction': 'Candidate is slower; -25% reduction means a 25% latency increase.',
        },
        'decision': {
            'state': 'EXECUTE',
            'authorization_scope': 'Analyze supplied synthetic data and hand off; no writing, network, GPU, or new measurements.',
            'paused_scope': 'Dependent writer work until actual files are copied and their hashes verified.',
        },
        'next_owner': 'writer',
        'handoff': {
            'rule': contract['handoff_rule'],
            'input_version': project['input_version'],
            'allowed_claim': 'Candidate has lower median latency for small, equal median latency for medium, and higher median latency for large in the supplied synthetic samples.',
            'writer_gate': 'Host must copy actual analysis.json and aggregate.csv unchanged. Writer must verify the aggregate SHA256 against analysis.json; the host must independently verify unchanged analysis.json. Missing files or hash mismatch block writing.',
            'remaining_work': 'Write a bounded interpretation using only this verified v3 handoff. The coordinator has not produced the writer deliverable.',
        },
        'execution': {
            'method': 'Python standard library statistics.median on CPU; script calculate.py',
            'execution_mode': 'Controller executes this script through its observable tool proxy; this node does not claim direct execution.',
            'synthetic': True,
            'new_experiments': False,
            'model_tokens_cost': 'unknown',
        },
    }
    assert set(contract['analysis_json_required']).issubset(analysis)
    assert isinstance(analysis['schema_version'], int)
    for key in ('project_id', 'input_version'):
        assert isinstance(analysis[key], str)
    for key in ('source_files', 'findings', 'limitations', 'invalidated_work', 'retained_work'):
        assert isinstance(analysis[key], list)
    analysis_path = args.outputs / 'analysis.json'
    analysis_path.write_text(json.dumps(analysis, ensure_ascii=False, indent=2) + '\n')
    # Validate persisted outputs rather than only their in-memory producer values.
    persisted = json.loads(analysis_path.read_text())
    with aggregate_path.open(newline='') as handle:
        reader = csv.DictReader(handle)
        assert reader.fieldnames == contract['aggregate_csv_columns']
        reread = list(reader)
    assert len(reread) == len(aggregates)
    for saved, expected in zip(reread, aggregates):
        assert saved['workload'] == expected['workload']
        for name in contract['aggregate_csv_columns'][1:]:
            assert float(saved[name]) == expected[name]
    assert sha256(aggregate_path) == persisted['aggregate_file']['sha256']
    assert all(sha256(path) == initial_hashes[str(path.resolve())] for path in source_paths)
    print(json.dumps({
        'status': 'passed', 'rows': aggregates,
        'input_hashes': initial_hashes,
        'aggregate_sha256': sha256(aggregate_path),
        'analysis_sha256': sha256(analysis_path),
        'checks': ['positive finite latencies', 'paired version presence', 'required schema fields and basic types',
                   'exact CSV columns', 'persisted numeric roundtrip', 'aggregate hash matches analysis', 'inputs unchanged'],
    }, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()

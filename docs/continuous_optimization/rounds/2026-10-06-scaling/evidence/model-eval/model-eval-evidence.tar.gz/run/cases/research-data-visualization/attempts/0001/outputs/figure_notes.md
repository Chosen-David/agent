# Timing results — design and provenance

Decision: EXECUTE within the supplied local-data task. Input is `measurements.csv`, six supplied **synthetic** rows. No measurement was run and no statistical analysis, aggregation, normalization, exclusions, error bars, or significance tests were added. All conditions report one replicate. Cost/model metadata are unknown.

## Data visual design brief

Reader question: how do baseline and candidate timings compare across small, medium, and large workloads, and does that comparison differ between kernel and end-to-end timing? This is a descriptive comparison, not evidence of statistical superiority or a measured system performance claim.

- Comparison/chart: paired horizontal bars expose all twelve timings. Two panels separate the scopes, keeping the scope explicit rather than merging incompatible timing ranges.
- Axes/baselines: both panels use the same linear 0–250 ms scale with zero-based bar lengths. Workload ordering is small, medium, large. No categorical interpolation.
- Uncertainty: none is supplied; one replicate per condition cannot support an invented interval or distribution.
- Encoding/accessibility: stable gray baseline and teal candidate; candidate hatch plus fixed within-workload order supplies redundant identification. Exact values retain small or equal differences honestly.
- Palette/legend: one shared legend, baseline then candidate. Equal visual weight; neither method receives an attention color intended to imply a winner.
- Typography: DejaVu Sans, 8–10 pt at native 7.2 × 3.65 in, editable SVG text and embedded PDF TrueType fonts. English only; no Chinese figure variant was requested.
- Layout/density: aligned panels, light x-axis grids, outside legend, reserved footer. Value labels use milliseconds and integer precision from input.
- Panels: kernel at left, end-to-end at right; shared scale prevents apparent improvement caused by different ranges. End-to-end equality at medium and candidate slowdown at large remain visible.

No published/local exemplar figure was supplied, and network access is excluded. Therefore actual exemplar reading and exemplar-derived aesthetic claims are unverified. This independent plot uses a task-specific design brief and local Matplotlib rendering; no external theme, code, or palette-audit service was installed.

## Caption

**Synthetic timing comparison by workload and timing scope.** Baseline and candidate times (ms) are shown for small, medium, and large workloads, separately for kernel (a) and end-to-end (b) timing. Bars start at zero and both panels share the same scale; labels give every supplied value. Each condition has one replicate. No uncertainty estimates or statistical tests were provided or added. These supplied synthetic values illustrate scope-dependent comparisons and do not establish real measured performance or statistical superiority.

## Reproduction

Run `python plot_results.py /absolute/path/to/inputs/measurements.csv` from this outputs directory. Requires existing Python, Matplotlib, Pillow and PyMuPDF. The script resolves its output directory from its own path. Source, CSV snapshot, full plotting values, input SHA-256, exports, font inventory, runtime versions and output hashes are preserved together. No network, GPU or new measurement is required.

Deliverables: editable `plot_results.py` and `timing_results.svg`; 300 DPI PNG and vector PDF; separate PDF raster; grayscale, native-size and page-embed previews; `numerical_audit.json`, `pdf_fonts.json`, and `output_hashes.json`. The supplied CSV is copied byte-for-byte as `measurements_snapshot.csv`.

## QA — completed rendering and controller image review

- Scientific/numerical: **pass**. Exact source command executed through controller CPU proxy with exit 0 (`render.log`). All checks passed: six complete conditions, one replicate, twelve faithfully mapped timings, full scope/workload coverage, 10 ms minimum and 225 ms maximum. `numerical_audit.json` retains every plotting value and the input SHA-256 `c470d3b8248787cac887e8b3b6a935ecedbb0e26be28b1cf0230c0cd974525b5`.
- Semantic: two distinct timing scopes; no invented statistics. Synthetic status is explicit in caption and footer.
- Visual: **pass by actual controller image review**, not an unobserved author claim. Controller opened `timing_results_final_size.png`, `timing_results_grayscale.png`, `timing_results_pdf_render.png` and `timing_results_page_embed.png`; reported all twelve labels present, the exact 0–250 ms axes, clear scope separation, distinguishable grayscale hatch, and no overlap or clipping. Synthetic/one-replicate/no-uncertainty disclosure is visible. Review dimensions are native 7.2 × 3.65 in, 100 DPI preview and an 8.5 × 11 in page embed at 100 DPI.
- Technical: **pass for these exports**. SVG/300 DPI PNG/PDF were actually produced. Runtime checked PDF dimensions; font report lists DejaVu Sans regular and bold TrueType subsets. The PDF's separate raster was opened by the controller and no glyph problem was reported. No Chinese export or color-vision simulation was produced or claimed.
- Reproducibility: **pass**. Supplied command executed with exit 0, source/data/audit/log available together. Script versions recorded in audit.
- Submission: unverified. Dimensions are provisional, not tied to any venue requirement.
- Independent aesthetics review: controller actual visual review is available; no external scholarly review or blinded aesthetics comparison was performed. No A/B improvement claim is made.

No before image exists because this is a new plot, not a polish task. If visual QA requires repair, preserve first-render source, figures and log before changing the source.

Status: **ready-for-review** for this local synthetic-data plotting task. The absence of published exemplars, submission specifications and new statistical evidence remains explicit; none is required to display the supplied data honestly. No visual repair was requested after the first render.

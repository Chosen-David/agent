# Notes directory documentation
This README describes inputs/organization/notes; no note is relocated here.
orphan.txt is explicitly unattributed; its run, task, producer and consumers are unknown.
Keep its current path pending source-owner and reference review.
No automatic archival, deletion or inferred experiment attribution is allowed.
See ../reorganization_proposal.md for proposal-only backlog and next owner.

# Actual validator invocation

Execution kind: authorized validator only, through `/root/role_pipeline` observable tool proxy. The selector itself was not executed or imported.

Working directory:

```text
/workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/code-reading/attempts/0001/outputs
```

Exact command supplied to and executed by the controller:

```bash
python /workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/snapshot/scripts/validate_handoff.py /workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/code-reading/inputs/handoff.json --root /workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/code-reading/inputs --require-complete --request /workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/code-reading/inputs/consumer_request.json > /workspace/scratch/c12f3d9f92bd/scaling-role-controller/run/cases/code-reading/attempts/0001/outputs/validator-result.json
```

Controller returned actual exit code **0**. `validator-result.json` was saved directly by the invocation and subsequently read by this agent; it is not reconstructed from an expectation. Result:

```json
{
  "integrity_valid": true,
  "errors": [],
  "completion_verified": true,
  "consumer_version_checked": true,
  "consumer_scope_verified": true,
  "scope": "local integrity and explicit consumer contract only; no semantic or visual certification"
}
```

No `--expected-input-version` was supplied: the independently supplied consumer request provides the expected version through V 83–89. No receipt, consumer request, source, or evidence bytes were altered. The receipt's `completed` status and pass labels are producer claims checked for contract consistency, not independently demonstrated semantic outcomes. The receipt's local evidence hash was checked by the actual invocation, but evidence content was not semantically certified.

Environment boundaries: local CPU validator, no network or GPUs. Exact Python/interpreter version, hardware, elapsed runtime, peak memory, exact model identity, token usage, and cost were not measured and are **unknown**. This execution is not a performance experiment.

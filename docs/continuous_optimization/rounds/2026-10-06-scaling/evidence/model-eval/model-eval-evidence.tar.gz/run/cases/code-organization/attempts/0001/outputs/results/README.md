# Results directory documentation
This README describes inputs/organization/results; original files remain there.
near.json and both.json contain synthetic latency_ms values, not verified measurements.
Both declare sweep.py as source; generation code/logs and run IDs are unavailable.
Their mode and k differ; these records do not establish a controlled improvement.
live.log is declared running and protected in active_tasks.json; preserve its exact path.
Future results may use <task_id>/<run_id>/ only after IDs and writers are assigned.
See ../CODEMAP.md for data, sources and unknown consumers.

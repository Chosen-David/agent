# results
对应原项目结果目录；本交付目录只放说明草稿。
`near.json` 与 `both.json` 均自述 synthetic，不当作实测性能证据。
mode/k 不同；真实生成链与消费者待核实。
`live.log` 被 active_tasks.json 声明 running/protected，必须原位保护。
未访问进程状态；未被声明活动的文件也不能推定已停用。
未来新结果沿用准确配置/运行标识，生产者单一，保留来源与失败记录。
来源、配置和哈希见 [CODEMAP](../CODEMAP.md)。

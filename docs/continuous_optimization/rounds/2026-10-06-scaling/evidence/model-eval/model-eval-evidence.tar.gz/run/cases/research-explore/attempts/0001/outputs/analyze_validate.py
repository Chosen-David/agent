#!/usr/bin/env python3
"""Offline arithmetic and structural verification; no new benchmark execution."""
import csv
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
INPUTS = HERE.parents[2] / 'inputs'

def main():
    rows = list(csv.DictReader((INPUTS / 'measurements.csv').open()))
    by_workload = {}
    derived = []
    for row in rows:
        b, c = float(row['baseline_ms']), float(row['candidate_ms'])
        assert b > 0 and c > 0
        item = dict(row, baseline_ms=b, candidate_ms=c,
                    speedup=b/c, latency_change_pct=100*(c/b-1))
        derived.append(item)
        by_workload.setdefault(row['workload'], {})[row['scope']] = item
    residuals = []
    for workload, pair in by_workload.items():
        k, e = pair['kernel'], pair['end_to_end']
        baseline_residual = e['baseline_ms'] - k['baseline_ms']
        candidate_residual = e['candidate_ms'] - k['candidate_ms']
        residuals.append(dict(workload=workload,
            baseline_residual_ms=baseline_residual,
            candidate_residual_ms=candidate_residual,
            residual_change_ms=candidate_residual-baseline_residual,
            ideal_e2e_if_residual_unchanged_ms=e['baseline_ms']-(k['baseline_ms']-k['candidate_ms']),
            zero_kernel_lower_bound_ms=baseline_residual,
            zero_kernel_speedup_upper_bound=e['baseline_ms']/baseline_residual))
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
              for p in (INPUTS/'manuscript.md', INPUTS/'measurements.csv')}
    result = dict(source_sha256=hashes, observations=derived,
                  conditional_additive_accounting=residuals,
                  caveats=['synthetic observations', 'one replicate per row',
                           'no uncertainty or accuracy estimate',
                           'residual subtraction assumes comparable additive timing scopes'])
    (HERE/'analysis.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    # The task chain uses JSON syntax, which is valid YAML 1.2.
    chain = json.loads((HERE/'task_chain.yaml').read_text())
    tasks = chain['tasks']; ids = {t['task_id'] for t in tasks}
    assert len(ids) == len(tasks), 'duplicate task ID'
    required = {'task_id','stage','depends_on','owner','inputs','action','outputs',
                'done_when','on_failure','resource_budget','status'}
    for task in tasks:
        assert required <= task.keys(), f'missing fields: {task["task_id"]}'
        assert set(task['depends_on']) <= ids, 'missing dependency'
        assert task['status'] in {'todo','doing','done','blocked','skipped'}
    remaining = {t['task_id']: set(t['depends_on']) for t in tasks}; order=[]
    while remaining:
        ready = sorted(k for k, deps in remaining.items() if not deps)
        assert ready, 'dependency cycle'
        order.extend(ready)
        for k in ready: del remaining[k]
        for deps in remaining.values(): deps.difference_update(ready)
    report = dict(arithmetic='pass', input_rows=len(rows), task_fields='pass',
                  dependencies='pass', acyclic='pass', topological_order=order,
                  scientific_validation='not performed; this is arithmetic and structure only')
    (HERE/'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(report, ensure_ascii=False))

if __name__ == '__main__': main()

# 范围、工具与贡献评价记录

状态：EXECUTE，完成用户授权的本地材料审阅。方法未改变；输出只写入本次指定目录。研究-review 的完整入口和相关执行、工作流、测量规范已读取，文件哈希见 evidence.json。采用当前提供的本地 skill 快照及标准库 CSV/哈希/算术核验，属于 offline_fallback；未安装、更新或检索其他工具，不能声称它是当前最佳。宿主模型版本和成本未知。

## Paper map / provisional rubric

Abstract L1–2：收益主张；Method L3–4：剪枝和未改变的编排/I/O；Results L5–6：证据限制；Appendix A L7–8：负结果披露。全部文字及CSV全部六行已检查。不存在给定图表、公式、算法代码、真实日志或PDF。没有套用未知venue的数值尺度。

本轮问题是系统优化主张的计时范围、证据强度及质量可比性。稿内只提供一条机制描述；其必要性、实现可行性和工程成本不能由表格认定。输入提供的baseline是唯一可比较路线，不代表强库或当前最佳方法。

## 来源登记 / search log

| 来源 | 本轮使用与覆盖 | 证据类型 |
| --- | --- | --- |
| manuscript.md | 全文8行，包括Appendix A | 提供的稿件主张/限制 |
| measurements.csv | 表头及六行；逐行复算 | 提供的合成观测 |
| evidence.json | 本轮复算、条件性残差、输入和规范哈希 | 派生算术证据，非新计时 |
| snapshot研究-review规范 | SKILL.md、execution、workflow相关章节、measurement contract | 本轮角色工作规则，非科学结果 |

review_date=2026-10-06；submission_cutoff、首次公开及稿件版本日期=unknown。search_cutoff=not_applicable（本轮禁止联网，无外部检索）；外部检索次数=0。没有引用未经核实的论文，也没有判断历史或当前新颖性。

## 逐贡献 novelty / utility matrix（材料内）

| 主张 | 新颖性/最近工作 | 可行性与必要性 | 可比性 | 可证增量价值与代价 | 状态与下一步 |
| --- | --- | --- | --- | --- | --- |
| C1 普遍端到端3× | 未评估，禁止外部检索 | 提供记录不能支持此收益；不能否定所有可能实现 | 无配置/质量信息；仅可在合成表内比较 | small 1.33×，medium 1×，large 0.8×；工程成本未知 | confirmed numerical contradiction；纠正范围并按REV-F001复查 |
| C2 剪枝改变kernel，编排/I/O不变 | 未评估，缺机制细节和文献 | 无代码、证明、trace，未验证；无组件移除实验，必要性未知 | 等价/近似与计时关系未知 | 合成kernel 3×/2×/2×；语义与成本未知 | insufficient_evidence；先质量约束与计时边界，再决定是否需要新实验 |

不能从当前表认定原方法在所有必要维度被替代路线支配。针对现有baseline的具体负结果已保留；没有伪造“最强外部方案”或新颖性否定。

下一负责人：main_ai/author 选择已授权范围内的主张澄清或准备真实补证；research-review 使用相同REV-ID复查实际新版。审阅建议不自动授权改稿、新实验、GPU或外发。

#!/usr/bin/env python3
"""Offline CPU-only build. SVG retains editable text and stable node/edge IDs."""
from pathlib import Path
import argparse, hashlib, json, platform, xml.etree.ElementTree as ET
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.path import Path as MPath

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
SOURCE = ROOT / 'inputs' / 'architecture.json'
# HERE = case/attempts/0001/outputs; source is case/inputs.
SOURCE = HERE.parents[2] / 'inputs' / 'architecture.json'

def build():
    spec = json.loads(SOURCE.read_text())
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'svg.fonttype': 'none'})
    fig, ax = plt.subplots(figsize=(7.2, 3.6), dpi=300)
    fig.subplots_adjust(left=0, right=1, top=1, bottom=0)
    ax.set(xlim=(0,12), ylim=(0,6)); ax.axis('off')
    bg='#ffffff'; ink='#173347'; line='#425a6b'
    fig.patch.set_facecolor(bg)
    ax.text(.48, 5.47, spec['title'], fontsize=13.3, color=ink, weight='bold', va='center')
    ax.text(.48, 5.01, 'PROPOSED  /  Synthetic specification · unimplemented', fontsize=8.3,
            color='#687680', va='center')
    centers={'a':(1.65,3.55),'b':(1.65,1.95),'sum':(4.4,2.75),
             'softmax':(7.3,2.75),'v':(10.3,4.15),'output':(10.3,2.75)}
    palettes={'a':('#e8f3f5','#4b858b'),'b':('#e8f3f5','#4b858b'),
              'sum':('#edf1f8','#657f9e'),'softmax':('#edf1f8','#657f9e'),
              'v':('#fbf3df','#b99852'),'output':('#e9f3ed','#5b8c71')}
    routes={('a','sum'):[(2.8,3.55),(3.02,3.55),(3.02,3.02),(3.25,3.02)],
            ('b','sum'):[(2.8,1.95),(3.02,1.95),(3.02,2.48),(3.25,2.48)],
            ('sum','softmax'):[(5.55,2.75),(6.15,2.75)],
            ('softmax','output'):[(8.45,2.75),(9.15,2.75)],
            ('v','output'):[(10.3,3.725),(10.3,3.175)]}
    for source,target in spec['edges']:
        points=routes[(source,target)]
        path=MPath(points,[MPath.MOVETO]+[MPath.LINETO]*(len(points)-1))
        edge=FancyArrowPatch(path=path, arrowstyle='-|>', mutation_scale=9,
                             linewidth=1.15, color=line, capstyle='round',
                             joinstyle='round', zorder=1)
        edge.set_gid(f'edge-{source}-{target}'); ax.add_patch(edge)
    for node in spec['nodes']:
        nid=node['id']; x,y=centers[nid]; fill,stroke=palettes[nid]
        box=FancyBboxPatch((x-1.15,y-.425),2.3,.85,
                          boxstyle='round,pad=0,rounding_size=0.11',
                          facecolor=fill,edgecolor=stroke,linewidth=1.05,zorder=2)
        box.set_gid(f'node-{nid}'); ax.add_patch(box)
        label=node['label']
        text=ax.text(x,y,label,fontsize=10.2,va='center',ha='center',color=ink,zorder=3)
        text.set_gid(f'label-{nid}')
    ax.plot([.48,11.52],[1.05,1.05],color='#dce3e7',linewidth=.65)
    ax.text(.48,.65,'Arrows: specified directed dependencies',fontsize=7.8,color=line,va='center')
    ax.text(11.52,.65,'Schematic · no performance evidence',fontsize=7.8,color='#687680',
            va='center',ha='right')
    fig.savefig(HERE/'architecture.svg',metadata={'Title':spec['title'],
                 'Description':'Proposed synthetic specification; unimplemented. Exactly six nodes and five edges.'})
    fig.savefig(HERE/'architecture.png',dpi=300,facecolor=bg)
    fig.savefig(HERE/'architecture.pdf',metadata={'Title':spec['title']})
    plt.close(fig)
    contract={'figure_id':'FIG-research-diagrams-0001','status':spec['status'],
      'evidence_type':spec['evidence_type'],'source':str(SOURCE),
      'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
      'nodes':[dict(n,svg_node_id='node-'+n['id'],svg_label_id='label-'+n['id'],
                    source_ref=f'architecture.json#/nodes/{i}') for i,n in enumerate(spec['nodes'])],
      'edges':[{'id':f'edge-{s}-{t}','source':s,'target':t,'direction':'source_to_target',
                'kind':'specified directed dependency','label':None,
                'source_ref':f'architecture.json#/edges/{i}'} for i,(s,t) in enumerate(spec['edges'])],
      'groups':[], 'constraints':spec['constraints'],
      'invariants':['Exactly six input nodes and five input edges.','V bypasses softmax.',
        'No near-to-far edge; no feedback.','All input labels preserved verbatim.'],
      'unknowns':['Tensor dimensions','Softmax axis','Cost','Model execution or implementation',
                  'Accuracy and speedup','Venue submission specification']}
    (HERE/'semantic_contract.json').write_text(json.dumps(contract,indent=2)+'\n')
    svg=ET.parse(HERE/'architecture.svg')
    ids=[e.get('id') for e in svg.iter() if e.get('id')]
    assert len(ids)==len(set(ids)), 'Duplicate SVG IDs'
    assert sorted(i for i in ids if i.startswith('node-'))==sorted('node-'+n['id'] for n in spec['nodes'])
    assert sorted(i for i in ids if i.startswith('edge-'))==sorted('edge-'+s+'-'+t for s,t in spec['edges'])
    for n in spec['nodes']:
        element=next(e for e in svg.iter() if e.get('id')=='label-'+n['id'])
        assert n['label'] in ''.join(element.itertext())
    assert not any(e.tag.endswith('image') for e in svg.iter()), 'Unexpected raster/external asset'
    record={'status':'pass','checks':['XML parse','unique SVG IDs','six exact nodes',
      'five exact directed edges','verbatim input labels','no raster image assets'],
      'source_sha256':contract['source_sha256'],'python':platform.python_version(),
      'matplotlib':matplotlib.__version__,'cpu_only':True,'network':False,
      'png_pixels':[2160,1080],'physical_inches':[7.2,3.6],'dpi':300,
      'semantic_check_limit':'Checks source and rendered SVG object membership; visual endpoints require actual view.'}
    (HERE/'build_checks.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))

if __name__=='__main__':
    build()

# 重组提案 v1

status=awaiting_alignment（仅将来输入重组）；本轮授权文档已完成。

目标：保持来源可追踪、活跃路径安全、历史索引连续。边界：本轮只读原始合成目录，映射已先向父控制器展示；只在 `attempts/0002/outputs/` 写文档。不得执行目标脚本、移动或删除输入。主控制器是 TASK 唯一作者，未提供 TASK 不补造任务 ID。

## 证据与 A/B 取舍

A（推荐当前方案）：保留现有 experiments/results/notes 布局，仅采纳增量索引与必要说明。成本是归属未知仍在 backlog；收益是无需变更消费者接口，保护 live.log 和历史路径。B（未授权实施）：证据齐全后将确认停用且确无必要引用的孤儿归档，其他目录保持。B 能减少散落文档，但路径变化、外部引用与并发写入仍有风险；未测收益，不认为 B 优于 A。

依据为实际读取 7 个文件与全文 `rg` 检索、主控制器实际 SHA-256 回执。确切源哈希见 CODEMAP。全文检索范围仅提供目录，发现两份 JSON 声明引用 sweep.py，active_tasks.json 两处引用 live.log，以及历史 missing legacy.py 索引。未发现 orphan 消费者；这不是全局无引用证明。未访问进程状态或 Git 远端，目录无可见 Git 元数据。源码只有参数解析，不能把 JSON 中 script 字段当作已验证生成链。

| 来源路径 | 本轮操作 | 条件性未来目的路径 | 阻塞 / 接口影响 |
|---|---|---|---|
| `experiments/sweep.py` | 原位登记 | 不变 | 保留 near/both 参数接口；真实生成代码待补 |
| `results/near.json`、`results/both.json` | 原位登记 | 不变 | synthetic；禁止伪造归属、比较或数据转移 |
| `results/live.log` | 原位保护 | 不变，禁止规划归档 | 声明 running/protected；实际状态 unknown |
| `notes/orphan.txt` | 原位保留，backlog | `archive/unattributed/orphan.txt`（仅候选） | 需确认停用、归属/保留策略及所有消费者；任何未知仍阻塞移动 |
| `active_tasks.json` | 读取不改 | 不变 | 状态声明非进程观测 |
| `CODEMAP.md` | 输出增量副本 | 原位由主控制器采纳 | 历史行顺序不变；引用版本/哈希绑定 |
| missing `experiments/legacy.py` | 保留历史缺失行 | 无 | 不恢复猜测代码，不删除历史行 |

候选 archive 目录本轮不创建。不存在删除方案。新产物预先用现有目录，单一作者与消费者在主控制器清单登记；future results 可按 task/run 子目录保存，但不把旧产物自动搬进去。

## 来源与状态缺口交接

主控制器向生产者索取 JSON 的真实生成实现、调用、日志、环境与运行 ID；没有证据前保留“声明来源未验证”。两个 latency_ms 字段是合成数值，k/mode 不同，不支持性能优劣结论。live 作业由主控制器取得真实拥有者、停用/完成证据；未确认前继续保护。orphan 归属、外部消费者和写入状态由主控制器核对。主控制器决定历史 baseline 是否恢复及根 TASK 所在项目；不让文件管理角色虚构任务真相。

## 本轮文档的撤回方法

本轮没有修改输入，所以撤回无需对输入反向移动。主控制器暂不采纳这份 outputs 索引，继续使用输入原 `CODEMAP.md`（SHA-256 `7041bda953c1d71c218d602341980e6a85a1fca7882962c2419e3082b4e3cf6f`）；保留本交付包作审计快照即可。若将来采纳文档，应先按下述方法备份原索引及实际被改 README，记录采纳后的哈希；需要撤回时恢复备份，不从本提案猜原内容。

## 将来单组归档的具体可回滚操作规程（本轮未执行）

以下以将来已授权的 `notes/orphan.txt → archive/unattributed/orphan.txt` 为唯一示例，所有命令均从实际原项目根执行。本轮不运行。没有 Git 时也不能只说“用 Git 回滚”。实施负责人主控制器；每组开始前建立独立备份与 manifest，未备份或未核对即不得开始。

1. 前置门禁：获得针对该源/目的路径的移动授权，确认无运行或未知状态写入者，完成代码/文档/任务/manifest/论文及外部消费者核查。再次读取活动声明；受保护路径始终排除。源必须是预期普通文件，目的路径不得已存在，任何源哈希变化重新核对。TASK 修改仅主控制器串行操作。
2. 创建不重复的回滚目录，例如 `.agent-runs/organization-rollback/approved-001/`，独占本次文件。备份所有将修改的引用文件（至少 CODEMAP，若将修改 TASK/README/manifest 也逐项加入），原样保留相对路径。以下固定路径仅用于该一组：

```bash
mkdir -p .agent-runs/organization-rollback/approved-001/files/notes
cp -a -- notes/orphan.txt .agent-runs/organization-rollback/approved-001/files/notes/orphan.txt
cp -a -- CODEMAP.md .agent-runs/organization-rollback/approved-001/files/CODEMAP.md
sha256sum notes/orphan.txt CODEMAP.md .agent-runs/organization-rollback/approved-001/files/notes/orphan.txt .agent-runs/organization-rollback/approved-001/files/CODEMAP.md
```

先保证 approved-001 是本次新建、空且无人使用的目录，不能复用覆盖旧备份。源与备份哈希必须逐项相等，否则中止。manifest 保存 `group_id`、授权证据、源/目的/备份精确路径、每份修改文件 pre_sha256、预计消费者、protected_paths、状态 prepared；当前已知 orphan 哈希为 `312931e9c7c861d927c31be4da0f46cb02ab20c3828cf3756964cdd99afa6f84`，将来必须重新测，不能盲用旧值。
3. 源/备份相等且目的不存在时，创建目的目录，按单组移动，然后修复经授权的消费者和索引；每份改动记录 post_sha256，manifest 追加 moved/reference-updated 状态，不能覆盖 preimage。

```bash
mkdir -p archive/unattributed
test ! -e archive/unattributed/orphan.txt && cmp -s notes/orphan.txt .agent-runs/organization-rollback/approved-001/files/notes/orphan.txt && mv -n -- notes/orphan.txt archive/unattributed/orphan.txt
```

`mv -n` 只防覆盖；必须确认源已不存在、目的存在且哈希等于备份才记录成功。路径并发修改、命令失败或引用检查失败，立即停止该组并进行下述回滚，不继续其他依赖迁移。任何消费者未知就不进入本步骤。
4. 回滚单组：先停止本组新写入并核对 manifest。若原路径不存在且归档文件字节等于备份，逆向移动，无须删除：

```bash
test ! -e notes/orphan.txt && cmp -s archive/unattributed/orphan.txt .agent-runs/organization-rollback/approved-001/files/notes/orphan.txt && mv -n -- archive/unattributed/orphan.txt notes/orphan.txt
```

若归档目的意外缺失但源也缺失，确认备份完整并获恢复授权后用 `cp -an -- .agent-runs/organization-rollback/approved-001/files/notes/orphan.txt notes/orphan.txt` 恢复，再核对实际存在与哈希；不得把命令退出零当恢复成功。若源已存在且等于备份，保留原位并核对；若任一文件内容与 manifest 冲突，禁止覆盖，保留两份交主控制器处理。未知或新增内容不能自动删除。
5. 恢复引用文件前，逐份确认当前 SHA-256 等于 manifest 记载的 post_sha256（没有后续他人修改），再从对应 preimage 复制恢复，例如 `cp -a -- .agent-runs/organization-rollback/approved-001/files/CODEMAP.md CODEMAP.md`；被改 TASK/README/manifest 同理逐份恢复，主控制器唯一写入 TASK。当前字节不同则停止，不覆盖并发变更，主控制器人工合并。未修改的文件不触碰。
6. 回滚验收：源及所有恢复引用的 SHA-256 与 pre_sha256 逐项相等；归档目的已不再占用该文件（冲突副本则明确 pending，不谎报完成）；`rg` 核对消费者重新指向原路径；历史行内容/顺序与备份一致；active_tasks.json 和 live.log 保持原位未变。manifest 追加 rolled_back、时间、检查结果和剩余冲突，备份永久保留到主控制器验收。空目录可保留，本规程不自动删除。

因此回滚材料包括文件 preimage、正反向路径、引用 pre/post 哈希和执行状态，而非只有“可回滚”标签。上述方案未执行、未测试，授权本轮明确禁止目标运行；将来必须在另行许可的隔离目录演练并进行授权范围内的消费者验证，才可称移动验收通过。

## 当前验收与下一步

当前验收限于文档组织：7/7 存在输入已登记，missing legacy 明示，历史行保留，保护 live 路径不变，孤儿仅提案，README 各≤10行。不存在脚本执行与科学正确性验收。本轮目录变更/删除为零，未启动监督器。主控制器复核文档后串行采纳；重组范围继续 awaiting_alignment，待决定的一件事是是否在补齐停用/消费者/备份证据后授权孤儿单组归档。任何拒绝或未知均保留 A。

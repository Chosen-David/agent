# Candidates under the unchanged interface

| Candidate | Contract | Time | Auxiliary space excluding output | Evidence and decision |
| --- | --- | --- | --- | --- |
| Original input | Fails final full window and explicit validation | O(nw) | O(w) | Preserve as failing reproduction; not a valid performance baseline |
| Corrected slicing + built-in max | Keeps original sequence/comparison semantics, validates window | O(nw), more exactly O((n-w+1)w) | O(w) | Selected minimal dependency-free repair; actual proxy execution passed 43 boundary and 3,897 random checks |
| Monotonic deque | Strong algorithmic baseline for ordered numeric values; arbitrary comparison/NaN behavior needs contract work | O(n) amortized | O(w) | Not implemented or measured; no numeric-total-order restriction was given |
| Specialized array library | Dtype, padding, NaN and alignment semantics must be matched | Library-dependent | Library-dependent | No dependency justification or matched interface evidence; not explored |
| GPU path | Requires explicit backend, data transfer and timing contract | Unmeasured | Unmeasured | Forbidden by task boundary; no device probe or fabricated results |

Pattern: sliding-window maximum. A deque retains only undominated candidate indices,
expiring indices outside the window; each index is inserted/removed at most once.
This explains its O(n) amortized bound under appropriate comparison semantics,
not a wall-clock speedup for the delivered implementation. No library, current
state-of-the-art, ISA, PTX or globally fastest claim is made. The strongest
applicable functional baseline here is an independent per-window exhaustive scan;
the erroneous original cannot supply a fair timing comparison.

# Abstract
Our proposed optimization gives a universally threefold end-to-end speedup.
# Method
Candidate pruning changes the kernel, while orchestration and I/O remain unchanged.
# Results
Only synthetic timing observations supplied in measurements.csv are available; one run, no accuracy evaluation.
# Appendix A
Large end-to-end latency rises from 180 to 225 ms. This regression is disclosed, not omitted.

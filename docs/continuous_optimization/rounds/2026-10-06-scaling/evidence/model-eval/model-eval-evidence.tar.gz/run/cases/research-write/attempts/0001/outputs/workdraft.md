# 通用工作稿

本稿仅依据所给合成计时记录，不代表真实部署评测或完整论文。以下加速比定义为基线延迟除以候选延迟；延迟变化以基线为分母，负值表示降低，正值表示增加。每个条件均仅有一次观测（replicates = 1）。

## 中文结果段落

在所给合成计时记录中，候选剪枝优化在三个工作负载上均降低了内核延迟：small 从 30 ms 降至 10 ms，medium 从 60 ms 降至 30 ms，large 从 120 ms 降至 60 ms，对应内核加速比分别为 3.00×、2.00× 和 2.00×。端到端收益则随工作负载而变化：small 从 60 ms 降至 45 ms，延迟降低 25%，对应约 1.33× 加速；medium 的基线和候选延迟均为 100 ms，在本次观测中没有变化；large 从 180 ms 升至 225 ms，延迟增加 25%，端到端加速比为 0.80×，表现为退化。因此，现有记录不支持原稿中“普遍获得三倍端到端加速”的主张，内核加速也不能直接用作端到端收益的证据。方法描述指出剪枝改变了内核，而编排与 I/O 保持不变，但这些计时记录无法确定端到端退化的具体原因。所有数据均为合成记录，且每个条件只有一次观测；无法据此估计测量波动、判断统计显著性，或将 medium 的单次相同延迟解释为性能等效。此外，尚无准确性评估，因而无法确认剪枝是否保持输出质量或正确性，也无法评估相应的性能与质量取舍。

## English abstract

We examine a candidate-pruning optimization using supplied synthetic timing observations for small, medium, and large workloads. The method description states that pruning changes the kernel while orchestration and I/O remain unchanged. Observed kernel latency decreases from 30 to 10 ms, 60 to 30 ms, and 120 to 60 ms, respectively, corresponding to speedups of 3.00×, 2.00×, and 2.00×. End-to-end behavior varies by workload: latency decreases from 60 to 45 ms for small (25% lower latency; approximately 1.33× speedup), remains at 100 ms for medium, and increases from 180 to 225 ms for large (25% higher latency; 0.80× speedup). These observations do not support a universal threefold end-to-end speedup, and they do not establish the cause of the large-workload regression. Each condition has only one observation, precluding an estimate of timing variability or a claim of statistical significance or performance equivalence. No accuracy evaluation is available, so preservation of output quality or correctness remains unverified. The results are limited to the supplied synthetic observations and do not establish performance on real deployments.

## 主张证据表

CSV 行号包含表头；“主张”均限于当前提供的合成记录。原始值是输入事实，比值及百分比是算术推导，不是新增实验。

| 主张 ID | 主张及状态 | 证据位置 | 计算口径或限定 |
| --- | --- | --- | --- |
| WRITE-C001 | 剪枝改变内核，编排与 I/O 保持不变；仅由方法文字支持 | manuscript.md，Method，行 4 | 属于提供的方法描述；未检查实现，也不由该描述推出退化原因 |
| WRITE-C002 | small 内核 30→10 ms，3.00×；观测支持 | measurements.csv，行 2（small, kernel） | 30/10；单次合成观测 |
| WRITE-C003 | medium、large 内核分别 60→30、120→60 ms，均 2.00×；观测支持 | measurements.csv，行 4、6 | 60/30、120/60；单次合成观测 |
| WRITE-C004 | small 端到端 60→45 ms，延迟降低 25%，约 1.33×；观测支持 | measurements.csv，行 3 | (45−60)/60 = −25%；60/45 ≈ 1.33 |
| WRITE-C005 | medium 端到端均为 100 ms；观测支持，等效性未证实 | measurements.csv，行 5 | 加速比 1.00×，观测变化 0%；不作统计等效结论 |
| WRITE-C006 | large 端到端 180→225 ms，延迟增加 25%，0.80×；观测支持 | measurements.csv，行 7；manuscript.md，Appendix A，行 8 | (225−180)/180 = +25%；180/225 = 0.80；正文及摘要均保留该退化 |
| WRITE-C007 | “普遍三倍端到端加速”不受支持 | manuscript.md，Abstract，行 2；反证为 measurements.csv 行 3、5、7 | 三个端到端加速比分别约 1.33×、1.00×、0.80×；已删除原强主张 |
| WRITE-C008 | 无法估计波动、判断显著性或认定 medium 性能等效 | measurements.csv，全体 replicates 列；manuscript.md，Results，行 6 | 每条件仅一次观测；无重复测量或不确定性数据 |
| WRITE-C009 | 准确性、质量与正确性保持情况未验证 | manuscript.md，Results，行 6 | 输入明确无准确性评估；不声称质量保持或已有性能质量取舍结果 |
| WRITE-C010 | 真实部署表现及 large 退化机制未建立 | manuscript.md，Results，行 6；measurements.csv，全表 | 仅合成计时；无部署数据或机制诊断证据 |

## 证据缺口

计时波动与统计推断、准确性与正确性、真实部署表现、large 端到端退化原因均未验证。本次仅记录这些缺口，没有增加实验、文献或机制结论。

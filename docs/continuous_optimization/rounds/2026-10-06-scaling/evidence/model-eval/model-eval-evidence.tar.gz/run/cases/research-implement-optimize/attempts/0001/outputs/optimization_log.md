# Repair log

CODE-O001: inclusive window-count repair plus explicit contract validation.

- Input: frozen `inputs/buggy.py`; original never overwritten.
- Root cause: exclusive stop omitted start n−w, and window validation was absent.
- Hypothesis: adding the final start and validation yields exactly max(0,n−w+1)
  complete-window results while preserving built-in max semantics.
- Invariants: signature, output order/list type, original input, slicing/max
  comparison behavior, empty output for oversize valid windows.
- Planned acceptance: original-failing regression fixtures; independent boundary
  and seeded randomized oracle; original before/after hashes equal.
- Performance acceptance: none claimed; supplied CSV analysis is separate evidence.
- Decision: retain correctness repair. Actual parent-proxy exit 0 confirmed
  43 boundary checks, 3,897 randomized checks and three failing-original fixtures.
  Original before/after hashes match. No rerun or extra iteration was needed.
- No additional iteration, numeric semantics change, GPU test, profiler or timing
  experiment was run. No claim compares this script's latency with the supplied CSV.

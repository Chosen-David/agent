"""Complete-window rolling maxima without external dependencies."""


def rolling_max(values, window):
    """Return built-in max for each full window, in input order.

    ``values`` must support len() and slicing, as in the original interface.
    ``window`` must be a positive int; bool is explicitly excluded.
    A window larger than the input returns an empty list. The input is not
    modified. Value comparison and tie behavior follow Python's built-in max.

    Time is O((n-window+1)*window) when window <= n; peak auxiliary
    space is O(window), excluding the O(n-window+1) result.
    """
    if isinstance(window, bool) or not isinstance(window, int):
        raise TypeError("window must be a positive integer excluding bool")
    if window <= 0:
        raise ValueError("window must be positive")
    return [max(values[i:i + window])
            for i in range(len(values) - window + 1)]

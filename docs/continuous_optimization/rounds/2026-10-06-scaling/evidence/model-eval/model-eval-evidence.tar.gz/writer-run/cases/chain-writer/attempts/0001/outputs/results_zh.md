# 结果工作稿（合成数据，v3）

在所提供的合成数据中，small、medium 和 large 三种工作负载在 baseline 与 candidate 下各有 3 个样本。以各组时延中位数为比较口径，small 的 baseline 为 42 ms，candidate 为 30 ms；baseline/candidate 比值为 1.40，时延降低 28.57%。medium 的两者中位数均为 80 ms，比值为 1.00，时延降低 0%。large 的 baseline 为 120 ms，candidate 为 150 ms；比值为 0.80，时延降低率为 −25%，即 candidate 时延增加 25%。时延降低率按 100 × (baseline − candidate) / baseline 计算。

这些描述性结果随工作负载而异：candidate 在 small 上的中位时延较低，在 medium 上相同，在 large 上较高，因此不支持各工作负载均获益的表述。输入未提供支持总体汇总收益的工作负载权重，也未报告不确定性区间或显著性检验；中位数相同不代表统计等效。上述结果仅适用于当前合成样本，不构成真实硬件或生产环境性能、因果机制、吞吐量、尾时延、资源消耗或质量的证据。

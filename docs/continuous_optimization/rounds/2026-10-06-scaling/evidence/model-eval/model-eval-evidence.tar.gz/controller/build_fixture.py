import json,pathlib,shutil,hashlib
from reportlab.pdfgen.canvas import Canvas
b=pathlib.Path(__file__).parent; f=b/'fixtures'; repo=pathlib.Path('/workspace/scratch/c12f3d9f92bd/agent')
def put(n,s):
 p=f/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def js(n,o):put(n,json.dumps(o,ensure_ascii=False,indent=2)+'\n')
put('measurements.csv','workload,scope,baseline_ms,candidate_ms,replicates\nsmall,kernel,30,10,1\nsmall,end_to_end,60,45,1\nmedium,kernel,60,30,1\nmedium,end_to_end,100,100,1\nlarge,kernel,120,60,1\nlarge,end_to_end,180,225,1\n')
put('manuscript.md','# Abstract\nOur proposed optimization gives a universally threefold end-to-end speedup.\n# Method\nCandidate pruning changes the kernel, while orchestration and I/O remain unchanged.\n# Results\nOnly synthetic timing observations supplied in measurements.csv are available; one run, no accuracy evaluation.\n# Appendix A\nLarge end-to-end latency rises from 180 to 225 ms. This regression is disclosed, not omitted.\n')
js('project.json',{'goal':'Analyze updated v3 synthetic timings and plan figure+writing','budget':'CPU only; no new service/GPU','state':[{'task_id':'collect','status':'done','inputs':['measurements.csv@v2'],'outputs':['measurements.csv@v2']},{'task_id':'figure','status':'done','depends_on':['collect'],'outputs':['figure@v2']},{'task_id':'write','status':'todo','depends_on':['figure']},{'task_id':'background','status':'done','inputs':['concept.txt@v1'],'outputs':['background@v1']}],'change':'v3 replaces v2 interpretation; previous claimed universal speedup is false; preserve raw v2 bytes, refresh dependent figure/write, background unchanged'})
put('buggy.py','''def rolling_max(values, window):
    """Return maxima for all full windows. window must be positive int excluding bool."""
    return [max(values[i:i+window]) for i in range(len(values)-window)]
''')
put('concept.txt','Synthetic teaching model: logits z=(0,0), fixed values V=(2,14). After perturbation z2=(0,log(3)), explain exact softmax/output, fixed-V Jacobian, and why this is not universal RoPE amplification evidence. Include a counterexample (V equal or additive common logit shift). CPU numeric check allowed; no literature needed.\n')
a={'status':'proposed','evidence_type':'synthetic specification; unimplemented','title':'Two candidates and fixed-value aggregation','nodes':[{'id':'a','label':'Near logits a'},{'id':'b','label':'Far logits b'},{'id':'sum','label':'z = a + b'},{'id':'softmax','label':'p = softmax(z)'},{'id':'v','label':'Fixed V'},{'id':'output','label':'y = p^T V'}],'edges':[['a','sum'],['b','sum'],['sum','softmax'],['softmax','output'],['v','output']],'constraints':['V bypasses softmax','No near-to-far edge or feedback','No measured accuracy or speedup specified']};js('architecture.json',a)
js('travel.json',{'fixture':'synthetic supplied facts only','date':'2026-10-07','people':2,'available':['10:30','18:00'],'hotel':'H, 10 Sample Road','lunch':{'name':'L','address':'20 Sample Road','service_windows':[['11:00','14:00']],'last_order':'13:00','duration_minutes':50,'price':[90,110],'unit':'per_person'},'photo':{'name':'P','address':'30 Sample Road','appointment':['15:30','16:30'],'confirmed_by_user':True,'price':[360,360],'unit':'per_group'},'commute':{'each_leg_minutes':25,'each_leg_price':[18,28],'unit':'per_vehicle','vehicles':1},'rest':{'place':'H','minutes':80,'room_available':True},'must_do':['lunch','photo','rest'],'amendment':'After first plan, each commute increases from25 to40 minutes; preserve confirmed photo and independent rest; no bookings'})
c=Canvas(str(f/'paper.pdf'),pagesize=(600,780))
for i,(title,lines) in enumerate([
 ('Synthetic attention teaching note',['Not a published paper or experiment. Fixed values V=(2,14).','Examples cannot establish a universal architectural conclusion.']),
 ('Timing observations',['Small: end-to-end 60 ->45ms. Medium: 100 ->100ms.','Large: 180 ->225ms. Kernel timing is a different scope.']),
 ('Worked softmax example',['z=(0,0): p=(1/2,1/2), y=8.','z2=(0,log(3)): p=(1/4,3/4), y=11.','Thus +3 arises from redistributed weight, not changed V.','Incorrect draft claim: RoPE errors always amplify outputs.']),
 ('Appendix / counterexamples',['V=(8,8): either probability vector yields y=8.','Adding (c,c) to logits leaves softmax unchanged.','One synthetic case is insufficient to show universal amplification.'])]):
 c.setFont('Helvetica',17);c.drawString(40,725,f'{i+1}. {title}');c.setFont('Helvetica',12)
 for j,l in enumerate(lines):c.drawString(40,675-j*30,l)
 c.drawString(40,40,f'Physical page {i+1}');c.showPage()
c.save()
put('synthetic_selector.py','''"""Claim: every layer can skip all attention and the index is query-trained."""
def project(k, dims=(1,3)):
    return [k[i] for i in dims]
def score(q,k):
    return sum(a*b for a,b in zip(q,k))
def run(q,keys,near_ids,skip_far=False,forced_ids=()):
    # skip_far changes candidate range; it does not skip near scoring.
    candidates=list(near_ids) if skip_far else list(range(len(keys)))
    ranked=sorted(candidates,key=lambda i:score(project(q),project(keys[i])),reverse=True)[:2]
    chosen=sorted(set(ranked)|set(forced_ids))
    return [(i,score(q,keys[i])) for i in chosen]
''')
put('organization/experiments/sweep.py','import argparse\np=argparse.ArgumentParser();p.add_argument("--mode",choices=["near","both"]);p.add_argument("--k",type=int);p.parse_args()\n')
js('organization/results/near.json',{'script':'experiments/sweep.py','args':{'mode':'near','k':8},'data_kind':'synthetic','latency_ms':12})
js('organization/results/both.json',{'script':'experiments/sweep.py','args':{'mode':'both','k':16},'data_kind':'synthetic','latency_ms':15})
put('organization/notes/orphan.txt','Unattributed report; do not infer which run produced it.\n')
put('organization/CODEMAP.md','# CODEMAP\n| item | source |\n|---|---|\n| historical baseline | experiments/legacy.py (historical, missing now) |\n')
js('organization/active_tasks.json',{'declared_running':['results/live.log'],'protected_paths':['results/live.log'],'scope':'No process status access; declared state only'})
put('organization/results/live.log','running-owned-pipeline\n')
js('chain_project.json',{'project_id':'latency-v3','input_version':'v3','changed_from':'v2','invalidated_work':['figure-v2','write-v2'],'retained_work':['raw-v2','background'],'scope':'synthetic medians, no accuracy/new experiment'})
put('chain_latencies.csv','workload,version,latency_ms\nsmall,baseline,40\nsmall,baseline,42\nsmall,baseline,44\nsmall,candidate,28\nsmall,candidate,30\nsmall,candidate,32\nmedium,baseline,78\nmedium,baseline,80\nmedium,baseline,82\nmedium,candidate,78\nmedium,candidate,80\nmedium,candidate,82\nlarge,baseline,118\nlarge,baseline,120\nlarge,baseline,122\nlarge,candidate,148\nlarge,candidate,150\nlarge,candidate,152\n')
shutil.copyfile(repo/'evals/pipeline_smoke/fixtures/handoff_fields.json',f/'handoff_fields.json')
roles=json.loads((repo/'config/role_registry.json').read_text())['roles'];base=json.loads((repo/'evals/tasks.json').read_text());rub=json.loads((repo/'evals/rubric.json').read_text())
for x in base['cases']:
 if x['id']=='research-implement-optimize':x['prompt']='Fix rolling_max in buggy.py retaining interface: all complete windows, positive integer window excluding bool, oversize returns empty. Deliver corrected reusable script and independent randomized+boundary oracle checks actually run; preserve input. Analyze supplied timing scope without inventing GPU benchmarks.'
 if x['id']=='paper-reading-companion':x['prompt']='Read paper.pdf physical page3: why y changes 8 to11, does it prove universal RoPE amplification? Read needed context, retain position+PDFhash, deliver offline original-page+explanation HTML, not whole-paper review.'
 if x['id']=='code-organization':x['fixtures']=['organization/experiments/sweep.py','organization/results/near.json','organization/results/both.json','organization/notes/orphan.txt','organization/CODEMAP.md','organization/active_tasks.json','organization/results/live.log']
for cid in rub['criteria']:
 rub['criteria'][cid]=[v.replace('all 4 rows','all 6 rows').replace('all 3 pages','all 4 pages').replace('physical page 2','physical page 3').replace('5 to 7.5','8 to 11').replace('outputs 5/7.5','outputs 8/11').replace('75-minute','80-minute').replace('16:00','15:30').replace('Default picks dimensions [0,2]; optional fixed basis is not query-trained; final score uses full original vectors','Default projects [1,3], fixed basis not query-trained; final score uses full original vectors').replace('Near is a candidate range, forced suffix is separate; skip_far keeps scoring near and final full_score','Near is candidate range, forced_ids independently unioned; skip_far preserves near scoring and full original-vector final score') for v in rub['criteria'][cid]]
rub['criteria']['research-implement-optimize']=['rolling_max handles negative/duplicate/empty/full/oversize windows and rejects nonpositive/noninteger/bool window','independent randomized oracle tests actually run and input unchanged','timing scopes separated, large25% regression included, no GPU or throughput measurement invented']
rub['criteria']['research-data-visualization'][0]='all 6 rows and both scopes exact; medium tie and large regression retained'
rub['criteria']['research-write']=['universal3x end-to-end claim rejected; small gain and medium tie accurate','large180->225ms25% latency increase included','claim evidence mapping and one-run/no-quality limits']
rub['criteria']['research-review'][0]='rejects universal3x claim using all end-to-end numbers'
rub['criteria']['code-reading']=['misleading module claims rejected with code/function line evidence','projection[1,3] fixed and final score uses original vectors','skip_far preserves near scoring, forced_ids union independent, budget2 explicit','read-only source unchanged; caller/data edges with conditions, no target execution or performance claim']
sm=json.loads((repo/'evals/pipeline_smoke/tasks.json').read_text());sr=json.loads((repo/'evals/pipeline_smoke/rubric.json').read_text())
for x in sm['cases']:
 if x['id'] in ['smoke-main-general','chain-coordinator']:
  if x['id']=='smoke-main-general':x['prompt']='Three roommates split a90CNY shared bill equally. I paid54, roommate B paid36, C paid0. Work out net transfers with minimal transactions, save calculation and a friendly group message to outputs/answer.txt. No external lookup or reminders needed.'
  base['cases'].append(x);rub['criteria'][x['id']]=sr['criteria'][x['id']]
rub['criteria']['smoke-main-general']=['each roommate owes30; B transfers6 and C transfers24 to user or equivalent correct settlement','concise natural group message; no research delegation/external claim']
rub['criteria']['chain-coordinator']=['CPU aggregates all18 rows; medians42/30,80/80,120/150 and formulas correct','actual source+aggregate hashes bind delivery; schema complete','v2 downstream invalidation/raw background retention and synthetic limited conclusions']
(b/'tasks.json').write_text(json.dumps(base,ensure_ascii=False,indent=2)+'\n');(b/'rubric.json').write_text(json.dumps(rub,ensure_ascii=False,indent=2)+'\n')
writer=next(x for x in sm['cases'] if x['id']=='chain-writer');(b/'writer-task.json').write_text(json.dumps({'cases':[writer]},ensure_ascii=False,indent=2)+'\n');(b/'writer-rubric.json').write_text(json.dumps({'criteria':{'chain-writer':sr['criteria']['chain-writer']}},ensure_ascii=False,indent=2)+'\n')
print('fixtures',len(list(f.rglob('*'))),'cases',len(base['cases']))

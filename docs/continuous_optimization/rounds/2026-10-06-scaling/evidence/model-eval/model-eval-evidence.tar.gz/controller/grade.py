import json,pathlib,sys,importlib.util
b=pathlib.Path(__file__).parent; spec=importlib.util.spec_from_file_location('pipeline',b/'pipeline.py'); p=importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
r=b/sys.argv[1]; cid=sys.argv[2]; a=int(sys.argv[3]); data=json.load(sys.stdin); d=r/'cases'/cid/'attempts'/f'{a:04d}'; c=p.read(d/'collection.json'); criteria=p.read(r/'rubric.json')['criteria'][cid]
assert len(criteria)==len(data)
g={'grader':'/root/role_pipeline','case_id':cid,'attempt':a,'output_hashes':c['output_hashes'],'checks':[dict(criterion=criterion,**check) for criterion,check in zip(criteria,data)]}
f=r/'host'/f'{cid}-{a}-independent-review.json'; p.write(f,g); p.grade_attempt(r,cid,a,f); print(cid,[x['verdict'] for x in g['checks']])

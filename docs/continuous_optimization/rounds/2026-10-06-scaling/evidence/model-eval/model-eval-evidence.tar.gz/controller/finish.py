import pathlib,json,sys,importlib.util,uuid,datetime
b=pathlib.Path(__file__).parent;spec=importlib.util.spec_from_file_location('pipeline',b/'pipeline.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
cid,actor,observation=sys.argv[1:4];run=b/(sys.argv[4] if len(sys.argv)>4 else 'run');attempt=int(sys.argv[5]) if len(sys.argv)>5 else 1
r={'event_id':'complete-'+cid+'-'+str(uuid.uuid4()),'kind':'complete','actor':actor,'adapter':'host','case_id':cid,'attempt':attempt,'status':'produced','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observed_completion':observation,'receipt_boundary':'Controller transcription of actual worker final message; not full transcript export'}
path=run/'host'/f'{cid}-{attempt}-complete.json';p.write(path,r);print(json.dumps(p.collect(run,cid,attempt,path),indent=2))

# results
alpha.json：GAMMA / synthetic-w4-g / inconclusive；beta.json：DELTA / synthetic-w4-d / rejected。
两者都是合成静态样例声明，不作为真实测量或独立验收证据。
beta.json 在 running_output_paths 中；alpha.json 运行状态 unknown；两者保持原路径和字节。
不重命名、不覆盖，不把不同实验文件当重复项合并；来源和 SHA256 见 ../manifest.json。
此 README 为 outputs 中的目录说明，内容路径相对原始 inputs/organization；索引见 ../CODEMAP.md。

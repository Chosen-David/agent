# COH-T27-F1 修订回应

已实际读取真实原 reviewer 的 mailbox seq 1，核对三个引用的 SHA256，并阅读原 review、collection 和旧提案。原发现指出“可回滚归档”没有具体恢复方法，也未明确评估重复项；ACK 仅记录反馈已消费。

本次在 reorganization_proposal.md 增加：（1）对全部七个文件的 SHA256 分组，明确无精确重复项；相似 alpha/beta 文件有不同实验、输入和结果声明，保留，不猜语义重复；（2）孤儿仅未来提案，明确保护解除和独立授权条件；（3）逐项原路径/目标映射、字节与 provenance/引用备份、冲突阻断、原路径恢复及哈希/引用/受保护输出核验的回滚流程。

同时重新完成原任务的静态盘点、增量 CODEMAP 和三个短 README。所有输入保持原位；GAMMA/DELTA 来源按文件内容核对，unknown 保留 unknown。此次不关闭 finding，不改写原评审；是否满足四项原条件交独立 reviewer 判断。

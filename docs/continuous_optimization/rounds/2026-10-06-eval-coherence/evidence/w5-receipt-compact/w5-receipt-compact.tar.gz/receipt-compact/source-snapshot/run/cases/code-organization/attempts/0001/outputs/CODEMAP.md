| Experiment | Conclusion | Script | Data | Result | Citation |
|---|---|---|---|---|---|
| HIST-0 | unknown | archived/missing.py | unknown | unknown | unknown |
| GAMMA | inconclusive（合成静态声明） | experiments/alpha.py | synthetic-w4-g | results/alpha.json | alpha.py:1 ↔ alpha.json:1；active_tasks.json:1 |
| DELTA | rejected（合成静态声明） | experiments/beta.py | synthetic-w4-d | results/beta.json | beta.py:1 ↔ beta.json:1；active_tasks.json:1 |
| UNKNOWN-NOTE | unknown；受保护的待溯源记录 | unknown | unknown | notes/orphan.txt | notes/orphan.txt:1；active_tasks.json:1 |

以上路径相对原始 `inputs/organization/`，本文件仅为 outputs 中的增量文档，不是输入树的替换或搬迁。原始表头及 HIST-0 历史行保持原字节和顺序。HIST-0 引用的 archived/missing.py 未提供，锚点缺失，不能推断结论或真实来源。

本次组织任务 task_id=COH-T27；GAMMA/DELTA 是源文件中的实验标识，不虚构额外任务编号。两条 active_scripts 均已登记（2/2）。文件字段双向一致只说明静态来源声明一致，不证明实验执行、结果正确或科研验收。

| 条目 | 声明生产者 | 实际作者 / 消费者 | 路径保护与待办 |
|---|---|---|---|
| GAMMA | experiments/alpha.py（results/alpha.json 的 script 字段） | 作者 unknown；实验消费者 unknown；本轮文档消费者为主控制器与独立 reviewer | 脚本 active；结果运行状态 unknown；保留原位 |
| DELTA | experiments/beta.py（results/beta.json 的 script 字段） | 作者 unknown；实验消费者 unknown；本轮文档消费者为主控制器与独立 reviewer | 脚本 active；results/beta.json 明确 running，保留原位 |
| UNKNOWN-NOTE | unknown | 作者、实验消费者 unknown；下一责任人主控制器协调溯源 | protected_files 明确保护；不因“孤儿”认定可移除 |
| HIST-0 | unknown | 作者、消费者 unknown；主控制器联系历史负责人 | archived/missing.py 缺失；保留历史行，补出处或缺失说明 |

真实原始数据未随输入提供，synthetic-w4-g/d 仅为合成来源标识；commit、真实进程和外部引用状态 unknown。七个实际输入的 SHA256、类型和来源在 manifest.json；整理与回滚提案见 reorganization_proposal.md。未创建第二份 TASK.md，总任务入口沿用冻结 task.txt，根 TASK.md 未提供。

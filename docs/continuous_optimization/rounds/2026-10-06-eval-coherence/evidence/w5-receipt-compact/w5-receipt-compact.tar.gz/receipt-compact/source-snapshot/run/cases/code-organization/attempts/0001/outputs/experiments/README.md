# experiments
源输入目录中的 alpha.py 声明 GAMMA / synthetic-w4-g，beta.py 声明 DELTA / synthetic-w4-d。
两者均在 active_tasks.json 的 active_scripts 中；仅作文档读取，禁止执行或导入。
声明结果分别为 results/alpha.json 与 results/beta.json；未知作者/消费者不补猜。
此 README 为 outputs 中的目录说明，路径以原始 inputs/organization 为基准；完整索引见 ../CODEMAP.md。

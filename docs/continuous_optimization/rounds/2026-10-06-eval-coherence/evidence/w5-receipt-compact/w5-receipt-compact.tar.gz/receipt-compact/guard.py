"""Host-owned bounded receipt-only proxy. Not a runtime or evaluation runner."""
from pathlib import Path
import json,sys,datetime,subprocess,uuid,hashlib
D=Path(__file__).resolve().parent;C=D.parent
now=lambda:datetime.datetime.now(datetime.timezone.utc)
actors={'main-controller':'/root/final_role_controller','research-review-recheck':'/root/final_role_controller/communication_reviewer','code-organization-repair':'/root/final_role_controller/communication_repair'}
request=json.load(sys.stdin);who=request['actor'];assert who in actors;path=D/(who+'-deadline.json')
if request['op']=='start':
 if path.exists():raise SystemExit('deadline already exists; no reset')
 start=now();body={'identity':who,'actor':actors[who],'started_at':start.isoformat(),'deadline':(start+datetime.timedelta(seconds=180)).isoformat(),'wall_seconds':180,'scope':'Receipt-only bounded recovery; no semantic work or output changes'}
 with path.open('x') as f:json.dump(body,f,indent=2)
 print(json.dumps(body));raise SystemExit(0)
phase=json.loads(path.read_text());start=now();remaining=(datetime.datetime.fromisoformat(phase['deadline'])-start).total_seconds();D.joinpath('host').mkdir(exist_ok=True)
record={'actor':actors[who],'request':request,'guard_checked_at':start.isoformat(),'deadline':phase['deadline'],'remaining_seconds_before_invocation':remaining,'actual_invocation':False}
code=0
try:
 if remaining<=0:raise ValueError('DEADLINE_EXPIRED; invocation refused; no retry/reset')
 op=request['op'];base=[sys.executable,'-B','-m','agent_runtime.communication','--db',str(C/'mailbox.sqlite'),'--plan',str(C/'plan.json'),'--root',str(C)]
 if op in ['inbox','status']:argv=base+([op,who] if op=='inbox' else [op])
 elif op=='consume':argv=base+['consume',who,str(int(request['seq'])),'--request',str(C/'consumer-request.json')]
 elif op in ['ack','publish']:
  f=(C/request['file']).resolve();assert f.is_relative_to((C/'artifacts').resolve()) or f.is_relative_to(D);assert f.is_file()
  argv=base+(['ack',who,str(int(request['seq'])),str(f)] if op=='ack' else ['publish',str(f)])
  if op=='publish':
   event=json.loads(f.read_text());assert who=='research-review-recheck' and event['sender']==who and event['kind']=='review';assert event['run_id']=='COH-T27-codeorg-repair-v1'
 elif op=='read-refs':
  allowed={'original-review-event.json':('research-review-original','review'),'repair-artifact-event.json':('code-organization-repair','artifact'),'repair-corrected-event.json':('code-organization-repair','artifact'),'recheck-review-after-transport-event.json':('research-review-recheck','review'),'bounded-recovery-review-event.json':('research-review-recheck','review')}
  name=request['event_file'];assert name in allowed
  def bounded(raw):
   raw=Path(raw);assert not raw.is_absolute();f=C/raw
   assert f.resolve().is_relative_to(C.resolve()) and f.is_file()
   assert not any(x.is_symlink() for x in [f,*f.parents] if x==C or C in x.parents)
   return f
  event=json.loads(bounded('artifacts/'+name).read_text());plan=json.loads((C/'plan.json').read_text())
  assert event['run_id']==plan['run_id'] and event['input_version']==plan['input_version'] and event['task_id']=='COH-T27'
  assert (event['sender'],event['kind'])==allowed[name] and isinstance(event['refs'],list)
  for ref in event['refs']:bounded(ref['path'])
  code='import json,hashlib,pathlib\nC=pathlib.Path('+repr(str(C))+')\nrefs='+repr(event['refs'])+'\nfor r in refs:\n raw=pathlib.Path(r["path"]);assert not raw.is_absolute();p=C/raw;assert p.resolve().is_relative_to(C.resolve()) and not any(x.is_symlink() for x in [p,*p.parents] if x==C or C in x.parents);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r["sha256"];print(r["path"]+"\\n"+b.decode())'
  argv=[sys.executable,'-B','-c',code]
 else:raise ValueError('op outside receipt-only allowlist')
 invocation_check=now();remaining=(datetime.datetime.fromisoformat(phase['deadline'])-invocation_check).total_seconds()
 record.update(invocation_checked_at=invocation_check.isoformat(),remaining_seconds_at_invocation=remaining)
 if remaining<=0:raise ValueError('DEADLINE_EXPIRED during preparation; invocation refused; no retry/reset')
 record['actual_invocation']=True;record['argv']=argv
 r=subprocess.run(argv,cwd=C/'runtime',capture_output=True,text=True,timeout=min(30,remaining));record.update(stdout=r.stdout,stderr=r.stderr,exit_code=r.returncode);code=r.returncode
except Exception as exc:record.update(error=str(exc),exit_code=3);code=3
record['finished_at']=now().isoformat();record['finished_before_deadline']=now()<=datetime.datetime.fromisoformat(phase['deadline']);out=D/'host'/(who+'-'+str(uuid.uuid4())+'.json');out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'record':str(out),**record},ensure_ascii=False));raise SystemExit(code)

"""Independent controller recheck of one actual compact attempt; no Mailbox mutation."""
from pathlib import Path
import json,hashlib,sqlite3,shutil,datetime,tarfile
D=Path(__file__).resolve().parent;C=D.parent;B=C.parent;E=B.parent/'agent/docs/continuous_optimization/rounds/2026-10-06-eval-coherence/evidence';P=E/'w5-receipt-compact';P.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
start=read(D/'code-organization-repair-deadline.json');deadline=datetime.datetime.fromisoformat(start['deadline']);begin=datetime.datetime.fromisoformat(start['started_at'])
assert all(sha(D/n)==h for n,h in read(D/'preregistration-hashes.json').items())
source_same=all(sha(C/n)==h and sha(D/'source-snapshot'/n)==h for n,h in read(D/'source-hashes.json').items());w4_same=all(sha(E/'w4-roles'/n)==h for n,h in read(D/'w4-public-before-hashes.json').items());assert source_same and w4_same
logs=[(p,read(p)) for p in sorted((D/'host').glob('*.json'))];ops=[x['request']['op'] for _,x in logs];assert ops.count('inbox')==1 and ops.count('read-refs')==2 and ops.count('ack')==2,len(logs)
assert all(x['actual_invocation'] and x['exit_code']==0 and x['finished_before_deadline'] and begin<=datetime.datetime.fromisoformat(x['invocation_checked_at'])<deadline and datetime.datetime.fromisoformat(x['finished_at'])<=deadline for _,x in logs)
acks={x['request']['seq']:x for _,x in logs if x['request']['op']=='ack'};assert set(acks)=={4,5}
reads=[x for _,x in logs if x['request']['op']!='ack'];assert max(x['finished_at'] for x in reads)<min(x['invocation_checked_at'] for x in acks.values())
with sqlite3.connect(f'file:{C}/mailbox.sqlite?mode=ro',uri=True) as db:
 events=db.execute('select seq,body from communication_events order by seq').fetchall();deliveries=db.execute('select seq,recipient,receipt from communication_deliveries order by seq,recipient').fetchall()
assert len(events)==5 and len(deliveries)==9 and all(r is not None for _,_,r in deliveries)
assert {str(s):json.loads(b) for s,b in events}==read(D/'before-state.json')['event_bodies']
for seq in [4,5]:
 actual=next(json.loads(r) for s,to,r in deliveries if s==seq and to=='code-organization-repair');assert actual==read(D/f'ack-seq{seq}.json');assert actual['status']=='consumed' and actual['reason'].strip()
shutil.copyfile(C/'mailbox.sqlite',D/'mailbox-after.sqlite');assert sha(C/'mailbox.sqlite')==sha(D/'mailbox-after.sqlite')
finish=max(datetime.datetime.fromisoformat(x['finished_at']) for _,x in logs);span=(finish-begin).total_seconds();host_spans=sum((datetime.datetime.fromisoformat(x['finished_at'])-datetime.datetime.fromisoformat(x['invocation_checked_at'])).total_seconds() for _,x in logs)
summary={'experiment':'W5 compact receipt recovery','candidate':'263958510f78789e33dd29676d510a672900ce26','attempts':1,'attempts_passed':1,'ack_denominator':2,'acks_passed':2,'actor':'/root/final_role_controller/communication_repair','recipient':'code-organization-repair','original_worker_context_reused':True,'preregistered_limit_seconds':180,'started_at':start['started_at'],'deadline':start['deadline'],'last_guarded_action_finished_at':finish.isoformat(),'elapsed_seconds':span,'guarded_operations':5,'planned_worker_tool_turns':2,'actual_worker_tool_turns':read(D/'completion.json')['tool_turns'],'protocol_deviation':read(D/'completion.json')['deviation'],'summed_guarded_subprocess_spans_seconds':host_spans,'events':5,'deliveries':9,'receipts':9,'pending':0,'new_events':0,'old_public_w4_unchanged':w4_same,'source_snapshot_unchanged':source_same,'old_attempt_reset':False,'old_budget_failures_preserved':True,'independent_recheck':'controller independently verified immutable source/public hashes, exact before/after event bodies, actual actor receipt bytes in durable DB, original guarded read-before-ACK timestamps and fixed deadline; no new semantic grading','guard_sha256':sha(D/'guard.py'),'host_records':[{ 'path':str(p.relative_to(D)),'sha256':sha(p),'op':x['request']['op'],'invocation_checked_at':x['invocation_checked_at'],'finished_at':x['finished_at'],'remaining_seconds':x['remaining_seconds_at_invocation']} for p,x in logs],'limitations':['One actual recovery attempt, not causal A/B proof; model snapshot, scheduling, tokens and cost unknown.','Worker actually read existing independent findings; ACK records handling and does not regrade or prove generalized communication improvement.','Old W4 failed/incomplete point-in-time evidence remains byte-identical; this separate W5 experiment changes only two live receipts.','Root owns publication decision.']}
write(D/'independent-recheck.json',summary);write(P/'summary.json',summary)
md=f'''# W5 compact receipt recovery

One separately preregistered attempt completed both actor-owned ACKs within the unchanged180-second cap: **{span:.3f}s** from recorded start to final guarded completion.

Actual current mailbox: **5events,9deliveries,9receipts,0pending**. No new event, source/Skill change or semantic regrading occurred. The same worker used two functional batches: actual inbox/full SHA-bound review reads, then its own explicit receipts and guarded ACK4/5. It reported one additional read-only guard-interface inspection:3tool turns rather than the planned2. This deviation is retained.

Independent controller recheck verified deadline/order, durable receipt bytes, unchanged event bodies,22source snapshot files and all frozen W4 public files. Original failed attempts and their deadlines remain unchanged. This is one successful recovery, not controlled A/B evidence or a generic performance claim; model/scheduling effects are not isolated.

Exact host timestamps/hashes and limitations: summary.json. Root decides publication.
'''
(D/'summary.md').write_text(md);(P/'summary.md').write_text(md)
files=[p for p in D.rglob('*') if p.is_file() and '__pycache__' not in p.parts];archive=P/'w5-receipt-compact.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for f in sorted(files):t.add(f,arcname='receipt-compact/'+str(f.relative_to(D)),recursive=False)
index={'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'files':{str(f.relative_to(D)):sha(f) for f in files},'scope':'Actual compact experiment; source snapshots plus before/after DB and unchanged guard. Pair W4 evidence for full historical context.'};write(P/'archive.json',index);print(json.dumps({'summary':summary,'archive_sha256':index['sha256'],'archive_bytes':index['bytes'],'public':str(P)},indent=2))

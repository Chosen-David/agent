"""One read-only batch of three existing guarded operations; never writes ACKs."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,sys,datetime
D=Path(__file__).resolve().parent
requests=[{'actor':'code-organization-repair','op':'inbox'},{'actor':'code-organization-repair','op':'read-refs','event_file':'recheck-review-after-transport-event.json'},{'actor':'code-organization-repair','op':'read-refs','event_file':'bounded-recovery-review-event.json'}]
def invoke(r):
 x=subprocess.run([sys.executable,'-B',str(D/'guard.py')],input=json.dumps(r),text=True,capture_output=True);return {'request':r,'returncode':x.returncode,'guard_result':json.loads(x.stdout),'stderr':x.stderr}
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(invoke,requests))
record={'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':results,'boundary':'Actual bounded inbox and SHA-checked full-reference reads only. No receipt written; model must inspect results before authoring ACK.'}
with (D/'inspection-batch.json').open('x') as f:json.dump(record,f,ensure_ascii=False,indent=2)
for x in results:print(json.dumps({'request':x['request'],'guard_record':x['guard_result']['record'],'exit_code':x['guard_result']['exit_code'],'full_stdout':x['guard_result'].get('stdout'),'error':x['guard_result'].get('error')},ensure_ascii=False,indent=2))
if any(x['returncode'] for x in results):sys.exit(1)

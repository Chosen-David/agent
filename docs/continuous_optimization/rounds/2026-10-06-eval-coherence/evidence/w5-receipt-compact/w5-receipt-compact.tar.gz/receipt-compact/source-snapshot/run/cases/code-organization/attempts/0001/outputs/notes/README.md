# notes
orphan.txt 声明没有实验来源；active_tasks.json 明确将它列为 protected_files。
保留原位；来源、作者和外部消费者 unknown，不归到 GAMMA 或 DELTA。
孤儿处理与未来回滚的条件见 ../reorganization_proposal.md；本轮不移动或删除。
此 README 为 outputs 中的目录说明，内容路径相对原始 inputs/organization；索引见 ../CODEMAP.md。

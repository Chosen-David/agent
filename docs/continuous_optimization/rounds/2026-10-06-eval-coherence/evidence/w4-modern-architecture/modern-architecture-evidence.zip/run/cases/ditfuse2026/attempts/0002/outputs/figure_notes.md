# DiTFuse architecture — attempt 0002

This revision adds an explicit redundant edge-style legend. Its scientific topology and all 32 semantic nodes / 38 typed directed edges are inherited unchanged from frozen attempt 0001. The controller supplied one repair finding: the first figure lacked a visible legend separating ordinary data/conditioning edges, parameter adaptation/training updates and repeated inference. No evaluation rubric was read by the maker.

The scientific caption is `caption.txt`, also rendered on page 2 of `page.pdf`. This file records source, design, limitations and execution rather than duplicating the caption.

Source: Li et al., *Towards Unified Semantic and Controllable Image Fusion: A Diffusion Transformer Approach*, arXiv:2512.07170v1, 8 December 2025; associated DOI 10.1109/TPAMI.2025.3642842. This is the author manuscript, not the IEEE typeset version. Original PDF SHA256: `742a48d608dd1cdfdc4a9e144759e16d352851fb5d4bdcfd1adda9ba0d0cedac`. Scientific anchors: Section III-A pp.4–5 and Fig.3; Section III-B pp.6–7, Fig.4, Fig.6 and Eqs.4–5. Source references and the brief hash are retained in `semantic_contract.json`.

Source reading occurred during attempt 0001: actual page 5, 6 and 7 PNGs were opened, with method text also extracted from pages 4 and 8. The reference pixels remain outside this output bundle at `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/reference-inspection/ditfuse2026/`. No new original-paper or repository inspection was required for this narrow legend repair. The explicit LoRA code discrepancy below comes from the supplied brief, not a claim that code was inspected.

Design: A shows one shared conditional model; B resolves causal versus image-internal attention; C separates target construction and flow-matching supervision; D shows noise-initialized inference with fixed adapted parameters. The legend beneath D shows (1) solid arrow + “Data / conditioning”, (2) dashed arrow + “Parameter adaptation / training update (A, C)”, and (3) a solid return-loop glyph + “Inference repeat (D)”. These textual and geometric distinctions do not depend on color. Existing data/conditioning, parameter and loop styles were preserved. The caption repeats their meanings.

The original panels were not compressed. The vector canvas was extended from 755 to 783 pt in height to reserve a separate 22 pt legend band. Final figure dimensions are 180 mm × 276.225 mm (510.236220 × 783 pt). Minimum primary label size is 8 pt, with 10.5 pt panel headings. Figure.svg retains editable text and vector shapes; build.py is the editable geometry source. A4 page 1 embeds the figure at its full 180 mm width and 1:1 scale, with a separate caption page. Page title/footer positions were adjusted to accommodate the added legend without shrinking labels.

Before: the frozen attempt 0001 figure had no edge-style key; its actual figure and page images remain immutable in that attempt. After: final figure.png, grayscale.png, page.png and caption-page.png in this attempt were each opened with the image viewer. The solid, dashed and return-loop samples are visibly distinct in grayscale. All three legend labels fit in their footer band, the A4 embedding includes the entire legend and page footer, and the caption page includes the edge explanation without clipping. Existing target-selection and attention routes are unchanged. These are actual maker observations, not an independent grade. No remaining visual issue was observed in this limited repair inspection.

Exact final inspected paths:
- `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/run/cases/ditfuse2026/attempts/0002/outputs/figure.png`
- `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/run/cases/ditfuse2026/attempts/0002/outputs/grayscale.png`
- `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/run/cases/ditfuse2026/attempts/0002/outputs/page.png`
- `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/run/cases/ditfuse2026/attempts/0002/outputs/caption-page.png`

Scientific limits remain unchanged: author-paper LoRA is all linear layers, rank 64, scale 0.5, while the provided brief reports code targeting qkv_proj/o_proj with lora_alpha equal to rank. Exact code equivalence is not asserted. The explicit causal/block-bidirectional attention rule governs the inset. The target image in the paper's flow equation is drawn as its VAE latent x in this latent architecture. M3 and other tasks have constructed supervision; the figure does not call all training unsupervised. Token counts and image tiles are schematic; sampling integrator, projection internals, empirical examples and benchmark results are not fabricated. GPT4o evaluation remains outside the architecture.

Exact rebuild command:

`python /workspace/scratch/c12f3d9f92bd/modern-architecture-controller/run/cases/ditfuse2026/attempts/0002/outputs/build.py`

The build is portable: move the source with its adjacent caption.txt and run `python /path/to/build.py`; outputs resolve beside it. Actual versions are in dependencies.json. No package installation, GPU or network was used. Rebuild exited 0 through controller proxy record `ditfuse2026-proxy-4aa1b8ff-5cc1-4bc5-be71-8e7b8291c793.json`. Controller-owned raw proxy logs and original-paper stdout/pixels are deliberately absent from this bundle. tool-actions.json is a self-authored action list, not a platform transcript or measured token/cost counter. Independent review of this revision remains pending with the controller.

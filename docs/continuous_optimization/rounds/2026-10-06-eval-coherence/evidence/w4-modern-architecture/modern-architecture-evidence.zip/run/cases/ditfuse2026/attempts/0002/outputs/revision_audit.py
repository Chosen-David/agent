"""Record the narrow, non-scientific legend revision and technical observations."""
from pathlib import Path
import json, hashlib, xml.etree.ElementTree as ET
import fitz
R=Path(__file__).resolve().parent
prior=R.parent.parent/'0001'/'outputs'
p=R/'semantic_contract.json'
c=json.loads(p.read_text()); old=json.loads((prior/'semantic_contract.json').read_text())
c['dimensions']['height_mm']=783/72*25.4
c['edge_style_legend']=[
 {'style':'solid directed arrow','label':'Data / conditioning','meaning':'Data or conditioning dependency'},
 {'style':'dashed directed arrow','label':'Parameter adaptation / training update (A, C)','meaning':'LoRA parameter contribution in A; training optimization in C'},
 {'style':'solid directed return loop','label':'Inference repeat (D)','meaning':'Repeated sampling, without parameter updates'}]
c['revision']={'attempt':'0002','scope':'Explicit edge-style legend and page placement; scientific topology unchanged','independent_review':'pending controller review'}
p.write_text(json.dumps(c,indent=2,ensure_ascii=False)+'\n')
same={k:c[k]==old[k] for k in ['nodes','edges','groups','invariants','attention_inset','source_refs']}
d=fitz.open(R/'figure.pdf'); pg=d[0]
spans=[s for b in pg.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
svg=ET.parse(R/'figure.svg').getroot(); ns={'s':'http://www.w3.org/2000/svg'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'attempt':'0002','scientific_contract_comparison_to_frozen_0001':same,'pdf_media_box_pt':list(pg.rect),'width_mm':pg.rect.width/72*25.4,'height_mm':pg.rect.height/72*25.4,'minimum_text_size_pt':min(s['size'] for s in spans),'pdf_images':len(pg.get_images()),'svg_text_elements':len(svg.findall('.//s:text',ns)),'svg_image_elements':len(svg.findall('.//s:image',ns)),'legend_text_present':all(x in pg.get_text() for x in ['Data / conditioning','Parameter adaptation /','training update (A, C)','Inference repeat (D)']),'hashes':{f:sha(R/f) for f in ['figure.pdf','figure.svg','figure.png','grayscale.png','page.pdf','page.png','caption-page.png','semantic_contract.json']},'boundary':'Technical observations and maker inspections do not replace independent review.'}
(R/'technical-check.json').write_text(json.dumps(report,indent=2)+'\n')
actions={'type':'self-authored action list','tokens':None,'cost':None,'actions':[
 {'action':'copy necessary original editable/scientific artifacts from frozen attempt 0001 into new attempt 0002','tool':'controller proxy','record':'ditfuse2026-proxy-0a5b0801-b3e9-49a9-8641-31e656b1b73a.json','files':['build.py','caption.txt','figure_notes.md','semantic_contract.json']},
 {'action':'add edge-style legend; extend canvas; adjust page placement; explain styles in caption','tool':'apply_patch','files':['build.py','caption.txt']},
 {'action':'actual rebuild','tool':'controller proxy','record':'ditfuse2026-proxy-4aa1b8ff-5cc1-4bc5-be71-8e7b8291c793.json','exit_code':0},
 {'action':'actual final pixel inspection','tool':'view_image','paths':[str(R/f) for f in ['figure.png','grayscale.png','page.png','caption-page.png']],'observations':'Legend samples distinct in color and grayscale; text fits; full A4 legend and caption visible; topology unchanged.'},
 {'action':'metadata patch rejected, then split into delete/add operations','tool':'apply_patch','result':'First combined delete/add patch rejected; subsequent separate operations succeeded.'},
 {'action':'write revision notes, preserve semantic topology and record technical dimensions','tool':'apply_patch + controller proxy','files':['figure_notes.md','revision_audit.py','semantic_contract.json','technical-check.json','tool-actions.json']}
]}
(R/'tool-actions.json').write_text(json.dumps(actions,indent=2)+'\n')
print(json.dumps(report,indent=2))

#!/usr/bin/env python3
"""Original DOUBT explanation. Rebuild: python build.py. No network or model execution."""
from pathlib import Path
import math, json, html, hashlib, shutil, platform
import reportlab, fitz, PIL
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import toColor as HexColor

ROOT=Path(__file__).resolve().parent
W=180*72/25.4
H=626
S=W/510
FONTDIR=ROOT/'fonts'; FONTDIR.mkdir(exist_ok=True)
for name in ['DejaVuSans.ttf','DejaVuSans-Bold.ttf']:
    dst=FONTDIR/name
    if not dst.exists(): shutil.copyfile(Path('/usr/share/fonts/truetype/dejavu')/name,dst)
pdfmetrics.registerFont(TTFont('Body',str(FONTDIR/'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('Bold',str(FONTDIR/'DejaVuSans-Bold.ttf')))
INK='#172B3A'; MUTED='#536474'; LINE='#637482'; BLUE='#275F8A'; TEAL='#19786D'
BLUEF='#EEF5FA'; TEALF='#EAF6F2'; PURPLE='#76528F'; PURPLEF='#F4EFF8'; GRAY='#F4F6F8'

class Draw:
    def __init__(self):
        self.pdf=canvas.Canvas(str(ROOT/'figure.pdf'),pagesize=(W,H*S),pageCompression=1)
        self.pdf.setTitle('DOUBT: separate-set trustworthiness'); self.pdf.setAuthor('Original diagram from supplied grounded method brief')
        self.svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="180mm" height="{H*S*25.4/72:.6f}mm" viewBox="0 0 510 {H}">', '<title>DOUBT: separate-set trustworthiness</title>', '<desc>Original architecture from grounded facts D1–D8. Direct and object-bridged answer sets are embedded and normalized separately, scored by resultant length, averaged, and thresholded. Reference answer A is evaluated only offline.</desc>']
        self.pdf.scale(S,S)
    def rect(self,id,x,y,w,h,fill='white',stroke=LINE,r=5,dash=None):
        c=self.pdf;c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(stroke));c.setLineWidth(.8);c.setDash(dash or [])
        c.roundRect(x,H-y-h,w,h,r,fill=1,stroke=1);c.setDash([])
        self.svg.append(f'<rect id="{id}" x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width=".8"'+(f' stroke-dasharray="{dash[0]} {dash[1]}"' if dash else '')+'/>')
    def text(self,x,y,txt,size=9,color=INK,bold=False,anchor='start',id=None):
        font='Bold' if bold else 'Body'; c=self.pdf;c.setFont(font,size);c.setFillColor(HexColor(color))
        offset={'start':0,'middle':pdfmetrics.stringWidth(txt,font,size)/2,'end':pdfmetrics.stringWidth(txt,font,size)}[anchor]
        c.drawString(x-offset,H-y,txt)
        self.svg.append(f'<text'+(f' id="{id}"' if id else '')+f' x="{x}" y="{y}" font-family="DejaVu Sans" font-size="{size}" fill="{color}" font-weight="{700 if bold else 400}" text-anchor="{anchor}">{html.escape(txt)}</text>')
    def line(self,id,pts,color=LINE,width=1.05,dash=None,arrow=True):
        c=self.pdf;c.setStrokeColor(HexColor(color));c.setLineWidth(width);c.setDash(dash or [])
        p=c.beginPath();p.moveTo(pts[0][0],H-pts[0][1])
        for x,y in pts[1:]:p.lineTo(x,H-y)
        c.drawPath(p);c.setDash([])
        coords=' '.join(f'{x},{y}' for x,y in pts)
        self.svg.append(f'<polyline id="{id}" points="{coords}" fill="none" stroke="{color}" stroke-width="{width}"'+(f' stroke-dasharray="{dash[0]} {dash[1]}"' if dash else '')+'/>')
        if arrow:
            x,y=pts[-1];x0,y0=pts[-2];a=math.atan2(y-y0,x-x0);l=5.;b=2.5
            tri=[(x,y),(x-l*math.cos(a)+b*math.sin(a),y-l*math.sin(a)-b*math.cos(a)),(x-l*math.cos(a)-b*math.sin(a),y-l*math.sin(a)+b*math.cos(a))]
            c.setFillColor(HexColor(color));p=c.beginPath();p.moveTo(tri[0][0],H-tri[0][1])
            for xx,yy in tri[1:]:p.lineTo(xx,H-yy)
            p.close();c.drawPath(p,fill=1,stroke=0)
            self.svg.append(f'<polygon points="'+ ' '.join(f'{xx},{yy}' for xx,yy in tri)+f'" fill="{color}"/>')
    def badge(self,id,x,y,label,color):
        c=self.pdf;c.setFillColor(HexColor(color));c.circle(x,H-y,8.5,fill=1,stroke=0)
        self.svg.append(f'<circle id="{id}" cx="{x}" cy="{y}" r="8.5" fill="{color}"/>')
        self.text(x,y+3,label,8.5,'white',True,'middle')
    def finish(self):
        self.pdf.showPage();self.pdf.save();self.svg.append('</svg>');(ROOT/'figure.svg').write_text('\n'.join(self.svg))

d=Draw()
d.text(0,13,'DOUBT',12,bold=True)
d.text(52,13,'Object-bridged sampling → separate-set trustworthiness',10)
d.line('title-rule',[(0,22),(510,22)],color=INK,width=.6,arrow=False)
d.text(0,40,'A',10,bold=True);d.text(16,40,'Repeated inference with one black-box MLLM M',10,bold=True)

# A: two semantically distinct sampling routes; every M call is the same black box.
d.rect('inputs',12,91,86,88,fill=GRAY)
d.rect('schematic-image',25,105,29,23,fill='white',stroke=MUTED,r=1)
d.line('schematic-mountains',[(28,124),(36,114),(42,121),(48,115),(51,124)],width=.7,arrow=False)
d.text(68,120,'I',11,bold=True,anchor='middle')
d.text(55,144,'Image +',9,anchor='middle');d.text(55,158,'question t',9,anchor='middle')
d.text(55,173,'schematic',8,MUTED,anchor='middle')

d.rect('direct-sampling',140,62,164,57,fill=BLUEF,stroke=BLUE)
d.text(151,79,'DIRECT SAMPLING',8.5,BLUE,True)
d.text(151,97,'K answers from M(I, t)',10)
d.text(151,111,'Repeated stochastic inference',8,MUTED)
d.line('input-direct',[(98,109),(119,109),(119,90),(140,90)],color=BLUE)
d.text(119,80,'I, t',8,BLUE,anchor='middle')
d.rect('ori-answers',350,62,148,57,fill=BLUEF,stroke=BLUE)
d.text(361,82,'Direct answer set',9.5,bold=True)
d.text(361,101,'S_ori = {a₁, …, a_K}',9)
d.badge('ori-continuation-out',487,111,'O',BLUE)
d.line('direct-to-set',[(304,90),(350,90)],color=BLUE)

d.rect('object-recognition',140,157,126,56,fill=TEALF,stroke=TEAL)
d.text(150,174,'OBJECT RECOGNITION',8,TEAL,True)
d.text(150,191,'r = M(I, p_obj)',10)
d.text(150,205,'Up to 3 main objects',8,MUTED)
d.line('image-object',[(98,151),(119,151),(119,185),(140,185)],color=TEAL)
d.text(119,143,'I',8,TEAL,anchor='middle')
d.rect('bridged-sampling',309,157,189,56,fill=TEALF,stroke=TEAL)
d.text(320,174,'OBJECT-BRIDGED SAMPLING',8.3,TEAL,True)
d.text(320,191,'K × M(I, t ‖ p_bri ‖ r)',10)
d.text(320,205,'‖ denotes prompt concatenation',8,MUTED)
d.line('objects-bridge',[(266,185),(309,185)],color=TEAL)
d.text(287,176,'r',9,TEAL,anchor='middle')
d.line('input-bridge',[(55,179),(55,237),(330,237),(330,213)],color=TEAL)
d.text(159,233,'I, t retained',8.5,TEAL)
d.rect('bri-answers',350,233,148,30,fill=TEALF,stroke=TEAL)
d.text(361,252,'S_bri = {b₁, …, b_K}',9)
d.badge('bri-continuation-out',487,251,'B',TEAL)
d.line('bridge-to-set',[(423,213),(423,233)],color=TEAL)
d.text(12,258,'p_obj: object prompt; p_bri: bridging prompt',8,MUTED)

# B: shared frozen model is not a mixing operation; normalizations and resultants remain per set.
d.line('panel-a-rule',[(0,276),(510,276)],width=.6,arrow=False)
d.text(0,292,'B',10,bold=True);d.text(16,292,'Frozen embeddings, then two independent resultant lengths',10,bold=True)
d.text(44,317,'Same frozen nli-roberta-large encoder f',9,bold=True)
d.rect('frozen-encoder',44,329,229,86,fill=PURPLEF,stroke=PURPLE)
d.line('encoder-separator',[(44,372),(273,372)],color=PURPLE,width=.6,arrow=False)
d.badge('ori-continuation-in',16,350,'O',BLUE);d.badge('bri-continuation-in',16,394,'B',TEAL)
d.line('ori-encode',[(25,350),(44,350)],color=BLUE)
d.line('bri-encode',[(25,394),(44,394)],color=TEAL)
d.text(56,347,'Each a_k:  e_k = f(a_k)',9)
d.text(56,361,'Normalize individually:  ê_k = e_k / ‖e_k‖₂',8.4)
d.text(56,390,'Each b_k:  e_k = f(b_k)',9)
d.text(56,404,'Normalize individually:  ê_k = e_k / ‖e_k‖₂',8.4)
d.rect('ori-resultant',318,329,180,43,fill=BLUEF,stroke=BLUE)
d.text(328,346,'Direct set only',8,BLUE,True)
d.text(328,361,'R_ori = ‖Σₖ ê_k‖₂ / K',10)
d.rect('bri-resultant',318,379,180,43,fill=TEALF,stroke=TEAL)
d.text(328,396,'Bridged set only',8,TEAL,True)
d.text(328,411,'R_bri = ‖Σₖ ê_k‖₂ / K',10)
d.line('ori-embeddings',[(273,350),(318,350)],color=BLUE)
d.line('bri-embeddings',[(273,394),(293,394),(293,400),(318,400)],color=TEAL)
d.text(282,340,'ê_k',8.5,BLUE)
d.text(282,383,'ê_k',8.5,TEAL)
d.rect('mean-trustworthiness',259,444,239,36,fill=GRAY,stroke=INK)
d.text(379,459,'Average the two scalar scores',8,bold=True,anchor='middle')
d.text(379,473,'R_avg = (R_ori + R_bri) / 2',10,anchor='middle')
d.line('ori-mean',[(498,350),(506,350),(506,434),(449,434),(449,444)],color=BLUE)
d.line('bri-mean',[(389,422),(389,444)],color=TEAL)
d.rect('operator-invariant',12,438,225,42,fill='white',stroke=MUTED,dash=[3,2])
d.text(22,453,'Operator order matters',9,bold=True)
d.text(22,467,'Unit vectors → sum → norm → divide by K',8)
d.text(22,478,'Compute per set; never pool the 2K vectors.',8)
d.rect('threshold',259,497,239,35,fill='#F8F6EF',stroke='#8A7042')
d.text(270,511,'R_avg > θ  →  flag 1: non-hallucinatory',8.5,bold=True)
d.text(270,525,'R_avg ≤ θ  →  flag 0: hallucination',8.5,bold=True)
d.line('score-threshold',[(379,480),(379,497)],color=INK)
d.text(12,506,'O / B link the same answer sets across panels.',8,MUTED)
d.text(12,522,'Higher R_avg means greater trustworthiness.',8,MUTED)

# C: A and ground truth affect only offline correctness comparison.
d.line('offline-boundary',[(0,546),(510,546)],width=.6,dash=[3,2],arrow=False)
d.text(0,562,'C',10,bold=True);d.text(16,562,'Offline evaluation only — reference A never enters the score',9.5,bold=True)
d.rect('reference-call',12,584,119,36,fill=GRAY)
d.text(20,599,'M(I, t), low temp.',8.5,bold=True)
d.text(20,613,'Reference answer A',8.5)
d.rect('reference-correctness',186,584,122,36,fill=GRAY)
d.text(247,599,'Correctness of A',9,bold=True,anchor='middle')
d.text(247,613,'against ground truth',8,anchor='middle')
d.line('reference-correctness-edge',[(131,602),(186,602)],dash=[3,2])
d.text(158,594,'A',8.5,anchor='middle')
d.rect('offline-comparison',354,584,144,36,fill=GRAY)
d.text(426,599,'Compare correctness',8.5,bold=True,anchor='middle')
d.text(426,613,'with detection flag',8.5,anchor='middle')
d.line('correctness-comparison',[(308,602),(354,602)],dash=[3,2])
d.line('flag-evaluation',[(498,516),(508,516),(508,574),(466,574),(466,584)],dash=[3,2])
d.text(382,581,'flag (evaluation use)',8,MUTED)
d.finish()

# Render the actual vector PDF. PNGs are previews, never the figure source.
doc=fitz.open(ROOT/'figure.pdf'); pix=doc[0].get_pixmap(matrix=fitz.Matrix(3,3),alpha=False);pix.save(ROOT/'figure.png')
Image.open(ROOT/'figure.png').convert('L').save(ROOT/'grayscale.png')

# Full A4 page embeds the vector figure at exactly 180 mm.
page=fitz.open();p=page.new_page(width=210*72/25.4,height=297*72/25.4)
x=(p.rect.width-W)/2;y=30
p.show_pdf_page(fitz.Rect(x,y,x+W,y+H*S),doc,0)
caption=("Figure 1. DOUBT architecture (original schematic). (A) The same black-box MLLM samples K direct answers and K object-bridged answers; bridging retains both image I and question t. (B) A shared frozen sentence encoder embeds each response, which is normalized individually. The two sets produce separate mean-resultant lengths; only these scalar scores are averaged. Thresholding estimates hallucination status. (C) Reference answer A and its ground-truth correctness are used only for offline evaluation. Solid arrows denote inference data; dashed arrows denote offline evaluation. O/B are continuation labels, not operations.\n\nSource: supplied grounded brief D1–D8, citing Chen et al., PMLR 306 (2026), pp. 16418–16441, Sections 3.1–3.3 and Algorithm 1. No original paper/figure was opened. Experimental choices (K=10, temperatures 0.1/0.5, top-k=10, top-p=0.99, theta=0.48) are not architectural constants. Detection is an estimate; object-recognition errors may propagate. No model performance was reproduced.")
p.insert_font(fontname='Body',fontfile=str(FONTDIR/'DejaVuSans.ttf'))
remaining=p.insert_textbox(fitz.Rect(x,y+H*S+12,x+W,p.rect.height-20),caption,fontname='Body',fontsize=8.1,lineheight=1.35,color=(.15,.2,.25))
assert remaining>=0, f'Caption overflow: {remaining}'
page.save(ROOT/'page.pdf',deflate=True)
page[0].get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(ROOT/'page.png')

source_path=Path('/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/run/cases/doubt2026/inputs/doubt2026/source-brief.md')
source_hash=hashlib.sha256(source_path.read_bytes()).hexdigest() if source_path.exists() else 'Source brief unavailable in this portable rebuild; see figure_notes.md.'
manifest={'figure_width_mm':180,'figure_height_mm':H*S*25.4/72,'minimum_label_pt':8*S,'primary_label_pt_range':[8*S,12*S],'page':'A4','page_figure_scale':1,'raster_dpi':216,'source_brief_sha256':source_hash,'python':platform.python_version(),'dependencies':{'reportlab':reportlab.Version,'PyMuPDF':fitz.VersionBind,'Pillow':PIL.__version__},'font':'bundled DejaVu Sans regular and bold','embedded_raster_images_in_figure_pdf':len(doc[0].get_images()),'figure_pdf_size_pt':list(doc[0].rect),'page_caption_remaining_pt':remaining}
(ROOT/'build_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(ROOT/'requirements.txt').write_text(f'reportlab=={reportlab.Version}\nPyMuPDF=={fitz.VersionBind}\nPillow=={PIL.__version__}\n')
print(json.dumps({'built':['figure.svg','figure.pdf','figure.png','grayscale.png','page.pdf','page.png'],'manifest':manifest},indent=2))

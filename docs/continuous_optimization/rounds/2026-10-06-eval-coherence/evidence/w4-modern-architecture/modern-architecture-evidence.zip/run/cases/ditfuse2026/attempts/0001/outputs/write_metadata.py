"""Write diagram semantics and transparent execution notes; does not draw figures."""
from pathlib import Path
import json, hashlib, shutil
import fitz
import xml.etree.ElementTree as ET

R=Path(__file__).resolve().parent
BASE=Path('/workspace/scratch/c12f3d9f92bd')
SOURCE=BASE/'recent-architecture-sources/ditfuse.pdf'
BRIEF=BASE/'modern-architecture-controller/run/cases/ditfuse2026/inputs/ditfuse2026/source-brief.md'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
refs={
 'S1':{'path':str(SOURCE),'version':'arXiv:2512.07170v1, 8 December 2025','sha256':sha(SOURCE),'location':'Section III-A pp.4-5; Fig.3 p.5'},
 'S2':{'path':str(SOURCE),'sha256':sha(SOURCE),'location':'Section III-B pp.6-7; Fig.4 p.6; Eqs.4-5 p.7'},
 'S3':{'path':str(SOURCE),'sha256':sha(SOURCE),'location':'Fig.6 and target construction text p.7'},
 'B1':{'path':str(BRIEF),'sha256':sha(BRIEF),'location':'F1-F9; source boundaries and conflicts','scope':'Provided brief, not independently inspected code'}
}
nodes=[]
def n(id,label,type,group,refs,**kw):nodes.append(dict(id=id,label=label,type=type,group=group,source_refs=refs,**kw))
n('input_image1','Image I1','condition_data','A',['S1'])
n('input_image2','Image I2','condition_data','A',['S1'])
n('instruction','Task-tagged textual instruction','condition_control','A',['S1','S3'])
n('vae1','Frozen SDXL VAE + visual patch embedding','encoder','A',['S1'],trainability='VAE frozen',patch_size=2,latent_shape='H/8 × W/8 × C',position='frequency-based')
n('vae2','Frozen SDXL VAE + visual patch embedding','encoder','A',['S1'],trainability='VAE frozen',patch_size=2,latent_shape='H/8 × W/8 × C',position='frequency-based')
n('text_encoder','Phi-3 tokenizer + text embeddings','encoder','A',['S1'],embedding_dimension=3072)
n('condition_sequence','Interleaved text and delimited image tokens','token_sequence','A',['S1','S3','B1'])
n('time_token','Timestep token t','temporal_condition','A',['S1','B1'])
n('noisy_target_tokens','Noisy target tokens xt','generation_state','A',['S1','B1'])
n('dit','32-layer OmniGen/Phi-3 pretrained DiT','shared_operator','A',['S1'],trainability='Backbone frozen')
n('lora','LoRA on all linear layers','adaptation_parameters','A',['S1','B1'],rank=64,scaling=0.5,architecture_choice='author-paper; not exact training-code equivalence')
n('target_velocity','Target tokens reconstructed to latent velocity','model_output','A',['S1','S2','B1'])
n('hybrid_mask','Causal sequence with image-block bidirectionality','attention_rule','B',['S1','B1'])
n('source_image','Source image for M3','training_data','C',['S2'])
n('m3','Duplicate and corrupt aligned patch grids','training_data_transform','C',['S2'],complementary_fraction=.75,common_fraction=.25,grid_options=['16×16','32×32','64×64'],corruptions=['noise mask','Gaussian noise','blur'])
n('m3_views','Two degraded views','condition_data','C',['S2'])
n('target_m3','Original source image','candidate_supervision','C',['S2'])
n('target_control','Brightness/contrast-adjusted image','candidate_supervision','C',['S2','S3'])
n('target_seg','Translucent blue target-class overlay','candidate_supervision','C',['S2','S3'])
n('target_fusion','Task-specific fusion target','candidate_supervision','C',['S3'],targets={'IVIF':'mean fusion','MEF':'normally exposed target in synthetic datasets','MFF':'provided pseudo ground truth'})
n('target_selection_bus','Select task target and frozen-VAE encode to latent x','selector_encoder','C',['S2','S3','B1'],drawing='Shared bus and text annotation, not an all-target sum')
n('noise_epsilon','Gaussian noise epsilon','training_random_variable','C',['S2'],drawing='Inside interpolation formula')
n('sample_t','Sample t in [0,1]','training_random_variable','C',['S2'],drawing='Inside interpolation formula')
n('interpolation','xt = t x + (1-t) epsilon','training_state_construction','C',['S2'])
n('training_call','Call shared velocity model A','operator_instance','C',['S1','S2'],alias_of='dit')
n('velocity_loss','Expected squared velocity error','training_objective','C',['S2'],formula='E ||(x-epsilon)-v_theta(xt,t,c)||^2')
n('inference_noise','Initial Gaussian noise x0','generation_initialization','D',['S1','B1'])
n('inference_call','Call shared model A with fixed adapted weights','operator_instance','D',['S1','B1'],alias_of='dit')
n('latent_update','Update latent using predicted velocity','sampling_operation','D',['S1','B1'],integrator='not specified in drawing')
n('final_latent','Final generated target latent','generation_data','D',['S1','B1'])
n('vae_decoder','Frozen VAE decoder','decoder','D',['S1'])
n('output_image','Task-consistent output image','generated_output','D',['S1'])
edges=[]
def e(src,tgt,kind,label='',refs=['S1'],drawn=True):
 edges.append({'id':f'e{len(edges)+1:02d}','source':src,'target':tgt,'direction':'source_to_target','kind':kind,'label':label,'source_refs':refs,'drawn_as_arrow_or_bus':drawn})
for i in [1,2]:e(f'input_image{i}',f'vae{i}','data_flow');e(f'vae{i}','condition_sequence','data_flow','visual tokens')
e('instruction','text_encoder','control_encoding');e('text_encoder','condition_sequence','condition_data_flow','text tokens')
for s in ['condition_sequence','time_token','noisy_target_tokens']:e(s,'dit','data_flow','unified sequence; condition then time then target')
e('lora','dit','parameter_adaptation','Wprime = W + alpha B A^T')
e('hybrid_mask','dit','attention_constraint',refs=['S1','B1'],drawn=False)
e('dit','target_velocity','data_flow','only output-image tokens converted to latent velocity',refs=['S1','B1'])
e('source_image','m3','training_data_flow',refs=['S2']);e('m3','m3_views','training_data_flow',refs=['S2'])
e('m3_views','input_image1','cross_panel_condition_binding',refs=['S2'],drawn=False);e('m3_views','input_image2','cross_panel_condition_binding',refs=['S2'],drawn=False)
e('source_image','target_m3','supervision_identity',refs=['S2'],drawn=False)
for s in ['target_m3','target_control','target_seg','target_fusion']:e(s,'target_selection_bus','alternative_target','select one according to task',refs=['S2','S3'])
e('instruction','target_selection_bus','task_control','instruction chooses target construction',refs=['S3'],drawn=False)
e('target_selection_bus','interpolation','training_data_flow','latent x',refs=['S2'])
e('noise_epsilon','interpolation','training_data_flow',refs=['S2'],drawn=False);e('sample_t','interpolation','temporal_condition',refs=['S2'],drawn=False)
e('interpolation','training_call','training_data_flow','xt and t',refs=['S2'])
e('condition_sequence','training_call','cross_panel_condition_binding','c',refs=['S1','S2'],drawn=False)
e('training_call','velocity_loss','prediction','v_theta',refs=['S2'])
e('target_selection_bus','velocity_loss','supervision','x-epsilon',refs=['S2']);e('noise_epsilon','velocity_loss','supervision','same epsilon',refs=['S2'],drawn=False)
e('velocity_loss','lora','parameter_update','training-only dashed return via model A',refs=['S1','S2'])
e('inference_noise','inference_call','data_flow','initial xt at t=0')
e('condition_sequence','inference_call','cross_panel_condition_binding','two image and text conditions fixed',drawn=False)
e('inference_call','latent_update','data_flow','predicted latent velocity')
e('latent_update','inference_call','sampling_feedback','next xt, next timestep; 50-step loop')
e('latent_update','final_latent','data_flow','after final step')
e('final_latent','vae_decoder','data_flow');e('vae_decoder','output_image','data_flow')
contract={'id':'T26-DiTFuse2026-architecture','schema_version':1,'evidence_type':'literature-grounded schematic','source_refs':refs,'nodes':nodes,'edges':edges,
 'groups':[{'id':k,'label':label,'members':[n['id'] for n in nodes if n['group']==k],'boundary_kind':'explanatory panel, not hardware/deployment boundary'} for k,label in [('A','Shared operator'),('B','Attention rule'),('C','Training only'),('D','Inference only')]],
 'invariants':[
 'I1 and I2 remain distinct until multimodal token processing; no pixelwise pre-addition.',
 'Condition sequence precedes timestep then output/noisy-target tokens. Image tokens retain delimiters.',
 'Token count in the attention inset is schematic, not a claimed sequence length.',
 'Cross-block attention cannot read future tokens. Each image block has internal bidirectional attention.',
 'Output target queries can see all earlier condition/time tokens and their own output block. Earlier blocks cannot see future target tokens.',
 'Only output-target token states are converted to the generated latent velocity; input-image and text tokens are not decoded.',
 'A, training_call and inference_call denote one shared operator, not three independent models.',
 'Paper LoRA choice is all linear layers, rank 64, alpha 0.5; brief reports code qkv_proj/o_proj and lora_alpha=rank. Do not conflate.',
 'M3 corruption aligns spatial patches in two source copies: about 75% complementary and 25% common.',
 'Task-target bus selects one instruction-appropriate target, never adds the four targets.',
 'Same target latent x and sampled epsilon form xt and target velocity x-epsilon.',
 'Training-only target/loss updates LoRA. Inference has neither target supervision nor parameter updates.',
 'Inference starts at noise and repeats latent denoising for the source Figure 3 count of 50 steps, then decodes.',
 'GPT4o segmentation evaluation is outside generation architecture and absent from this figure.'
 ],
 'attention_inset':{'order':['T0','I1a','I1b','T1','I2a','I2b','T2','t','xta','xtb'],'rows':'queries','columns':'keys','allowed_rule':'column <= row OR same image block in {I1,I2,xt}','values':'binary permitted/blocked, not measured weights'},
 'dimensions':{'width_mm':180,'height_mm':755/72*25.4,'primary_font_min_pt':8},
 'review_status':'Author source reconciliation and pixel inspection completed; independent review is owned by controller, not self-awarded'}
(R/'semantic_contract.json').write_text(json.dumps(contract,indent=2,ensure_ascii=False)+'\n')
notes=f'''# DiTFuse architecture redraw

Purpose: explain how two condition images, task text and a separate noisy output latent interact, while keeping training data construction distinct from inference.

Scientific caption is in `caption.txt` and page 2 of `page.pdf`; it is separate from these execution notes.

Source: Li et al., *Towards Unified Semantic and Controllable Image Fusion: A Diffusion Transformer Approach*, arXiv:2512.07170v1 (8 December 2025), associated DOI 10.1109/TPAMI.2025.3642842. Author manuscript, not a claim to the IEEE typeset version. PDF SHA256: `{sha(SOURCE)}`. Brief SHA256: `{sha(BRIEF)}`. Source image files are not part of the deliverable.

The actual original PDF pages 5, 6 and 7 were rasterized and opened for pixel inspection. The reference figure combines training/inference in a mirrored layout, with frozen snowflake markers and LoRA adaptation indicated separately. Fig.4 shows complementary/common corruption followed by an instruction-specific target pool. Fig.6 provides task tags, optional subtags and image delimiters. The original full pages were read at their actual rendering; method text on pp.4 and 8 was additionally extracted to resolve architecture context. No repository code was read. Any code-level discrepancy here comes from the supplied brief.

Original inspected paths (subsequently moved outside outputs as requested): `outputs/source-reading/page-5.png`, `page-6.png`, `page-7.png`. Current reference paths: `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/reference-inspection/ditfuse2026/page-5.png`, `page-6.png`, `page-7.png`. Original PDF is unchanged.

Design: a vertical four-panel explanatory composition was selected over mirrored train/infer architectures so that the common operator is shown once, with its two uses explicitly named. A holds the token/DiT topology; B resolves directional attention; C contains supervision construction; D contains sampling. Teal marks image conditions/decoding, purple text, amber output states/supervision and blue the shared network. Names, borders, panel letters and line styles carry meaning independently of color. Solid arrows are data or sampling flows. Dashed amber edges concern trainable parameters; the inference loop is solid. Two input images are schematic tile glyphs, not real examples. The attention matrix encodes permissions exactly for a deliberately small schematic sequence.

Physical dimensions: 180 mm wide × {755/72*25.4:.6f} mm high. PDF MediaBox is {180/25.4*72:.6f} × 755 points. Labels are 8–10.5 pt; the embedded figure on the A4 page is placed at exactly 180 mm width and 1:1 scale. No shrinking to fit. Caption has its own second A4 page. Font: DejaVu Sans for editable figure text, embedded in PDF. Figure.svg retains text nodes; the Python source controls geometry and labels.

Source choices and limits: author-paper LoRA applies to all linear layers with r=64, alpha=0.5. The brief reports training-code differences (qkv_proj/o_proj and lora_alpha=rank), so code equivalence is not asserted. The explicit hybrid attention rule is authoritative over broad prose about text queries. Target-image x in Eq.4 is represented as its VAE latent in this latent-model diagram; the caption makes this notation bridge explicit. The schematic does not claim all training is unsupervised: M3, control, segmentation and fusion each have target construction. No benchmark values, empirical outputs, runtime results or evaluator model are drawn. Sampling integrator, per-layer internals and tensor projection implementation are abstracted, not invented. Submission-format compliance beyond the assigned width/font constraint is unverified.

Actual iteration record: initial color, grayscale, full-page and caption-page PNGs were all opened. Dark panel badges hid the A–D letters; encoder labels had tight horizontal padding; separate target arrows misleadingly singled out M3 for interpolation and fusion for loss. The actual first outputs, source and issues are preserved in `iterations/01/`. Revision made panel letters white, shortened patch-label text and joined all four alternative targets into one selected/encoded target bus. The revised color, grayscale, full-page and caption-page PNGs were all opened again. Letters now contrast; label baselines and node padding are clear; attention cells and axes remain distinct in grayscale; selected-target bus feeds both interpolation and loss; the inference loop returns to the model and the final latent alone feeds the decoder. No overlaps or clipping were observed in these final actual pixels. This is a maker inspection, not independent grading.

Exact final inspected paths:
- `{R/'figure.png'}`
- `{R/'grayscale.png'}`
- `{R/'page.png'}`
- `{R/'caption-page.png'}`

Rebuild from any directory: `python {R/'build.py'}`. For a relocated bundle, run `python /path/to/bundle/build.py`; outputs resolve beside the script. The only content input for the build is the adjacent `caption.txt`. Dependencies and actual versions are in `dependencies.json`. No install, GPU or network was used. `python {R/'write_metadata.py'}` writes the source-audit metadata and technical checks and requires the pinned source paths; it is not needed to redraw the figure.

Actual execution was routed through the controller proxy. Own proxy records available at execution time are copied into `proxy-logs/`; the terminal outputs and exit codes are real, including failed exploratory dependency/path lookups and one quoting error before the iteration backup. Tool actions are a self-authored list, not token or cost measurements. Platform model tokens/cost are unknown. Independent scientific and visual review remains the controller's separate responsibility.
'''
(R/'figure_notes.md').write_text(notes)
records=['e30e3441-7fe6-46d8-9d0b-aa3464e30492','4f761635-62ac-4d6e-8e3a-24cd0442378f','1d2f2fab-f777-4f5a-84ae-ae84b39053d0','896c9cba-f974-4eba-a245-8bafd13c2cbc','4f3e276a-09ae-44ed-8feb-1a2df3f150fd','e708625e-3fe9-4638-96d7-5d85bd5d116b','ef2a6e92-91f5-4de8-88f5-379b062ee998','a338ed38-45c5-497e-a651-cb4edf7417f6','fca1b9ab-ac57-43a4-80d4-e0a876ef6fa6']
(R/'proxy-logs').mkdir(exist_ok=True)
for r in records:
 p=BASE/f'modern-architecture-controller/run/host/ditfuse2026-proxy-{r}.json'
 if p.exists():shutil.copy2(p,R/'proxy-logs'/p.name)
actions=[{'action':'read_protocol_task_skill','mechanism':'exec_command (initial read, before START writing authorization)','result':'protocol/task/skill read; first guessed brief path absent'},
 {'action':'read_skill_contracts_and_brief','mechanism':'controller proxy','records':records[:5]},
 {'action':'view_original_pixels','mechanism':'view_image','paths':[str(BASE/f'modern-architecture-controller/run/cases/ditfuse2026/attempts/0001/outputs/source-reading/page-{i}.png') for i in [5,6,7]],'later_moved_to':str(BASE/'modern-architecture-controller/reference-inspection/ditfuse2026')},
 {'action':'write_original_source_and_caption','mechanism':'apply_patch','paths':['build.py','caption.txt']},
 {'action':'initial_render','mechanism':'controller proxy','record':records[5]},
 {'action':'view_initial_pixels','mechanism':'view_image','paths':[str(R/f) for f in ['figure.png','grayscale.png','page.png','caption-page.png']],'preserved_at':'iterations/01, except unchanged caption-page render'},
 {'action':'preserve_initial_iteration','mechanism':'controller proxy','records':records[6:8]},
 {'action':'revise_readability_and_target_routing','mechanism':'apply_patch','paths':['build.py','caption.txt']},
 {'action':'rebuild_final','mechanism':'controller proxy','record':records[8]},
 {'action':'view_final_pixels','mechanism':'view_image','paths':[str(R/f) for f in ['figure.png','grayscale.png','page.png','caption-page.png']]},
 {'action':'write_semantics_notes_logs_and_technical_report','mechanism':'apply_patch + controller proxy','paths':['write_metadata.py','semantic_contract.json','figure_notes.md','tool-actions.json','technical-check.json']}]
(R/'tool-actions.json').write_text(json.dumps({'list_type':'self-authored observed actions, not platform transcript','platform_tokens':None,'platform_cost':None,'actions':actions},indent=2)+'\n')
pdf=fitz.open(R/'figure.pdf'); p=pdf[0]; spans=[s for b in p.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
root=ET.parse(R/'figure.svg').getroot(); ns={'svg':'http://www.w3.org/2000/svg'}
check={'pdf_media_box_pt':list(p.rect),'pdf_images':len(p.get_images()),'pdf_vector_drawings':len(p.get_drawings()),'minimum_text_size_pt':min(s['size'] for s in spans),'svg_text_elements':len(root.findall('.//svg:text',ns)),'svg_external_images':len(root.findall('.//svg:image',ns)),'semantic_nodes':len(nodes),'semantic_edges':len(edges),'all_edge_endpoints_exist':all(e['source'] in {n['id'] for n in nodes} and e['target'] in {n['id'] for n in nodes} for e in edges),'generated_hashes':{f:sha(R/f) for f in ['figure.pdf','figure.svg','figure.png','grayscale.png','page.pdf','page.png']},'review_boundary':'Technical observations do not certify scientific quality or independent review.'}
(R/'technical-check.json').write_text(json.dumps(check,indent=2)+'\n')
print(json.dumps(check,indent=2))

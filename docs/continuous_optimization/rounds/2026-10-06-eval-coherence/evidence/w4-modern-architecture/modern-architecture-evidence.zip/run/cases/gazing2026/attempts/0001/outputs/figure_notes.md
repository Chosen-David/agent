# AutoGaze mechanism redraw

Original editable explanatory diagram, FIG-gazing2026-autogaze. The question is how AutoGaze selects patches before the downstream ViT while adapting the number of selections per frame.

## Scientific caption

AutoGaze selects multi-scale patches before the downstream vision transformer. **A:** For every spatiotemporal tile, a lightweight convolutional encoder processes frames sequentially. An autoregressive transformer conditions on current/past frame features and the selected-index prefix. Its patch-index head selects a scale and location; its reconstruction-loss head predicts the loss after that selection. Gazing continues until the predicted loss falls below the user threshold, then advances to the next frame. Multiple index/loss heads are an optional variant that retains history. **B:** Gazed tile positions are merged. Frames and positional embeddings are interpolated per scale, patch embeddings are produced per scale, and the selected tokens from all 16 frames form one downstream ViT sequence before feeding the MLLM. **C:** Greedy-search sequence pre-training uses index cross-entropy and squared reconstruction-loss prediction error. Subsequent on-policy GRPO uses negative actual reconstruction loss as reward and auxiliary loss prediction supervision at each frame's last selected patch. A custom block-causal VideoMAE supplies the training reconstruction objective. The input depiction is schematic; no empirical gaze result or benchmark is shown.

## Source and version

Baifeng Shi, Stephanie Fu, Long Lian, Hanrong Ye, David Eigen, Aaron Reite, Jan Kautz, Boyi Li, David M. Chan, Trevor Darrell, Pavlo Molchanov, and Hongxu Yin. *Attend Before Attention: Efficient and Scalable Video Understanding via Autoregressive Gazing.* CVPR 2026, CVF accepted-paper open-access version, pp. 17022–17034. This is the accepted-version author list, not arXiv v1's different list.

PDF: https://openaccess.thecvf.com/content/CVPR2026/papers/Shi_Attend_Before_Attention_Efficient_and_Scalable_Video_Understanding_via_Autoregressive_CVPR_2026_paper.pdf

SHA256: `7ccb3e8de6ec4731c294e6894d3f61b5ed15b0d3a1e139f934a0b1c7f93e9d11` (checked against the authorized original).

Actually read physical PDF pages 3–5, printed 17024–17026: Sec. 3 objective and 3.1, Fig. 3 and caption, Sec. 3.2 Eqs. 3–4, and Sec. 3.3. Original page images were opened at:

- `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/reference-inspection/gazing2026/page-3.png`
- `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/reference-inspection/gazing2026/page-4.png`
- `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/reference-inspection/gazing2026/page-5.png`

The source PDF and its rendered pages remain outside deliverables. None is pasted into the redraw. The provided source brief is supplementary evidence; G1–G8 are mapped in the semantic contract.

## Design choices and reference analysis

Fig. 3's wide, interleaved two-frame decoder illustration makes history prominent, but its compact training region and numeric loss examples can obscure the predicted-versus-actual distinction. This redraw uses three vertically ordered panels: detailed per-tile inference, compact downstream integration, and separate training. The explicit decision node makes per-frame stopping visible. Source photos are replaced with a labeled schematic frame input; illustrative loss values are omitted. A possible single horizontal chain was rejected because it conceals feedback and leaves the training/inference boundary ambiguous.

The vocabulary labels name **image resolutions**, avoiding the erroneous interpretation of four patch sizes. No Appendix-v1-only candidate-count claim is imported. Color uses pale teal for inference/data modules, gold for vocabulary/stopping quantities, and lilac for training. Line styles redundantly encode solid data/index feedback, dashed control, and dotted training relations. The dotted connection marked “then” denotes stage order within training. Line crossings have white gaps and do not denote junctions. Panel handoff labels link selected patches to panel B without a long connector through the optional-head inset.

Dimensions: **180 × 242.0056 mm**. PDF has a 510.23622 × 686 pt vector page. Primary labels are 8.2–12 pt; the smallest source note is 8.1 pt. The A4 page preview embeds the figure at exactly 180 mm width with no scaling. Figure uses Helvetica in PDF and editable sans-serif text in SVG. No external image assets, generated photographs, or copied figure geometry are used.

## Inspection and revisions

Build 1 rendered successfully. I opened `figure.png` and observed the yes/advance-frame text crossing the upward patch-lookup arrow; several necessary line crossings lacked clear gaps. The original render/source are retained in `iterations/01/`. A first archival command failed due to a quoting error; a corrected archival command preserved the original SVG/PDF/PNG before rebuilding. Build 2 moved the yes label, added non-junction crossing gaps, and labeled training-stage order.

Actually opened the final absolute paths:

- `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/run/cases/gazing2026/attempts/0001/outputs/figure.png`
- `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/run/cases/gazing2026/attempts/0001/outputs/grayscale.png`
- `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/run/cases/gazing2026/attempts/0001/outputs/page.png`

Observed after revision: the yes label no longer touches the gather arrow; solid index feedback enters history and the dashed continuation enters the decoder; the separated frame-advance path returns to current-frame input. Gray preview retains legible text and distinguishes dashed/dotted/solid paths even though pastel fills converge. The whole-page view preserves readable labels, a full caption, and margins without visible clipping. The figure is intentionally tall to preserve 8+ pt labels rather than compressing a full method into one narrow strip. No color-vision simulation was performed. Independent scientific and visual review is the controller's next step, not claimed here.

## Rebuild

From this directory, run:

```sh
python build.py
```

The build source resolves all outputs relative to itself and uses no source-PDF dependency, network, GPU, or downloaded assets. It emits `figure.svg`, `figure.pdf`, `figure.png`, `grayscale.png`, `page.pdf`, `page.png`, and `dependencies.json`. Actual installed dependencies: ReportLab 4.4.9, PyMuPDF 1.26.6, Pillow 12.3.0; no package installation was performed. The editable SVG and PDF are drawn from the same operator calls. The PDF contains zero embedded raster images. PNG rendering is 2.5 pixels/point; the page preview is 1.6 pixels/point.

The actual build was executed through the authorized logged proxy with `argv=["python","build.py"]` and this output directory as `cwd`. Both builds returned exit code 0. `tool-actions.json` is a self-authored action list, not a platform transcript, token count, or independent grade.

Final technical validation (`validation.json`) parsed the SVG XML and matched all 19 semantic node IDs. Extracted PDF text sizes have a minimum of 8.10000038 pt, the actual PDF width is 179.99999491 mm, and there are no raster images. A copy of `build.py` alone was rebuilt in a fresh temporary directory from a different working directory; it exited 0 and produced a byte-identical `figure.svg`. No source PDF, original pixels, or raw proxy log was copied into these deliverables.

## Limits and interpretation

The strict `< epsilon` threshold follows the main text; original Fig. 3 uses an illustrative `<= 0.7`. Equality behavior and actual reconstruction quality are not experimentally guaranteed here. The objective is weighted pixel and perceptual loss against the original video; its weights, GRPO return expansion, and implementation-specific capacities are omitted because they are not necessary to explain this mechanism. Block-causal reconstruction is named rather than inventing a detailed attention mask absent from the inspected pages. This is a scientific diagram, not a reproduction of model performance or an implementation of AutoGaze. Venue-specific submission compliance is unverified; final width and label-size requirements were implemented directly.

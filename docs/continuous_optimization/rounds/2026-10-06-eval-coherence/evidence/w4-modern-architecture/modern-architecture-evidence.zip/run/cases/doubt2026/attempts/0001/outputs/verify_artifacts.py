"""Small local inspection of exported files; does not replace pixel review."""
from pathlib import Path
import json, xml.etree.ElementTree as ET, fitz, hashlib, shutil
p=Path(__file__).resolve().parent
root=ET.parse(p/'figure.svg').getroot()
ids=[e.attrib['id'] for e in root.iter() if 'id' in e.attrib]
contract=json.loads((p/'semantic_contract.json').read_text())
doc=fitz.open(p/'figure.pdf')
spans=[s for b in doc[0].get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans']]
check={
    'svg_xml_parses':True,
    'svg_ids_unique':len(ids)==len(set(ids)),
    'semantic_node_ids_in_svg':all(n['id'] in ids for n in contract['nodes']),
    'semantic_edge_ids_in_svg':all(e['id'] in ids for e in contract['edges']),
    'pdf_image_count':len(doc[0].get_images()),
    'pdf_min_text_pt':min(s['size'] for s in spans),
    'pdf_fonts':[f[3] for f in doc[0].get_fonts()],
    'width_mm':doc[0].rect.width*25.4/72,
    'png_hashes':{n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['figure.png','grayscale.png','page.png']}
}
(p/'technical_check.json').write_text(json.dumps(check,indent=2)+'\n')
license_file=Path('/usr/share/doc/fonts-dejavu-core/copyright')
if license_file.exists(): shutil.copyfile(license_file,p/'fonts'/'LICENSE.txt')
print(json.dumps(check,indent=2))

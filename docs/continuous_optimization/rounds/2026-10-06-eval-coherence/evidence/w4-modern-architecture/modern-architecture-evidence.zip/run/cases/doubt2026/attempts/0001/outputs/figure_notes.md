# DOUBT architecture — original reference-hidden redraw

Artifact ID: doubt2026-architecture-attempt-0001. Evidence class: literature-grounded conceptual architecture, not measured output. Pinned skill: `run/snapshot/plugins/research-assistant/skills/research-diagrams/SKILL.md` plus workflow, figure_shared, execution and paper_exemplar_learning section 7. The explicit heldout task overrides exemplar-paper viewing: no original paper, figure, website, repository, evaluator material, or other case was opened.

## Scientific caption

DOUBT uses one black-box MLLM to collect K direct responses and K responses conditioned on object recognition. The bridged prompt preserves both image I and original instruction t. Each response is embedded by the same frozen nli-roberta-large model and normalized to unit length. The norm of the sum of these unit vectors, divided by K, is computed separately for each response set. Their two scalar resultant lengths are averaged to give R_avg. R_avg > θ gives flag 1 (non-hallucinatory), while R_avg ≤ θ gives flag 0 (hallucination). This is a detection estimate, not a truth guarantee. The low-temperature reference answer A is assessed against ground truth only in offline evaluation and does not enter the score. Object-recognition errors can propagate.

Source: supplied grounded method brief D1–D8, citing *DOUBT: Decoupled Object-level Understanding and Bridging via vMF-based Trustworthiness for Hallucination Detection in MLLMs*, PMLR 306 (2026), pp. 16418–16441; Sections 3.1–3.3, Eqs. 4–6 and Algorithm 1. Source URL retained as identity only: https://proceedings.mlr.press/v306/chen26dl.html . Original PDF was deliberately not accessed.

- Brief absolute path: `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/run/cases/doubt2026/inputs/doubt2026/source-brief.md`
- Brief SHA256, measured locally: `809cc40e7778074e12b1a6ba6a236f17ea77b33b8557aa2d2a3d531eef949683`
- Official 24-page PDF SHA256, supplied but not independently checked: `635ee9cfbfd752499fe22f8d0ba934a9617b68409d606719d76e6123f9f44b68`

## Design and mapping

The top panel separates direct and object-bridged sampling, preserving the original-input bypass into bridging. The middle panel exposes the method's critical reduction order rather than hiding it inside a scoring box. The O/B badges continue the exact same response sets across panels and prevent long crossing arrows. A single purple encoder box, divided into two lanes, communicates shared frozen parameters without pooling the sets. An operator inset explicitly states normalize → sum → norm → divide, performed per set. The bottom dashed boundary isolates offline correctness evaluation. This is a logical grouping, not a hardware, model-training, or deployment boundary. M appears in all relevant calls to preserve model identity; there is no extra model introduced for object recognition.

Blue identifies the direct set and teal the bridged set; their names, lane positions and O/B labels preserve identity in grayscale. Solid arrows carry inference/scalar data; dashed arrows carry offline evaluation data. The only image is an original labeled schematic icon. No empirical examples or performance numbers appear. A compact one-row alternative was rejected in planning because it would either shrink labels below 8 pt or obscure the retained image/question and per-set reductions.

Physical size: **180 × 220.941176 mm**. PDF MediaBox: approximately 510.2362 × 626.2899 pt. Figure text ranges from 8.0037 to 12.0056 pt; primary equations and labels are mainly 8.5–10 pt before the 1.00046 scale. The A4 page embeds the vector figure at exactly 180 mm, without further downscaling. Caption is 8.1 pt. DejaVu Sans regular/bold fonts are bundled; PDF embeds font subsets and the SVG retains editable text. The SVG uses no raster images, filters, external resources, or marker definitions; arrowheads are explicit vector polygons.

## Actual observations and revisions

1. The first command build failed on ReportLab's `HexColor('white')`; changed only the parser to `toColor`. The failure is summarized in `iterations/01-build-failure.md`; no pre-failure rendered artifact existed.
2. Opened the first successful color render with view_image. The phrase “independent resultant lengths” risked claiming statistical independence. Changed it to “separate” and added the detection-estimate limitation. The before image, SVG and source are preserved under `iterations/02-before-wording/`. No scientific edge, formula or flag polarity changed.
3. Opened **all final pixel artifacts**, individually displayed in the view_image output:
   - `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/run/cases/doubt2026/attempts/0001/outputs/figure.png`
   - `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/run/cases/doubt2026/attempts/0001/outputs/grayscale.png`
   - `/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/run/cases/doubt2026/attempts/0001/outputs/page.png`

Observed final color pixels: the image/question bypass reaches bridging, object list r reaches the correct call, O/B answer-set continuations match the two embedding rows, and both scalar-resultant arrows reach the mean. Threshold inequality and flag polarity are legible. No label overflow, missing glyph or clipped arrowhead was observed. The direct resultant route runs close to the right figure edge but remains inside it. Grayscale pixels: color distinctions become similar, but explicit lane names, O/B labels, formulas and dashed offline arrows preserve interpretation. Full-page pixels: the 180 mm figure, offline block and complete caption fit within A4 margins; no caption clipping. The lower line of the operator inset has tight but visible clearance from its border. These are maker observations, not an independent review or score.

Scientific check against the supplied brief: D1–D8 are mapped in `semantic_contract.json`; the panel C grouping indicates offline use of A, not that reference generation must temporally occur after detection. Prompt concatenation uses ‖ in the bridge call and is explicitly defined there; norm notation is scoped to panel B equations. The repeated sets have K members, but no statistical independence of their scores is asserted. No gold-answer input, retrieval database, gradient or training stage feeds detection.

## Source conflicts and limits

- The supplied source notes inconsistent use of “uncertainty.” The figure follows the explicit equation/algorithm polarity: high R_avg is trustworthiness and flag 1.
- The finite-sample estimator is not labeled unbiased; this property has not been verified.
- Reported K=10, reference temperature=0.1, sample temperature=0.5, top-k=10, top-p=0.99 and θ=0.48 remain caption context, not hardwired architecture constants.
- Original source figures remain hidden by instruction. No model run, performance reproduction, external-source verification, color-vision simulation, venue-template compliance assessment, or independent scientific/visual review is claimed. Independent review is deferred to the controller.

## Rebuild and deliverables

Portable command from this directory: `python build.py`. The source needs only the versions listed in `requirements.txt` and bundled `fonts/`; it performs no network access. The supplied source brief is optional for a relocated rebuild (the original measured hash remains documented here). Output size, actual dependencies and raster-image count are saved in `build_manifest.json`.

Exact command used under the controller protocol:

```sh
python /workspace/scratch/c12f3d9f92bd/modern-architecture-controller/proxy.py <<'JSON'
{"case":"doubt2026","argv":["python","/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/run/cases/doubt2026/attempts/0001/outputs/build.py"],"cwd":"/workspace/scratch/c12f3d9f92bd/modern-architecture-controller/run/cases/doubt2026/attempts/0001/outputs","timeout":180}
JSON
```

The final rebuild completed with exit code 0. `figure.pdf` contains zero raster images; figure previews are generated from that vector PDF using PyMuPDF. `page.pdf` embeds the vector PDF directly. Deliverables: `figure.svg`, `figure.pdf`, `figure.png`, `grayscale.png`, `page.pdf`, `page.png`, `build.py`, `fonts/`, `requirements.txt`, `build_manifest.json`, `semantic_contract.json`, this note, `tool-actions.json`, and preserved iterations. Proxy logs remain controller-owned and are not copied into this output.

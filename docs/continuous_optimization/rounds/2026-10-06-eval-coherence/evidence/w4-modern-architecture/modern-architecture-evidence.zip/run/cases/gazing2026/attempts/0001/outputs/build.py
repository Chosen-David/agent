"""Original AutoGaze mechanism redraw. Run: python build.py (CPU, offline)."""
from pathlib import Path
import json, math, html, hashlib, importlib.metadata
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
import fitz
from PIL import Image

ROOT=Path(__file__).resolve().parent
W,H=510.23622,686
INK='#21313D'; MUTED='#546470'; BLUE='#176F8C'; TEAL='#DDF0F1'; GOLD='#FCEDD0'; PURPLE='#EEE6F5'; LINE='#9AAAB2'; WHITE='#FFFFFF'
c=canvas.Canvas(str(ROOT/'figure.pdf'),pagesize=(W,H),pageCompression=1)
c.setTitle('AutoGaze: autoregressive multi-scale patch selection')
parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="180mm" height="{H/W*180:.5f}mm" viewBox="0 0 {W} {H}">', '<title>Original explanatory redraw of AutoGaze</title>']
def rect(x,y,w,h,fill=WHITE,stroke=LINE,r=5,id=None,dash=None):
    c.setFillColor(HexColor(fill)); c.setStrokeColor(HexColor(stroke)); c.setLineWidth(.75); c.setDash(dash or [])
    c.roundRect(x,H-y-h,w,h,r,stroke=1,fill=1)
    parts.append(f'<rect '+(f'id="{id}" ' if id else '')+f'x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="0.75"'+(f' stroke-dasharray="{",".join(map(str,dash))}"' if dash else '')+'/>')
def text(x,y,s,size=8.5,bold=False,color=INK,anchor='start'):
    c.setFillColor(HexColor(color)); c.setFont('Helvetica-Bold' if bold else 'Helvetica',size)
    {'start':c.drawString,'middle':c.drawCentredString,'end':c.drawRightString}[anchor](x,H-y,s)
    parts.append(f'<text x="{x}" y="{y}" font-family="Arial,Helvetica,sans-serif" font-size="{size}" font-weight="{700 if bold else 400}" fill="{color}" text-anchor="{anchor}">{html.escape(s)}</text>')
def lines(x,y,ss,size=8.5,bold=False,color=INK,anchor='start',leading=12):
    for i,s in enumerate(ss): text(x,y+i*leading,s,size,bold,color,anchor)
def edge(points,kind='data',id=None):
    color=PURPLE if False else ('#7B558F' if kind=='training' else BLUE if kind=='control' else INK)
    dash=[4,2.5] if kind=='control' else [1.5,2.5] if kind=='training' else []
    c.setStrokeColor(HexColor(color)); c.setLineWidth(1); c.setDash(dash)
    p=c.beginPath(); p.moveTo(points[0][0],H-points[0][1])
    for x,y in points[1:]: p.lineTo(x,H-y)
    c.drawPath(p)
    a,b=points[-2:]; ang=math.atan2(b[1]-a[1],b[0]-a[0]); L=4.5
    tips=[b,(b[0]-L*math.cos(ang-.5),b[1]-L*math.sin(ang-.5)),(b[0]-L*math.cos(ang+.5),b[1]-L*math.sin(ang+.5))]
    p=c.beginPath(); p.moveTo(tips[0][0],H-tips[0][1]); [p.lineTo(x,H-y) for x,y in tips[1:]]; p.close(); c.setFillColor(HexColor(color)); c.drawPath(p,stroke=0,fill=1)
    parts.append('<g '+(f'id="{id}"' if id else '')+'><polyline points="'+' '.join(f'{x},{y}' for x,y in points)+f'" fill="none" stroke="{color}" stroke-width="1"'+(f' stroke-dasharray="{",".join(map(str,dash))}"' if dash else '')+'/><polygon points="'+' '.join(f'{x},{y}' for x,y in tips)+f'" fill="{color}"/></g>')
def box(id,x,y,w,h,ss,fill=WHITE,size=8.5):
    rect(x,y,w,h,fill=fill,id=id); lines(x+w/2,y+(h-(len(ss)-1)*12)/2+3,ss,size=size,anchor='middle')
def crossing(x,y,vertical=True,color=INK,dash=False):
    # White halo: unconnected crossing. Redraw only the foreground segment.
    pts=[(x,y-4),(x,y+4)] if vertical else [(x-4,y),(x+4,y)]
    for width,ink in [(3.8,'#F8FBFC'),(1,color)]:
        c.setStrokeColor(HexColor(ink)); c.setLineWidth(width); c.setDash([4,2.5] if dash and width==1 else [])
        c.line(pts[0][0],H-pts[0][1],pts[1][0],H-pts[1][1])
        parts.append(f'<polyline points="{pts[0][0]},{pts[0][1]} {pts[1][0]},{pts[1][1]}" fill="none" stroke="{ink}" stroke-width="{width}"'+(' stroke-dasharray="4,2.5"' if dash and width==1 else '')+'/>')
def title(letter, y, s):
    rect(0,y,19,19,INK,INK,3); text(9.5,y+13.5,letter,10,True,WHITE,'middle'); text(27,y+13.5,s,10,True)

text(0,12,'AutoGaze',12,True); text(68,12,'Select multi-scale patches before the downstream ViT',10,color=MUTED)
title('A',26,'Inference: frame-by-frame gazing within each tile')
text(0,60,'Any-length / resolution video',8.5,True)
edge([(156,56),(179,56)])
box('tiles',181,46,159,29,['Tile into 16 x 224 x 224 blocks'],TEAL,8.3)
edge([(342,60),(362,60)])
text(367,63,'Repeat panel A per tile',8.3)
rect(0,85,W,266,'#F8FBFC',LINE,7,id='inference_group')
text(13,101,'Frame t',9,True)
box('frame',13,110,98,44,['Current frame X(t)','(schematic input)'],WHITE)
box('encoder',137,110,108,44,['Lightweight','convolutional encoder'],TEAL,8.2)
box('frame_history',282,110,211,44,['Frame feature history: X(1), ..., X(t)','Encode only after advancing to frame t'],TEAL,8.3)
edge([(111,132),(137,132)],id='frame_to_encoder'); edge([(245,132),(282,132)],id='encoder_to_features')

box('history',13,188,110,49,['Selected-index history','prior frames + current','frame prefix'],TEAL,8.2)
box('decoder',156,188,139,49,['Autoregressive','transformer decoder'],TEAL,9)
edge([(123,212),(156,212)],id='history_to_decoder')
edge([(340,154),(340,169),(225,169),(225,188)],id='features_to_decoder')
text(349,176,'current + past only',8.2,color=MUTED)
box('index_head',340,191,153,34,['Patch-index head: p(t,k)'],TEAL,8.7)
box('loss_head',340,243,153,34,['Loss head: predicted l_hat(t,k)'],GOLD,8.2)
edge([(295,203),(340,203)],id='decoder_to_index')
edge([(295,223),(315,223),(315,260),(340,260)],id='decoder_to_loss')
edge([(416,191),(416,181),(68,181),(68,188)],id='index_feedback')
text(91,176,'append selected index',8.2,color=MUTED)

rect(13,257,110,78,GOLD,LINE,5,id='vocabulary')
lines(20,271,['Multi-scale vocabulary','Image resolutions (px):','32, 64, 112, 224','Each index identifies a','scale and patch position.'],8.2,leading=12)
box('selected',156,265,139,47,['Gather selected patches','using scale + position','Accumulate across frames'],TEAL,8.2)
edge([(123,290),(156,290)],id='vocabulary_to_gather')
edge([(493,208),(502,208),(502,341),(225,341),(225,312)],id='index_to_gather')
text(291,336,'index-to-patch lookup',8.2,color=MUTED)
box('stop',340,293,153,34,['Predicted loss < epsilon?'],GOLD,8.6)
edge([(416,277),(416,293)],'control',id='predicted_loss_to_stop')
edge([(340,310),(322,310),(322,247),(225,247),(225,237)],'control',id='continue_gazing')
text(261,260,'no',8.2,color=BLUE)
text(350,290,'user threshold',8.2,color=BLUE)
text(17,345,'yes: stop frame; advance t',8.2,color=BLUE)
edge([(365,327),(365,349),(5,349),(5,132),(13,132)],'control',id='advance_frame')
crossing(225,181)
crossing(315,247,True)
crossing(365,341,False)

rect(0,362,W,39,WHITE,LINE,5,id='multi_token')
text(10,376,'Optional multi-token prediction',8.5,True)
text(10,391,'Several heads emit multiple indices and matching predicted losses per decoder step.',8.4)
text(291,376,'The autoregressive history is retained.',8.2,color=MUTED)

title('B',414,'Downstream: merge positions, embed selected patches, then attend')
box('merge',0,447,103,54,['Merge tile positions','Selected multi-scale','patches'],TEAL,8.2)
box('embedding',121,447,179,54,['Interpolate frames + position embeddings','to each scale; patch-embed per scale','Retain selected patch tokens'],TEAL,8.2)
box('vit',320,447,102,54,['Downstream ViT','One sequence from','all 16 frames'],TEAL,8.2)
box('mllm',440,447,70,54,['MLLM','Encoded','visual tokens'],TEAL,8.2)
edge([(103,474),(121,474)],id='merge_to_embeddings'); edge([(300,474),(320,474)],id='embeddings_to_vit'); edge([(422,474),(440,474)],id='vit_to_mllm')
text(0,441,'Panel A outputs from all tiles',8.2,color=MUTED)

title('C',519,'Training only: measured reconstruction loss supervises the policy')
box('reconstruction',0,550,170,47,['Selected patches -> custom VideoMAE','Block-causal reconstruction','Actual pixel + perceptual loss'],PURPLE,8.2)
box('stage1',193,550,148,62,['1  Next-token pre-training','Greedy-search gaze sequences','Index cross-entropy','+ squared loss-prediction error'],PURPLE,8.2)
box('stage2',362,550,148,62,['2  On-policy GRPO','Reward: negative recon. loss','+ loss-head supervision','at each frame\'s last patch'],PURPLE,8.2)
edge([(170,574),(193,574)],'training',id='recon_to_stage1')
edge([(341,573),(362,573)],'training',id='stage1_to_stage2')
text(351,545,'then',8.2,color='#7B558F',anchor='middle')
edge([(84,597),(84,623),(436,623),(436,612)],'training',id='recon_to_stage2')
text(106,636,'Actual reconstruction is used for training; predicted loss controls inference.',8.4,color=MUTED)
text(0,613,'Targets / reward',8.2,color='#7B558F')
edge([(0,657),(27,657)]); text(33,660,'data / index feedback',8.2)
edge([(177,657),(204,657)],'control'); text(210,660,'stop / continue control',8.2)
edge([(361,657),(388,657)],'training'); text(394,660,'training supervision',8.2)
text(0,681,'Original mechanism schematic; not an empirical gaze example. Source: Shi et al., CVPR 2026, Fig. 3 and Sec. 3.',8.1,color=MUTED)

c.showPage(); c.save(); parts.append('</svg>'); (ROOT/'figure.svg').write_text('\n'.join(parts))
doc=fitz.open(ROOT/'figure.pdf'); doc[0].get_pixmap(matrix=fitz.Matrix(2.5,2.5),alpha=False).save(ROOT/'figure.png')
Image.open(ROOT/'figure.png').convert('L').save(ROOT/'grayscale.png')
page=fitz.open(); p=page.new_page(width=595.2756,height=841.8898)
p.insert_text((42.52,30),'AutoGaze mechanism overview',fontsize=11,fontname='hebo',color=(.13,.19,.24))
p.show_pdf_page(fitz.Rect(42.52,45,42.52+W,45+H),doc,0)
caption=('Figure. AutoGaze selects multi-scale patches before the downstream vision transformer. '
    '(A) Within each 16-frame tile, the decoder conditions on current/past frame features and selected-index history. '
    'Its predicted reconstruction loss controls stopping for each frame. (B) Tile positions are merged; scale-specific '
    'patch embeddings and interpolated positional embeddings supply one 16-frame token sequence to the ViT, then the MLLM. '
    '(C) Greedy-search next-token pre-training precedes on-policy GRPO. Actual block-causal VideoMAE reconstruction supplies '
    'training targets/reward. The strict threshold follows Sec. 3.1; it is not a quality guarantee. '
    'Original redraw from the CVF accepted version, pp. 17024-17026; width 180 mm. All inputs are schematic.')
p.insert_textbox(fitz.Rect(42.52,741,552.76,827),caption,fontsize=8.4,fontname='helv',lineheight=1.25,color=(.13,.19,.24))
page.save(ROOT/'page.pdf'); p.get_pixmap(matrix=fitz.Matrix(1.6,1.6),alpha=False).save(ROOT/'page.png')
versions={m:importlib.metadata.version(m) for m in ['reportlab','PyMuPDF','Pillow']}
(ROOT/'dependencies.json').write_text(json.dumps({'python':'3.x','packages':versions,'external_assets':[]},indent=2))
print(json.dumps({'build':'success','dimensions_mm':[180,round(H/W*180,4)],'minimum_label_pt':8.1,'pdf_pages':len(doc),'vector_pdf_images':len(doc[0].get_images()),'packages':versions},indent=2))

#!/usr/bin/env python3
"""Original vector DiTFuse mechanism redraw. CPU only; outputs beside this file."""
from pathlib import Path
import json, hashlib, platform
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, FancyArrowPatch
from matplotlib.path import Path as MPath
import fitz
from PIL import Image

ROOT=Path(__file__).resolve().parent
W=180/25.4*72
H=755
INK='#233344'; MUTED='#536574'; LINE='#526575'
TEAL='#177D84'; TP='#E8F3F2'; PURPLE='#70549A'; PP='#F0EBF7'
ORANGE='#A85B1B'; OP='#FFF0DF'; BLUE='#365F98'; BP='#ECF2FA'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5,'svg.fonttype':'none','pdf.fonttype':42})
fig=plt.figure(figsize=(W/72,H/72)); ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,W); ax.set_ylim(H,0); ax.axis('off')
def text(x,y,s,size=8.5,color=INK,ha='left',weight='normal',va='center',gid=None):
    a=ax.text(x,y,s,fontsize=size,color=color,ha=ha,va=va,fontweight=weight,linespacing=1.28)
    if gid:a.set_gid(gid)
    return a
def box(x,y,w,h,label='',fill='white',stroke=LINE,size=8.5,gid=None,dash=False,weight='normal'):
    r=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=4',facecolor=fill,edgecolor=stroke,linewidth=.85,linestyle=(0,(3,2)) if dash else '-')
    if gid:r.set_gid(gid)
    ax.add_patch(r)
    if label:text(x+w/2,y+h/2,label,size,ha='center',weight=weight)
def line(points,color=LINE,dash=False,arrow=True,lw=.9,gid=None):
    path=MPath(points,[MPath.MOVETO]+[MPath.LINETO]*(len(points)-1))
    p=FancyArrowPatch(path=path,arrowstyle='-|>' if arrow else '-',mutation_scale=8,linewidth=lw,color=color,linestyle=(0,(3,2)) if dash else '-',shrinkA=0,shrinkB=0)
    if gid:p.set_gid(gid)
    ax.add_patch(p)
def panel(y,h,letter,title,subtitle=''):
    box(2,y,W-4,h,fill='#FFFFFF',stroke='#CDD6DE')
    box(12,y+10,19,18,fill=INK,stroke=INK)
    text(21.5,y+19,letter,10,color='white',ha='center',weight='bold')
    text(39,y+19,title,10.5,weight='bold')
    if subtitle:text(W-14,y+19,subtitle,8,color=MUTED,ha='right')
def image_tile(x,y,label,variant=0):
    box(x,y,104,35,fill=TP,stroke=TEAL,gid='input_image1' if variant==0 else 'input_image2')
    for row in range(3):
        for col in range(4):
            shade=['#DCEBEA','#ABCBCB','#80AEB2','#F6FAFA'][(row+col+variant)%4]
            ax.add_patch(Rectangle((x+7+col*7,y+7+row*7),6,6,facecolor=shade,edgecolor=TEAL,linewidth=.25))
    text(x+65,y+18,label,8.5,ha='center')

panel(2,255,'A','One shared conditional velocity model','Schematic inputs')
image_tile(18,39,'Image I₁',0); image_tile(135,39,'Image I₂',2)
box(262,39,230,35,'[TASK] · optional <SUBTASK> · free text',fill=PP,stroke=PURPLE,gid='instruction')
box(18,88,104,35,'Frozen SDXL VAE\nPatch embed (p=2)',fill=TP,stroke=TEAL,gid='vae1')
box(135,88,104,35,'Frozen SDXL VAE\nPatch embed (p=2)',fill=TP,stroke=TEAL,gid='vae2')
box(262,88,230,35,'Phi-3 tokenizer + text embeddings',fill=PP,stroke=PURPLE,gid='text_encoder')
for x,c in [(70,TEAL),(187,TEAL),(377,PURPLE)]:line([(x,74),(x,88)],c)
line([(70,123),(70,137)],TEAL);line([(187,123),(187,137)],TEAL)
line([(280,123),(280,137)],PURPLE)
box(18,137,294,34,'Condition sequence c\n… <img>I₁</img> … <img>I₂</img> …',fill=TP,stroke=TEAL,size=8.2,gid='condition_sequence')
box(327,137,47,34,'Time\ntoken t',fill=OP,stroke=ORANGE,gid='time_token')
box(389,137,103,34,'Noisy target\ntokens xₜ',fill=OP,stroke=ORANGE,gid='noisy_target_tokens')
text(492,130,'t and xₜ: from C or D',8,color=ORANGE,ha='right')
for x in [165,350.5,440.5]:line([(x,171),(x,182)],arrow=False)
line([(165,182),(440.5,182)],arrow=False)
line([(194,182),(194,192)])
box(18,192,354,37,'DiT  ·  32 Transformer layers\nPretrained OmniGen / Phi-3 backbone — frozen',fill=BP,stroke=BLUE,gid='dit')
box(389,192,103,37,'LoRA · all linear\nr=64, α=0.5\ntrainable',fill=OP,stroke=ORANGE,size=8,gid='lora')
line([(389,210),(372,210)],ORANGE,dash=True)
line([(194,229),(194,242)],BLUE)
text(202,243,'Target tokens → latent velocity vθ(xₜ, t, c)',8.4,color=BLUE,gid='target_velocity')

panel(270,121,'B','Hybrid attention','Allowed dependencies, not scores')
cell=7.3; x0=88; y0=310
groups=[('T₀',0,1),('I₁',1,3),('T₁',3,4),('I₂',4,6),('T₂',6,7),('t',7,8),('xₜ',8,10)]
for r in range(10):
    for c in range(10):
        allowed=c<=r or any(a<=r<b and a<=c<b for a,b in [(1,3),(4,6),(8,10)])
        color=TEAL if allowed else '#FFFFFF'
        ax.add_patch(Rectangle((x0+c*cell,y0+r*cell),cell,cell,facecolor=color,edgecolor='#CBD6DB',linewidth=.35))
for label,a,b in groups:
    text(x0+(a+b)*cell/2,303,label,8,ha='center')
    text(x0-8,y0+(a+b)*cell/2,label,8,ha='right')
text(18,343,'Query\nrows',8.2)
text(178,315,'Key columns →',8.3,weight='bold')
text(178,335,'Across blocks: attend to earlier tokens only.',8.3)
text(178,353,'Inside I₁, I₂ and xₜ: bidirectional attention.',8.3)
text(178,371,'Target xₜ sees all conditions, t and its own block.',8.3)
text(320,303,'T₀ / T₁ / T₂ = interleaved text',8,color=MUTED)

panel(404,217,'C','Training only','Task-aware data + one flow-matching objective')
box(18,442,70,37,'Source\nimage',fill=TP,stroke=TEAL,gid='source_image')
box(102,442,255,37,'M3: duplicate → aligned patch grids\n75% complementary / 25% common corruption',fill=TP,stroke=TEAL,size=8.2,gid='m3')
box(376,442,116,37,'Two views I₁, I₂\n→ conditions in A',fill=TP,stroke=TEAL,size=8.3,gid='m3_views')
line([(88,460),(102,460)],TEAL);line([(357,460),(376,460)],TEAL)
text(229,489,'Noise mask, Gaussian noise or blur; grids: 16×16 / 32×32 / 64×64',8.1,color=MUTED,ha='center')
text(18,505,'Select target image by instruction',8.8,weight='bold')
labels=['M3\nOriginal source','Control\nBrightness / contrast','Segmentation\nBlue class overlay','Fusion\nTask-specific target*']
for i,l in enumerate(labels):box(18+120*i,516,114,29,l,fill=OP,stroke=ORANGE,size=8.1,gid=['target_m3','target_control','target_seg','target_fusion'][i])
for x in [75,195,315,435]:line([(x,545),(x,550)],ORANGE,arrow=False)
line([(75,550),(435,550)],ORANGE,arrow=False,gid='target_selection_bus')
line([(75,550),(75,569)],ORANGE)
text(254,559,'Selected target → frozen VAE → x',8,color=ORANGE,ha='center')
box(18,569,162,37,'xₜ = tx + (1 − t)ε\nε ~ N(0,1); t ∈ [0,1]',fill=OP,stroke=ORANGE,size=8.6,gid='interpolation')
box(197,569,104,37,'Shared model A\nvθ(xₜ, t, c)',fill=BP,stroke=BLUE,size=8.5,gid='training_call')
box(318,569,174,37,'L = E ‖(x − ε) − vθ‖²\nUpdates LoRA parameters in A',fill=OP,stroke=ORANGE,size=8.3,gid='velocity_loss')
line([(180,587),(197,587)],ORANGE);line([(301,587),(318,587)],BLUE)
line([(435,550),(435,569)],ORANGE)
text(443,560,'x − ε',8,color=ORANGE)
line([(405,606),(405,614),(248,614),(248,606)],ORANGE,dash=True)

panel(634,119,'D','Inference only','Fixed adapted weights; no loss or target image')
box(18,676,55,35,'Gaussian\nnoise x₀',fill=OP,stroke=ORANGE,gid='inference_noise')
box(88,676,100,35,'Shared model A\nI₁, I₂, text, t, xₜ',fill=BP,stroke=BLUE,size=8.1,gid='inference_call')
box(203,676,74,35,'Latent update\nusing vθ',fill=OP,stroke=ORANGE,size=8.3,gid='latent_update')
box(292,676,45,35,'Final\nlatent',fill=OP,stroke=ORANGE,size=8.2,gid='final_latent')
box(352,676,73,35,'Frozen VAE\ndecoder',fill=TP,stroke=TEAL,size=8.2,gid='vae_decoder')
box(440,676,52,35,'Output\nimage',fill=TP,stroke=TEAL,size=8.2,gid='output_image')
for a,b in [(73,88),(188,203),(277,292),(337,352),(425,440)]:line([(a,694),(b,694)])
line([(240,711),(240,735),(137,735),(137,711)],ORANGE)
text(190,726,'50 denoising steps',8.2,color=ORANGE,ha='center')
text(354,733,'Decode only the final target latent.',8,color=MUTED,ha='center')

fig.savefig(ROOT/'figure.svg',format='svg',facecolor='white')
fig.savefig(ROOT/'figure.pdf',format='pdf',facecolor='white')
plt.close(fig)
d=fitz.open(ROOT/'figure.pdf'); p=d[0]; p.get_pixmap(matrix=fitz.Matrix(2.5,2.5),alpha=False).save(ROOT/'figure.png')
Image.open(ROOT/'figure.png').convert('L').save(ROOT/'grayscale.png')
page=fitz.open(); p1=page.new_page(width=595.276,height=841.89)
p1.insert_text((42.52,25),'DiTFuse | architecture and learning mechanism',fontsize=10,fontname='helv',color=(.15,.2,.27))
p1.show_pdf_page(fitz.Rect(42.52,42,42.52+W,42+H),d,0)
p1.insert_text((42.52,816),'Original redraw • 180 mm figure width • caption and source notes on page 2',fontsize=8,fontname='helv',color=(.3,.35,.4))
p2=page.new_page(width=595.276,height=841.89)
caption=(ROOT/'caption.txt').read_text()
p2.insert_textbox(fitz.Rect(43,46,552,790),caption,fontsize=10.5,fontname='helv',lineheight=1.4,color=(.13,.18,.23))
page.save(ROOT/'page.pdf'); page[0].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False).save(ROOT/'page.png'); page[1].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False).save(ROOT/'caption-page.png')
versions={'python':platform.python_version(),'matplotlib':matplotlib.__version__,'PyMuPDF':fitz.VersionBind,'Pillow':Image.__version__}
(ROOT/'dependencies.json').write_text(json.dumps(versions,indent=2)+'\n')
print(json.dumps({'figure_pt':[W,H],'figure_mm':[180,H/72*25.4],'primary_font_pt_min':8,'PDF_pages':len(page),'dependencies':versions},indent=2))

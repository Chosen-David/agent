#!/usr/bin/env python3
"""Portable manuscript build: preserves the adjacent producer PDF files."""
from pathlib import Path
import hashlib, json, platform, subprocess
import fitz
ROOT=Path(__file__).resolve().parent
commands=[]
for i in range(2):
    argv=['pdflatex','-interaction=nonstopmode','-halt-on-error','-file-line-error','manuscript.tex']
    result=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True)
    (ROOT/f'latex-pass-{i+1}.txt').write_text(result.stdout+result.stderr)
    commands.append({'argv':argv,'cwd':str(ROOT),'exit_code':result.returncode})
    if result.returncode:
        (ROOT/'build-result.json').write_text(json.dumps({'commands':commands,'status':'failed'},indent=2))
        raise SystemExit(result.returncode)
pdf=ROOT/'manuscript.pdf'
doc=fitz.open(pdf)
pages=ROOT/'pages';pages.mkdir(exist_ok=True)
details=[]
for n,p in enumerate(doc,1):
    p.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(pages/f'page-{n:02}.png')
    details.append({'page':n,'size_pt':list(p.rect),'text_characters':len(p.get_text()),'raster_images':len(p.get_images())})
(ROOT/'manuscript.txt').write_text('\n\n'.join(p.get_text() for p in doc))
(ROOT/'build-result.json').write_text(json.dumps({'status':'built','commands':commands,'pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'page_count':len(doc),'pages':details,'python':platform.python_version(),'pymupdf':fitz.VersionBind},indent=2))
print(json.dumps({'status':'built','pages':len(doc),'pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest()}))

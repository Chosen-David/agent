from pathlib import Path
import sys,json,importlib.util,datetime,hashlib,uuid
B=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('pipeline',B/'pipeline.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
kind,cid,actor=sys.argv[1:4];run=B/(sys.argv[4] if len(sys.argv)>4 else 'run');host=run/'host';host.mkdir(exist_ok=True)
body=json.load(sys.stdin)
trust=p.read(B/'root-trust.json') if run.name=='run' else p.read(B/'writer-trust.json')
if kind=='authorize':
 result=p.authorize_dispatch(run,cid,actor,material_review=trust)
 p.write(host/f'{cid}-pre-spawn-authorization-{uuid.uuid4()}.json', {'planned_actor':actor,'trust':result,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'order':'before actual host spawn'})
 print(json.dumps(result));sys.exit(0)
if kind in ('start','complete'):
 attempt=body.pop('attempt',1)
 receipt={'event_id':f'controller-observed-{kind}-{cid}-{uuid.uuid4()}','kind':kind,'actor':actor,'adapter':'host','case_id':cid,'attempt':attempt,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event_id_boundary':'Controller record ID for actual observed host event, not an exported platform event ID','model':'unknown','tokens':'unknown','cost':'unknown',**body}
 path=host/f'{cid}-{attempt}-{kind}.json';p.write(path,receipt)
 result=p.record_start(run,cid,actor,path,material_review=trust) if kind=='start' else p.collect(run,cid,attempt,path)
 print(json.dumps(str(result) if kind=='start' else result))
elif kind=='grade':
 path=Path(body['path']);print(json.dumps(p.grade_attempt(run,cid,body.get('attempt',1),path)))

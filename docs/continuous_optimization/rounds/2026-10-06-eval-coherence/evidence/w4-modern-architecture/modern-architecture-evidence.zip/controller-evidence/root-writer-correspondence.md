# Root pre-dispatch material review

Six criteria read against actual accepted input artifacts, task and original critical source pages already inspected in this same batch. No consumer has executed or been graded yet.

## Criterion 1
The manuscript uses all three actual producer vector PDFs without altering them; a handoff receipt binds received and embedded file hashes and an executable inspection confirms their use.

Producer collection/grade bytes were freshly hashed, all12 criteria per accepted producer passed, and all3 figurePDF/contract/notes copied byte-identically. This criterion tests actual consumer use, not only receipt declaration.

## Criterion 2
AutoGaze explanation preserves selection before downstream ViT/MLLM, causal history, predicted-loss stopping and training-only actual reconstruction without unsupported empirical reproduction claims.

CVF accepted version Sec3.1–3.3/Fig3, root original pp3–5 and actual AutoGaze figure reviewed: selection precedes ViT, past/history is causal, predicted loss stopping distinct from training reconstruction. No reproduction requested.

## Criterion 3
DOUBT explanation preserves separate per-set normalized-vector resultant lengths then scalar averaging and correct threshold polarity, with no reference-answer or ground-truth leakage into detection.

Original DOUBT Eq4–5/Algorithm1 read by root, plus actual final color/grayscale/page: individual normalization, separate per-set norm of mean, scalar average; >theta flag1, <=theta flag0. Offline reference is downstream evaluation only.

## Criterion 4
DiTFuse explanation preserves condition/noisy-target separation, hybrid attention, training-only targets/M3 and repeated inference denoising, and explicitly scopes paper-versus-code LoRA discrepancy.

Original DiTFuse author v1 pp5–7 and source/code discrepancy checked by root; actual repaired figure and both final pages viewed. Conditional inputs vs noisy target, training M3/targets, inference recurrence and LoRA mismatch are valid scoped facts.

## Criterion 5
The substantive text explains mechanisms and contrasts in coherent scientific prose, with source/version citations and bounded claims; provenance/audit logs remain a separate companion artifact.

Task explicitly asks scholarly mechanism comparison and exact version citations, separate provenance companion; qualitative independent prose review required. No unsupported aesthetic or venue-success fact is embedded.

## Criterion 6
Editable source rebuilds the complete PDF successfully and every final page has been independently viewed at readable size; figures, captions and text contain no cropping, overlaps, missing glyphs or unsupported modifications.

Task explicitly asks editable source, compiled PDF and every rendered page inspection. Installed LaTeX/PDF pipeline exists from actual prior papers; this requires real rebuild/view, not existence or self-report.

# Towards Unified Semantic and Controllable Image Fusion: A Diffusion Transformer Approach

Source: https://ieeexplore.ieee.org/document/11297852/
Full text: https://arxiv.org/pdf/2512.07170v1
Version: arXiv2512.07170v1 author manuscript, associated DOI10.1109/TPAMI.2025.3642842; not claimed typeset IEEEversion
SHA256: 742a48d608dd1cdfdc4a9e144759e16d352851fb5d4bdcfd1adda9ba0d0cedac

## Architecture facts

**F1** Two distinct input images use VAE image encoding; instruction is tokenized. Conditions are combined with timestep and separate noisy target latent for DiT, not pre-added pixel fusion. (Fig.3 p.5; Sec.III-A pp.4–5; code model.forward)

**F2** Paper architecture uses32Transformer layers, pre-trained OmniGen/Phi3 base, LoRA adaptation; VAE remains frozen and trainable adaptations are distinguished from inference use. (Sec.III-A pp.4–5; Fig.3)

**F3** Condition images are represented as visual tokens inside image delimiters; timestep token and noisy target tokens follow the condition sequence in inspected code. Output target tokens alone are converted back to latent image, then VAE decoder. (Sec.III-A.2 p.5; model.forward314–357)

**F4** Hybrid attention is causal across sequence order but bidirectional inside an image block. Processor additionally allows output-image tokens to attend all earlier condition/time and own output tokens, never reverse future edges. (Sec.III-A.3 p.5; processor169–213)

**F5** Training uses target x and noise epsilon to form x_t=t*x+(1-t)*epsilon; predict velocity and squared loss against x-epsilon. Target enters loss/noisy-target construction, not as inference input. (Eqs.4–5 p.7)

**F6** M3 duplicates a source image into two views, uses complementary corruption on75%patches and common corruption on25%, with noise-mask/Gaussian-noise/blur; target is original source forM3. (Fig.4 p.6; Sec.III-B.2 p.7)

**F7** Multi-task targets depend on instruction: source forM3, brightness/contrast control target, semantic masked target, task-specific fusion targets. Distinguish this data construction from denoising network. (Fig.4/6 pp.6–7)

**F8** Inference starts from noise under two-image/text conditions, iterates denoising (Fig.3 labels50steps), and decodes output; no training target/loss or repeatedparameter-update loop during inference. (Fig.3 p.5)

**F9** GPT4o three-criterion segmentation evaluation in Fig.13 is outside DiTFuse model architecture. Do not add evaluator into generation loop. (Fig.13 p.12)

## Source boundaries and conflicts

- Author PDF header JOURNAL OF LATEX CLASS FILES2021 is template boilerplate, not publication date; citation uses DOI/issue identity.
- Paper Sec.III-A says LoRA all linear layers rank64 scaling0.5. Pinned train.py lines101–112 targets qkv_proj/o_proj with lora_alpha=lora_rank. Diagram must explicitly choose author-paper architecture and disclose this discrepancy, not assert exact code equivalence.
- Sec.III-A prose broadly describes text queries accessing image keys, but explicit hybrid-mask rule and pinned processor are causal across sequence blocks with within-image bidirectionality. Use that explicit rule; do not draw all-to-all intermodal attention.
- Source no-ground-truth claim concerns real fused targets; M3 has source-image targets and IVIF training mentions mean-fusion targets. Do not label all training unsupervised.

## Design brief

Explain the key mechanism to a technically literate reader using original editable vector composition. Read the stated source figure/caption; reference imagery is evidence, not a template to paste. Use180mm finalwidth, readable≥8pt labels, choose height or two-panel composition for clarity. Distinguish data, control, training-only and repeated inference; preserve all source-backed branches and operator order. Keep representative image inputs schematic and explicitly labeled; no fabricated examples presented as empirical output. Include an operator/attention inset where it materially resolves ambiguity. The main figure should answer how the method transforms inputs and which dependencies apply, while the caption locates source/version and scientific limits. No actualmodelperformance reproduction is requested.

## Controller-provided local original

Read the already retrieved pinned original at `/workspace/scratch/c12f3d9f92bd/recent-architecture-sources/ditfuse.pdf`; critical architecture pages 5–7. This local original is authorized for this reference-visible case only.

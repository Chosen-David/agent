# DOUBT: Decoupled Object-level Understanding and Bridging via vMF-based Trustworthiness for Hallucination Detection in MLLMs

Source: https://proceedings.mlr.press/v306/chen26dl.html
Full text: https://raw.githubusercontent.com/mlresearch/v306/main/assets/chen26dl/chen26dl.pdf
Version: PMLR306 pp.16418–16441, official24page PDF
SHA256: 635ee9cfbfd752499fe22f8d0ba934a9617b68409d606719d76e6123f9f44b68

## Architecture facts

**D1** Input is image I and instruction/question t. Same black-box MLLM supplies a low-temperature reference answer A; this is an evaluated answer, not a score input. (Sec.3.1 p.3; Algorithm1 p.4)

**D2** Direct path samples K answers from M(I,t). Object path first recognizes up to3 main objects r=M(I,p_obj). (Sec.3.2 p.4)

**D3** Bridging then samples K answers from M(I,t||p_bri||r), retaining image and original question, not only the object list. (Sec.3.2 p.4; Algorithm1 lines2–4)

**D4** Each response in each set is encoded by the same frozen nli-roberta-large sentence embedding model, then individually normalized to unit length. (Sec.3.3 p.5; Fig.2 snowflake)

**D5** For each set separately compute R_set=||sum_k e_hat_k||/K. Then R_avg=(R_ori+R_bri)/2; do not pool all2K vectors before norm. (Eq.4 p.5; Algorithm1 lines5–7)

**D6** R_avg>theta gives flag1, judged non-hallucinatory; R_avg≤theta gives flag0, hallucination. This is detection estimate, not truth guarantee. (Eq.5 p.5; Algorithm1 lines8–12)

**D7** Ground truth compares correctness of reference A against detection flag only in offline evaluation; no gold answers, retrieval database, gradient or fine-tuning required by detection diagram. (Eq.6 p.5; Sec.3.1)

**D8** Reported setup K10, reference temperature0.1, sample temperature0.5, top-k10/top-p0.99, threshold0.48 are experimental choices, not universal architecture constants. Object-recognition errors may propagate. (Implementation p.6; limitation p.4–5)

## Source boundaries and conflicts

- PDF running title abbreviates the publication title; citation uses PMLR metadata.
- The main prose sometimes calls scores uncertainty; Eq.5 and Algorithm1 clearly use high mean-resultant score as trustworthiness, flag1=non-hallucinatory.
- The text labels the finite-sample resultant-length estimator unbiased; this property is not independently verified and must not be asserted by the redraw.

## Design brief

Explain the key mechanism to a technically literate reader using original editable vector composition. This is the reference-hidden holdout. Use only the supplied grounded method facts; do not open the original PDF, original architecture figure, external webpage or evaluator material. The independent evaluator retains the original figure and equations. Use180mm finalwidth, readable≥8pt labels, choose height or two-panel composition for clarity. Distinguish data, control, training-only and repeated inference; preserve all source-backed branches and operator order. Keep representative image inputs schematic and explicitly labeled; no fabricated examples presented as empirical output. Include an operator/attention inset where it materially resolves ambiguity. The main figure should answer how the method transforms inputs and which dependencies apply, while the caption locates source/version and scientific limits. No actualmodelperformance reproduction is requested.

# Root independent pre-dispatch material correspondence
Root actually checked all36 criteria against tasks/briefs and original critical pages: AutoGaze pp3-5, DOUBT pp4-5, DiTFuse pp5-7; source/code version conflict preserved. Previous critical-page inspection is this same root context, not a new all-paper read. No output quality has yet been scored.

## gazing2026 criterion1
Current/past frame features and selected-patch history feed autoregressive decoding; no future-frame leakage arrow.

G1, Sec3.1/Fig3: current/past features and selected history, block-causal context; future leakage contradicts method.

## gazing2026 criterion2
Multi-scale indices, their gathered patches, and actual image scales are distinct objects; scale labels do not falsely become patch side lengths.

G2, Fig3:32/64/112/224 resolutions; author AppendixA separately supports16px patches. Distinct version attribution retained.

## gazing2026 criterion3
Loss prediction head and user threshold drive per-frame stop/advance control, separate from patch-index data output.

G3, Fig3/Sec3.1: predicted reconstruction loss and user threshold stop current frame; patch index is separate head.

## gazing2026 criterion4
Selected indices feed back as autoregressive history and advance-to-next-frame preserves past context.

G1/G3, Fig3: autoregressive selected-index history feeds subsequent prediction; frame context persists.

## gazing2026 criterion5
Actual VideoMAE reconstruction/reward is training-only in the depicted training path; it is not falsely a mandatory downstream inference pass.

G4, Sec3.2: real reconstruction reward trains selector; inferred loss controls deployment without mandatory reconstruction.

## gazing2026 criterion6
NTP→RL training sequence, reconstruction reward and loss-prediction supervision are represented with correct direction and boundaries.

G5, Eqs3-4: greedy-sequence NTP precedes on-policy GRPO with reconstruction reward and auxiliary loss supervision.

## gazing2026 criterion7
Gazing selection precedes downstream ViT→MLLM; multi-scale embedding/position adaptation and tile/merge scope are explicit.

G6/G7, Sec3.3: selected patches before ViT, interpolated position/frame handling,16-frame tiles and position merge.

## gazing2026 criterion8
Multi-token prediction annotation retains causal history; caption states schematic redraw and does not claim original empirical speedups were reproduced.

G8, Sec3.1: multiple token heads do not introduce future information; task asks redraw only, no performance rerun.

## gazing2026 criterion9
At declared 180 mm final width all primary labels are at least 8 pt and readable in full-page embedding; no crop, overlap or missing glyph.

Task design brief explicitly declares180mm width and primary labels at least8pt plus actual full-page render inspection; measurable typography, not venue certification.

## gazing2026 criterion10
Where present, data, control, training-only edges and recurrent flow are visually distinct with an explicit redundant legend; arrowheads land on intended nodes. Do not invent absent edge types or recurrence.

Task requires source-faithful typed edges and legend. Revised before dispatch to only present edge types; DOUBT must not invent training/recurrence.

## gazing2026 criterion11
Hierarchy, grouping, alignment, whitespace and color are purposeful; grayscale retains semantic distinctions without decorative confusion.

Task design brief requests clear grouping and grayscale inspection; independent visual judgement plus actual rendered evidence required, not keyword gate.

## gazing2026 criterion12
Editable original source, vector PDF, color PNG, grayscale PNG, full-page PDF/PNG, source map, caption and exact rebuild command exist and rebuild succeeds.

Task explicit deliverables include editable source/vectorPDF/color/grayscale/page renders/contract/caption/build; rebuild must execute, existence alone insufficient.

## doubt2026 criterion1
Image plus original question reach both sampling paths; object recognition precedes bridging and supplies the object list only to the bridged path.

D2/D3, Algorithm1 lines2-4/Fig2: direct M(I,t) and bridged M(I,t||prompt||r), r recognized first.

## doubt2026 criterion2
The same black-box MLLM and K-sample multiplicities are clear; object recognition is not depicted as K independent gold annotations.

D1-D3, Fig2: same black-box generator, K samples each answer set, object recognition not gold annotations.

## doubt2026 criterion3
Separate reference answer and offline correctness assessment are not score inputs or deployed ground truth.

D1/D7, Sec3.1/Eq6: reference answer accuracy is offline evaluation; R formula has no reference input.

## doubt2026 criterion4
Both paths use frozen sentence embeddings and per-response unit normalization before score computation.

D4, Fig2/Sec3.3: frozen sentence encoder and each individual unit-normalized embedding.

## doubt2026 criterion5
Mean-resultant length is computed independently within each K-set; output operators show norm(mean vectors) then scalar average across sets, not pooled-vector norm or vote.

D5, Eq4: separate mean-resultant norms then arithmetic scalar average. Norm of pooled vectors is different.

## doubt2026 criterion6
Threshold polarity and equality are correct: >theta→flag1 non-hallucinatory; ≤theta→flag0 hallucination.

D6, Eq5/Algorithm1: strictly greater theta yields flag1 non-hallucination; equality belongs flag0.

## doubt2026 criterion7
No invented model-training, retrieval, learned detector or feedback correction loop; optional OUB correction discussion is not the detection pipeline.

D7, Algorithm1: detection needs no training/retrieval/correction feedback. OUB discussion not deployed detector.

## doubt2026 criterion8
Schematic caption states score is proxy, may fail after object misidentification; no claims that high consistency guarantees truth or published accuracy was reproduced.

D8, stated limitation: mistaken object recognition propagates; consistency proxy not ground truth and no reproduced accuracy.

## doubt2026 criterion9
At declared 180 mm final width all primary labels are at least 8 pt and readable in full-page embedding; no crop, overlap or missing glyph.

Task design brief explicitly declares180mm width and primary labels at least8pt plus actual full-page render inspection; measurable typography, not venue certification.

## doubt2026 criterion10
Where present, data, control, training-only edges and recurrent flow are visually distinct with an explicit redundant legend; arrowheads land on intended nodes. Do not invent absent edge types or recurrence.

Task requires source-faithful typed edges and legend. Revised before dispatch to only present edge types; DOUBT must not invent training/recurrence.

## doubt2026 criterion11
Hierarchy, grouping, alignment, whitespace and color are purposeful; grayscale retains semantic distinctions without decorative confusion.

Task design brief requests clear grouping and grayscale inspection; independent visual judgement plus actual rendered evidence required, not keyword gate.

## doubt2026 criterion12
Editable original source, vector PDF, color PNG, grayscale PNG, full-page PDF/PNG, source map, caption and exact rebuild command exist and rebuild succeeds.

Task explicit deliverables include editable source/vectorPDF/color/grayscale/page renders/contract/caption/build; rebuild must execute, existence alone insufficient.

## ditfuse2026 criterion1
Two image-condition paths and instruction-token path remain distinct until sequence composition; noisy target and timestep are separately identified.

F1/F3, Fig3/SecIII-A: two condition images and instruction sequence distinct from noisy target and timestep.

## ditfuse2026 criterion2
Train/inference panels and frozen VAE/base versus trained LoRA boundaries are explicit; code/paper LoRA mismatch is disclosed with chosen paper-version scope.

F2/conflict, Fig3 and train.py101-112: paper all-linear rank64 scale0.5 versus code qkv/o alpha=rank; scope must be disclosed, VAE/base frozen.

## ditfuse2026 criterion3
Hybrid-mask inset or precise annotation preserves sequence-causal cross-block and bidirectional intra-image behavior; no unrestricted intermodal loop.

F4, SecIII-A.3 and processor169-213: cross-block causal, image-block bidirectional, not all-to-all reverse dependencies.

## ditfuse2026 criterion4
Training noised target and velocity objective match x_t=t*x+(1-t)*epsilon and target x-epsilon; no target leakage to inference.

F5, Eqs4-5: interpolation t*x+(1-t)*epsilon, velocity x-epsilon; training target not inference conditioning.

## ditfuse2026 criterion5
M3 source duplication,75/25complementary/common corruptions and original-source target are correct and contained in training-data path.

F6, Fig4/SecIII-B.2: two corrupted views of source, complementary75/common25 percent; original source target.

## ditfuse2026 criterion6
Task-specific target selection is not confused with parallel model inputs or inference outputs; no universally ground-truth-free claim.

F7, Fig4/6: task-specific instruction/targets belong data construction; some source or mean-fusion targets exist.

## ditfuse2026 criterion7
Inference is repeated denoising under fixed conditions followed by VAE decode; paper50steps are a depicted setting, not50 stackedTransformer layers.

F8, Fig3: iterative50step inference example with fixed conditioning followed by decoder, not50 network layers.

## ditfuse2026 criterion8
No GPT4o/evaluation module is inserted into model generation; caption identifies selected authorversion associated with journal article and unexecuted model results.

F9, Fig13: GPT4o is evaluation only. SelectedarXivv1 vsjournalversion and no model execution explicitly in tasks.

## ditfuse2026 criterion9
At declared 180 mm final width all primary labels are at least 8 pt and readable in full-page embedding; no crop, overlap or missing glyph.

Task design brief explicitly declares180mm width and primary labels at least8pt plus actual full-page render inspection; measurable typography, not venue certification.

## ditfuse2026 criterion10
Where present, data, control, training-only edges and recurrent flow are visually distinct with an explicit redundant legend; arrowheads land on intended nodes. Do not invent absent edge types or recurrence.

Task requires source-faithful typed edges and legend. Revised before dispatch to only present edge types; DOUBT must not invent training/recurrence.

## ditfuse2026 criterion11
Hierarchy, grouping, alignment, whitespace and color are purposeful; grayscale retains semantic distinctions without decorative confusion.

Task design brief requests clear grouping and grayscale inspection; independent visual judgement plus actual rendered evidence required, not keyword gate.

## ditfuse2026 criterion12
Editable original source, vector PDF, color PNG, grayscale PNG, full-page PDF/PNG, source map, caption and exact rebuild command exist and rebuild succeeds.

Task explicit deliverables include editable source/vectorPDF/color/grayscale/page renders/contract/caption/build; rebuild must execute, existence alone insufficient.

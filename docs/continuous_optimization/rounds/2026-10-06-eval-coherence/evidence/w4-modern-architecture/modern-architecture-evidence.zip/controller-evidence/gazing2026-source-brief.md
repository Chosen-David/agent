# Attend Before Attention: Efficient and Scalable Video Understanding via Autoregressive Gazing

Source: https://openaccess.thecvf.com/content/CVPR2026/html/Shi_Attend_Before_Attention_Efficient_and_Scalable_Video_Understanding_via_Autoregressive_CVPR_2026_paper.html
Full text: https://openaccess.thecvf.com/content/CVPR2026/papers/Shi_Attend_Before_Attention_Efficient_and_Scalable_Video_Understanding_via_Autoregressive_CVPR_2026_paper.pdf
Version: CVF accepted-paper open-access version, pp.17022–17034
SHA256: 7ccb3e8de6ec4731c294e6894d3f61b5ed15b0d3a1e139f934a0b1c7f93e9d11

## Architecture facts

**G1** Frames are encoded sequentially by a lightweight convolutional encoder; an autoregressive transformer decodes patch indices using current/past frames and prior selections. (Sec.3.1 p.3; Fig.3 p.4)

**G2** Multi-scale vocabulary uses resolutions32,64,112,224 pixels in Fig.3. These are image scales, not four patch side lengths; author Appendix A says patch side16 and 265 candidate positions. (Fig.3 p.4; authorv1 AppendixA p.14)

**G3** Decoder has patch-index prediction and reconstruction-loss prediction outputs. User threshold controls stopping per frame, then move to next frame; preserve autoregressive selected-index feedback/history. (Sec.3.1 p.3–4)

**G4** Actual reconstruction model is custom block-causal VideoMAE used for objective/training reward. Predicted reconstruction loss, not rerunning actual reconstruction at each inference step, controls stopping. (Sec.3 p.3; Sec.3.2 p.4)

**G5** Stage1 next-token-prediction learns from greedy-search gazing sequences, with auxiliary squared loss on reconstruction-loss prediction. Stage2 on-policy GRPO uses negative reconstruction reward and auxiliary loss prediction supervision. (Sec.3.2 Eqs.3–4 p.4)

**G6** Selected multi-scale patches are processed before downstream ViT, whose frame/position embeddings are interpolated per scale; tokens from16frames share a sequence and feed the MLLM. (Sec.3.3 p.4–5)

**G7** Any-resolution/length inference tiles video into16×224×224 spatiotemporal blocks, runs gazing per tile, then merges positions. (Sec.3.3 p.4)

**G8** Multi-token prediction uses several heads for multiple indices and corresponding losses; show it as an optional explicit inset/annotation, not replace history with fully parallel noncausal selection. (Sec.3.1 p.4)

## Source boundaries and conflicts

- CVF accepted PDF has a different author list from arXiv v1 (which additionally lists Song Han); use CVF authors for CVPR citation, do not silently conflate versions.
- Main text says predicted loss falls below threshold; Fig.3 displays threshold ≤0.7. Label threshold rule generically or explicitly cite chosen comparator; equality must not be portrayed as a measured guarantee.

## Design brief

Explain the key mechanism to a technically literate reader using original editable vector composition. Read the stated source figure/caption; reference imagery is evidence, not a template to paste. Use180mm finalwidth, readable≥8pt labels, choose height or two-panel composition for clarity. Distinguish data, control, training-only and repeated inference; preserve all source-backed branches and operator order. Keep representative image inputs schematic and explicitly labeled; no fabricated examples presented as empirical output. Include an operator/attention inset where it materially resolves ambiguity. The main figure should answer how the method transforms inputs and which dependencies apply, while the caption locates source/version and scientific limits. No actualmodelperformance reproduction is requested.

## Controller-provided local original

Read the already retrieved pinned original at `/workspace/scratch/c12f3d9f92bd/recent-architecture-sources/gazing.pdf`; critical architecture pages 3–5. This local original is authorized for this reference-visible case only.

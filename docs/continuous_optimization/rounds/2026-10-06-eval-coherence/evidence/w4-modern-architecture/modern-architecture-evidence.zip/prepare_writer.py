from pathlib import Path
import json, importlib.util, shutil, hashlib
B=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('p',B/'pipeline.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
r=p.report(B/'run')
if not r['complete']:raise SystemExit('Require all three independently accepted diagram cases before handoff')
F=B/'writer-fixtures';F.mkdir(exist_ok=False)
t=json.loads((B/'handoff-task-template.json').read_text());fixture_paths=[];chain=[]
for case in r['cases']:
 cid=case['case_id'];attempt=int(case['attempts'][-1]['attempt']);A=B/'run/cases'/cid/'attempts'/f'{attempt:04d}'
 collection=p.read(A/'collection.json');grade=p.read(A/'grade.json')
 for name in ['figure.pdf','semantic_contract.json','figure_notes.md']:
  f=A/'outputs'/name
  if hashlib.sha256(f.read_bytes()).hexdigest()!=collection['output_hashes'][name]:raise ValueError('Mutated output')
  target=F/cid/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,target);fixture_paths.append(f'{cid}/{name}')
 chain.append({'producer_case':cid,'producer_actor':p.read(A/'start.json')['actor'],'attempt':attempt,'collection_sha256':p.digest((A/'collection.json').read_bytes()),'grade_sha256':p.digest((A/'grade.json').read_bytes()),'source_figure_sha256':collection['output_hashes']['figure.pdf']})
(F/'handoff-input.json').write_text(json.dumps({'task_ref':'T26','actual_producer_chain':chain,'scope':'Only accepted generated vector figures, no original reference bitmap'},indent=2)+'\n');fixture_paths.append('handoff-input.json')
t['cases'][0]['fixtures']=fixture_paths
(B/'writer-task.json').write_text(json.dumps(t,indent=2)+'\n')
adapter={'name':'host','model':'unknown; inherited host configuration','max_attempts':2,'worker_wall_seconds':1500,'worker_tool_budget':40,'tokens':'unknown','cost':'unknown','worker_context':'fresh fork_turns=none'}
m=p.prepare_run(B.parent/'agent','25fc74b57a9c426cfac82fda2eaf727979adb137',B/'writer-run',B/'writer-task.json',B/'handoff-rubric.json',F,adapter,require_material_review=True)
(B/'writer-review-packet.json').write_text(json.dumps({'material_bindings':p.material_bindings(B/'writer-run',m),'producer_chain':chain,'status':'prepared, not executed'},indent=2)+'\n')
print(json.dumps({'manifest_sha256':p.digest((B/'writer-run/manifest.json').read_bytes()),'packet':str(B/'writer-review-packet.json')},indent=2))

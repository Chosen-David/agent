# T26 contemporary CCF-A architecture evaluation

Batch: 2026-10-06-eval-coherence. Task T26. Three targeted cases; classic diagrams remain separate foundational regression. All tasks consume candidate25fc74b57a9c426cfac82fda2eaf727979adb137 with protected material review before host dispatch. Rubric frozen before workers. Inputs include no grading material. DOUBT original is reference-hidden. Two other cases use selected original PDFs.

Pipeline implementation is reused verbatim from the candidate, not a parallel evaluator. prepare.py creates pinned task/snapshot/input/criterion hashes. control.py calls authorize_dispatch before spawn, then record_start, collect, grade_attempt. proxy.py records actual requested subprocess execution. Root supplies independent material review and hash trust, never worker self-approval. Independent scientific/visual grading must read actual rendered outputs and original evidence. Actual diagram-to-writer handoff will be recorded separately after diagram artifacts exist.

Budget3attempts/case,25min/40toolcalls each. No external GPU/runtime installation; no empirical model accuracy/speed reproduction claimed. This is finite-domain diagram task acceptance, not comprehensive coverage of CCF-A venues or benchmark quality improvement. Any failures remain immutable.

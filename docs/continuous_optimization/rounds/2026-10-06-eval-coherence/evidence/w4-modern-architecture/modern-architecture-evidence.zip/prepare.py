from pathlib import Path
import json, shutil, subprocess, hashlib, importlib.util
B=Path(__file__).resolve().parent
S=B.parent/'recent-architecture-sources'; R=B.parent/'agent'; rev='25fc74b57a9c426cfac82fda2eaf727979adb137'
def wr(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
tasks=json.loads((S/'tasks.json').read_text()); rubric=json.loads((S/'rubric.json').read_text())
old='Data/control/training-only edges and recurrent flow are visually distinct with explicit redundant legend; arrowheads land on intended nodes.'
new='Where present, data, control, training-only edges and recurrent flow are visually distinct with an explicit redundant legend; arrowheads land on intended nodes. Do not invent absent edge types or recurrence.'
for cid,criteria in rubric['criteria'].items():
 assert criteria[9]==old; criteria[9]=new
shutil.copytree(S/'fixtures',B/'fixtures')
for cid,filename,pages in [('gazing2026','gazing.pdf','3–5'),('ditfuse2026','ditfuse.pdf','5–7')]:
 p=B/'fixtures'/cid/'source-brief.md'
 with p.open('a') as f:f.write(f'\n## Controller-provided local original\n\nRead the already retrieved pinned original at `{S/filename}`; critical architecture pages {pages}. This local original is authorized for this reference-visible case only.\n')
for c in tasks['cases']:
 c['prompt']=c['prompt'].replace('Wait for rootSTART outputpath.', 'Wait for controller START and assigned output path. Route command execution through the supplied logging proxy and record actual render inspections; the proxy is an execution trace, not a platform transcript.')
wr(B/'tasks.json',tasks);wr(B/'rubric.json',rubric)
adapter={'name':'host','model':'unknown; inherited host configuration','max_attempts':3,'worker_context':'fresh fork_turns=none; per-case isolation by instruction, shared filesystem not a security sandbox','worker_wall_seconds':1500,'worker_tool_budget':40,'tokens':'unknown','cost':'unknown','source_modes':{'gazing2026':'reference_visible','doubt2026':'reference_hidden','ditfuse2026':'reference_visible'}}
wr(B/'adapter.json',adapter)
(B/'pipeline.py').write_bytes(subprocess.check_output(['git','-C',str(R),'show',rev+':scripts/agent_eval_pipeline.py']))
spec=importlib.util.spec_from_file_location('p',B/'pipeline.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
m=p.prepare_run(R,rev,B/'run',B/'tasks.json',B/'rubric.json',B/'fixtures',adapter,require_material_review=True)
E=B/'controller-evidence';E.mkdir()
for f in ['w4-recent-architecture.md','w4-recent-architecture.json','w4-ccf-classification.json']:
 shutil.copyfile(R/'docs/continuous_optimization/rounds/2026-10-06-eval-coherence/research'/f,E/f)
for c in tasks['cases']:shutil.copyfile(B/'fixtures'/c['id']/'source-brief.md',E/(c['id']+'-source-brief.md'))
wr(B/'review-packet.json',{'task_ref':'T26','revision':rev,'manifest_sha256':p.digest((B/'run/manifest.json').read_bytes()),'pipeline_sha256':p.digest((B/'pipeline.py').read_bytes()),'material_bindings':p.material_bindings(B/'run',m),'cases':3,'criteria':36,'status':'prepared, no dispatch','preexecution_rubric_change':{'old':old,'new':new,'reason':'DOUBT contains no training or recurrent flow; require faithful representation where present, never invented loops.'},'source_scope':'CVPR2026 AutoGaze, ICML2026 DOUBT, TPAMI2026 DiTFuse author-v1; finite sample, not comprehensive CCF-A coverage','design':'targeted acceptance of current frozen Skill, no fair old/new performance A/B claim'})
print(json.dumps({'manifest_sha256':p.digest((B/'run/manifest.json').read_bytes()),'review_packet':str(B/'review-packet.json')},indent=2))

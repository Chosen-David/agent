from pathlib import Path
import json,hashlib,subprocess,importlib.util,shutil
B=Path(__file__).resolve().parent;P=B.parent;repo=P.parent/'agent';candidate='0150292b8712fb6e4351df7b0a910af464704088'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
shutil.copyfile(P/'v4/pipeline.py',B/'pipeline.py')
s=importlib.util.spec_from_file_location('p',B/'pipeline.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
case=next(c for c in read(P/'v3/tasks.json')['cases'] if c['id']=='code-organization');write(B/'tasks.json',{'schema_version':1,'cases':[case]});write(B/'rubric.json',{'schema_version':1,'criteria':{'code-organization':read(P/'v3/rubric.json')['criteria']['code-organization']}})
fixtures=B/'fixtures';shutil.copytree(P/'v3/run/cases/code-organization/inputs',fixtures)
adapter=read(P/'v4/adapter.json');adapter['max_attempts']=1;write(B/'adapter.json',adapter)
m=p.prepare_run(repo,candidate,B/'run',B/'tasks.json',B/'rubric.json',fixtures,adapter,require_material_review=True)
A=B/'artifacts';A.mkdir();old=P/'v3/run/cases/code-organization/attempts/0001';collection=read(old/'collection.json');shutil.copyfile(old/'collection.json',A/'original-collection.json');shutil.copyfile(old/'grade.json',A/'original-review.json')
for name,h in collection['output_hashes'].items():
 src=old/'outputs'/name;assert sha(src)==h;dst=A/'prior-outputs'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
R=B/'runtime'
for path in ['agent_runtime/communication.py','scripts/validate_handoff.py','workflows/agent_communication_workflow.md']:
 dst=R/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(subprocess.check_output(['git','-C',str(repo),'show',candidate+':'+path]))
plan={'schema_version':1,'run_id':'COH-T27-codeorg-repair-v1','input_version':'codeorg-w4-inputs+v3-feedback-v1','max_message_bytes':8192,'max_events':8,'routes':[]}
for sender,recipient,kind in [('research-review-original','code-organization-repair','review'),('code-organization-repair','research-review-recheck','artifact'),('code-organization-repair','main-controller','artifact'),('research-review-recheck','main-controller','review'),('research-review-recheck','code-organization-repair','review')]:plan['routes'].append(dict(sender=sender,recipient=recipient,task_id='COH-T27',kind=kind))
write(B/'plan.json',plan)
write(B/'actor-bindings.json',{'research-review-original':{'role':'research-review','actor':'/root/final_role_controller/v3_grader','purpose':'actual original independent finding publisher'},'code-organization-repair':{'role':'code-organization','actor':'/root/final_role_controller/communication_repair'},'research-review-recheck':{'role':'research-review','actor':'/root/final_role_controller/communication_reviewer'},'main-controller':{'role':'main','actor':'/root/final_role_controller'}})
record={'candidate':candidate,'manifest_sha256':sha(B/'run/manifest.json'),'task_hash_unchanged':m['cases']['code-organization']['task_hash']==read(P/'v3/run/manifest.json')['cases']['code-organization']['task_hash'],'input_hashes_unchanged':m['cases']['code-organization']['input_hashes']==read(P/'v3/run/manifest.json')['cases']['code-organization']['input_hashes'],'criteria_unchanged':read(B/'rubric.json')['criteria']['code-organization']==read(P/'v3/rubric.json')['criteria']['code-organization'],'material_hashes':{str(f.relative_to(B)):sha(f) for f in [B/'plan.json',B/'actor-bindings.json',A/'original-review.json',A/'original-collection.json',*sorted((A/'prior-outputs').rglob('*')),*sorted(R.rglob('*'))] if f.is_file()},'original_review_source':str(old/'grade.json'),'original_collection_source':str(old/'collection.json'),'max_attempts':1,'max_events':8,'classification':'Explicit feedback-assisted repair, not clean first-pass or A/B; previous independent failure retained; no messages yet.'}
write(B/'material-packet.json',record);print(json.dumps(record,indent=2))

# Synthetic manuscript: selective execution
This is an invented fixture, not a published paper.
## Abstract
The method achieves 3x end-to-end speedup on every workload without regression.
## Method
A selected kernel changes; all supplied timings refer to the same synthetic CPU configuration. No GPU run exists.
## Results
Each timing is one observation without independent repeats. Kernel-only timings are already included within end-to-end paths: never add them.
## Appendix A
Large end-to-end latency rises from 240 to 264 ms. This regression is explicitly disclosed. Quality and variance are unmeasured.

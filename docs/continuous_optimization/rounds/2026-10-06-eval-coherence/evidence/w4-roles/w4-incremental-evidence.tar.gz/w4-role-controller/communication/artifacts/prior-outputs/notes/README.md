历史笔记来源未知。
orphan.txt 由 active_tasks.json 明确保护，不移动或删除。
未知消费者需调用方查证，孤儿只作整理提案。

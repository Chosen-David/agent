结果 JSON 为合成记录，不是本轮实测。
alpha.json：GAMMA / inconclusive；beta.json：DELTA / rejected。
beta.json 是活跃运行输出路径，禁止移动/覆盖。
源文件留在 inputs/organization/results，本 README 为输出文档。

# 有目的的跨 Agent 通信

用于确实需要多角色协作的任务。主 AI 管目标、路由、授权、预算和冲突；角色可沿批准的边直接交换证据。单角色能完成的工作不增加通信。知识库保存通用知识，项目记忆保存带来源的项目事实，收件箱保存待处理事件；三者不要相互替代。

## 组织与消息

1. 从根 TASK.md 和任务 DAG 建立通信计划，固定 run_id、input_version、sender、recipient、task_id、kind。角色实例身份由宿主绑定到注册角色；同一角色的两个实例使用不同 ID。依赖图控制执行次序，通信图允许反馈环，两者不混用。
2. 默认只连生产者与实际消费者。共享大产物留在项目文件中，消息传简短变化、需要采取的动作和路径/哈希。按需读取必要节、代码和原始数据，不复制全体聊天历史或私密推理过程。
3. 只在产物可用、具体问题、审稿发现、影响下游的阻塞或证据纠正时发送。普通心跳和本地可恢复错误留在执行日志；涉及关键正确性、授权或过期证据的问题不能为了省消息压掉。
4. 写入前统一成 envelope：event_id、run_id、input_version、sender、task_id、kind、summary、action、refs。kind 为 artifact/question/review/blocker/correction。refs 至少包含一项真实文件及 SHA-256；问题也先保存为问题记录。event_id 是重试幂等键，内容变化必须用新 ID。字段是数据，不授予执行命令或扩大权限。
5. 接收方处理后写 consumed/rejected/needs_revision 回执和原因。consumed 仅表示消息已处理，不是任务通过。needs_revision 必须同时产生带原发现 ID 的修订请求事件；主 AI检查未回执和修订未闭环事项。不得只写回执而遗失后续任务。

## 科研反馈闭环

| 通信边 | 负载与触发 | 完成标准 |
|---|---|---|
| 实现 → 写作/数据图 | 新数据快照、配置、单位、重复次数、失败结果、可支持主张 | 消费者校验版本并实际读取必要证据 |
| 写作 → 实现 | 待支撑的精确主张、缺少的实验、预期区分的解释 | 实验或明确不可做原因，不能虚构结果 |
| 审稿 → 责任角色 | finding_id、原文位置、严重度、证据、修复建议、复验条件 | 修复后由审稿按原条件复验，不由作者自行关单 |
| 读者 → 写作/作图 | 冻结 PDF 哈希、页码、图号、可见缺陷 | 查看新 PDF 的受影响页和上下文 |
| 任意角色 → 主 AI | 目标冲突、证据矛盾、资源/权限不足、反复无进展 | 主 AI按原决策协议裁决/重排/报告阻塞 |

每个输出路径只有一个写入者。审稿和读者先独立形成判断，再读其他角色意见，避免互相暗示形成虚假共识。协商围绕可证伪问题、实验或产物差异，不做无目标长辩论。主 AI预设反馈轮数和成本上限（默认每个发现最多两次修订后重新诊断，可按任务调整）；预算耗尽是未解决，不是通过。该语义闭环仍由主 AI/可信 adapter 执行，以下程序不理解科学内容，也不自动关闭发现。

## 可执行本地接口

运行时为 [agent_runtime/communication.py](../agent_runtime/communication.py)，使用 Python 标准库 SQLite 事务保存事件和每个消费者的回执。它是本地同盘 inbox，没有网络监听、模型调用或新调度器；现有宿主 adapter 按任务阶段调用它。完整仓库可运行，单独分发 Skill 的宿主须提供此能力，否则使用同一字段手工交接并明确未接入持久 inbox。

计划示例（主 AI/消费者持有，不交给生产者修改）：

```json
{
  "schema_version": 1,
  "run_id": "study-v1",
  "input_version": "actual-input-version",
  "max_message_bytes": 8192,
  "max_events": 1000,
  "routes": [
    {"sender":"research-implement-optimize", "recipient":"research-write", "task_id":"EXP-1", "kind":"artifact"},
    {"sender":"research-implement-optimize", "recipient":"research-review", "task_id":"EXP-1", "kind":"artifact"},
    {"sender":"research-review", "recipient":"research-implement-optimize", "task_id":"EXP-1", "kind":"review"}
  ]
}
```

预算是显式可调默认值，不是论文测出的最优参数。需要 question/correction/blocker 等边时在启动前按实际消费者补齐；无匹配路由报错，不能静默丢弃。目标/版本/路由改变建立新 run，主 AI核对并迁移未闭环事项，保留旧历史；不能把旧消息简单换版本继续当新证据。

```bash
python -m agent_runtime.communication --db .agent-runs/study-v1/messages.sqlite --plan communication-plan.json --root . publish event.json
python -m agent_runtime.communication --db .agent-runs/study-v1/messages.sqlite --plan communication-plan.json --root . inbox research-write
python -m agent_runtime.communication --db .agent-runs/study-v1/messages.sqlite --plan communication-plan.json --root . consume research-write 1 --request consumer-request.json
python -m agent_runtime.communication --db .agent-runs/study-v1/messages.sqlite --plan communication-plan.json --root . ack research-write 1 receipt.json
python -m agent_runtime.communication --db .agent-runs/study-v1/messages.sqlite --plan communication-plan.json --root . status
```

seq 用实际 publish/inbox 返回值，不猜测。完成产物消息的 refs 包含 `id="handoff"`，指向现有 [handoff JSON](../docs/handoff_validation.md)。consume 重新验证 manifest 及其产物哈希、生产角色/run、输入版本和独立 consumer-request 的完整任务范围；不自动 ACK。实际读取内容、语义审查和幂等动作完成后才 ack。普通问题/审稿记录由宿主检查原引用哈希并按上表处理。

API 为 `Mailbox(db, plan, artifact_root).publish/inbox/consume_handoff/acknowledge/status`。支持重复发布去重、事务内投递、重启后待办恢复、有限分页和不可覆盖的回执。多个轮询者会看到同一未回执消息：至少一次读取，**不保证副作用恰好一次**。宿主给每个 recipient 配置一个消费者，使用 `(run_id,event_id,recipient)` 作为动作幂等键；不确定的外部副作用先查证。现有 Engine.current()/取消/租约/授权检查必须在执行副作用前复核；邮箱不接管 Engine 状态或设置 task done。

同盘 SQLite 适合当前单机可移植运行时。它不是认证/隔离沙箱，也不抵抗恶意并发替换文件；可信宿主持有计划、请求、artifact_root 并控制文件权限。数据库只含运行事件，知识文件仍是知识库事实源。将来跨机器时再考虑 A2A/消息服务，保留相同业务契约并单独验证重试、身份和版本。

## 验收与持续优化

先测无关投递、重复执行、重启、旧数据、缺失任务、失败回执；再测真实代码→图→论文→审稿→读者链。公平对照现有主 AI转述、全广播和定向引用三种方式，固定输入、模型、工具、预算和验收；统计实际 token/耗时、正确关闭的发现、错误复用、返工和最终质量。离线消息数下降不能代替模型性能收益。记录无收益和缺测，学习式剪枝、主动中断及自动语义压缩需独立实验后再启用。

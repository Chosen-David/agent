from pathlib import Path
import sys,json,subprocess,datetime,hashlib,time,uuid
B=Path(__file__).resolve().parent
request=json.load(sys.stdin);out=B/request.get('run','run')/'host';out.mkdir(exist_ok=True)
start=time.monotonic();r=subprocess.run(request['argv'],cwd=request.get('cwd'),capture_output=True,text=True,timeout=request.get('timeout',180))
record={'kind':'actual-controller-tool-proxy','request':request,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout':r.stdout,'stderr':r.stderr,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'file_hashes':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in request.get('hash_paths',[]) if Path(p).is_file()},'boundary':'Actual subprocess execution requested by worker during task; not a platform transcript export'}
p=out/(request['case']+'-proxy-'+str(uuid.uuid4())+'.json');p.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'record':str(p),**record},ensure_ascii=False))

import csv,json,math,hashlib
from pathlib import Path
O=Path(__file__).resolve().parent
I=O.parents[2]/"inputs"
rows=list(csv.DictReader((I/"measurements.csv").open()))
result=[]
for r in rows:
 b,c=float(r["baseline_ms"]),float(r["candidate_ms"])
 result.append(dict(workload=r["workload"],scope=r["scope"],baseline_ms=b,candidate_ms=c,speedup=b/c,latency_change_percent=(c/b-1)*100,time_saved_ms=b-c))
def output(a,b,v):
 z=[x+y for x,y in zip(a,b)];e=[math.exp(t-max(z)) for t in z];p=[t/sum(e) for t in e]
 return p,sum(x*y for x,y in zip(p,v))
v=[-2.,14.];p0,y0=output([0,0],[0,0],v);p1,y1=output([0,0],[0,math.log(3)],v)
j0=[p*(v_i-y0) for p,v_i in zip(p0,v)];j1=[p*(v_i-y1) for p,v_i in zip(p1,v)]
h=1e-6
finite=[(output([h if k==j else 0 for k in range(2)],[0,0],v)[1]-output([-h if k==j else 0 for k in range(2)],[0,0],v)[1])/(2*h) for j in range(2)]
assert abs(y0-6)<1e-12 and abs(y1-10)<1e-12
assert max(abs(x-y) for x,y in zip(j0,finite))<1e-7
assert [r['time_saved_ms'] for r in result]==[18.,25.,-24.,24.]
summary={"kind":"derived_from_synthetic_inputs","input_version":"measurements.csv@v5","measurements":result,"concept":{"probabilities_before":p0,"probabilities_after":p1,"output_before":y0,"output_after":y1,"delta":y1-y0,"jacobian_before":j0,"jacobian_after":j1,"finite_difference_before":finite,"finite_difference_step":h},"checks":"passed","new_experiments":False}
(O/"analysis.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False,indent=2))

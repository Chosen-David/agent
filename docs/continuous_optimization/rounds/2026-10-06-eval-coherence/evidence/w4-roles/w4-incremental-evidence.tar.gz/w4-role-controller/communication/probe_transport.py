"""Separate actual transport program probes; not model/semantic outcomes."""
from pathlib import Path
import json,subprocess,sys,hashlib,datetime
B=Path(__file__).resolve().parent;D=B/'program-probes';D.mkdir(exist_ok=False)
source=B/'artifacts/original-review.json';artifact=D/'review.json';artifact.write_bytes(source.read_bytes());h=hashlib.sha256(artifact.read_bytes()).hexdigest()
plan={'schema_version':1,'run_id':'COH-T27-program-probes','input_version':'probe-v1','max_events':8,'routes':[{'sender':'probe-reviewer','recipient':'probe-worker','task_id':'probe','kind':'review'}]};(D/'plan.json').write_text(json.dumps(plan))
event={'event_id':'probe-1','run_id':plan['run_id'],'input_version':'probe-v1','sender':'probe-reviewer','task_id':'probe','kind':'review','summary':'program-only transport probe','action':'validate persistence, not semantic review','refs':[{'id':'review','path':'review.json','sha256':h}]};(D/'event.json').write_text(json.dumps(event))
base=[sys.executable,'-B','-m','agent_runtime.communication','--db',str(D/'mailbox.sqlite'),'--plan',str(D/'plan.json'),'--root',str(D)];records=[]
def run(*args):
 r=subprocess.run(base+list(map(str,args)),cwd=B/'runtime',capture_output=True,text=True);result=json.loads(r.stdout);records.append({'argv':base+list(map(str,args)),'stdout':r.stdout,'stderr':r.stderr,'exit_code':r.returncode,'fresh_process':True});return r.returncode,result
c,first=run('publish',D/'event.json');assert c==0 and first['duplicate'] is False
c,restart=run('inbox','probe-worker');assert c==0 and len(restart)==1 and restart[0]['event']==event
c,dup=run('publish',D/'event.json');assert c==0 and dup['duplicate'] and dup['seq']==first['seq']
stale={**event,'event_id':'probe-stale','input_version':'probe-old'};(D/'stale.json').write_text(json.dumps(stale));c,res=run('publish',D/'stale.json');assert c!=0 and 'stale' in res['error']
changed={**event,'summary':'changed payload same id'};(D/'changed.json').write_text(json.dumps(changed));c,res=run('publish',D/'changed.json');assert c!=0 and 'different content' in res['error']
receipt={'status':'consumed','reason':'program-only ACK; no semantic acceptance'};(D/'receipt.json').write_text(json.dumps(receipt));c,res=run('ack','probe-worker',first['seq'],D/'receipt.json');assert c==0
c,res=run('inbox','probe-worker');assert c==0 and res==[]
c,res=run('status');assert c==0 and len(res)==1 and res[0]['receipt']==receipt
(D/'results.json').write_text(json.dumps({'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':{'fresh_process_restart_persistence':True,'same_id_exact_duplicate_one_delivery':True,'stale_version_rejected':True,'same_id_changed_payload_rejected':True,'ack_persists_and_removes_pending':True},'records':records,'boundary':'Program checks only, separate DB; no model execution or semantic closure claim'},indent=2)+'\n');print(D/'results.json')

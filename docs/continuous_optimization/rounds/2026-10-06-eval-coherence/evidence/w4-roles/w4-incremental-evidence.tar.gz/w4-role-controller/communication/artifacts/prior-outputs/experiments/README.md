实验脚本索引：alpha.py 声明 GAMMA，beta.py 声明 DELTA。
两者均为活跃文档 fixture，不执行。
数据来源与结果见 ../CODEMAP.md 和 manifest.json。

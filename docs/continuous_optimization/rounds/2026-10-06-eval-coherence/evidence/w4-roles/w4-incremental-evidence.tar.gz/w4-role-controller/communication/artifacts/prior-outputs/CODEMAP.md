| Experiment | Conclusion | Script | Data | Result | Citation |
|---|---|---|---|---|---|
| HIST-0 | unknown | archived/missing.py | unknown | unknown | unknown |
| GAMMA | inconclusive；合成记录 | experiments/alpha.py | synthetic-w4-g（原始数据未提供） | results/alpha.json | 脚本注释与结果script字段双向一致；消费者unknown |
| DELTA | rejected；合成记录；运行中输出保护 | experiments/beta.py | synthetic-w4-d（原始数据未提供） | results/beta.json | 脚本注释与结果script字段双向一致；消费者unknown |
| UNKNOWN-NOTE | protected；来源unknown | unknown | unknown | notes/orphan.txt | active_tasks.json 明确保护；不移动删除 |

补充登记：上述 GAMMA/DELTA 是源中实验ID，不能由文件名猜成 ALPHA/BETA；producer 为对应脚本，真实运行者/commit/消费者均 unknown。HIST-0 历史行保持原顺序及字节内容，archived/missing.py 在提供目录中缺失。本轮登记负责人 code-organization，task_ref=case task.txt（根 TASK.md 未提供）。输入全为合成 fixture，未执行脚本；存在不等于实验验收通过。哈希与文件状态见 manifest.json。

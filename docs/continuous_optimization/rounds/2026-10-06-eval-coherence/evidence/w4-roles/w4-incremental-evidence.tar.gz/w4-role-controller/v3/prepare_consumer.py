from pathlib import Path
import importlib.util,json,hashlib
B=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('pipeline',B/'pipeline.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
freeze=p.read(B/'trusted-freeze.json');m,errors=p.verify_run(B/'run');assert not errors,errors
assert p.digest((B/'run/manifest.json').read_bytes())==freeze['manifest_sha256']
a=B/'run/cases/main-knowledge-producer/attempts/0001';c=p.read(a/'collection.json');assert c['status']=='produced'
f=B/'consumer-fixtures';f.mkdir(exist_ok=False);records=[]
for name in ['modeling_request.json','problem.json']:
 src=a/'outputs'/name;data=src.read_bytes();sha=p.digest(data);assert c['output_hashes'][name]==sha
 (f/name).write_bytes(data);records.append({'source':str(src),'destination':str(f/name),'sha256':sha,'destination_sha256':p.digest((f/name).read_bytes())})
original=B/'run/cases/main-knowledge-producer/inputs/handoff_problem.json'
assert (f/'problem.json').read_bytes()==original.read_bytes(),'producer problem copy differs; preserve failure, do notfix'
record={'source_collection':str(a/'collection.json'),'source_collection_sha256':p.digest((a/'collection.json').read_bytes()),'source_actor':c['receipt']['actor'],'original_input_sha256':p.digest(original.read_bytes()),'files':records,'boundary':'Only actual collected producer outputs copied unchanged; no prefilled/hand-authored consumer input'}
p.write(B/'handoff.json',record)
manifest=p.prepare_run(Path(freeze['source_repo']),freeze['revision'],B/'consumer-run',B/'consumer-task.json',B/'consumer-rubric.json',f,p.read(B/'adapter.json'),require_material_review=True)
print(json.dumps({'run':str(B/'consumer-run'),'manifest_sha256':p.digest((B/'consumer-run/manifest.json').read_bytes()),'expected':manifest['expected_cases'],'handoff':str(B/'handoff.json')},indent=2))

"""Derive honest applicability/provenance matrix; never claim replay model executions."""
from pathlib import Path
import json,hashlib,importlib.util,collections,subprocess
B=Path(__file__).resolve().parent;E=B.parent/'agent/docs/continuous_optimization/rounds/2026-10-06-eval-coherence/evidence';D=B/'final-controller-evidence';D.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,x:p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
s=importlib.util.spec_from_file_location('p',B/'v5/pipeline.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
proofnames=['concurrent-role-dependencies.json','concurrent-role-dependencies-2.json','concurrent-role-dependencies-3.json']
for n in proofnames+['concurrent-shared-dependencies-3.json']:
 if (E/n).exists():(D/n).write_bytes((E/n).read_bytes())
proofs=[read(D/n) for n in proofnames]
registry=B/'v5/run/snapshot/config/role_registry.json';candidate='263958510f78789e33dd29676d510a672900ce26'
configs=[('v2',['run','writer-run'],19,60),('v3',['run'],12,38),('v4',['run','consumer-run'],7,23),('v5',['run','consumer-run'],3,11),('communication',['run'],1,4),('assistant-repair',['run'],1,3)]
reports={};history=[]
for ver,names,den,crit in configs:
 rs={n:p.report(B/ver/n) for n in names if (B/ver/n/'manifest.json').exists()};reports[ver]=rs;counts=collections.Counter();collected=graded=0
 for name in rs:
  for a in (B/ver/name/'cases').glob('*/attempts/*'):
   collected+=(a/'collection.json').exists()
   if (a/'grade.json').exists():graded+=1;counts.update(x['verdict'] for x in read(a/'grade.json')['checks'])
 history.append({'version':ver,'preregistered_denominator':den,'preregistered_criteria':crit,'actual_collected_attempts':collected,'graded_attempts':graded,'raw_case_passes':sum(r['passed'] for r in rs.values()),'raw_first_passes':sum(r['first_pass'] for r in rs.values()),'criteria':dict(counts),'not_executed_or_deferred':den-collected,'feedback_assisted':ver in {'communication','assistant-repair'},'integrity_errors':{n:r['integrity_errors'] for n,r in rs.items()}})
rows=[];v3roles={'research-explore','research-implement-optimize','explain-research-concepts','paper-reading-companion','travel-planner'}
for role in read(registry)['roles']:
 cid=role['id'];ver='assistant-repair' if cid=='research-assistant' else 'communication' if cid=='code-organization' else 'v5' if cid=='model-with-knowledge' else 'v3' if cid in v3roles else 'v2'
 result=next(c for c in reports[ver]['run']['cases'] if c['case_id']==cid); proof=[]
 start={'v2':0,'v3':1,'v4':2,'communication':2,'v5':3,'assistant-repair':3}[ver]
 for i in range(start,3):
  entry=next(x for x in proofs[i]['roles'] if x['role']==cid);proof.append({'file':'final-controller-evidence/'+proofnames[i],'sha256':sha(D/proofnames[i]),'changed':entry['changed'],'all_dependencies_equal':all(x['same'] for x in entry['dependencies'])})
 grade=B/ver/'run/cases'/cid/'attempts/0001/grade.json';feedback=ver in {'communication','assistant-repair'}
 rows.append({'role':cid,'version':ver,'source_candidate':reports[ver]['run']['revision'],'case':cid,'pass':result['passed'],'feedback_assisted':feedback,'first_unassisted_gate_pass':False if feedback else result['first_pass'],'execution_claim':'actual explicit-feedback repair' if feedback else 'executed on v5 frozen candidate' if ver=='v5' else 'reused prior actual execution, NOT reexecuted on v5','unchanged_dependency_proof':proof,'reuse_proven':all(x['all_dependencies_equal'] and not x['changed'] for x in proof),'grade_path':str(grade.relative_to(B)),'grade_sha256':sha(grade) if grade.exists() else None,'criteria':dict(collections.Counter(c['verdict'] for c in read(grade)['checks'])) if grade.exists() else {}})
extra=[]
for ver,run,cid in [('v4','run','smoke-main-general'),('v4','run','smoke-main-route'),('v4','run','main-wait-publication'),('v5','run','main-knowledge-producer'),('v5','consumer-run','knowledge-handoff-consumer')]:
 rr=reports[ver].get(run,{});c=next((c for c in rr.get('cases',[]) if c['case_id']==cid),{});extra.append({'version':ver,'run':run,'case':cid,'pass':c.get('passed',False),'claim':'actual v5' if ver=='v5' else 'prior actual v4 main case reused under unchanged shared dependencies','proof':None if ver=='v5' else 'final-controller-evidence/concurrent-shared-dependencies-3.json'})
out={'candidate':candidate,'role_denominator':len(rows),'applicable_role_passes':sum(x['pass'] and x['reuse_proven'] for x in rows),'unassisted_applicable_role_passes':sum(x['pass'] and x['reuse_proven'] and not x['feedback_assisted'] for x in rows),'feedback_assisted_role_passes':sum(x['pass'] and x['feedback_assisted'] for x in rows),'roles':rows,'targeted_main_handoff_cases':extra,'historical_denominators':history,'reports':reports,'budget_grading_correction':read(B/'budget-gate-correction.json'),'boundary':'Candidate matrix for independent root review. Original v4 assistant raw pass adjudicated false; new repair counted separately. Reused cases retain source candidate. Grouped contexts are not independent trials. Host observations, unknown model/tokens/cost, no performance or Skill-learning claim. Old v1 excluded.'}
write(B/'final-matrix.json',out)
lines=['# Latest applicable role evidence candidate','', '| Role | Version | Pass | Evidence |','|---|---|---|---|']
for x in rows:lines.append(f"| {x['role']} | {x['version']} | {x['pass']} | {'explicit-feedback repair' if x['feedback_assisted'] else 'actual v5' if x['version']=='v5' else 'prior actual; dependency proof'} |")
lines+=['',f"Applicable passes: {out['applicable_role_passes']}/{len(rows)}; {out['unassisted_applicable_role_passes']} without feedback repair, {out['feedback_assisted_role_passes']} explicit-feedback recoveries.",'','Historical denominators and raw grading errors remain distinct in final-matrix.json. This is evidence applicability, not a claim every role reran on the latest candidate.']
(B/'final-matrix.md').write_text('\n'.join(lines)+'\n');print(json.dumps({k:out[k] for k in ['candidate','applicable_role_passes','unassisted_applicable_role_passes','feedback_assisted_role_passes','role_denominator']},indent=2))

run=v3/research-assistant/0001；本轮目标：基于 v5 合成时间推进分析，安排图与有界结果段落。不做新实验、不启用服务、无 GPU。使用固定科研协调角色，分阶段完成；无后台监督器，本轮同步处理。TASK.md 未随输入提供；不另造第二份项目总清单。

版本影响：collect@v4 是历史已完成声明，原始 v4 证据保留，未提供原文件不得冒称本轮检查过；v5 数据已读取并算术复核。figure@v4 依赖旧数据，对 v5 解释标 stale；历史图未提供，不能作为本轮验收。write 原为 todo，旧依赖暂停，改绑定 v5 analysis/figure。background@v1 的 concept 输入未变，不因计时更新重跑；但 background@v1 产物本身未提供，保留的是适用范围与历史状态，不把历史背景文档标成本轮独立验收。

本轮实际完成 RES-T001 输入变更影响核对，RES-T002 v5 汇总计算，RES-T003 背景适用性保留检查（产物 availability 单独 unknown）；输出 analysis.json、impact.json 与当前文件。下一步 FIG-T001 按 v5 画图，再 WRITE-T001 写有界结果段，最后 RES-T004 检查数据与解释一致。图和正文未生成，不伪称完成。

派生观察：small 1.25× / 降20%，medium 1.20× / 降16.667%，large 0.9091× / 增10%，kernel 3× / 降66.667%。每负载仅单条合成观察；kernel-only 与 end-to-end 分层，不相加；不得说所有负载3×或没有退化。没有方差、质量或瓶颈证据；无权重，不合并排名。

图规范：FIG-T001 使用 v5 analysis.json 与原 CSV，横轴 small/medium/large，纵轴 latency(ms)，baseline/candidate 成对柱或点图；kernel 另 panel/另图标 kernel-only；不得误差条（缺重复）；caption 明示 synthetic one observation，large 回归可见。验收需读取最终图、核对4行单位/口径/数据哈希，不把生成成功当通过。
结果段规范：WRITE-T001 明说两项端到端改善、一项10%退化、局部3×不可外推；限定单次合成配置，不断言显著性、质量等价或机制成立。正文数值绑定 v5；写前核查图和数据版本，不引用失效图。由于本轮用户要求计划图和段落，这两项为后续可执行任务。

下一负责人为调用方主 AI：取得历史背景产物时另核真实性；当前不存在必须重做背景的证据。后台运行未启动，无需停止服务；后续节点不应自动消耗新计算预算。

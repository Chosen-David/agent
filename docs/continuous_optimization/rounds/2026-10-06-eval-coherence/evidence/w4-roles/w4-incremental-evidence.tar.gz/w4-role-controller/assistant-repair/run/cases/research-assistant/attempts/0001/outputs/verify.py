"""Read-only acceptance checks; one CPU invocation, no experiment or mutation."""
import csv, hashlib, json, math
from pathlib import Path
O=Path(__file__).resolve().parent
I=O.parents[2]/"inputs"
def read(n): return json.loads((O/n).read_text())
rows=list(csv.DictReader((I/"measurements.csv").open()))
a=read("analysis.json")
assert len(rows)==len(a["measurements"])==4
for r,s in zip(rows,a["measurements"]):
    b,c=float(r["baseline_ms"]),float(r["candidate_ms"])
    assert s["workload"]==r["workload"] and s["scope"]==r["scope"]
    assert s["baseline_ms"]==b and s["candidate_ms"]==c
    assert math.isclose(s["speedup"],b/c)
    assert math.isclose(s["latency_change_percent"],100*(c-b)/b,abs_tol=1e-12)
assert a["measurements"][2]["latency_change_percent"]>0
assert a["concept"]["output_before"]==6 and a["concept"]["output_after"]==10
for r in read("input_version.json")["files"]:
    assert hashlib.sha256(Path(r["path"]).read_bytes()).hexdigest()==r["sha256"]
tasks=read("task_chain.json")["tasks"]; by={t["task_id"]:t for t in tasks}
assert len(by)==len(tasks)
visiting=set(); visited=set()
def walk(k):
    assert k not in visiting
    if k in visited:return
    visiting.add(k)
    for d in by[k]["depends_on"]:
        assert d in by
        if by[k]["status"]=="done":assert by[d]["status"]=="done"
        walk(d)
    visiting.remove(k);visited.add(k)
for t in tasks:
    walk(t["task_id"])
    assert t["resource_budget"]["max_attempts"]==1
    assert t["resource_budget"]["max_retries"]==0
    if t["status"]=="done":
        for p in t["outputs"]:assert (O/p).is_file()
assert "RES-v5" in by["RES-concept"]["depends_on"]
future=[t for t in tasks if t["status"]=="todo"]
assert len(future)==3
assert sum(t["resource_budget"]["wall_seconds_max"] for t in future)==120
budget=read("budget.json")
assert budget["worker_attempts_max"]==1 and budget["worker_wall_seconds_max"]==600
assert budget["planned_followup"]["cumulative_wall_seconds_max"]==120
assert budget["planned_followup"]["max_retries_per_node"]==0
spec=read("figure_spec.json")
assert [p["scope"] for p in spec["panels"]]==["end_to_end","kernel_only"]
assert [p["workloads"] for p in spec["panels"]]==[["small","medium","large"],["kernel"]]
print(json.dumps({"status":"passed","scope":"read-only arithmetic, source hashes, graph and budget structure; not independent semantic grading", "rows":4,"tasks":len(tasks),"acyclic":True,"done_dependencies_satisfied":True,"future_budget_seconds":120,"future_attempts_per_node":1,"new_experiments":False},ensure_ascii=False,indent=2))

"""Preserve v3/v4 increment evidence; v2 archive remains untouched."""
from pathlib import Path
import json,tarfile,hashlib,datetime,shutil,subprocess
B=Path(__file__).resolve().parent;E=B.parent/'agent/docs/continuous_optimization/rounds/2026-10-06-eval-coherence/evidence/w4-roles';E.mkdir(exist_ok=True,parents=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[]
for name in ['v3','v4','v5','communication','assistant-repair','final-controller-evidence']:
 files += [p for p in (B/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
for name in ['final_matrix.py','final-matrix.json','final-matrix.md','package_incremental.py','replay_incremental.py','budget-adjudication.json','budget-adjudication.md','budget-gate-correction.json','summarize_communication.py','packaging-failure.json']:
 if (B/name).exists():files.append(B/name)
archive=E/'w4-incremental-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for rootname in ['v3','v4','v5','communication','assistant-repair','final-controller-evidence']:
  for path in sorted((B/rootname).rglob('*')):
   if path.is_dir() and '__pycache__' not in path.parts and not any(path.iterdir()):t.add(path,arcname='w4-role-controller/'+str(path.relative_to(B)),recursive=False)
 for f in sorted(set(files)):t.add(f,arcname='w4-role-controller/'+str(f.relative_to(B)),recursive=False)
index={'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_files':{str(f.relative_to(B)):sha(f) for f in sorted(set(files))},'boundary':'Actual archived executions, grouped contexts explicitly reported, not new replay execution. Pair with original v2 archive for reused role artifacts.'}
(E/'incremental-archive.json').write_text(json.dumps(index,indent=2)+'\n')
for f in ['final-matrix.json','final-matrix.md']:shutil.copyfile(B/f,E/f)
print(json.dumps({k:v for k,v in index.items() if k!='source_files'},indent=2))

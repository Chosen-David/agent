"""Portable record/hash replay only; not a new worker run."""
from pathlib import Path
import json,importlib.util
B=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('p',B/'v4/pipeline.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
r={}
for ver,names in [('v3',['run']),('v4',['run','consumer-run']),('v5',['run','consumer-run']),('communication',['run']),('assistant-repair',['run'])]:
 r[ver]={n:p.report(B/ver/n) for n in names if (B/ver/n/'manifest.json').exists()}
print(json.dumps({'reports':r,'boundary':'Read-only hash/materialreview replay, no model reexecution. v3 denominator12 includes unexecuted superseded main-route and deferred consumer; v4 denominator7; v5denominator3; two separate explicit-feedback repairs1each. Rawv4assistant pass subject preserved independent adjudication.'},indent=2))

# Experiment DELTA; input synthetic-w4-d; result results/beta.json
# Documentation fixture: do not execute.

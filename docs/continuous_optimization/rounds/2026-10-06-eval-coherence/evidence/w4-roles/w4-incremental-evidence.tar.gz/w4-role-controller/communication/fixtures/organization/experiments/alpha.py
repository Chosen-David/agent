# Experiment GAMMA; input synthetic-w4-g; result results/alpha.json
# Documentation fixture: do not execute.

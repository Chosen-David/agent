# Independent budget adjudication

**Recommendation: both v3 and v4 fail criterion 2 on the documented stopping budget; both pass its DAG/dependency parts.** The opposite original verdicts are not explained by a material change in the disputed obligation. Original reviews and collected outputs are preserved.

Exact frozen criterion:

> acyclic plan with bounded CPU budget; completed tasks do not depend on blocked/skipped execution tasks

The task and all three inputs are byte-identical. `project.json` gives `CPU only; no new service or GPU spend`. That constrains hardware/spend, but does not erase the rubric's bounded-budget requirement. The original Skill expressly directs reading `references/execution.md`; its first instruction says **“维护 task_id、输入版本、依赖、负责人、完成条件和停止预算。”** That supplement is byte-identical in v3 and v4. The unchanged supervision reference also names maximum attempts. No new numerical timeout requirement is needed to reach this conclusion.

| Obligation/evidence | v3 | v4 |
| --- | --- | --- |
| Graph | 6 nodes, acyclic, references exist | 7 nodes, acyclic, references exist |
| Completed dependencies | All done dependencies done | All done dependencies done |
| CPU restriction | `CPU only, bounded local task` | `CPU only; no new data/service/GPU` |
| Fixed scope | Four timing rows; one chart with separated kernel scope; paragraph; final acceptance | Same four rows; extra finite concept check; one two-panel chart; paragraph |
| Future work | Figure, paragraph, acceptance | Figure rendering, final paragraph |
| Failure behavior | Stop dependent task; retain evidence | Retain evidence; diagnose mismatch; preserve v4 |
| Consumption/attempt stopping allowance | Not stated | Not stated |

V4 materially improves deliverable completeness by writing the draft and a structured figure specification. It does not materially improve the CPU budget. V3 already has the finite input/output scope that the v4 review cites as sufficient. V3's statement that future nodes should not automatically consume a new compute budget limits escalation; it does not give an executable stopping allowance for those nodes. Its failure rule stops dependent work, not an explicitly limited number of attempts at the current task.

The consistent threshold is an identifiable finite allowance or equivalent stopping rule for execution when acceptance is not achieved. It need not be wall-clock seconds or a process-enforced timeout. A fixed one-pass computation is intrinsically bounded; “produce one acceptable figure/paragraph” bounds output count but leaves effort/revision attempts unspecified. No assumption is made that either run actually exceeded resources.

A permissive interpretation equating “bounded budget” with finite desired deliverables under CPU-only restrictions would make **both pass**, not distinguish them. However, that reading fails to give effect to the original Skill's explicit stopping-budget instruction. Thus both-fail is the better-supported interpretation; old grader verdicts were not treated as authoritative.

Gate recommendation: do not use the existing v4 pass as proof that the v3 budget gap was repaired. Keep the original reviews, attach this adjudication, and retain the criterion as failed/unresolved at the publication gate until the established resolution procedure or a genuinely new authorized attempt. Do not alter collected outputs or silently import replacement grades. If a scope-only interpretation is adopted, apply it consistently to both versions and record the interpretation change.

This was read-only adjudication, not new task execution. Only these two adjudication files were created in the controller directory. No network, nested agents, grade edits, output repairs, source changes or rerunning submitted programs occurred. An independent read-only DFS verified both DAGs; every original review and collection output hash matches the currently collected bytes. The JSON companion contains the exact task, authority quotations, comparison, checks and complete SHA-256 evidence manifest.

## Evidence manifest

- `rubric.json` — SHA-256 `78421e01c94dd058a6a7a52e868dceaa599fac0065283c373a11d21d5abbe6c6`
- `v3/run/rubric.json` — SHA-256 `cc5d82900ddcd2549f4b25a473b98e911dbf75e6382619c00061a32d38fd4457`
- `v3/run/cases/research-assistant/task.txt` — SHA-256 `551dcc43ff66a709538218010fd68d8b9c67b0516a04045ff2bdc8c54a6e40b9`
- `v3/run/cases/research-assistant/inputs/concept.txt` — SHA-256 `58f7bd9ff07c2f3821a3a65501f8e5ad46c9216f75c73573d03a4dd6178f34fe`
- `v3/run/cases/research-assistant/inputs/measurements.csv` — SHA-256 `4eb8981ad44ca91bacdaed1e4412dd033fd9cae02e0bc2febcfa9676013557db`
- `v3/run/cases/research-assistant/inputs/project.json` — SHA-256 `37b77c640a75def0cd7a020ff6a306a2015808b52e12a2975402f8f501844fa1`
- `v3/run/cases/research-assistant/attempts/0001/collection.json` — SHA-256 `999a811dc842b0ae81427d1a5d0d0cca49af4116206341ccb9587c3b67954148`
- `v3/run/reviews/research-assistant.json` — SHA-256 `435de01b9cf4cc8f6ac4ab62cc1de5c291c3ce1227cc9fffe4aa805cedc68a14`
- `v3/run/reviews/v3_grader-notes.md` — SHA-256 `ef256c4e863a701b3cc8ab935ddaeef1a6cdeacebe4caee9cc2c0620faae867a`
- `v3/run/cases/research-assistant/attempts/0001/outputs/aggregate.py` — SHA-256 `e2a9c3b7776dca9ac8e6329f9bef4cac85ad63c29ee52fe1079d7bdadd21ee7a`
- `v3/run/cases/research-assistant/attempts/0001/outputs/analysis.json` — SHA-256 `d829e6b7b37795051c8f099b6959ae0409e78490589ddbb277e00e03981b9188`
- `v3/run/cases/research-assistant/attempts/0001/outputs/execution.md` — SHA-256 `29d2088402831fcfed86cf637673361da48e7ba284cea74247dd5c54bbcb6be7`
- `v3/run/cases/research-assistant/attempts/0001/outputs/handoff.md` — SHA-256 `becbad95d75e5dba0d2f2a6c85eb2706b88f1e890bfacf0a07dcfc69ea73ecb3`
- `v3/run/cases/research-assistant/attempts/0001/outputs/impact.json` — SHA-256 `7a57d4d1faaf0ce50ba2b40a9c1591012373cf2b569a49c8c1da84d2c5015f36`
- `v3/run/cases/research-assistant/attempts/0001/outputs/loaded.json` — SHA-256 `370f1dbe235e40642760a030e176081440310bfa6b9d4f3d7191f057d1b8cf3d`
- `v3/run/cases/research-assistant/attempts/0001/outputs/project_state.md` — SHA-256 `b647b047d8955b6cbdcf5a2e5018cad6b301ac9073fa1c91aed1f2a71cac1933`
- `v3/run/cases/research-assistant/attempts/0001/outputs/task_chain.yaml` — SHA-256 `5be02e4c96a9dcc902cd589fcea8ec29ffb4cac944b45e634d480001c597e54f`
- `v3/run/snapshot/plugins/research-assistant/skills/research-assistant/SKILL.md` — SHA-256 `1cdadc16c99c4ed1f6811af6a71ed235b041db65a551cbf897858a4e022f65b5`
- `v3/run/snapshot/plugins/research-assistant/skills/research-assistant/references/execution.md` — SHA-256 `03fb1be653be48a441a5bbdd11462d9901399c3c2b2f8c39b8189128ce20a067`
- `v3/run/snapshot/plugins/research-assistant/skills/research-assistant/references/task_supervision_workflow.md` — SHA-256 `c567a6f6d555d60c5fabc45632352e76326d01ab6ae6d496e64f26d9c58e98c8`
- `v3/run/snapshot/plugins/research-assistant/skills/research-assistant/references/orchestrator.md` — SHA-256 `634cf76b289863db18df56b95a25fa013c3bcb1c5eb763cc66a62e56def47d42`
- `v4/run/rubric.json` — SHA-256 `989ffb0bcc474ef850d09b6cfbdcac067af97bdd7eaee91b65c7b91a371f8488`
- `v4/run/cases/research-assistant/task.txt` — SHA-256 `551dcc43ff66a709538218010fd68d8b9c67b0516a04045ff2bdc8c54a6e40b9`
- `v4/run/cases/research-assistant/inputs/concept.txt` — SHA-256 `58f7bd9ff07c2f3821a3a65501f8e5ad46c9216f75c73573d03a4dd6178f34fe`
- `v4/run/cases/research-assistant/inputs/measurements.csv` — SHA-256 `4eb8981ad44ca91bacdaed1e4412dd033fd9cae02e0bc2febcfa9676013557db`
- `v4/run/cases/research-assistant/inputs/project.json` — SHA-256 `37b77c640a75def0cd7a020ff6a306a2015808b52e12a2975402f8f501844fa1`
- `v4/run/cases/research-assistant/attempts/0001/collection.json` — SHA-256 `c1901500e5f68c6a19349741ee29c4ad26c0a6bd92dbffe3f56942e7c0271613`
- `v4/run/reviews/research-assistant.json` — SHA-256 `d574b7fcb0617521466f8d86e77890abac81f460d87b5becc4aadca9f59d8964`
- `v4/run/reviews/v4_grader-notes.md` — SHA-256 `7df948085bc2429eccfc9d4bfce0b31f8f3f34877cf9720348984ed218805d29`
- `v4/run/cases/research-assistant/attempts/0001/outputs/analysis.json` — SHA-256 `16667ef9757799a31cedcd1d6381661bb83980104988e10256f089c6037b859d`
- `v4/run/cases/research-assistant/attempts/0001/outputs/analyze.py` — SHA-256 `5fb7d8003b27032d2625afcb03bce3023fd94424a0d28153d1c50391fe92ef9a`
- `v4/run/cases/research-assistant/attempts/0001/outputs/artifacts.json` — SHA-256 `7cbb81e56c72e9aa80c25e8afefb1d7684365ff3632a227f9c769a6ac220be28`
- `v4/run/cases/research-assistant/attempts/0001/outputs/execution.md` — SHA-256 `8de02ad0e8f1b3c5aa3a167f534ab2356eb72ffa1e099a4666ae32df37babb5d`
- `v4/run/cases/research-assistant/attempts/0001/outputs/figure_spec.json` — SHA-256 `03293e606aeeafc0f51650ffbd3715abd32b55c71038c6130368682bec9a2821`
- `v4/run/cases/research-assistant/attempts/0001/outputs/input_version.json` — SHA-256 `dc815a2be1883c7095ea653c828d1784c76bfdb83ff9d64e3650468421b0a00b`
- `v4/run/cases/research-assistant/attempts/0001/outputs/loaded.json` — SHA-256 `2cfff6fda5278d29d20d33151354d0b252be25bb88592dbfab55e365d78fde8d`
- `v4/run/cases/research-assistant/attempts/0001/outputs/project_state.md` — SHA-256 `feafd58b6c2063e343d2f15ae7940a0f15890cb0ea1b7edafaee507c9b340063`
- `v4/run/cases/research-assistant/attempts/0001/outputs/report.md` — SHA-256 `c6c307a30550c5f1609b0e095ec00464f778a15060a59763631e073dccd94801`
- `v4/run/cases/research-assistant/attempts/0001/outputs/task_chain.json` — SHA-256 `34ec9ae4ac9cac1bedd36ca29b82af195b516714323f74d4db7b6b9244e14ab9`
- `v4/run/snapshot/plugins/research-assistant/skills/research-assistant/SKILL.md` — SHA-256 `1cdadc16c99c4ed1f6811af6a71ed235b041db65a551cbf897858a4e022f65b5`
- `v4/run/snapshot/plugins/research-assistant/skills/research-assistant/references/execution.md` — SHA-256 `03fb1be653be48a441a5bbdd11462d9901399c3c2b2f8c39b8189128ce20a067`
- `v4/run/snapshot/plugins/research-assistant/skills/research-assistant/references/task_supervision_workflow.md` — SHA-256 `c567a6f6d555d60c5fabc45632352e76326d01ab6ae6d496e64f26d9c58e98c8`
- `v4/run/snapshot/plugins/research-assistant/skills/research-assistant/references/orchestrator.md` — SHA-256 `8cf6767d5b9b4bb2939e093cc9e73f4db6b8a532b7fbf2511fe468b4a8ab66b5`

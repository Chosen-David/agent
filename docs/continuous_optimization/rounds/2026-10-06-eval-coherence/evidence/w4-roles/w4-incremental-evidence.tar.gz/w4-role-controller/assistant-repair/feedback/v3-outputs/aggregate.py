import csv,json
from pathlib import Path
source=Path(__file__).resolve().parents[3]/'inputs/measurements.csv'
rows=[]
for x in csv.DictReader(source.open()):
    b=float(x['baseline_ms']);c=float(x['candidate_ms'])
    rows.append(dict(x,speedup=b/c,latency_reduction=(b-c)/b))
Path(__file__).with_name('analysis.json').write_text(json.dumps({'source':str(source),'version':'v5','kind':'synthetic supplied observations','rows':rows},indent=2))
print(json.dumps(rows))

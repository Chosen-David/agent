# Root v3 pre-dispatch correspondence
All task/rubric text and raw fixtures reviewed. Prior v2 travel CNY approval was wrong and retained; new material keeps currency unknown. No output acceptance claimed.

## research-assistant criterion 1
v5 update invalidates dependent v4 figure/write interpretations, retains raw v4 evidence and unchanged background with a dependency-based explanation

project.json explicitly changes measurements v4 to v5 and identifies figure/write dependencies while concept.txt remains v1; raw historical evidence must remain.

## research-assistant criterion 2
acyclic plan with bounded CPU budget; completed tasks do not depend on blocked/skipped execution tasks

project.json CPU-only resource restriction and dependency graph support bounded acyclic plan; criterion asserts required behavior, not that any task already executed.

## research-assistant criterion 3
no invented run, role or completed artifact

Task prohibits invented experiments. Inputs label synthetic data; artifact or role existence must be observed.

## research-explore criterion 1
Separates kernel-only 3x from end-to-end 1.25x/1.2x/10 percent large latency increase; no universal3x claim

Actual CSV arithmetic root recomputed: kernel36/12=3; small90/72=1.25; medium150/125=1.2; large264/240-1=10%. Manuscript itself overclaims in abstract, discloses regression in Appendix.

## research-explore criterion 2
rival explanation and discriminating experiment with fixed metric

Explicit task asks mechanism, strongest rival and discriminating experiment with metric; no required canned hypothesis.

## research-explore criterion 3
bounded go/pivot/stop criteria, no novelty assertion

Explicit task asks stopping/resources and prohibits novelty claim; proposed experiments are not completed experiments.

## research-implement-optimize criterion 1
moving_average([2,6,10],2)==[4,8]; full-window, empty, oversize, negative/zero/noninteger/bool-window behavior is correct and input preserved

Task/code docstring states positive int excluding bool, complete windows, oversize empty and input preservation. [2,6,10] width2 has means4,8; original range misses final window.

## research-implement-optimize criterion 2
independent tests actually run; input unchanged

Task requires independently run checks, not merely proposed tests; acceptance may execute outputs independently.

## research-implement-optimize criterion 3
large workload regression and no GPU claim

CSV large240→264 is regression; no GPU measured per manuscript/task.

## paper-reading-companion criterion 1
Correct6->10 calculation with p=(1/2,1/2) then(1/4,3/4), V=(-2,14); universal RoPE claim bounded

Actual same-byte PDF page2 and concept data give V=(-2,14), p=(.5,.5) output6 then(.25,.75) output10. It explicitly labels universal RoPE claim as draft overclaim.

## paper-reading-companion criterion 2
physical page 2 retained; notes match PDF hash

Physical page2 differs from printed page1; actual source SHA c5428c1e... checked and equals prior v2 bytes.

## paper-reading-companion criterion 3
real offline HTML generated with no fake live backend

Task asks genuine local HTML; generated equivalent PDF is additional requirement and will be visually checked, no live service claim.

## explain-research-concepts criterion 1
Correct exact softmax probabilities(1/2,1/2)->(1/4,3/4) and outputs6->10 from fixed V=(-2,14)

Root exact rational computation: (-2+14)/2=6 and -2/4+42/4=10; softmax log3 gives1/4,3/4.

## explain-research-concepts criterion 2
Jacobian (diag(p)-pp^T) and fixed-V scope correct

For logits z=a+b, dp/dz=diag(p)-pp^T; fixed V output derivative multiplies this matrix by V. It is local and does not license arbitrary finite-error cancellation.

## explain-research-concepts criterion 3
no claim of RoPE-specific universal evidence

concept.txt explicitly synthetic with no RoPE model or empirical evidence; common-logit shifts form a valid invariance counterexample.

## travel-planner criterion 1
Both schedules honor available11:00-19:00, lunch starts by13:00 and full70 minutes within11:00-14:00, and16:30-17:30 confirmed photo

Actual travel.json available11–19, lunch last_order13/service11–14/duration70, photo16:30–17:30 userconfirmed. Root constructed both feasible schedules in oracle without changing these windows.

## travel-planner criterion 2
Each schedule includes independent uninterrupted80-minute Hotel M rest and all four supplied directed commutes:25min original,40min amended; no invented shortcut/teleport

Source route gives exactly hotel→lunch→hotel→photo→hotel, duration25 original and40 amended; independent80-minute Hotel M rest and roomavailable. Feasible schedules preserve all four legs and separate rest.

## travel-planner criterion 3
Both two-person base budgets are180-220 meals+240 group photo+80-120 one-vehicle fares=500-580 input currency units; currency is unspecified and stays unknown. Any optional contingency is separate from base costs; synthetic facts only, no real booking/liveverification claim

No currency field or explicit currency in raw source. Root recomputed 2*(90..110)+240+4*(20..30)=500..580; fares one vehicle, photo one group. Optional contingency cannot silently alter base range. Synthetic context prohibits livebooking claim.

## smoke-main-general criterion 1
Actual answer correctly derives total74CNY, each share37CNY, roommate transfers13CNY to user; no reversed transfer

Explicit CNY in user prompt:22+28+24=74, equalshare37, roommatepaid24 so owes13; independently recomputed.

## smoke-main-general criterion 2
Natural non-coercive Chinese reminder; directly answers ordinary request without research workflow, delegation, novelty search or extra clarification

Ordinary task only asks calculation/draft reminder, no sending or research. Naturalness independently judged against this scope.

## smoke-main-route criterion 1
Observable execution selects the reading-companion workflow/capability for page-specific continuing reading (by actually loading its repository entry/dependencies); does not substitute a full scientific review or full-PDF defect audit. Explicit role-name text alone is not sufficient evidence.

User asks ongoing page reading; reading-companion actual entry loading is observable behavior, not assumed from role name.

## smoke-main-route criterion 2
Actually reads/renders original physical page2 and explains10=(4+10+16)/3 versus13=(10+16)/2, difference3; bounds universal claim with valid reasoning/counterexample such as reverse sequence giving10 versus7

Actual same-byte PDF page2 x=(4,10,16), full10/recent13; reverse(16,10,4) full10/recent7. This is a synthetic teaching example.

## smoke-main-route criterion 3
Actual offline HTML or equivalent offline reading page opens with original page and explanation side by side, local assets available; saved reading state is bound to actual PDF hash and physical page 2. Does not claim a live backend exists.

Task now explicitly requests a static PDF equivalent alongside HTML. Original criterion already allows equivalent offline page. Real local ReportLab/PyMuPDF available; actual production/open must still be observed, not assumed.

## code-organization criterion 1
CODEMAP 每行含可核对锚点（脚本路径/结果文件/commit 至少其一），不虚构映射

Actual scripts alpha/beta comments identify GAMMA/DELTA; results independently reference those scripts and inconclusive/rejected. HIST-0 missing.py stays unknown.

## code-organization criterion 2
目录 README 不超过十行且只覆盖必要目录

Task explicitly limits each needed directory README to ten lines.

## code-organization criterion 3
孤儿与重复文件给提案与回滚方式，不执行删除；运行中管线输出路径未移动

Frozen original criterion explicitly requires rollback proposal; active_tasks marks beta results running and orphan protected. No deletion or movement authorized. Prior omission remains a failure.

## code-organization criterion 4
增量更新不重排历史行，diff 可读

Original CODEMAP has HIST-0 as first historical row; task requires incremental order-preserving diff.

## model-with-knowledge criterion 1
Observed real pinned-corpus search/show and applicability-appropriate fulltext/dependency reads, with actual id/version/sha256 refs for items used; if topk-margin is used its cauchy-schwarz strongdependency is included. Actual check-refs validates closure; no fabricated retrieval or formalproof

Actual Skill and source corpus read; topk-margin requires cauchy-schwarz. Genuine search/show/closure validation are observed process checks, not prefilled expected retrieval scores.

## model-with-knowledge criterion 2
Maps fixedq=(5,0), per-key Euclideanerror<=0.03 to each absolute scoreerror<=0.15; original scores1.2,0.8,0.5 and top1gap0.4>0.3 guarantee set stability under stateduniformbound

Root independently recomputed from fixture exact fractions: qnorm5, bound.03 yields eta.15; scores1.2,.8,.5, gap.4>.3. Cauchy plus pairwise margin proves sufficient stability.

## model-with-knowledge criterion 3
Boundaryscores1.1,0.8 give gap0.3=2eta and admissible opposite aligned errors yield tie0.95,0.95; conditionfailure does not imply unavoidableflip, averageerror alone insufficient

Boundary input .22/.16 with opposed .03 key changes yields both.19 times5=.95; tie at gap2eta possible. Zero perturbation shows failure of sufficient inequality does not force flip; average bound cannot imply per-key bound.

## model-with-knowledge criterion 4
Actual CPU check and derivation are consistent with fixed-query/per-key scope; task_id/task_refs preserved and no empirical speedup/GPU/formalverification invention

Task requires actual CPU checking and K41 refs, forbids benchmarks/GPU/formal claims; domain is fixed real Euclidean query.

## main-knowledge-producer criterion 1
Main actually selects and reads pinned model-with-knowledge entry for fixed-query ranking/perturbation problem; produces modeling_request.json rather than merely naming a role or claiming a launched child

New pinned main conditional route includes model-with-knowledge; input is fixed-query ranking under uniform errors, so actual entry selection/read is appropriate, not mandatory for unrelated main tasks.

## main-knowledge-producer criterion 2
Actual outputs/problem.json is byte-identical to provided handoff_problem.json and source/delivery SHA256 agree; request preserves K42/task_refs, w3-handoff-v1, q=(2,0), all3keys, Euclidean per-keybound0.1 and top_k2 without inventing corpus results

Actual input K42/w3-handoff-v1/q=(2,0)/keys1,.7,.4/error.1/topk2 inspected. Byte-copy/hash rule follows explicit task, no producer result assumed.

## main-knowledge-producer criterion 3
Handoff preserves local-only permissions, fixed-query/uniform-per-key assumptions, expected derivation/refs/CPU checks and clear consumer owner; producer does not substitute a completed proof or fake downstream success

Fixture local-only authorization and requested consumer deliverables are explicit; producer is instructed not to solve or launch child, host owns real next node.

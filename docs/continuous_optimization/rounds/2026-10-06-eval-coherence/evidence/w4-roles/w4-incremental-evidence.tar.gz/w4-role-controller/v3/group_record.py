from pathlib import Path
import sys,json,datetime,uuid,importlib.util
B=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('pipeline',B/'pipeline.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
kind,actor,*cases=sys.argv[1:];run=B/'run';host=run/'host';host.mkdir(exist_ok=True);trust=p.read(B/'root-trust.json');body=json.load(sys.stdin)
for cid in cases:
 if kind=='authorize':
  auth=p.authorize_dispatch(run,cid,actor,material_review=trust);p.write(host/f'{cid}-pre-spawn-authorization.json',{'planned_actor':actor,'trust':auth,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'order':'before actual host spawn','context_group_cases':cases});continue
 receipt={'event_id':f'controller-observed-{kind}-{cid}-{uuid.uuid4()}','event_id_boundary':'Controller record ID for an actual observed host event; no platform event export','kind':kind,'actor':actor,'adapter':'host','case_id':cid,'attempt':1,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'model':'unknown','tokens':'unknown','cost':'unknown','context_group_cases':cases,**body}
 path=host/f'{cid}-1-{kind}.json';p.write(path,receipt)
 p.record_start(run,cid,actor,path,material_review=trust) if kind=='start' else p.collect(run,cid,1,path)
print(json.dumps({'kind':kind,'actor':actor,'cases':cases}))

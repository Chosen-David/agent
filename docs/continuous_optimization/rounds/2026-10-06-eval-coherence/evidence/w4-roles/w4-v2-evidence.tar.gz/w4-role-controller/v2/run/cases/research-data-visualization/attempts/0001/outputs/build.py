from pathlib import Path
import csv,json,hashlib,sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from PIL import Image
O=Path(__file__).resolve().parent
I=O.parents[2]/'inputs'
C=O.parents[2].name
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
rows=list(csv.DictReader((I/'measurements.csv').open())) if (I/'measurements.csv').exists() else []
arch=json.loads((I/'architecture.json').read_text()) if (I/'architecture.json').exists() else None

def diagram(ax,title):
 ax.set(xlim=(0,12),ylim=(0,9));ax.axis('off');ax.set_title(title,loc='left',fontweight='bold',pad=16)
 pos={'a':(1.3,6),'b':(1.3,3.1),'sum':(4.4,4.55),'softmax':(7.5,4.55),'output':(10.6,4.55),'v':(10.6,7.1)}
 labels={x['id']:x['label'] for x in arch['nodes']}
 for n,(x,y) in pos.items():
  box=FancyBboxPatch((x-1.12,y-.58),2.24,1.16,boxstyle='round,pad=0.04,rounding_size=0.13',facecolor='#e6f3f1' if n in ['sum','softmax','output'] else '#edf0f4',edgecolor='#526371',linewidth=1.1);box.set_gid('node_'+n);ax.add_patch(box)
  ax.text(x,y,labels[n],ha='center',va='center',fontsize=9)
 for s,t in arch['edges']:
  x,y=pos[s];xx,yy=pos[t]
  if s=='v':start=(x,y-.65);end=(xx,yy+.65)
  else:start=(x+1.17,y);end=(xx-1.17,yy)
  edge=FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=12,color='#344958',linewidth=1.3);edge.set_gid('edge_'+s+'_'+t);ax.add_patch(edge)
 ax.text(6,1.25,'Proposed • synthetic specification • not implemented',ha='center',fontsize=9,color='#526371')
 ax.text(6,.65,'Arrows: data flow. V enters only the output.',ha='center',fontsize=9,color='#526371')

def data(ax,title):
 x=[0,1,2,3.6]; w=.33
 baseline=[float(r['baseline_ms']) for r in rows];candidate=[float(r['candidate_ms']) for r in rows]
 b=ax.bar([v-w/2 for v in x],baseline,w,label='Baseline',color='#63778d')
 q=ax.bar([v+w/2 for v in x],candidate,w,label='Candidate',color='#249b8d',hatch='///',edgecolor='#145c55',linewidth=.5)
 ax.bar_label(b,padding=3,fontsize=9,fmt='%g');ax.bar_label(q,padding=3,fontsize=9,fmt='%g')
 ax.set_xticks(x,[r['workload'].capitalize() for r in rows]);ax.set_ylim(0,320);ax.set_yticks([0,60,120,180,240,300]);ax.set_ylabel('Time (ms; lower is better)');ax.set_title(title,loc='left',fontweight='bold',pad=16)
 ax.grid(axis='y',color='#e4e8eb',linewidth=.7);ax.set_axisbelow(True)
 ax.axvline(2.8,color='#adb7bf',linestyle=':',linewidth=1)
 ax.text(1,305,'End-to-end',ha='center',fontsize=9,color='#526371');ax.text(3.6,305,'Kernel only',ha='center',fontsize=9,color='#526371')
 ax.legend(loc='upper left',bbox_to_anchor=(0,-.15),frameon=False,ncol=2)
 ax.text(1,-.28,'Supplied timings; uncertainty not reported',transform=ax.transAxes,ha='right',fontsize=8,color='#526371')

def save(fig,name):
 fig.savefig(O/(name+'.svg'),bbox_inches='tight')
 fig.savefig(O/(name+'.png'),dpi=180,bbox_inches='tight')
 plt.close(fig)
 Image.open(O/(name+'.png')).convert('L').save(O/(name+'-grayscale.png'))
if C=='research-figures':
 fig,axs=plt.subplots(1,2,figsize=(13,4.8),gridspec_kw={'width_ratios':[1.2,1]});fig.subplots_adjust(wspace=.24,bottom=.22);diagram(axs[0],'A  Proposed method');data(axs[1],'B  Supplied performance results');save(fig,'figure')
 fig,ax=plt.subplots(figsize=(7,4.8));diagram(ax,'A  Proposed method');save(fig,'panel-a')
 fig,ax=plt.subplots(figsize=(6,4.8));fig.subplots_adjust(bottom=.22);data(ax,'B  Supplied performance results');save(fig,'panel-b')
elif C=='research-diagrams':
 fig,ax=plt.subplots(figsize=(8,4.8));diagram(ax,'Proposed dual-logit normalization');save(fig,'diagram')
else:
 fig,ax=plt.subplots(figsize=(7,4.8));fig.subplots_adjust(bottom=.22);data(ax,'Supplied performance results');save(fig,'results')
if arch:
 (O/'semantic-contract.json').write_text(json.dumps({'source':str(I/'architecture.json'),'nodes':arch['nodes'],'edges':[{'source':s,'target':t,'direction':'forward','kind':'data_flow'} for s,t in arch['edges']],'constraints':arch['constraints'],'status':arch['status'],'evidence_type':arch['evidence_type'],'groups':[],'check':{'node_count':6,'edge_count':5,'no_added_edges':True}},indent=2))
if rows:
 (O/'plotted-values.json').write_text(json.dumps({'source':str(I/'measurements.csv'),'rows':rows,'transforms':[],'missing_cells':sum(v=='' for r in rows for v in r.values()),'uncertainty':'not supplied; none drawn','sample_size':'unknown','comparisons':'descriptive only'},indent=2))
cap=[]
if arch:cap.append('Proposed dual-logit normalization (synthetic specification, not implemented). Parallel logits a and b merge as z = a + b; softmax yields p, and fixed values V enter only y = p^T V. Arrows denote the five supplied data-flow relations. No model execution or architecture validation is claimed.')
if rows:cap.append('Supplied timing results (ms). All four rows are shown without aggregation: small 90/72, medium 150/125, large 240/264, and kernel 36/12 for baseline/candidate. Small, medium and large are end-to-end timings; kernel is kernel-only and does not establish end-to-end improvement. The candidate is slower for large. Repeat counts and uncertainty are unspecified, so no error bars or statistical claims are shown. These values were provided, not measured in this task.')
if C=='research-figures':cap.insert(0,'Panel A: proposed method. Panel B: supplied timing results. The inputs do not establish that the measured candidate implements this proposed architecture; panels are juxtaposed without asserting that linkage.')
(O/'caption.md').write_text('\n\n'.join(cap)+'\n')
(O/'routing.json').write_text(json.dumps({'route':'mixed' if C=='research-figures' else ('diagram' if arch else 'data_visualization'),'owner':'/root/final_role_controller/v2_visual','execution':'staged responsibilities within one worker; no independent agents','panels':[{'id':'A','role':'research-diagrams','source':'architecture.json','evidence':'synthetic proposed specification','editable':'panel-a.svg'} ,{'id':'B','role':'research-data-visualization','source':'measurements.csv','evidence':'supplied reported timings; provenance beyond CSV unknown','editable':'panel-b.svg'}] if C=='research-figures' else [],'versions':{'python':sys.version,'matplotlib':matplotlib.__version__}},indent=2))
print(C, 'rendered', sorted(p.name for p in O.glob('*.png')))

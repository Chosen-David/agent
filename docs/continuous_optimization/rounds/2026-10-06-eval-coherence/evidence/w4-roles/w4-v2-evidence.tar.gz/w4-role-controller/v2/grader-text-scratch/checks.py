from pathlib import Path
import json,csv,hashlib,math,random,statistics,runpy,subprocess
B=Path('/workspace/scratch/c12f3d9f92bd/w4-role-controller/v2'); report={}
cs=['research-assistant','research-explore','research-implement-optimize','research-write','research-review','explain-research-concepts','travel-planner','code-reading','code-organization','smoke-main-general','main-wait-publication','chain-coordinator','chain-writer']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for c in cs:
 R=B/('writer-run' if c=='chain-writer' else 'run'); P=R/'cases'/c; O=P/'attempts/0001/outputs';co=json.loads((O.parent/'collection.json').read_text())
 assert all(sha(O/n)==h for n,h in co['output_hashes'].items())
 ld=json.loads((O/'loaded.json').read_text()); rec=ld.get('files',ld.get('records',[]))
 assert all(sha(Path(z['path']))==z['sha256'] for z in rec)
 # Byte compare frozen material against source fixture where available.
 for f in (P/'inputs').rglob('*'):
  if f.is_file():
   source=B/('writer-fixtures' if c=='chain-writer' else 'fixtures')/f.relative_to(P/'inputs')
   assert f.read_bytes()==source.read_bytes(),str(f)
 if (O/'analysis.json').exists() and c.startswith('research-'):
  a=json.loads((O/'analysis.json').read_text())
  for orig,out in zip(csv.DictReader((P/'inputs/measurements.csv').open()),a['rows']):
   x,y=float(orig['baseline_ms']),float(orig['candidate_ms']);assert out['workload']==orig['workload'] and out['scope']==orig['scope']
   assert math.isclose(out['speedup'],x/y) and math.isclose(out['latency_change_pct'],100*(y/x-1))
 if (O/'task_chain.json').exists():
  ts=json.loads((O/'task_chain.json').read_text());assert ts==json.loads((O/'task_chain.yaml').read_text());d={t['task_id']:t for t in ts};seen=set()
  def visit(k,stack):
   assert k not in stack
   for x in d[k]['depends_on']:visit(x,stack|{k})
   seen.add(k)
  for k,t in d.items():
   visit(k,set())
   if t['status']=='done':assert all(d[x]['status']=='done' for x in t['depends_on'])
 report[c]={'collection_hashes_match':True,'loaded_hashes_match':True,'input_bytes_match_frozen_sources':True}
O=B/'run/cases/research-implement-optimize/attempts/0001/outputs'
f=runpy.run_path(str(O/'fixed.py'))['moving_average']; rng=random.Random(997)
for _ in range(600):
 n=rng.randrange(0,40);v=[rng.randrange(-100,101) for _ in range(n)];w=rng.randrange(1,50);before=v[:]
 # independent bucket accumulation by start positions
 expected=[]
 for end in range(w-1,n):
  total=0
  for j in range(end-w+1,end+1):total+=v[j]
  expected.append(total/w)
 assert f(v,w)==expected and v==before
assert f([2,6,10],2)==[4,8] and f([],1)==[] and f([2,6,10],3)==[6] and f([2],3)==[]
for w in [True,False,1.2,'2',None]:
 try:f([1,2],w)
 except TypeError:pass
 else:raise AssertionError(w)
for w in [0,-1,-100]:
 try:f([],w)
 except ValueError:pass
 else:raise AssertionError(w)
z=subprocess.run(['python','-B',str(O/'check.py')],capture_output=True,text=True);assert z.returncode==0
report['cpu']={'independent_random_cases':600,'worker_checker_rerun':json.loads(z.stdout),'explicit':[4,8]}
P=B/'run/cases/chain-coordinator';O=P/'attempts/0001/outputs';rows=list(csv.DictReader((P/'inputs/chain_latencies.csv').open()));agg=list(csv.DictReader((O/'aggregate.csv').open()));sc=json.loads((P/'inputs/handoff_fields.json').read_text());a=json.loads((O/'analysis.json').read_text());assert len(rows)==18
assert list(agg[0])==sc['aggregate_csv_columns']
for key,typ in sc['analysis_json_required'].items():
 assert isinstance(a[key],int if typ=='integer' else str if typ=='string' else list if typ.startswith('array') else dict)
for out in agg:
 vals={v:[float(r['latency_ms']) for r in rows if r['workload']==out['workload'] and r['variant']==v] for v in ['baseline','candidate']}
 b,c=[statistics.median(vals[v]) for v in ['baseline','candidate']]
 for key,expected in [('n_baseline',3),('n_candidate',3),('baseline_median_ms',b),('candidate_median_ms',c),('speedup_ratio',b/c),('latency_reduction_pct',100*(b-c)/b)]:assert math.isclose(float(out[key]),expected,abs_tol=1e-4)
assert all(sha(Path(s['path']))==s['sha256'] for s in a['source_files']+[a['aggregate_file']])
h=json.loads((B/'handoff.json').read_text());assert sha(Path(h['source_collection']))==h['source_collection_sha256']
for q in h['files']:
 name=Path(q['source']).name;inp=B/'writer-run/cases/chain-writer/inputs'/name
 assert Path(q['source']).read_bytes()==Path(q['destination']).read_bytes()==inp.read_bytes()
 assert sha(inp)==q['source_sha256']==q['destination_sha256']
report['handoff']={'all_bytes_hashes_match':True,'aggregate':agg}
# Independent exact teaching arithmetic and finite difference local Jacobian.
V=[-2,14]
def y(z):
 e=[math.exp(i) for i in z];p=[i/sum(e) for i in e];return sum(x*v for x,v in zip(p,V))
assert y([0,0])==6 and math.isclose(y([0,math.log(3)]),10)
for z,grad in [([0,0],[-4,4]),([0,math.log(3)],[-3,3])]:
 for k in range(2):
  lo=z[:];hi=z[:];lo[k]-=1e-6;hi[k]+=1e-6;assert math.isclose((y(hi)-y(lo))/2e-6,grad[k],abs_tol=1e-7)
# Recompute schedule segment lengths, uninterrupted coverage and fixed appointment.
import re
for n,leg in [(1,25),(2,40)]:
 txt=(B/f'run/cases/travel-planner/attempts/0001/outputs/itinerary_v{n}.md').read_text();segs=[]
 for line in txt.splitlines():
  m=re.match(r'\| (\d\d):(\d\d)–(\d\d):(\d\d) \| (.*?) \|',line)
  if m:
   hh,mm,HH,MM,desc=m.groups();segs.append((60*int(hh)+int(mm),60*int(HH)+int(MM),desc))
 assert segs[0][0]==660 and segs[-1][1]==1140 and all(a[1]==b[0] for a,b in zip(segs,segs[1:]))
 assert [b-a for a,b,d in segs if '→' in d]==[leg]*4
 lunch=[(a,b) for a,b,d in segs if '70分钟' in d][0];rest=[(a,b) for a,b,d in segs if '80分钟' in d][0]
 assert lunch[1]-lunch[0]==70 and lunch[0]<=780 and lunch[1]<=840 and rest[1]-rest[0]==80
 assert any(a==990 and b==1050 and '预约' in d for a,b,d in segs)
report['travel']={'schedules_verified':True,'known_cost':[2*90+240+4*20,2*110+240+4*30],'currency':'not specified'}
report['smoke']={'total':22+28+2*12,'share':(22+28+2*12)/2,'roommate_to_user':50-(22+28+2*12)/2}
(B/'grader-text-scratch/check-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))

# Results
Supplied synthetic metadata, not verified measurements.
alpha.json reports GAMMA as inconclusive; source experiments/alpha.py.
beta.json reports DELTA as rejected; source experiments/beta.py.
beta.json is a running output path: preserve its location.
Raw input data and run provenance are absent.
See ../CODEMAP.md.

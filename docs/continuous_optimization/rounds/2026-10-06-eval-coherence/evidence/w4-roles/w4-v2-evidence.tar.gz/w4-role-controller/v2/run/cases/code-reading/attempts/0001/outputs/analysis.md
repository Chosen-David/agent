# CODE-READ-001: static selector audit

Source: inputs/synthetic_selector.py, SHA256 921976187bedcf18b0f4268ef97ad7bde737a06af2a00f7b4a03f2a7d05bf4c3. Standalone synthetic fixture; commit/branch unavailable. Read via controller numbered-source proxy; never imported/executed. All mechanism claims below are source facts or static inferences, not measured behavior. Module narrative at L1–2 is deliberately contradicted by implementation.

| Claim | Source evidence and corrected conclusion |
|---|---|
| Projector is query-trained | represent L6–9: default selects zero-based dimensions [1,3]. Optional externally supplied basis produces one dot product per column. No fitting/training or basis generation exists. select L21–22 applies same basis to query and each key; neither depends on training here. |
| near is forced window | select L19–20,L24–25: near_len determines far/near boundary; forced_len alone defines mandatory suffix. near candidates are ranked and truncated; merely being in near range does not guarantee inclusion. |
| skip means no scoring | select L21–23: qsmall and reduced scores for EVERY key are computed before skip_far is consulted. skip_far only sets far=[]; near sorting, forced selection and full scoring remain. |
| Final scoring uses reduced keys | run L29–30 sends ORIGINAL query, keys and selected positions to full_score; L12–13 computes original-coordinate dot products via zip. No reduced keys reach final scorer. |

## Calls and data edges

| Caller → callee | Lines | Conditions / data |
|---|---|---|
| run → select | 28–29 | options forwarded as keyword overrides; returns ordered position list |
| select → represent(query) | 21 | original query to 2 coordinates by default, or len(basis) projected coordinates |
| select → represent(key) | 22 | every original key to same reduced representation; score is reduced dot product |
| select → sorting/slicing | 23–25 | reduced scores rank far and near candidates; forced suffix bypasses scoring choice |
| run → full_score | 30 | selected positions plus original query and original key collection |
| full_score → result | 12–13 | one original-coordinate dot product per supplied position; order and duplicates preserved |

Resolved within this file; no dynamic external dispatch shown. Shape inference assumes ordinary numeric sequences and compatible dimensions. zip truncates to shorter inputs both for basis projection and final scoring; no validation enforces equal full dimensions. Default projection raises IndexError for vectors shorter than 4. Dtype, numerical error and runtime shapes are unknown.

## Defaults, budget and ranges

Defaults (L16–17): near_len=5, forced_len=2, budget=4, far_budget=1, skip_far=False, basis=None. run **options can override each; actual runtime options unknown.
For nonnegative sensible lengths and n=len(keys), boundary=max(0,n-near_len). Far pool is indices [0,boundary), capped by far_budget after score ranking (L23); near pool is [boundary,max(boundary,n-forced_len)) (L24); forced suffix is [max(0,n-forced_len),n) (L20). Near quota is max(0,budget-len(forced)-len(far)) (L25). Output is far then ranked near then ascending forced, not a globally score-sorted list. Equal scores retain ascending index order through stable sorted.

Default example n=8 (static reasoning): far pool 0..2, near pool 3..5, forced [6,7]; one far and up to one near give four positions. skip_far=True gives no far and up to two near plus [6,7], while scoring still happens. n=1 has empty far/near and forced [0]. n=0 still projects query (L21), then returns empty selection and scores if projection succeeds.

budget is NOT an absolute upper bound: forced and far are appended even when their total exceeds it. Under arbitrary options, near_len<forced_len can make far overlap forced, and L25 performs no deduplication, yielding duplicate final scores. Negative far_budget uses Python negative slicing, not validation; negative/out-of-range lengths and non-integers are not rejected consistently. Hence budget/range guarantees require preconditions not enforced by this code.

## Unknowns and bounded follow-up

No runtime behavior, performance, GPU/backend, trained-basis provenance, quality/approximation bound, normalization or attention computation is established. No supplied tests/logs/consumer outside run. Suggested future tests (not executed): short query with empty keys, budget below forced size, near_len<forced_len duplicate overlap, malformed basis and mismatched vector lengths. Self-review of cited source only; no independent reviewer claimed.

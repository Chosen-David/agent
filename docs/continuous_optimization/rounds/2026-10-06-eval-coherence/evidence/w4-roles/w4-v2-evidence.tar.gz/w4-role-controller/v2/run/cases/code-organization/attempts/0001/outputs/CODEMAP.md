| Experiment | Conclusion | Script | Data | Result | Citation |
|---|---|---|---|---|---|
| HIST-0 | unknown | archived/missing.py | unknown | unknown | unknown |
| GAMMA | inconclusive (synthetic fixture; not execution proof) | experiments/alpha.py | synthetic-w4-g (label; raw data absent) | results/alpha.json | Result JSON references script; external consumer unknown |
| DELTA | rejected (synthetic fixture; not execution proof) | experiments/beta.py | synthetic-w4-d (label; raw data absent) | results/beta.json (running output; protected) | Result JSON references script; external consumer unknown |

Historical HIST-0 row retained verbatim and first; archived/missing.py does not exist in supplied tree. Task IDs GAMMA/DELTA come from script and result metadata; root TASK.md is absent. Producer script mapping is resolved, human/agent owner unknown. Both scripts are active per active_tasks.json; actual process state not independently inspected. File hashes and source classifications are in inventory.json. notes/orphan.txt is explicitly protected with unknown experimental provenance. File inventory is not task acceptance.

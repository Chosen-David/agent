import argparse,csv,hashlib,json,statistics
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,required=True);p.add_argument('--outputs',type=Path,required=True);a=p.parse_args()
project=json.loads((a.inputs/'chain_project.json').read_text());schema=json.loads((a.inputs/'handoff_fields.json').read_text())
with (a.inputs/'chain_latencies.csv').open(newline='') as f: raw=list(csv.DictReader(f))
groups={}
for row in raw:
    assert row['input_version']==project['input_version'] and row['scope']=='end_to_end'
    assert row['variant'] in ['baseline','candidate']
    key=(row['workload'],row['variant']);groups.setdefault(key,[]).append((int(row['repeat']),float(row['latency_ms'])))
rows=[]
for workload in dict.fromkeys(r['workload'] for r in raw):
    values={}
    for variant in ['baseline','candidate']:
        group=groups[(workload,variant)]
        assert len(group)==project['measurement_conditions']['repeats_per_variant']
        assert len({r for r,v in group})==len(group) and all(v>0 for r,v in group)
        values[variant]=statistics.median(v for r,v in group)
    b,c=values['baseline'],values['candidate']
    rows.append(dict(workload=workload,n_baseline=len(groups[(workload,'baseline')]),n_candidate=len(groups[(workload,'candidate')]),baseline_median_ms=b,candidate_median_ms=c,speedup_ratio=b/c,latency_reduction_pct=100*(b-c)/b))
with (a.outputs/'aggregate.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=schema['aggregate_csv_columns']);w.writeheader();w.writerows(rows)
def ref(path):return dict(path=str(path.resolve()),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
result=dict(rows=rows,source_files=[ref(a.inputs/n) for n in ['chain_project.json','chain_latencies.csv','handoff_fields.json']],aggregate_file=ref(a.outputs/'aggregate.csv'),raw_row_count=len(raw),validation='Input version, scope, variants, repeat counts, repeat uniqueness, positive latencies checked.')
(a.outputs/'aggregation_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))

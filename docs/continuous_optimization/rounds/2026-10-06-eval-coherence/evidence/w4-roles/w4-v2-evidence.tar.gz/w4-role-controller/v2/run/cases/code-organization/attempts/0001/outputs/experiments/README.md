# Experiments
Synthetic documentation fixtures; do not execute.
alpha.py documents GAMMA / synthetic-w4-g / results/alpha.json.
beta.py documents DELTA / synthetic-w4-d / results/beta.json.
Both scripts are declared active in active_tasks.json.
See ../CODEMAP.md; names do not imply ALPHA/BETA experiment IDs.

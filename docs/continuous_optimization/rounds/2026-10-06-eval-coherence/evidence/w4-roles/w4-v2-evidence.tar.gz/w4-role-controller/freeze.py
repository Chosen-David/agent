"""Root supplies a final content-addressed candidate; this never creates commits."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, subprocess
B=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--revision',required=True);args=p.parse_args()
def git(*items):return subprocess.check_output(['git','-C',str(args.repo),*items])
sha=git('rev-parse','--verify',args.revision+'^{commit}').decode().strip()
registry=json.loads(git('show',sha+':config/role_registry.json'))['roles']
tasks=json.loads((B/'tasks.json').read_text());roles={r['id'] for r in registry}
assert len(roles)==14 and roles=={c['id'] for c in tasks['cases'] if c['id'] in roles}
assert len(tasks['cases'])==18
frozen=B/'pipeline.py'
with frozen.open('xb') as stream:stream.write(git('show',sha+':scripts/agent_eval_pipeline.py'))
spec=importlib.util.spec_from_file_location('pinned_pipeline',frozen);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
adapter=json.loads((B/'adapter.json').read_text())
manifest=module.prepare_run(args.repo,sha,B/'run',B/'tasks.json',B/'rubric.json',B/'fixtures',adapter)
record={'source_repo':str(args.repo.resolve()),'revision':sha,'tree':git('rev-parse',sha+'^{tree}').decode().strip(),'run_manifest_sha256':hashlib.sha256((B/'run/manifest.json').read_bytes()).hexdigest(),'pipeline_sha256':hashlib.sha256(frozen.read_bytes()).hexdigest(),'snapshot_hashes':manifest['snapshot_hashes'],'preflight_sha256':hashlib.sha256((B/'material-validation.json').read_bytes()).hexdigest(),'denominator':19,'independent_cases':18,'deferred_writer_cases':1,'status':'frozen, not executed'}
with (B/'trusted-freeze.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps({k:v for k,v in record.items() if k!='snapshot_hashes'},indent=2))

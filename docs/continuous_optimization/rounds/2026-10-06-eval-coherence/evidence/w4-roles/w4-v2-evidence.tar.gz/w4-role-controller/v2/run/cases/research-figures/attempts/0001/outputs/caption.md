Panel A: proposed method. Panel B: supplied timing results. The inputs do not establish that the measured candidate implements this proposed architecture; panels are juxtaposed without asserting that linkage.

Proposed dual-logit normalization (synthetic specification, not implemented). Parallel logits a and b merge as z = a + b; softmax yields p, and fixed values V enter only y = p^T V. Arrows denote the five supplied data-flow relations. No model execution or architecture validation is claimed.

Supplied timing results (ms). All four rows are shown without aggregation: small 90/72, medium 150/125, large 240/264, and kernel 36/12 for baseline/candidate. Small, medium and large are end-to-end timings; kernel is kernel-only and does not establish end-to-end improvement. The candidate is slower for large. Repeat counts and uncertainty are unspecified, so no error bars or statistical claims are shown. These values were provided, not measured in this task.

Pinned research-implement-optimize entry/workflow/execution/measurement-evidence contract applied with local standard-library fallback. Read inputs only; original buggy.py was not executed or modified. Produced fixed.py and check.py in authorized outputs after start.json existed.

Actual CPU correctness command requested during work and executed by controller:
`python -B /workspace/scratch/c12f3d9f92bd/w4-role-controller/v2/run/cases/research-implement-optimize/attempts/0001/outputs/check.py`

Controller evidence: /workspace/scratch/c12f3d9f92bd/w4-role-controller/v2/run/host/research-implement-optimize-proxy-332ed472-e781-4c1a-98ba-eb2603551d76.json (read after execution). Exit 0, stderr empty; 1062 valid cases and 8 invalid cases passed, seed 81273, Python 3.12.14. Exact host record copied to test_result.json. CPU correctness only: elapsed subprocess duration is not a benchmark. No GPU, network, installation, profiler or new performance experiment occurred.

CSV analysis is arithmetic from supplied values, not independently reproduced timing. Candidate has a 10% large-workload latency regression; kernel-only 3x does not establish end-to-end 3x. No uncertainty estimate possible from provided aggregates. No full external integration suite available. Repair keeps direct-window arithmetic, with no claim of algorithmic acceleration.

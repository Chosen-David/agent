"""Prepare the preregistered writer ONLY from actual collected coordinator bytes."""
from pathlib import Path
import hashlib, importlib.util, json, shutil
B=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('pinned_pipeline',B/'pipeline.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
freeze=json.loads((B/'trusted-freeze.json').read_text())
manifest,errors=p.verify_run(B/'run');assert not errors,errors
assert hashlib.sha256((B/'run/manifest.json').read_bytes()).hexdigest()==freeze['run_manifest_sha256']
case=B/'run/cases/chain-coordinator'
attempts=sorted((case/'attempts').glob('*'));assert attempts,'no actual coordinator attempt'
attempt=attempts[-1];collection=json.loads((attempt/'collection.json').read_text())
assert collection['receipt']['kind']=='complete' and collection['receipt']['status']=='produced'
out=attempt/'outputs';dest=B/'writer-fixtures';dest.mkdir(exist_ok=False)
records=[]
for name in ['analysis.json','aggregate.csv']:
    data=(out/name).read_bytes();digest=hashlib.sha256(data).hexdigest()
    assert collection['output_hashes'][name]==digest,'producer output changed'
    (dest/name).write_bytes(data)
    records.append({'source':str(out/name),'destination':str(dest/name),'source_sha256':digest,'destination_sha256':hashlib.sha256((dest/name).read_bytes()).hexdigest()})
analysis=json.loads((dest/'analysis.json').read_text())
assert analysis['input_version']=='synthetic-v5','producer version incorrect; preserve failure, do not patch'
assert analysis['aggregate_file']['sha256']==records[1]['source_sha256'],'producer aggregate hash mismatch; preserve failure'
record={'source_collection':str(attempt/'collection.json'),'source_collection_sha256':hashlib.sha256((attempt/'collection.json').read_bytes()).hexdigest(),'files':records,'source_actor':collection['receipt']['actor'],'boundary':'actual collected producer outputs, copied without edits; no expected-answer fixture'}
with (B/'handoff.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
writer=p.prepare_run(Path(freeze['source_repo']),freeze['revision'],B/'writer-run',B/'writer-task.json',B/'writer-rubric.json',dest,json.loads((B/'adapter.json').read_text()),require_material_review=True)
print(json.dumps({'writer_cases':writer['expected_cases'],'manifest_sha256':hashlib.sha256((B/'writer-run/manifest.json').read_bytes()).hexdigest(),'handoff':str(B/'handoff.json')}))

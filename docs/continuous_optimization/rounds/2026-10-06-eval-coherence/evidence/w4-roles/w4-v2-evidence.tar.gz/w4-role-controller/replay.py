"""Read-only record-integrity replay; never claims new model execution."""
from pathlib import Path
import importlib.util,json,sys,hashlib
B=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('protected_pipeline',B/'v2/pipeline.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
reports={name:p.report(B/'v2'/name) for name in ['run','writer-run']}
summary={'denominator':19,'expected':sum(r['expected'] for r in reports.values()),'passed':sum(r['passed'] for r in reports.values()),'first_pass':sum(r['first_pass'] for r in reports.values()),'complete':all(r['complete'] for r in reports.values()),'integrity_errors':{n:r['integrity_errors'] for n,r in reports.items()},'reports':reports,'boundary':'Archived record/hash/materialreview replay, not a new modelexecution or performance comparison; old v1 attempt excluded.'}
print(json.dumps(summary,ensure_ascii=False,indent=2))
if '--require-complete' in sys.argv and not(summary['complete'] and summary['expected']==19 and summary['passed']==19):sys.exit(1)

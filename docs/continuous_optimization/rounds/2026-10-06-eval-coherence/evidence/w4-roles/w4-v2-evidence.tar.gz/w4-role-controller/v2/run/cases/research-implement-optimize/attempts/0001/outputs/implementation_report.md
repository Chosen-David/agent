# CODE-T001: moving_average repair

Contract: positive Python integer window, excluding bool; all complete consecutive windows, no input mutation, [] if window exceeds length. Non-integer/bool raises TypeError; nonpositive integer raises ValueError (chosen explicit error classes; task specified rejection, not classes).

Static minimum reproduction: buggy.py([1,2,3],3) would return [] because range(0) is empty; expected [2.0]. This is static inference: fixture was not executed. Root cause is omitted final window (range(n-window) rather than range(n-window+1)), plus absent validation. fixed.py makes only these corrections.

Independent CPU oracle in check.py accumulates Fraction values using explicit endpoint loops, avoiding the production slice/sum expression. It covers empty/single/exact/oversized windows, window=1, negative and large values, tuples/lists, input immutability, invalid types/bools/nonpositive windows and 1000 seeded random binary-fraction arrays. Actual proxy execution receipt is recorded in execution.md.

## Candidate choice and complexity

Direct window summation: O((n-w+1)w) time for 1<=w<=n, O(w) transient slice space plus O(n-w+1) output. Rolling sum: O(n), O(1) auxiliary plus output, but changes floating accumulation and nonfinite handling. Prefix sum: O(n) extra memory, cancellation/subtraction changes. Keep minimal direct summation to preserve baseline per-window arithmetic; no performance claim about this repair. Python numeric sequence semantics retained; exotic custom numeric objects and arbitrary iterators are not tested. No external skill/network discovery; pinned local workflow and standard library suffice (offline_fallback).

## Supplied measurements only

Speedup = baseline/candidate; latency reduction=(baseline-candidate)/baseline.

| Workload | Scope | Baseline ms | Candidate ms | Speedup | Latency reduction |
|---|---|---:|---:|---:|---:|
| small | end_to_end | 90 | 72 | 1.25x | 20% |
| medium | end_to_end | 150 | 125 | 1.20x | 16.67% |
| large | end_to_end | 240 | 264 | 0.9091x | -10% |
| kernel | kernel_only | 36 | 12 | 3x | 66.67% |

Candidate regresses on large. Kernel-only 3x does not establish end-to-end 3x; scopes cannot be merged. No workload weights or repeated samples, so no global ranking, uncertainty interval, significance, or generalizable improvement is supported. Hardware, versions, input sizes, measurement protocol and relationship between CSV candidate and this repair are unknown. These numbers are supplied observations, not measurements made here. No GPU, profiler or extra timing was run.

Next if performance work is requested: recover paired raw timings/protocol/version linkage first, specify workload weights and numerical contract, then test rolling-sum alternative against an independent oracle before any matched benchmark. Current repair does not depend on that future work.

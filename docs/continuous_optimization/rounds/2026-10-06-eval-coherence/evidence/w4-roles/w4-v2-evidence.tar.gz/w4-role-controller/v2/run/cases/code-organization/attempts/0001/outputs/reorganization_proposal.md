# Read-only proposal

Mapping was sent to parent before writing CODEMAP/README/proposal; acknowledgment record: run/host/code-organization-mapping-before-write.json. Only output documentation is authored.

Keep experiments/alpha.py and experiments/beta.py in place because active_tasks.json declares them active. Preserve results/beta.json as a running output path. Preserve notes/orphan.txt as explicitly protected even though no experimental provenance or consumer is known. Do not infer names ALPHA/BETA from filenames: comments and JSON resolve GAMMA/DELTA. Keep rejected/inconclusive results, which are legitimate metadata outcomes.

No input files moved, renamed, changed or deleted; no target script executed. Existing history row is first and unmodified. Two of two declared active scripts are mapped (100% within this fixture); historical archived/missing.py is missing and remains unknown. This inventory does not prove any experiment ran or passed.

Future proposal only: coordinator supplies authoritative TASK.md and task owner/consumer mapping; producers attach raw input and versioned execution manifests for GAMMA/DELTA; investigate HIST-0 missing script before treating it as reconstructable. If later stopped and explicitly authorized, consider results/<experiment>/<run_id>/ with manifest and repaired references, preserving current paths until process state and all consumers are confirmed. Orphan note requires owner decision; no automatic archive/delete. No duplicate content justified by hashes and no rename is needed now.

Necessary README drafts are under outputs/experiments/ and outputs/results/ for review, not installed in input directories. CODEMAP is an incremental proposed replacement preserving history.

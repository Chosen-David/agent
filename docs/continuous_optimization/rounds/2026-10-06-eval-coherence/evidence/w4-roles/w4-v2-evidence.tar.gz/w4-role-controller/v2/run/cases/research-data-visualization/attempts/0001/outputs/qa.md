Scientific fidelity: source values and topology preserved. No invented observations, uncertainty, architecture edges, or model execution.

Numerical QA: all supplied timing values are plotted and directly labeled; zero baseline, common millisecond scale, kernel-only group explicitly separated. Large candidate 264 ms exceeds baseline 240 ms. No aggregation, filtering, interpolation or inferential analysis. Not applicable to standalone diagram.

Semantic QA: six nodes and five directed data-flow edges, checked by exact SVG stable IDs. A/B are parallel, merge at sum, then softmax, then output. V enters output only. No feedback or A-to-B edge. Not applicable to standalone data plot.

Visual self-review: actual final PNGs opened through view_image. Diagram node text legible; arrows terminate at intended node boundaries; no crossing arrows. Shared neutral/teal palette is redundant with text and hatch. Grey previews actually opened; methods remain distinguishable through hatch, direct labels and position. Headings establish reading order. Mixed data footer originally too close to legend; moved below legend and rerendered. Revised full figure has separate footer, readable values and no label clipping. Standalone outputs preserve these properties.

Technical: exported SVG parsed as XML; IDs unique, editable text retained; no external raster embedding. PNG sizes and hashes in technical-checks.json. SVG/Python are editable master sources; combined figure is vector-authored, not a screenshot collage.

Reproduction: python -B build.py from this output directory, reading only corresponding case inputs. Versions in routing.json; source paths/hashes in loaded.json.

Limits: supplied CSV provenance, sampling unit, n and uncertainty unknown. No statistical or causal claim. No external exemplar learning or independent specialist agents; roles executed sequentially within one worker. No target venue, print proof, color-vision simulation, PDF export or full-paper embedding requested/verified. Provisional sizes only; not submission-spec-verified. Controller image-open observations to be recorded separately in execution.md.

Controller review completed during task; exact final PNG hashes matched the returned host record. Review confirms readable labels/scopes, no clipping or overlap, and accurate final topology/data. See visual-proxy-receipt.json and execution.md.

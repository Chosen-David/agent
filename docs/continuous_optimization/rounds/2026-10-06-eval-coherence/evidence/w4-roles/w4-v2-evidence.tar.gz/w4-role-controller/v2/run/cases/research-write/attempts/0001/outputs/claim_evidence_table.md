| ID | 主张/稿内位置 | 证据位置 | 定义及范围 | 状态 |
|---|---|---|---|---|
| WRITE-C001 | 中文句2、摘要句3：small1.25×，下降20% | measurements.csv small行 | 90/72；(90−72)/90；synthetic CPU端到端 | 支持此单次观察 |
| WRITE-C002 | 中文句2、摘要句3：medium1.20×，下降16.7% | medium行 | 150/125；25/150 | 支持此单次观察 |
| WRITE-C003 | 中文句3、摘要句4：large退化10% | large行、Appendix A | (264−240)/240；240/264≈0.91 | 支持；不得隐去 |
| WRITE-C004 | 中文句4、摘要句5：kernel3× | kernel行、Results | 36/12，仅kernel_only；不相加 | 支持限定范围 |
| WRITE-C005 | 限制句：一次观察，质量/方差未知 | Results、Appendix A、Method | 无GPU、同合成CPU配置 | 来源事实，不是本轮实测 |
| WRITE-C006 | 原Abstract“every workload 3× without regression” | 原Abstract vs四行数据 | 混淆范围，并受large反证 | 不支持；本工作稿删除夸大表述 |

输入版本由 loaded.json SHA-256 锁定；写作前控制器实际核对两输入哈希，见 execution.md。未新增引用、实验、作者信息或外部背景。稿件状态 draft_complete；仅文字和算术核对，无完整论文/PDF需求，未宣称投稿检查完成。

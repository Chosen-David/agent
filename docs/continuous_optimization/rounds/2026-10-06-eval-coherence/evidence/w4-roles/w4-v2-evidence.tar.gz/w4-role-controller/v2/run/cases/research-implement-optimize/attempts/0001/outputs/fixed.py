def moving_average(values, window):
    """Return all full consecutive-window means without modifying values."""
    if isinstance(window, bool) or not isinstance(window, int):
        raise TypeError("window must be an integer (not bool)")
    if window <= 0:
        raise ValueError("window must be positive")
    return [sum(values[i:i + window]) / window
            for i in range(len(values) - window + 1)]

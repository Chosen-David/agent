import json,hashlib,importlib.util,datetime
from pathlib import Path
b=Path(__file__).parent;r=b/'writer-run';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=importlib.util.spec_from_file_location('pipeline','/workspace/scratch/c12f3d9f92bd/agent/scripts/agent_eval_pipeline.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
handoff=json.loads((b/'handoff.json').read_text());inp=r/'cases/chain-writer/inputs'
for f in handoff['files']:
 assert sha(Path(f['source']))==f['source_sha256']==f['destination_sha256']==sha(inp/Path(f['destination']).name)
a=json.loads((inp/'analysis.json').read_text());assert a['aggregate_file']['sha256']==sha(inp/'aggregate.csv')
notes='''# Root writer material correspondence

Reviewed actual coordinator collection, copied writer inputs and all three writer criteria before dispatch. Independently checked source→destination bytes and analysis.aggregate_file SHA against actual aggregate.csv.

1. Real source actor is /root/final_role_controller/v2_coordinator; collection997c901d… and analysis d5649eb5…/aggregate83e63365… bind actual outputs. Worker must still perform its own observable hash check. This check does not pretend it has done so before running.
2. CSV rows2-4 contain45/36,70/77,125/100ms, each count3. Ratios1.25,10/11,1.25 and reductions20,-10,20 agree with root preflight CPU arithmetic. Chinese results+English abstract+claim map are explicit requested outputs. Medium slowdown and synthetic/no-quality/no-significance boundaries match actual analysis.
3. Upstream files and workload rows are available, no literature or new experiments requested. Missing/hash-mismatch behavior is blocking, not completed writing. Expected successful branch is based on inspected valid bytes, not fabricated output.
'''
p=b/'controller-evidence/root-writer-correspondence.md';p.write_text(notes)
review={'schema_version':1,'reviewer_actor':'/root','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'material_hashes':m.material_bindings(r,json.loads((r/'manifest.json').read_text())),'cases':{}}
criteria=json.loads((r/'rubric.json').read_text())['criteria']['chain-writer']
review['cases']['chain-writer']=[{'criterion':c,'kind':'factual','status':'supported','verification':'source_review','reason':reason,'evidence':[{'path':'controller-evidence/root-writer-correspondence.md','sha256':sha(p),'location':f'criterion{i+1}'}]} for i,(c,reason) in enumerate(zip(criteria,['Actual collected producer bytes, copied without edits, independently hashed by root; writer must visibly check again.','Actual3CSVrows validate numerical claims and slowdown; task requires2prose artifacts+JSON under synthetic scope.','File/row claim mapping and honest mismatch blocking follow task; no sources/experiments permitted.']))]
p=b/'controller-evidence/writer-material-review.json';p.write_text(json.dumps(review,indent=2,ensure_ascii=False)+'\n')
trust={'path':'controller-evidence/writer-material-review.json','sha256':sha(p),'reviewer_actor':'/root'}
(b/'writer-trust.json').write_text(json.dumps(trust,indent=2)+'\n')
m.authorize_dispatch(r,'chain-writer','/root/final_role_controller/planned_writer',material_review=trust)
print(trust)

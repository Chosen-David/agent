# CPU analysis and writer handoff

Selected capability: pinned research-assistant coordinator. Read entry plus orchestrator, execution and project-memory dependencies; exact reads and SHA256 are in loaded.json. This is a bounded analysis node, without delegated subagents or a background supervisor.

Actual command requested through controller proxy:

```sh
python -B /workspace/scratch/c12f3d9f92bd/w4-role-controller/v2/run/cases/chain-coordinator/attempts/0001/outputs/aggregate.py
```

The controller returned exit 0, empty stderr, and 18 input records. I read its actual result at:
`/workspace/scratch/c12f3d9f92bd/w4-role-controller/v2/run/host/chain-coordinator-proxy-9cc1c20c-9a5e-4fe1-972b-06c3b0cd00ed.json`.
Recorded elapsed CPU-command wall time: 0.03637139199781814 seconds. This is arithmetic runtime, not benchmark latency.

The execution checked input version, end-to-end scope, positive latency, repeat identities, counts, and required schema fields. I reviewed actual aggregate.csv and analysis.json after receiving the execution result.

| Workload | Baseline median ms | Candidate median ms | Speedup ratio | Reduction % |
|---|---:|---:|---:|---:|
| small | 45 | 36 | 1.25 | 20 |
| medium | 70 | 77 | 0.9090909090909091 | -10 |
| large | 125 | 100 | 1.25 | 20 |

WRITE-OLD depends on synthetic-v4 and its universal ≥1.8x statement is invalid for v5. Preserve its historical provenance but exclude the stale claim from new writing. BACKGROUND-1 is retainable only as the input manifest's latency-independent definition; its underlying prose was not supplied or independently checked.

analysis.json holds real SHA256 values for all three source files and aggregate.csv. cpu-result.json records output hashes, including analysis.json. The host must copy analysis.json and aggregate.csv unchanged to the writer; missing artifacts or any hash mismatch block dependent writing. The writer is next owner and must verify hashes before composing the Chinese Results paragraph and English abstract. This node did not write that prose.

Data are synthetic, three observations per variant/workload. Hardware and quality metrics are absent. Findings are descriptive and workload-specific; no statistical significance, causal mechanism, quality preservation or real-device generalization is established. No network, GPU, new experiments, installations or global repository changes occurred.

Task dependency record: ANALYZE-V5 (this node, actual artifacts produced) → VERIFY-HANDOFF (host/writer, pending) → WRITE-V5 (writer, pending). A missing or mismatched handoff blocks only the dependent writer; recover by copying the original verified outputs. No claim of completed downstream writing or independent acceptance is made.

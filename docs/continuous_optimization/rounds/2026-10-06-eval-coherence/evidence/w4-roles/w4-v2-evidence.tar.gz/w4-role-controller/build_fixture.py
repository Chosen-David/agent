"""Prepare held-out material only; never dispatch workers or manufacture results."""
from pathlib import Path
import csv, hashlib, json, shutil
import fitz

B = Path(__file__).resolve().parent
R = B.parent / 'agent'
F = B / 'fixtures'
F.mkdir(exist_ok=True)
def put(name, text):
    path = F / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')
def js(name, value, root=F):
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def pdf(name, pages):
    doc = fitz.open()
    for number, (title, lines) in enumerate(pages, 1):
        page = doc.new_page(width=620, height=800)
        page.insert_text((40, 65), title, fontsize=17)
        for row, line in enumerate(lines):
            page.insert_text((40, 110 + row*30), line, fontsize=11)
        page.insert_text((40, 755), f'Physical page {number}', fontsize=10)
    doc.save(F/name, no_new_id=True)

# New values, distinct from both registry defaults and the previous scaling run.
put('measurements.csv', 'workload,baseline_ms,candidate_ms,scope\nsmall,90,72,end_to_end\nmedium,150,125,end_to_end\nlarge,240,264,end_to_end\nkernel,36,12,kernel_only\n')
put('manuscript.md', '# Synthetic manuscript: selective execution\nThis is an invented fixture, not a published paper.\n## Abstract\nThe method achieves 3x end-to-end speedup on every workload without regression.\n## Method\nA selected kernel changes; all supplied timings refer to the same synthetic CPU configuration. No GPU run exists.\n## Results\nEach timing is one observation without independent repeats. Kernel-only timings are already included within end-to-end paths: never add them.\n## Appendix A\nLarge end-to-end latency rises from 240 to 264 ms. This regression is explicitly disclosed. Quality and variance are unmeasured.\n')
js('project.json', {'goal':'Analyze updated synthetic timings and plan a figure and bounded results paragraph', 'budget':'CPU only; no new service or GPU spend', 'state':[{'task_id':'collect','status':'done','inputs':['measurements.csv@v4'],'outputs':['measurements.csv@v4']},{'task_id':'figure','status':'done','depends_on':['collect'],'inputs':['measurements.csv@v4'],'outputs':['figure@v4']},{'task_id':'write','status':'todo','depends_on':['figure'],'inputs':['measurements.csv@v4']},{'task_id':'background','status':'done','inputs':['concept.txt@v1'],'outputs':['background@v1']}], 'change':'measurements.csv is now v5. Preserve raw v4 evidence; re-evaluate dependent interpretation/figure/write; concept.txt is unchanged.'})
shutil.copyfile(R/'evals/fixtures/buggy.py', F/'buggy.py')
put('concept.txt', 'Synthetic teaching model, not a paper finding: y=softmax(a+b)V, a=b=(0,0), fixed V=(-2,14). Change only b to (0,log(3)). Explain in Chinese why separately checking the two logit-path errors cannot guarantee unchanged combined output. Derive exact probabilities, outputs and fixed-V local Jacobian. Give a valid boundary/counterexample. This has no RoPE-specific model or empirical evidence. No network needed.\n')
architecture = json.loads((R/'evals/fixtures/architecture.json').read_text())
architecture['title'] = 'Proposed dual-logit normalization, held-out W4'
js('architecture.json', architecture)
pdf('paper.pdf', [('Synthetic two-path teaching note', ['Not a published paper or experiment.', 'y = softmax(a+b) V. Fixed values V=(-2,14).']), ('Worked example and an overclaim', ['Physical page 2; printed page 1.', 'a=b=(0,0): p=(1/2,1/2); output is 6.', 'Change b to (0,log(3)): p=(1/4,3/4); output is 10.', 'Draft claim: this proves RoPE always amplifies error in every model.']), ('Appendix: limitations', ['This teaching example contains no RoPE-specific architecture.', 'No model, dataset, quality or variance was measured.', 'Equal values or a common logit shift can leave output unchanged.'])])
pdf('reading_excerpt.pdf', [('Synthetic window-average note', ['This offline teaching note defines simple uniform averages.', 'No real attention model or measured experiment is claimed.']), ('Requested worked example', ['Sequence x=(4,10,16).', 'Full average is (4+10+16)/3 = 10.', 'Recent-two average is (10+16)/2 = 13.', 'Question: why +3, and is the recent average always larger?']), ('Boundary', ['Reverse the sequence: x=(16,10,4).', 'Full average remains 10; recent-two average is 7.', 'Ordering determines this example; no universal larger-output result.'])])
js('travel.json', {'fixture':'synthetic facts only; not real merchants', 'date':'2026-10-12','timezone':'Asia/Shanghai','people':2,'available':['11:00','19:00'],'hotel':'Hotel M, 40 Synthetic Road','lunch':{'name':'Cafe N','address':'50 Synthetic Road','service_windows':[['11:00','14:00']],'last_order':'13:00','duration_minutes':70,'price':[90,110],'unit':'per_person'},'photo':{'name':'Studio P','address':'60 Synthetic Road','appointment':['16:30','17:30'],'confirmed_by_user':True,'price':[240,240],'unit':'per_group'},'commute':{'each_leg_minutes':25,'each_leg_price':[20,30],'unit':'per_vehicle','vehicles':1,'route':'hotel -> lunch -> hotel -> photo -> hotel; each of these four directed legs has supplied duration/fare'},'rest':{'place':'Hotel M','minutes':80,'room_available':True},'must_do':['lunch','photo','independent hotel rest'],'amendment':'For revised plan each of the four commute legs takes 40 minutes instead of25; fare range unchanged. Keep photo booking and independent rest. No booking.'})
selector=(R/'evals/fixtures/synthetic_selector.py').read_text().replace('vector[0], vector[2]', 'vector[1], vector[3]').replace('near_len=4, forced_len=1, budget=3, far_budget=1', 'near_len=5, forced_len=2, budget=4, far_budget=1')
put('synthetic_selector.py', selector)
for path in (R/'evals/fixtures/organization').rglob('*'):
    if path.is_file():
        content = path.read_text().replace('ALPHA','GAMMA').replace('BETA','DELTA').replace('synthetic-x','synthetic-w4-g').replace('synthetic-y','synthetic-w4-d')
        put('organization/'+path.relative_to(R/'evals/fixtures/organization').as_posix(),content)

project=json.loads((R/'evals/pipeline_smoke/fixtures/chain_project.json').read_text())
project['project_id']='heldout-w4-latency';project['input_version']='synthetic-v5'
project['previous_work'][1]['input_version']='synthetic-v4'
project['previous_work'][1]['description']='Old text claimed at least1.8x end-to-end speedup on every workload; recheck against v5.'
js('chain_project.json',project)
with (F/'chain_latencies.csv').open('w', newline='') as stream:
    writer=csv.writer(stream);writer.writerow(['input_version','workload','variant','repeat','latency_ms','scope'])
    for workload,baseline,candidate in [('small',45,36),('medium',70,77),('large',125,100)]:
        for variant,mid in [('baseline',baseline),('candidate',candidate)]:
            for repeat,delta in enumerate([-3,0,3],1): writer.writerow(['synthetic-v5',workload,variant,repeat,mid+delta,'end_to_end'])
shutil.copyfile(R/'evals/pipeline_smoke/fixtures/handoff_fields.json',F/'handoff_fields.json')
js('main_state.json', {'fixture':'synthetic observation snapshot, not an actual host receipt', 'task_requirements':{'T31':'Finish and independently verify the computation','T32':'Finish the independent documentation','T33':'Publish this repository after all gates and remote verification'},'authorization':{'local_compute':'allowed within original budget','local_docs':'allowed','publish':'this repository only, after all gates','other_repositories':'not authorized','force_push':False},'long_job':{'task_refs':['T31'],'job_id':'synthetic-job-417','status':'pending','attempts':0,'max_attempts':1,'dispatches':4,'pending_polls':4,'wait_policy':{'max_polls':9,'max_seconds':300,'diagnose_after_seconds':60},'elapsed_wait_seconds':100,'last_progress':'no substantive progress detail supplied; no failure event','next_poll':'due'},'independent_docs':{'task_refs':['T32'],'status':'todo','dependencies':[],'action':'write a factual progress note using supplied observations'},'publication':{'task_refs':['T33'],'candidate':'candidate-w4-A','historical_status':'tested','committed':False,'pushed':False,'remote_verified':False,'candidate_base':'synthetic-remote-R1','latest_observed_remote':'synthetic-remote-R2','remote_changed':True,'all_role_gate_complete':False},'late_snapshot':{'same_job':True,'status':'blocked','reason_kind':'wait_budget','pending_polls':9,'elapsed_wait_seconds':220,'external_job_completion':'unknown','user_granted_extra_budget':False}})

tasks=json.loads((R/'evals/tasks.json').read_text())
rubric=json.loads((R/'evals/rubric.json').read_text())
for case in tasks['cases']:
    case['role']=case['id']
    if case['id']=='paper-reading-companion':
        case['prompt']='陪我读 paper.pdf 的物理第2页：输出为何从6到10，这能证明RoPE在所有模型中都放大误差吗？看原页及必要上下文，保存阅读位置与PDF hash，交离线原页/解释双栏HTML。不要做全篇审稿，不联网。'
    if case['id']=='research-implement-optimize':
        case['prompt']='修复 buggy.py 的 moving_average，保留接口：正整数window（bool不算），完整连续窗口均值，超过长度返回空，不修改输入。交修复源、独立随机/边界正确性检查并实际运行；分析measurements.csv可支持的性能结论，不编GPU或额外实测。'
rubric['criteria']['research-assistant'][0]='v5 update invalidates dependent v4 figure/write interpretations, retains raw v4 evidence and unchanged background with a dependency-based explanation'
rubric['criteria']['research-explore'][0]='Separates kernel-only 3x from end-to-end 1.25x/1.2x/10 percent large latency increase; no universal3x claim'
rubric['criteria']['research-implement-optimize'][0]='moving_average([2,6,10],2)==[4,8]; full-window, empty, oversize, negative/zero/noninteger/bool-window behavior is correct and input preserved'
rubric['criteria']['research-write']=['Rejects universal3x claim and accurately states small90->72ms and medium150->125ms end-to-end observations','Large240->264ms, 10 percent latency increase explicitly included; speedup and latency-reduction denominators not conflated','Claim evidence mapping and one-observation/no-quality/no-variance limits; no fabricated references or experiments']
rubric['criteria']['research-review'][0]='Rejects Abstract universal3x/no-regression claim against actual four timing rows and scopes'
rubric['criteria']['paper-reading-companion'][0]='Correct6->10 calculation with p=(1/2,1/2) then(1/4,3/4), V=(-2,14); universal RoPE claim bounded'
rubric['criteria']['explain-research-concepts'][0]='Correct exact softmax probabilities(1/2,1/2)->(1/4,3/4) and outputs6->10 from fixed V=(-2,14)'
rubric['criteria']['travel-planner']=['Both schedules honor available11:00-19:00, lunch starts by13:00 and full70 minutes within11:00-14:00, and16:30-17:30 confirmed photo','Each schedule includes independent uninterrupted80-minute Hotel M rest and all four supplied directed commutes:25min original,40min amended; no invented shortcut/teleport','Both double-person budgets are180-220 meals+240 group photo+80-120 one-vehicle fares=500-580 CNY; synthetic source and no real booking/live verification claim']
rubric['criteria']['code-reading'][1]='Default picks dimensions[1,3]; optional caller-supplied basis is fixed rather than query-trained; final full_score uses original vectors'
smoke=json.loads((R/'evals/pipeline_smoke/tasks.json').read_text())
sr=json.loads((R/'evals/pipeline_smoke/rubric.json').read_text())
for case in smoke['cases']:
    cid=case['id']
    if cid not in {'smoke-main-general','smoke-main-route','chain-coordinator'}: continue
    if cid=='smoke-main-general':
        case['prompt']='我和室友平摊日用品：纸巾22元、清洁剂28元、垃圾袋两袋每袋12元。我先付50元，室友付24元。他还应转给我多少？写一句轻松自然的微信提醒。计算和提醒放outputs/answer.txt，不发送消息。'
        checks=['Actual answer correctly derives total74CNY, each share37CNY, roommate transfers13CNY to user; no reversed transfer','Natural non-coercive Chinese reminder; directly answers ordinary request without research workflow, delegation, novelty search or extra clarification']
    elif cid=='smoke-main-route':
        case['prompt']='帮我看reading_excerpt.pdf物理第2页：10变13这里为什么增加3？最近窗口是不是永远更大？围绕这一页解释，记住阅读位置，给能离线打开、原页和解释并排的页面。下次我还要接着问。合成教学例子无需联网，产物放outputs/。'
        checks=[sr['criteria'][cid][0], 'Actually reads/renders original physical page2 and explains10=(4+10+16)/3 versus13=(10+16)/2, difference3; bounds universal claim with valid reasoning/counterexample such as reverse sequence giving10 versus7', sr['criteria'][cid][2]]
    else:
        checks=['Observed CPU arithmetic uses all18 rows, and both requested files satisfy handoff_fields.json schema/columns','Medians baseline/candidate small45/36, medium70/77, large125/100ms; speedups1.25,10/11,1.25; reduction percentages20,-10,20; count3 per variant/workload (absolute tolerance1e-4)','Actual source/aggregate SHA256 match, input_version synthetic-v5 preserved, WRITE-OLD invalidated and BACKGROUND-1 retained; medium slowdown and rejection of universal>=1.8x present','Descriptive synthetic end-to-end observations only; three repetitions, hardware/quality unknown, no significance/GPU/real-world claim']
    tasks['cases'].append(case);rubric['criteria'][cid]=checks
tasks['cases'].append({'id':'main-wait-publication','role':'main-general','entry_type':'prompt','skill':'prompts/orchestrator.md','fixtures':['main_state.json'],'prompt':'按main_state.json接续这条已授权任务链。它是合成状态，不能当真实宿主回执。读取必要本地流程，写outputs/decision.json和给用户的简短进度说明：当前继续/暂停哪些动作、理由、下个owner及恢复条件；实际完成独立的T32事实进度便笺。分别处理初始pending与late_snapshot，不要虚构执行/后台监督/提交/推送。不得联网、实际Git写入、改输入、杀作业或重置预算。说明现有发布阶段能证明什么，以及远端变化后下一步。'})
rubric['criteria']['main-wait-publication']=['Initial pending under explicit wait policy is not failed or done: attempts0, polls4/9 and100/300s kept distinct; diagnosis threshold60 exceeded triggers evidence gathering, not restart/kill/budget reset or invented bottleneck','Actually delivers independent T32 factual note while T31 waits; plans bounded polling/diagnosis and fair service of independent ready work without claiming an unavailable live supervisor','Late wait-budget blocked remains unresolved/unknown, preserves job identity and evidence, requires authorized versioned recovery rather than automatic extra budget, restart, success or cancellation','Historical tested is not committed/pushed/remote-verified; changed remote R1->R2 and incomplete role gate prevent publication claim/action; next owner main must reconcile, refreeze changed candidate, revalidate applicable evidence then commit/push/independent readback within same-repository authorization']
writer=next(case for case in smoke['cases'] if case['id']=='chain-writer')
writer['fixtures']=writer['handoff_inputs']
# The baseline rubric wrongly hard-coded a medium regression in an older rotated
# writer run. Here the actual rotated input DOES regress medium; verify below.
js('tasks.json',tasks,B);js('rubric.json',rubric,B)
js('writer-task.json',{'schema_version':1,'cases':[writer]},B)
js('writer-rubric.json',{'schema_version':1,'criteria':{'chain-writer':sr['criteria']['chain-writer']}},B)
js('adapter.json',{'name':'host','model':'unknown; inherited host configuration','tokens':'unknown','cost':'unknown','max_attempts':2,'worker_context':'fresh fork_turns=none','grader_context':'fresh and distinct from workers/controller','worker_slots_max':2,'worker_wall_seconds':600,'tools':['local file/CPU/render tools','controller observable tool proxy'],'network':'forbidden for synthetic tasks'},B)
print(json.dumps({'independent_cases':len(tasks['cases']),'dependent_writer_cases':1,'total':len(tasks['cases'])+1,'status':'prepared material only; not frozen or executed'}))

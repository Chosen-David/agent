# Root writer material correspondence

Reviewed actual coordinator collection, copied writer inputs and all three writer criteria before dispatch. Independently checked source→destination bytes and analysis.aggregate_file SHA against actual aggregate.csv.

1. Real source actor is /root/final_role_controller/v2_coordinator; collection997c901d… and analysis d5649eb5…/aggregate83e63365… bind actual outputs. Worker must still perform its own observable hash check. This check does not pretend it has done so before running.
2. CSV rows2-4 contain45/36,70/77,125/100ms, each count3. Ratios1.25,10/11,1.25 and reductions20,-10,20 agree with root preflight CPU arithmetic. Chinese results+English abstract+claim map are explicit requested outputs. Medium slowdown and synthetic/no-quality/no-significance boundaries match actual analysis.
3. Upstream files and workload rows are available, no literature or new experiments requested. Missing/hash-mismatch behavior is blocking, not completed writing. Expected successful branch is based on inspected valid bytes, not fabricated output.

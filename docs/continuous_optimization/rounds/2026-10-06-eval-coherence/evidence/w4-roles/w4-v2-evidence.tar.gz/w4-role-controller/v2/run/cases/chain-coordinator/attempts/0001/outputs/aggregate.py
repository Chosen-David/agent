from pathlib import Path
import csv, json, hashlib, statistics, datetime
OUT=Path(__file__).resolve().parent
IN=OUT.parents[2]/'inputs'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
project=json.loads((IN/'chain_project.json').read_text())
schema=json.loads((IN/'handoff_fields.json').read_text())
rows=list(csv.DictReader((IN/'chain_latencies.csv').open()))
assert len(rows)==18
assert all(r['input_version']==project['input_version'] and r['scope']=='end_to_end' for r in rows)
result=[]
for name in dict.fromkeys(r['workload'] for r in rows):
    vals={v:[float(r['latency_ms']) for r in rows if r['workload']==name and r['variant']==v] for v in ['baseline','candidate']}
    assert all(len(x)==3 and all(y>0 for y in x) for x in vals.values())
    for v in vals:
        assert {int(r['repeat']) for r in rows if r['workload']==name and r['variant']==v}=={1,2,3}
    b,c=(statistics.median(vals[v]) for v in ['baseline','candidate'])
    result.append(dict(workload=name,n_baseline=len(vals['baseline']),n_candidate=len(vals['candidate']),baseline_median_ms=b,candidate_median_ms=c,speedup_ratio=b/c,latency_reduction_pct=100*(b-c)/b))
agg=OUT/'aggregate.csv'
with agg.open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=schema['aggregate_csv_columns']);w.writeheader();w.writerows(result)
findings=[]
for i,r in enumerate(result,2):
    findings.append({'workload':r['workload'],'evidence':{'file':'aggregate.csv','csv_line':i},'statement':f"在 synthetic-v5 合成数据中，{r['workload']} 的 baseline/candidate 端到端中位延迟分别为 {r['baseline_median_ms']:g}/{r['candidate_median_ms']:g} ms，speedup ratio 为 {r['speedup_ratio']:.12g}，延迟降幅为 {r['latency_reduction_pct']:.12g}%。",'interpretation':'candidate 延迟降低' if r['latency_reduction_pct']>0 else 'candidate 延迟升高；负降幅表示回退'})
analysis={'schema_version':schema['schema_version'],'project_id':project['project_id'],'input_version':project['input_version'],'source_files':[{'path':str(IN/n),'sha256':sha(IN/n)} for n in ['chain_project.json','chain_latencies.csv','handoff_fields.json']],'aggregate_file':{'path':str(agg),'sha256':sha(agg)},'findings':findings,'limitations':['数据为提供的合成测量；CPU 本次仅执行聚合运算，不是新 benchmark、真实模型或 GPU 实验。','每个工作负载每版本仅 3 个观测；仅报告描述性中位数与比值，未进行显著性检验或置信区间估计。','硬件未说明；无法推广至真实设备、其他工作负载或生产系统。','没有质量指标，不能推断质量保持、准确率收益或速度与质量取舍。','没有因果机制证据；不能把中位数差异解释为特定机制导致。','没有跨工作负载总体加权指标，不能声称总体平均收益。'],'invalidated_work':['WRITE-OLD'],'retained_work':['BACKGROUND-1'],'work_disposition':[{'id':'WRITE-OLD','status':'stale','reason':'依赖 synthetic-v4；所有工作负载至少 1.8x 的旧断言不受 v5 支持。small/large 均为 1.25x，medium 为约 0.9091x；其数据依赖文字、摘要与派生图表应由下一节点按 v5 重写。原历史记录保留。'},{'id':'BACKGROUND-1','status':'retained_definition_only','reason':'项目声明其 baseline/candidate 比较定义独立于延迟数值，可保留该概念背景；未提供原文，未独立验收原始背景产物。'}],'formulas':schema['formulas'],'next_owner':'writer','next_action':'由宿主原样复制 analysis.json 和 aggregate.csv；下一写作者先校验文件存在与 SHA256，再写中文 Results 段落与英文摘要。本节点未执行写作。','execution_scope':'CPU arithmetic only; no network, new experiments, GPU, or installations'}
assert set(schema['analysis_json_required']).issubset(analysis)
(OUT/'analysis.json').write_text(json.dumps(analysis,ensure_ascii=False,indent=2)+'\n')
report={'executed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':len(rows),'aggregate':result,'sha256':{n:sha(OUT/n) for n in ['aggregate.py','analysis.json','aggregate.csv']},'validation':'versions, scope, positive latencies, repeat identities, counts and required fields checked'}
(OUT/'cpu-result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))

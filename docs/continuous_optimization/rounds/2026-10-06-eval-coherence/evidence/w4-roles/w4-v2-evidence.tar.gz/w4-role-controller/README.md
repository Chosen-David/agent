# W4 all-role gate preregistration

Status: materials prepared and fact-checked; final candidate pin and root go are
pending. No W4 worker has been dispatched and no W4 case has passed.

The fixed denominator is **19 cases / 60 semantic criteria**: one for each of the
14 registry roles, ordinary main routing, reading main routing, coordinator,
dependent writer, and targeted main waiting/publication behavior. The independent
run contains 18 cases; writer is prepared separately only after actual coordinator
collection. The combined denominator remains 19 even if its dependency fails.
Missing, blocked, failed and ungradable cases remain visible. First-attempt and
latest-attempt counts are separate. All criteria must pass for a case to pass;
19/19 is the complete role gate. It does not substitute for program regressions,
targeted improvement evidence, full-paper writing evaluation or publication gates.

Only existing `scripts/agent_eval_pipeline.py` prepare/record-start/collect/grade/
report transitions are used. There is no replacement runner, self-grade, keyword
grader or staged fake receipt. These controller files only supply catalogs,
fixtures, provenance, host records and wrappers around the existing pipeline.

## Data and rubric coherence

`build_fixture.py` constructs new synthetic values; `validate_material.py` checks
25 input-fact groups and maps every criterion to its task and input sources.
`material-validation.json` records exact fixture/catalog SHA256s, arithmetic,
page identities, topology and declared state. These are material checks, not
execution passes or a proof that semantic grading can be automated. All six
pages of the two PDFs were rendered and actually opened during preparation:
page content is readable, uncropped and consistent with the requested physical
pages. This preparation viewing is not worker evidence.

The rotated chain's medium latency really increases70->77ms (10% increase),
unlike the older scaling fixture's tie. The writer's medium-regression criterion
was directly checked against the current 18 raw rows, not inherited as truth.
At handoff freeze it must be checked again against actual collected producer
outputs. Preserve incorrect producer outputs as failures, never edit their bytes
to manufacture a successful handoff. Remaining unchanged legacy task shapes are
basic smoke coverage only; the added main case targets current wait/publication
behavior. No previous role pass is imported by default.

## Candidate content freeze without a main commit

Root owns the final candidate and repository. Recommended pin: root creates a
temporary isolated Git index containing the reviewed candidate paths, runs
`write-tree`, then makes an unreferenced `commit-tree` object with the current
baseline parent. This creates a content-addressable object, without moving main,
committing main, changing root's real index or pushing. Alternatively root supplies
an isolated local snapshot repository and its commit. The final snapshot must
include every task-relevant change and the exact pipeline implementation.

After root supplies the candidate repository/commit and explicit go:

1. Re-read registry from that commit; require exact equality of its14 role IDs and
   the role catalog. Recheck input assertions and frozen criterion counts.
2. Run `freeze.py --repo PATH --revision SHA`; it copies the exact pinned pipeline
   and invokes its `prepare_run` developer API. Save manifest digest and source
   snapshot hashes in `trusted-freeze.json` outside worker outputs.
3. Record root's provided source-tree/diff identity in the eventual evidence.
   Any task-relevant candidate-byte change invalidates this freeze and requires
   a new run or root-approved proof of unaffected evidence reuse. Do not mutate
   frozen manifests/rubrics or overwrite previous attempts.
4. Dispatch fresh `fork_turns=none` workers, max2 worker slots and only within
   root's current concurrency grant. Record actual tool dispatch response/agent
   ID before `record-start`; worker waits for that start record before writing.
5. Use observed host completion with actual same agent ID for `collect`. Record
   model/tokens/cost as unknown when unavailable. Never label fabricated tool
   IDs or self-reports as exported host events.
6. A fresh independent grader gets frozen inputs, exact criteria, collections,
   actual outputs and host process records. It reads full relevant artifacts,
   recomputes numbers, actually executes code checks and views final images/PDFs.
   The controller imports its exact records through `grade` and checks reports.
7. Only after coordinator collection, `prepare_writer.py` copies its actual two
   handoff files unchanged, saves source/destination/collection hashes, checks
   producer aggregate hash and input version, then invokes the same pipeline
   prepare API with the already preregistered writer catalog and rubric. No
   human-authored expected aggregate or analysis is used as writer input.

Use max2 attempts per case, preserve every failure, and target at most600s per
worker. Host controller observes elapsed time and interrupts only its own worker
if the bounded allocation is exceeded. A missing capability is blocked/ungradable,
not an invented success. No network/GPU/payments/bookings/daemon or nested worker
delegation. Existing available local CPU/render tools only.

## Process evidence

`worker-protocol.md` requires observable proxy requests during execution for
process-sensitive checks when the host lacks tool transcript export. The
controller records the exact request, actual operation/result, elapsed time,
exit code, requested paths and content hashes, then returns it before dependent
work proceeds. Visual requests open actual rendered pages/images. Later grader
replay is additional artifact validation, never retroactive proof of an earlier
worker action. Shared directories are not an OS sandbox; actor IDs do not by
themselves prove independence. Actual fresh contexts and host records are required.

## Files and ownership

Controller owns only this scratch directory and eventual repository evidence
`docs/continuous_optimization/rounds/2026-10-06-eval-coherence/evidence/w4-roles/`.
It does not edit implementation, root TASK, main index or publication state.
Root serializes those. Archive reproducible evidence and real receipts only after
execution; do not publish private sample material. No result reuse without root's
explicit approval of an unchanged-byte/provably-unaffected boundary.

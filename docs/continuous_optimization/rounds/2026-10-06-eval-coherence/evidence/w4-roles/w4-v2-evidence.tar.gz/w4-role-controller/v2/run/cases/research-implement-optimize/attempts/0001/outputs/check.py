import json, math, platform, random
from fractions import Fraction
from fixed import moving_average

def reference(values, width):
    # Independent endpoint-driven exact rational oracle: no slicing or sum.
    output = []
    for end in range(width, len(values) + 1):
        total = Fraction(0)
        for index in range(end - width, end):
            total += Fraction(values[index])
        output.append(float(total / width))
    return output

count = 0
def check(values, width):
    global count
    before = list(values)
    actual = moving_average(values, width)
    expected = reference(values, width)
    assert len(actual) == len(expected), (values, width, actual, expected)
    assert all(math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-10) for a,b in zip(actual,expected)), (values,width,actual,expected)
    assert list(values) == before
    count += 1

for values in ([], [7], [1, 2, 3], [-2, 0, 9, -7], [0]*8, [2**40, -2**40, 3]):
    for width in range(1, len(values)+3):
        check(values, width)
        check(tuple(values), width)
for invalid in (True, False, 1.5, '2', None):
    try: moving_average([1,2], invalid)
    except TypeError: pass
    else: raise AssertionError(('accepted invalid window', invalid))
for invalid in (0,-1,-10):
    try: moving_average([], invalid)
    except ValueError: pass
    else: raise AssertionError(('accepted invalid window', invalid))
rng = random.Random(81273)
for _ in range(1000):
    n = rng.randrange(0, 81)
    values = [rng.randrange(-100000,100001)/8 for _ in range(n)]
    check(values, rng.randrange(1, n+5))
assert moving_average([1,2,3], 3) == [2.0]
assert moving_average([1,2,3], 1) == [1.,2.,3.]
print(json.dumps({'status':'passed', 'valid_cases':count, 'invalid_cases':8, 'seed':81273, 'python':platform.python_version(), 'scope':'CPU correctness only; no timings or GPU execution'}))

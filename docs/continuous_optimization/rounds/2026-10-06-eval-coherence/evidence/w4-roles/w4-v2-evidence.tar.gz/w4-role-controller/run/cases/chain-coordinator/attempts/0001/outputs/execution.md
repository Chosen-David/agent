# 执行与交接

本节点完成 synthetic-v5 CPU 聚合和分析交接，使用固定 research-assistant 入口与执行、版本纠错和任务链相关规范。未启动新的后台监督或独立 Agent。

## 实际执行

等待 attempt/start.json 后才写入输出。先写 aggregate.py，再请求宿主执行下列命令；收到真实 exit 0 结果并读取 host record 后，才生成 analysis.json。

```bash
python -B /workspace/scratch/c12f3d9f92bd/w4-role-controller/run/cases/chain-coordinator/attempts/0001/outputs/aggregate.py --inputs /workspace/scratch/c12f3d9f92bd/w4-role-controller/run/cases/chain-coordinator/inputs --outputs /workspace/scratch/c12f3d9f92bd/w4-role-controller/run/cases/chain-coordinator/attempts/0001/outputs
```

宿主证据：/workspace/scratch/c12f3d9f92bd/w4-role-controller/run/host/chain-coordinator-proxy-834d041d-c983-4825-9154-a4f13f2a341c.json

宿主实际耗时 0.04470223699900089 秒；检查 18 行版本、scope、variant、每组重复数、重复标识唯一性和正延迟。交接前再次读取实际源文件与 aggregate.csv，复核其 SHA256 一致，并核对 analysis 必需字段存在。脚本可复用；这不是新实验。

## 结果与旧工作

small：45 → 36 ms，1.25x，20% 降幅。medium：70 → 77 ms，0.9090909091x，−10% 降幅（增加 10%）。large：125 → 100 ms，1.25x，20% 降幅。每版本每工作负载 n=3。

WRITE-OLD 对 v5 失效，因数据版本变化且当前数值不支持至少 1.8x 的普遍加速；保留历史记录。BACKGROUND-1 所述比较定义独立于延迟值，可保留该背景；原文未提供，不作全文质量背书。

## 下游与限制

下一位 writer 只在宿主原样复制 analysis.json、aggregate.csv 并核对哈希后写中文 Results 段落和英文摘要。handoff_manifest.json 提供两文件真实 SHA256；analysis.json 同时绑定全部输入及聚合文件。当前没有代写下游正文。

数据为合成值、每组仅三次重复、硬件未知、质量指标缺失；仅支持这些工作负载上的描述性端到端延迟比较，不支持真实部署、质量不变、统计显著或所有负载加速的结论。未联网、未用 GPU、未安装运行时、未新增测量。

# Actual execution

Read exact task.txt, authorized pinned entry and relevant references; start.json existed before all output writes. loaded.json records hashes of actual reads (registration time, not invented per-read timestamps). No network, installations, subagents, source edits, or other-case results were used.

Rendered assigned PDF with `python -B` and `fitz.open(pdf); page.get_pixmap(dpi=160, alpha=False).save(path)`. Recorded SHA-256, page count and image hashes in render_manifest.json. Actually opened each listed PNG with tools.view_image. The controller also opened originals during execution; returned observations match my own reading.

Observed proxy records consumed:

- /workspace/scratch/c12f3d9f92bd/w4-role-controller/v2/run/host/smoke-main-route-pages-proxy.json
- /workspace/scratch/c12f3d9f92bd/w4-role-controller/v2/run/host/smoke-main-route-proxy-02d53c4e-4979-4732-afa0-f99cc95a0e83.json

Only research-read-pdf is a full visual audit. Companion viewed page2 and necessary page1 definitions/page3 limits; main-route viewed only1–2 and leaves3 unread. All sources are supplied synthetic notes, not published empirical papers.

For offline readers ran pinned `scripts/build_reader.py PDF --out OUTPUT/reader.html --pages 1-3` (companion) or `--pages 1-2` (main-route), with `--notes OUTPUT/notes.json`, using python -B. Exact argv/exit/stdout in build_record.json. Reader default index adjusted to page2; template retains hash-keyed localStorage resume. Companion printed label set from visible original body because PDF label metadata is absent. No live model/backend; manual context-copy fallback retained.

Validation used Python standard library to parse embedded reader JSON and compare hashes/notes/state, page2 presence, embedded image data and absence of external script/stylesheets. Arithmetic recalculated on CPU and saved in validation.json. These checks do not prove rendered HTML layout.

Screenshot limitation: system chromium/chromium-browser/google-chrome absent; runtime Playwright exists but its reported Chromium executable `/root/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome` does not exist. Targeted runtime/system file search found no browser executable. Browser screenshot not produced or claimed; no installation was authorized. Original PDF visual review is complete for stated scopes.

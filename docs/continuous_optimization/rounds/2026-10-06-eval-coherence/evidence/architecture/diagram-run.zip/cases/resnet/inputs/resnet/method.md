# Original residual blocks

Produce a method diagram comparing the original basic residual block with the bottleneck block, and make the residual-learning equation understandable. Choose your own composition.

For a same-shape block, input x branches into the learned residual function F(x) and an identity shortcut. Elementwise addition combines F(x) with x, followed by ReLU. This is the original post-activation block.

The basic example preserves 64 channels: a 3×3 convolution to 64 channels, ReLU, then another 3×3 convolution to 64 channels. The bottleneck example takes 256 channels: 1×1 convolution to 64, ReLU, 3×3 convolution to 64, ReLU, and 1×1 convolution back to 256. Each merges with its own identity shortcut and then applies ReLU. The paper uses batch normalization after each convolution and before activation; figures omit BN for compactness, so either show BN or state its omission. No activation separates the final BN from addition.

Scope is same-resolution identity blocks. A dimension-changing variant requires shape matching (for example, a projection shortcut); do not accidentally substitute that variant for these examples. Basic blocks support ResNet-18/34; bottleneck blocks support ResNet-50/101/152.

Paper: He et al., *Deep Residual Learning for Image Recognition*, CVPR 2016, Fig.2 (PDF p.2), Fig.5 (p.6), §§3.2–3.4 and §4.1. https://openaccess.thecvf.com/content_cvpr_2016/papers/He_Deep_Residual_Learning_CVPR_2016_paper.pdf

Code handoff: official ResNet-50 deploy model at commit `a7026cb6d478e131b765b898c312e25f9f6dc031`, `prototxt/ResNet-50-deploy.prototxt`, lines 225–354: `res2a` supplies both the residual branch and direct merge input; three convolution/BN/Scale stages produce `res2b_branch2c`; `res2b` merges both inputs, then ReLU consumes it. This is static source inspection, not executed inference. https://github.com/KaimingHe/deep-residual-networks/blob/a7026cb6d478e131b765b898c312e25f9f6dc031/prototxt/ResNet-50-deploy.prototxt

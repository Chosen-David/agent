from pathlib import Path
import json, hashlib, subprocess, platform
import xml.etree.ElementTree as ET
from html import escape
import fitz
from PIL import Image

OUT=Path(__file__).resolve().parent
SOURCE=OUT.parents[2]/'inputs/transformer/method.md'
W,H=510.23622,634
C={'ink':'#233444','muted':'#526171','enc':'#e8f0f7','dec':'#e8f3ef','norm':'#f3f4f5','memory':'#255f8b','outline':'#a0adba'}
parts=[]
nodes=[]; edges=[]
def text(x,y,lines,size=9.5,weight='normal',anchor='middle',fill=None,id=None,leading=12):
    if isinstance(lines,str): lines=[lines]
    attrs=f' id="{id}"' if id else ''
    parts.append(f'<text{attrs} x="{x}" y="{y}" text-anchor="{anchor}" font-size="{size}" font-weight="{weight}" fill="{fill or C["ink"]}">')
    for j,line in enumerate(lines):parts.append(f'<tspan x="{x}" dy="{0 if j==0 else leading}">{escape(line)}</tspan>')
    parts.append('</text>')
def path(id,pts,arrow=True,color=None,width=1.1,dash=None):
    d='M '+' L '.join(f'{x},{y}' for x,y in pts)
    parts.append(f'<path id="{id}" d="{d}" fill="none" stroke="{color or C["ink"]}" stroke-width="{width}" stroke-linejoin="round"'+(f' stroke-dasharray="{dash}"' if dash else '')+(f' marker-end="url(#arrow-memory)"' if arrow and color==C['memory'] else ' marker-end="url(#arrow)"' if arrow else '')+'/>')
def node(id,label,type,xy,group,source,fill=None,fontsize=9.5):
    x,y,w,h=xy
    parts.append(f'<g id="{id}"><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="3" fill="{fill or C["norm"]}" stroke="{C["outline"]}" stroke-width="0.8"/>')
    lines=label.split('\n');text(x+w/2,y+h/2-(len(lines)-1)*5.8+3.1,lines,size=fontsize,leading=11.6)
    parts.append('</g>')
    nodes.append(dict(id=id,label=label,type=type,group=group,source=source))
def plus(id,x,y,group,source):
    parts.append(f'<g id="{id}"><circle cx="{x}" cy="{y}" r="9" fill="white" stroke="{C["ink"]}" stroke-width="1.1"/>')
    text(x,y+3.6,'+',size=13);parts.append('</g>')
    nodes.append(dict(id=id,label='Elementwise addition',type='addition',group=group,source=source))
def edge(id,src,tgt,pts,label='',color=None,width=1.1):
    path(id,pts,color=color,width=width)
    edges.append(dict(id=id,source=src,target=tgt,direction='forward',kind='data_flow',label=label))
def free_node(id,label,typ,x,y,group,source):
    text(x,y,label,size=9.5,weight='bold',id=id)
    nodes.append(dict(id=id,label=label,type=typ,group=group,source=source))

parts.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="180mm" height="{H/W*180:.6f}mm" viewBox="0 0 {W} {H}">')
parts.append('<title>Original Transformer encoder–decoder architecture (2017)</title><desc>Two token streams; six post-norm encoder layers and six post-norm decoder layers, final encoder memory to all decoder cross-attention layers, linear projection and softmax.</desc>')
parts.append(f'<defs><marker id="arrow" viewBox="0 0 8 8" refX="7.4" refY="4" markerWidth="5.5" markerHeight="5.5" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L8,4 L0,8 Z" fill="{C["ink"]}"/></marker><marker id="arrow-memory" viewBox="0 0 8 8" refX="7.4" refY="4" markerWidth="6" markerHeight="6" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L8,4 L0,8 Z" fill="{C["memory"]}"/></marker></defs>')
parts.append('<rect width="100%" height="100%" fill="white"/><g font-family="DejaVu Sans, sans-serif">')
text(17,20,'Transformer',size=13,weight='bold',anchor='start')
text(493,18,'2017 base model · width 512 · 8 heads',size=9,anchor='end')
text(140,43,'SOURCE STREAM',size=9,weight='bold',fill=C['muted'])
text(400,43,'TARGET STREAM',size=9,weight='bold',fill=C['muted'])
free_node('source_tokens','Source tokens','tokens',140,65,'encoder_stream','method.md ¶2')
free_node('target_tokens','Target tokens (shifted right)','tokens',400,65,'decoder_stream','method.md ¶3')
node('source_embedding','Input embedding','embedding',(70,84,140,27),'encoder_stream','method.md ¶2',C['enc'])
node('target_embedding','Output embedding','embedding',(330,84,140,27),'decoder_stream','method.md ¶3',C['dec'])
edge('source_to_embedding','source_tokens','source_embedding',[(140,69),(140,84)])
edge('target_to_embedding','target_tokens','target_embedding',[(400,69),(400,84)])
plus('source_position_add',140,139,'encoder_stream','method.md ¶2, ¶4')
plus('target_position_add',400,139,'decoder_stream','method.md ¶3, ¶4')
edge('source_embedding_to_add','source_embedding','source_position_add',[(140,111),(140,130)])
edge('target_embedding_to_add','target_embedding','target_position_add',[(400,111),(400,130)])
text(69,132,['Positional','encoding'],size=8.5,leading=11,id='source_pe')
text(329,132,['Positional','encoding'],size=8.5,leading=11,id='target_pe')
nodes.extend([dict(id='source_pe',label='Positional encoding',type='position_signal',group='encoder_stream',source='method.md ¶2'),dict(id='target_pe',label='Positional encoding',type='position_signal',group='decoder_stream',source='method.md ¶3')])
edge('source_pe_add','source_pe','source_position_add',[(104,139),(131,139)])
edge('target_pe_add','target_pe','target_position_add',[(364,139),(391,139)])
# Logical repeated layers, not deployment boundaries.
for id,x,w,label in [('encoder_layer',25,210,'Encoder layer × 6'),('decoder_layer',307,188,'Decoder layer × 6')]:
    parts.append(f'<rect id="{id}" x="{x}" y="177" width="{w}" height="333" rx="7" fill="none" stroke="{C["outline"]}" stroke-width="1.0"/>')
    text(x,168,label.split(' × ')[0],size=10.5,weight='bold',anchor='start')
    text(x+w,168,'× 6',size=10.5,weight='bold',anchor='end')
# Encoder layer: post-norm at both sublayers.
node('encoder_self_attention','Self-attention\n8 heads · unmasked','attention',(70,210,140,39),'encoder_layer','method.md ¶2, ¶3, ¶4',C['enc'])
plus('encoder_attention_add',140,270,'encoder_layer','method.md ¶2')
node('encoder_attention_norm','LayerNorm','normalization',(70,286,140,23),'encoder_layer','method.md ¶2')
node('encoder_ffn','Position-wise FFN\n512 → 2048 → 512','feed_forward',(70,381,140,39),'encoder_layer','method.md ¶2, ¶4',C['enc'])
plus('encoder_ffn_add',140,440,'encoder_layer','method.md ¶2')
node('encoder_ffn_norm','LayerNorm','normalization',(70,456,140,23),'encoder_layer','method.md ¶2')
edge('encoder_input','source_position_add','encoder_self_attention',[(140,148),(140,210)])
edge('encoder_attention_to_add','encoder_self_attention','encoder_attention_add',[(140,249),(140,261)])
edge('encoder_attention_residual','source_position_add','encoder_attention_add',[(140,194),(46,194),(46,270),(131,270)],'identity residual')
edge('encoder_attention_postnorm','encoder_attention_add','encoder_attention_norm',[(140,279),(140,286)])
edge('encoder_to_ffn','encoder_attention_norm','encoder_ffn',[(140,309),(140,381)])
edge('encoder_ffn_residual','encoder_attention_norm','encoder_ffn_add',[(140,350),(46,350),(46,440),(131,440)],'identity residual')
edge('encoder_ffn_to_add','encoder_ffn','encoder_ffn_add',[(140,420),(140,431)])
edge('encoder_ffn_postnorm','encoder_ffn_add','encoder_ffn_norm',[(140,449),(140,456)])
# Decoder layer.
node('decoder_self_attention','Masked self-attention\n8 heads · no future positions','attention',(330,186,140,33),'decoder_layer','method.md ¶3, ¶4',C['dec'],fontsize=8.5)
plus('decoder_attention_add',400,237,'decoder_layer','method.md ¶3')
node('decoder_attention_norm','LayerNorm','normalization',(330,252,140,23),'decoder_layer','method.md ¶3')
node('decoder_cross_attention','Cross-attention\n8 heads','attention',(330,296,140,33),'decoder_layer','method.md ¶3, ¶4',C['dec'])
plus('decoder_cross_add',400,348,'decoder_layer','method.md ¶3')
node('decoder_cross_norm','LayerNorm','normalization',(330,363,140,23),'decoder_layer','method.md ¶3')
node('decoder_ffn','Position-wise FFN\n512 → 2048 → 512','feed_forward',(330,407,140,34),'decoder_layer','method.md ¶3, ¶4',C['dec'])
plus('decoder_ffn_add',400,460,'decoder_layer','method.md ¶3')
node('decoder_ffn_norm','LayerNorm','normalization',(330,475,140,23),'decoder_layer','method.md ¶3')
edge('decoder_input','target_position_add','decoder_self_attention',[(400,148),(400,186)])
edge('decoder_attention_residual','target_position_add','decoder_attention_add',[(400,179),(484,179),(484,237),(409,237)],'identity residual')
edge('decoder_attention_to_add','decoder_self_attention','decoder_attention_add',[(400,219),(400,228)])
edge('decoder_attention_postnorm','decoder_attention_add','decoder_attention_norm',[(400,246),(400,252)])
edge('decoder_queries','decoder_attention_norm','decoder_cross_attention',[(400,275),(400,296)],'Q')
text(389,290,'Q',size=8.5,anchor='end')
edge('decoder_cross_residual','decoder_attention_norm','decoder_cross_add',[(400,285),(484,285),(484,348),(409,348)],'identity residual')
edge('decoder_cross_to_add','decoder_cross_attention','decoder_cross_add',[(400,329),(400,339)])
edge('decoder_cross_postnorm','decoder_cross_add','decoder_cross_norm',[(400,357),(400,363)])
edge('decoder_to_ffn','decoder_cross_norm','decoder_ffn',[(400,386),(400,407)])
edge('decoder_ffn_residual','decoder_cross_norm','decoder_ffn_add',[(400,397),(484,397),(484,460),(409,460)],'identity residual')
edge('decoder_ffn_to_add','decoder_ffn','decoder_ffn_add',[(400,441),(400,451)])
edge('decoder_ffn_postnorm','decoder_ffn_add','decoder_ffn_norm',[(400,469),(400,475)])
# Shared memory: output after entire six-layer encoder, used in every decoder copy.
edge('encoder_memory','encoder_ffn_norm','decoder_cross_attention',[(140,479),(140,530),(263,530),(263,312.5),(330,312.5)],'final encoder output: K,V to each of six decoder layers',color=C['memory'],width=1.6)
text(291,305,'K, V',size=9,fill=C['memory'])
text(144,552,['Final encoder output','K, V for every decoder layer'],size=9,leading=13,fill=C['memory'])
node('linear_projection','Learned linear projection','projection',(330,526,140,25),'probability_head','method.md ¶4',fontsize=9)
node('softmax','Softmax','softmax',(330,563,140,25),'probability_head','method.md ¶4')
free_node('next_token_probabilities','Next-token probabilities','probabilities',400,612,'probability_head','method.md ¶4')
edge('decoder_to_linear','decoder_ffn_norm','linear_projection',[(400,498),(400,526)])
edge('linear_to_softmax','linear_projection','softmax',[(400,551),(400,563)])
edge('softmax_to_probabilities','softmax','next_token_probabilities',[(400,588),(400,601)])
text(17,600,['+  Elementwise addition','All sublayers: residual add, then LayerNorm'],size=8.5,anchor='start',leading=13,fill=C['muted'])
parts.append('</g></svg>')
svg='\n'.join(parts)
(OUT/'figure.svg').write_text(svg)
ET.parse(OUT/'figure.svg')
source_hash=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
contract=dict(id='transformer_2017_architecture',evidence_type='literature_method_schematic',source=dict(path=str(SOURCE),sha256=source_hash),version='Original 2017 encoder–decoder; base model',nodes=nodes,edges=edges,groups=[dict(id='encoder_stream',kind='logical_sequence_stream'),dict(id='decoder_stream',kind='logical_sequence_stream'),dict(id='encoder_layer',kind='logical_repeated_layer',repeat=6,members=[n['id'] for n in nodes if n['group']=='encoder_layer']),dict(id='decoder_layer',kind='logical_repeated_layer',repeat=6,members=[n['id'] for n in nodes if n['group']=='decoder_layer']),dict(id='probability_head',kind='logical_output_head')],invariants=['Source and target positional encodings are added, not concatenated.','Encoder and decoder repeat separate layer templates six times; repetition does not imply weight sharing.','Each sublayer has identity residual addition followed by LayerNorm (post-norm).','Source self-attention is unmasked; target self-attention masks future target positions.','Cross-attention Q comes from the preceding decoder sublayer; K and V come from the final encoder stack output.','The shared final encoder output supplies cross-attention in all six decoder layers.','The decoder stack feeds learned linear projection, then softmax, then next-token probabilities.','Base hidden width is 512, each attention has eight heads, and FFN intermediate width is 2048.'],abstraction_notes=['Each repeated-layer container displays one template; the outgoing edge denotes the sixth layer output.','Attention projection matrices, FFN activation, dropout, and embedding weight tying are not specified by the supplied source and are not introduced.','Forward activation topology is shown; no training loss, optimizer, performance, or measured results are claimed.'])
for n in nodes:
    n['inputs']=[e['source'] for e in edges if e['target']==n['id']]
    n['outputs']=[e['target'] for e in edges if e['source']==n['id']]
for e in edges:
    if e['id'].startswith('encoder_'):
        e['evidence']='method.md paragraph 2; paragraph 3-4 for encoder_memory'
    elif e['id'].startswith('decoder_'):
        e['evidence']='method.md paragraph 3; paragraph 4 for probability head'
    elif e['id'].startswith('source_'):
        e['evidence']='method.md paragraph 2'
    elif e['id'].startswith('target_'):
        e['evidence']='method.md paragraph 3'
    else:
        e['evidence']='method.md paragraph 4'
contract['groups'][2]['parent']='encoder_stream'
contract['groups'][2]['repeat_semantics']='Six layers in series: layer i output is layer i+1 input. Source positional sum feeds the first copy only.'
contract['groups'][2]['input_binding']='source_position_add -> first-layer input; previous encoder_ffn_norm -> subsequent-layer input'
contract['groups'][2]['output_binding']='encoder_ffn_norm from sixth copy is the final encoder output'
contract['groups'][3]['repeat_semantics']='Six layers in series: layer i output is layer i+1 input. Target positional sum feeds first copy only; final encoder memory feeds every copy.'
contract['groups'][3]['input_binding']='target_position_add -> first-layer input; previous decoder_ffn_norm -> subsequent-layer input'
contract['groups'][3]['output_binding']='decoder_ffn_norm from sixth copy feeds probability head'
contract['groups'][3]['external_memory_binding']='encoder_memory supplies K,V to decoder_cross_attention in every copy'
contract['groups'][3]['parent']='decoder_stream'
(OUT/'semantic_contract.json').write_text(json.dumps(contract,indent=2)+'\n')
(OUT/'input_hashes.json').write_text(json.dumps({str(SOURCE):source_hash},indent=2)+'\n')
subprocess.run(['inkscape',str(OUT/'figure.svg'),'--export-type=pdf','--export-filename='+str(OUT/'figure.pdf')],check=True)
fig=fitz.open(OUT/'figure.pdf')
fig[0].get_pixmap(dpi=180,alpha=False).save(OUT/'figure.png')
Image.open(OUT/'figure.png').convert('L').save(OUT/'grayscale.png')
# Exact 180 mm embedding on an A4 page, with a self-contained caption.
page=fitz.open();p=page.new_page(width=595.2756,height=841.8898)
rect=fitz.Rect((p.rect.width-W)/2,39,(p.rect.width+W)/2,39+H)
p.show_pdf_page(rect,fig,0)
caption=('Figure 1. Original Transformer encoder-decoder architecture (2017 base model). '
'Both streams add positional encodings to token embeddings. Each container denotes a layer '
'repeated six times. FFN denotes a position-wise feed-forward network. Every sublayer uses a residual addition followed '
'by LayerNorm. Decoder self-attention masks future positions. The final encoder output supplies '
'keys and values to cross-attention in every decoder layer; queries arrive from the preceding '
'decoder sublayer. A learned linear projection and softmax produce next-token probabilities. '
'Architecture schematic from the supplied method summary of Vaswani et al., sections 3.1-3.5.')
remaining=p.insert_textbox(fitz.Rect(43,688,552,799),caption,fontsize=9,fontname='helv',lineheight=1.25,color=(.14,.18,.23))
assert remaining>=0,remaining
p.insert_text((43,822),'A4 embedding preview · figure width 180 mm · provisional layout',fontsize=8,color=(.35,.39,.44))
page.save(OUT/'page.pdf');p.get_pixmap(dpi=120,alpha=False).save(OUT/'page.png')
qa=dict(figure_points=[fig[0].rect.width,fig[0].rect.height],figure_width_mm=180,figure_height_mm=H/W*180,primary_font_min_pt=8.5,pdf_images=len(fig[0].get_images()),pdf_font_count=len(fig[0].get_fonts()),svg_node_count=len(nodes),svg_edge_count=len(edges),page_embedding_width_mm=180,python=platform.python_version(),inkscape=subprocess.run(['inkscape','--version'],capture_output=True,text=True).stdout.strip())
(OUT/'build_report.json').write_text(json.dumps(qa,indent=2)+'\n')
print(json.dumps(qa,indent=2))

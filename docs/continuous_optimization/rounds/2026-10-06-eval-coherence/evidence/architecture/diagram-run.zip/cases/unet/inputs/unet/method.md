# Original U-Net architecture

Draw the original 2D segmentation architecture and its feature-map connections; choose the visual arrangement yourself. This case is held out from skill development.

Use valid (unpadded) 3×3 convolutions, each followed by ReLU. Each contracting stage applies two convolutions, then 2×2 max pooling with stride 2. Four downsamplings lead to a two-convolution bottom stage. Channel counts are 64, 128, 256, 512, 1024.

Each of four expanding stages upsamples with a 2×2 up-convolution, halves channels, concatenates a cropped copy of the corresponding contracting-stage output, then applies two valid 3×3 convolutions with ReLU. Concatenation is not addition. Cropping aligns spatial dimensions because valid convolutions shrink maps. A final 1×1 convolution maps 64 channels to two output classes in the illustrated example.

For the square-tile example, track these dimensions (spatial side lengths; both axes equal):

| Stage | Spatial progression | Channels after paired convolutions |
|---|---|---|
| Input / encoder 1 | 572 → 570 → 568 | 1 → 64 → 64 |
| Encoder 2 | pool 284 → 282 → 280 | 128 |
| Encoder 3 | pool 140 → 138 → 136 | 256 |
| Encoder 4 | pool 68 → 66 → 64 | 512 |
| Bottom | pool 32 → 30 → 28 | 1024 |
| Decoder 4 | up 56 → 54 → 52 | 512 |
| Decoder 3 | up 104 → 102 → 100 | 256 |
| Decoder 2 | up 200 → 198 → 196 | 128 |
| Decoder 1 / output | up 392 → 390 → 388 → 388 | 64 → 2 |

Copied encoder endpoints (568, 280, 136, 64) are cropped to (392, 200, 104, 56), respectively. Concatenation doubles the upsampled channel count before the paired convolutions.

Source: Ronneberger, Fischer & Brox, *U-Net: Convolutional Networks for Biomedical Image Segmentation*, MICCAI 2015, Fig.1 (arXiv v1 PDF p.2), §2 (p.4). https://arxiv.org/pdf/1505.04597v1 . Author publication record: https://lmb.informatik.uni-freiburg.de/Publications/2015/RFB15a/

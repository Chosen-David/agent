# Transformer architecture figure

Original module-level schematic of the 2017 encoder–decoder base model. Built solely from the supplied `inputs/transformer/method.md`; the paper URL is provenance supplied by that file, not an independently opened source. No original figure, other cases, grading material, or external sources were used.

## Files and reproduction

- Editable primary vector: `figure.svg`, with live text and stable node/edge IDs.
- Reproducible drawing and page compositor: `build_figure.py`.
- Actual vector export: `figure.pdf` (84 vector drawing objects, 0 embedded raster images, 3 embedded font subsets).
- Rendered views: `figure.png` and `grayscale.png` (180 dpi).
- Full-page preview: `page.pdf`, `page.png` (A4; figure embedded at exactly 180 mm; page PNG at 120 dpi).
- Semantic/source records: `semantic_contract.json`, `input_hashes.json`, `build_report.json`.
- Revision evidence: `revisions/01.svg`, `revisions/01.png`, `revisions/01_semantic_contract.json`, `revisions/02_page.png`.

Exact build command, from any current directory:

```bash
python /workspace/scratch/c12f3d9f92bd/architecture-eval-v2/cases/transformer/attempts/0001/outputs/build_figure.py
```

Uses existing Python 3.12.14, PyMuPDF, Pillow, and Inkscape 1.2.2. The script writes only its own output directory and reads the case method file through a relative path. No installation or paid service is required. SVG→PDF is performed by Inkscape; PyMuPDF renders PDF→PNG and embeds the vector PDF into the page; Pillow creates the grayscale derivative. The script preserves prior revision evidence. Inkscape emitted a nonfatal GtkRecentManager warning; output PDFs were successfully opened, inspected and rendered.

## Source mapping

Paragraph numbering counts the opening drawing instruction as paragraph 1, excluding the Markdown title.

| Supplied source | Diagram objects and relationships |
|---|---|
| Paragraph 2: source embedding, positional sum, six encoder layers, self-attention and FFN, residual plus post-normalization | Source stream, encoder layer container and its two attention/FFN → addition → LayerNorm chains; the two identity bypasses |
| Paragraph 3: shifted-right targets, output embedding and positional sum, six decoder layers, masked self-attention → encoder–decoder attention → FFN, residual plus post-normalization | Target stream, decoder layer container and its three sublayer chains and identity bypasses |
| Paragraph 3: decoder queries; final encoder keys and values; future masking and unmasked source attention | `Q` connector into cross-attention, `K, V` memory connector, explicit masked/unmasked block labels |
| Paragraph 4: learned linear projection, softmax, next-token probabilities, width 512, eight heads, FFN width 2048, added positional signals and memory in every decoder layer | Probability head; top configuration; per-attention head count; FFN dimension labels; addition circles; memory annotation |

Input SHA-256: `fe392930b7edd286d3668b48ffea59dcd295b18baf1cf183ad1014cddc49ab29`.

## Abstraction and design

The reader follows the source and target streams downwards. Encoder and decoder computations use pale blue and green fills, while neutral LayerNorm blocks keep post-norm order visually explicit. Position and stream labels provide redundant identity in grayscale. The memory route uses a heavier blue connector and an explicit K,V label, so color is not necessary to identify its role.

A two-column layout was selected over a single long horizontal pipeline because the latter would compress five residual sublayers and the probability head at 180 mm. The space between columns is reserved for the memory route. The encoder's two sublayers are spread through the same vertical extent as the decoder's three sublayers, keeping stack inputs and exits visually comparable without inventing an extra encoder block.

Each outlined container shows one layer template, repeated six times in series. The next copy receives the previous copy's output; positional sums feed the first copy only. Edges leaving the container represent the sixth layer output. The memory annotation explicitly binds that final encoder output to every decoder copy. The contract records these repeat bindings. Container boundaries are logical, not hardware or deployment boundaries. Repetition does not denote shared parameters.

FFN means position-wise feed-forward network. Attention internals, dropout, activation choice, loss, embedding weight sharing, and optimizer are omitted because they are not given in the supplied method. No measured result or performance claim is introduced.

Final figure dimensions are 180 × 223.661 mm, provisional. Primary type is DejaVu Sans, 8.5–13 pt at the declared figure width; all extracted PDF text is at least 8.5 pt. The page caption uses 9 pt Helvetica. The figure remains vector and has no external linked resources.

## Caption

Figure 1. Original Transformer encoder-decoder architecture (2017 base model). Both streams add positional encodings to token embeddings. Each container denotes a layer repeated six times. FFN denotes a position-wise feed-forward network. Every sublayer uses a residual addition followed by LayerNorm. Decoder self-attention masks future positions. The final encoder output supplies keys and values to cross-attention in every decoder layer; queries arrive from the preceding decoder sublayer. A learned linear projection and softmax produce next-token probabilities. Architecture schematic from the supplied method summary of Vaswani et al., sections 3.1-3.5.

## Observed revisions and checks

1. First color render was opened and inspected. The central input connector crossed each centered layer title. Saved revision 01, then moved each layer name to the left above its boundary and the ×6 count to the right, leaving a clear route for the central line. Also clarified the FFN label as “Position-wise FFN.” No node identity, edge endpoint, edge direction, edge kind, or group membership changed.
2. Opened the revised grayscale figure and full-page color preview. All five bypasses visibly rejoin addition circles before the corresponding LayerNorm. The query edge enters cross-attention from above; the memory edge enters from the left; the memory route does not cross another data-flow line. Color is redundant with stream positions and text. The page caption showed question marks in place of unsupported en dashes in the Helvetica export. Saved revision 02 page evidence and changed caption punctuation to ASCII.
3. Opened the final full-page render. Caption punctuation is now legible; title routes are clear; figure and caption fit within the page. The 180 mm embedding retains the intended hierarchy, and text and arrow endpoints are unobscured. Final drawing geometry is the same as the inspected revised grayscale figure.

Technical checks: SVG parses; IDs are unique; all 26 semantic nodes and 30 edges resolve to SVG objects. The revision comparison checked node ID/type/group and edge ID/source/target/direction/kind without changes. The PDF has embedded DejaVu fonts, a minimum extracted figure text size of 8.5 pt, and no raster images. PDF width is 510.2362 points, equivalent to 180 mm. Source hash and build dimensions are recorded.

Unresolved scope: no venue/year formatting specification was supplied, so submission compliance remains unverified. A color-vision simulation was not performed. The source paper and implementation were not independently checked; fidelity is to the supplied method summary. Files are delivered for independent review, without a self-assigned acceptance grade.

from pathlib import Path
import hashlib,json,subprocess,sys
import fitz
from PIL import Image
from xml.sax.saxutils import escape
O=Path(__file__).resolve().parent
SOURCE=Path('/workspace/scratch/c12f3d9f92bd/architecture-eval-v2/cases/resnet/inputs/resnet/method.md')
W=85*72/25.4; H=409
els=[]; nodes=[]; edges=[]
def add(s): els.append(s)
def text(id,x,y,s,size=8.3,weight='normal',anchor='middle',fill='#182733',extra=''):
 add(f'<text id="{id}" x="{x}" y="{y}" font-size="{size}" font-weight="{weight}" text-anchor="{anchor}" fill="{fill}" {extra}>{escape(s)}</text>')
def edge(id,src,dst,d,kind='data_flow',label=None):
 add(f'<path id="{id}" d="{d}" fill="none" stroke="#344b5c" stroke-width="0.9" marker-end="url(#arrow)"/>')
 edges.append(dict(id=id,source=src,target=dst,direction='forward',kind=kind,label=label,source_ref='method.md paragraphs 2–3'))
def node(id,label,typ,group,channels=None): nodes.append(dict(id=id,label=label,type=typ,group=group,channels=channels,source_ref='method.md paragraphs 2–3'))
def box(id,c,y,lines,typ,group,channels=None,fill='#e8f1f6',width=70,height=26):
 node(id,'; '.join(lines),typ,group,channels)
 add(f'<rect id="{id}" x="{c-width/2}" y="{y}" width="{width}" height="{height}" rx="2" fill="{fill}" stroke="#47758f" stroke-width="0.8"/>')
 if len(lines)==2:
  text(id+'-label',c,y+10,lines[0]);text(id+'-channels',c,y+21,lines[1])
 else:text(id+'-label',c,y+height/2+2.8,lines[0])
add(f'<svg xmlns="http://www.w3.org/2000/svg" width="85mm" height="{H*25.4/72}mm" viewBox="0 0 {W} {H}">')
add('<defs><marker id="arrow" viewBox="0 0 8 6" refX="7" refY="3" markerWidth="5" markerHeight="4" orient="auto" markerUnits="userSpaceOnUse"><path d="M0 0L8 3L0 6Z" fill="#344b5c"/></marker></defs>')
add(f'<rect width="{W}" height="{H}" fill="white"/>')
add('<g font-family="DejaVu Sans, sans-serif">')
for g,c,depth,cin,title in [('basic',45,'ResNet-18 / 34',64,'a  Basic block'),('bottleneck',165,'ResNet-50 / 101 / 152',256,'b  Bottleneck')]:
 text(g+'-title',c+12,13,title,9.2,'bold')
 text(g+'-depth',c+12,27,depth,8.05)
 add(f'<path d="M{c-37} 33H{c+63}" stroke="#bac8d0" stroke-width="0.65"/>')
 text(g+'-input-label',c,47,f'x ({cin} ch.)',8.6)
 node(g+'-input','x','tensor',g,cin)
 node(g+'-split','input branch point','branch',g,cin)
 add(f'<path d="M{c} 50V57" fill="none" stroke="#344b5c" stroke-width="0.9"/>')
 add(f'<circle id="{g}-split" cx="{c}" cy="57" r="1.6" fill="#344b5c"/>')
 edges.append(dict(id=g+'-input-to-split',source=g+'-input',target=g+'-split',direction='forward',kind='data_flow',source_ref='method.md paragraph 2'))
 add(f'<rect x="{c-38}" y="65" width="76" height="166" rx="4" fill="#f5f8fa"/>')
 text(g+'-identity-label',c+53,150,'identity x',8.2,extra=f'transform="rotate(-90 {c+53} 150)"')
 edge(g+'-identity',g+'-split',g+'-sum',f'M{c} 57H{c+62}V248H{c+7.5}',label='identity x')
 if g=='basic':
  box(g+'-conv1',c,76,['3 × 3 conv','64 → 64 ch.'],'convolution',g,[64,64])
  box(g+'-relu1',c,142,['ReLU'],'activation',g,64,fill='#ffffff',width=48,height=18)
  box(g+'-conv2',c,199,['3 × 3 conv','64 → 64 ch.'],'convolution',g,[64,64])
  edge(g+'-e1',g+'-split',g+'-conv1',f'M{c} 57V76')
  edge(g+'-e2',g+'-conv1',g+'-relu1',f'M{c} 102V142')
  edge(g+'-e3',g+'-relu1',g+'-conv2',f'M{c} 160V199')
  last=g+'-conv2'
 else:
  box(g+'-conv1',c,71,['1 × 1 conv','256 → 64 ch.'],'convolution',g,[256,64])
  box(g+'-relu1',c,108,['ReLU'],'activation',g,64,fill='#ffffff',width=48,height=16)
  box(g+'-conv2',c,135,['3 × 3 conv','64 → 64 ch.'],'convolution',g,[64,64])
  box(g+'-relu2',c,172,['ReLU'],'activation',g,64,fill='#ffffff',width=48,height=16)
  box(g+'-conv3',c,199,['1 × 1 conv','64 → 256 ch.'],'convolution',g,[64,256])
  edge(g+'-e1',g+'-split',g+'-conv1',f'M{c} 57V71')
  edge(g+'-e2',g+'-conv1',g+'-relu1',f'M{c} 97V108')
  edge(g+'-e3',g+'-relu1',g+'-conv2',f'M{c} 124V135')
  edge(g+'-e4',g+'-conv2',g+'-relu2',f'M{c} 161V172')
  edge(g+'-e5',g+'-relu2',g+'-conv3',f'M{c} 188V199')
  last=g+'-conv3'
 text(g+'-residual-label',c-11,238,'F(x)',8.2,anchor='end')
 edge(g+'-residual',last,g+'-sum',f'M{c} 225V240.5',label='F(x)')
 node(g+'-sum','elementwise addition','elementwise_sum',g,cin)
 add(f'<circle id="{g}-sum" cx="{c}" cy="248" r="7.5" fill="white" stroke="#344b5c" stroke-width="0.9"/>')
 add(f'<path d="M{c-3.5} 248H{c+3.5}M{c} 244.5V251.5" stroke="#344b5c" stroke-width="0.9"/>')
 box(g+'-postrelu',c,267,['ReLU'],'activation',g,cin,fill='#ffffff',width=48,height=18)
 edge(g+'-postadd',g+'-sum',g+'-postrelu',f'M{c} 255.5V267')
 node(g+'-output','y','tensor',g,cin)
 edge(g+'-outputedge',g+'-postrelu',g+'-output',f'M{c} 285V297')
 text(g+'-output-label',c,309,f'y ({cin} ch.)',8.6)
add(f'<path d="M120 39V312" stroke="#dce3e8" stroke-width="0.6"/>')
add(f'<rect x="8" y="321" width="{W-16}" height="37" rx="3" fill="#eef3f5"/>')
text('equation',W/2,337,'y = ReLU(x + F(x))',10.4,'bold')
text('equation-meaning',W/2,351,'F(x): learned residual   +: elementwise sum',8.0)
text('note-resolution',8,373,'Same spatial resolution; identity shortcuts.',8.05,anchor='start')
text('note-bn',8,387,'BN after every conv is omitted for clarity.',8.05,anchor='start')
text('note-final',8,401,'Final BN → addition → ReLU (post-activation).',8.05,anchor='start')
add('</g></svg>')
(O/'figure.svg').write_text('\n'.join(els))
contract=dict(figure_id='resnet-original-identity-blocks',evidence_type='source-grounded method schematic',source_inputs=[dict(path=str(SOURCE),sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest())],dimensions=dict(width_mm=85,height_mm=H*25.4/72,minimum_font_pt=8.0),nodes=nodes,edges=edges,groups=[dict(id='basic',label='Basic block',members=[n['id'] for n in nodes if n['group']=='basic'],meaning='same-resolution 64-channel identity block'),dict(id='bottleneck',label='Bottleneck block',members=[n['id'] for n in nodes if n['group']=='bottleneck'],meaning='same-resolution 256-channel identity block')],invariants=['Each x branches before all learned operations; identity carries x directly to its own addition.','Basic convolutions: 3x3,64→64; ReLU; 3x3,64→64.','Bottleneck convolutions: 1x1,256→64; ReLU; 3x3,64→64; ReLU; 1x1,64→256.','BN follows every convolution but is suppressed in this visual abstraction. Conv-output edges represent post-BN tensors.','No activation separates final BN and addition.','Both additions are elementwise and shape-preserving, then ReLU produces y.','All operations preserve spatial resolution. No projection shortcut or dimension-changing block is drawn.','Depth mapping: basic ResNet-18/34; bottleneck ResNet-50/101/152.'],abstraction=dict(BN='Every conv node abstracts conv followed by BN. Omission is explicit in figure.',scale='Scale layers are present in the supplied code handoff and not individually shown; this is a method-level abstraction.',code_evidence='Supplied static inspection only; code was not fetched or executed.'))
(O/'semantic_contract.json').write_text(json.dumps(contract,indent=2,ensure_ascii=False)+'\n')
subprocess.run(['inkscape',str(O/'figure.svg'),'--export-type=pdf','--export-filename='+str(O/'figure.pdf')],check=True,capture_output=True)
doc=fitz.open(O/'figure.pdf'); p=doc[0]
p.get_pixmap(dpi=300,alpha=False).save(O/'figure.png')
p.get_pixmap(dpi=96,alpha=False).save(O/'final_size.png')
Image.open(O/'figure.png').convert('L').save(O/'grayscale.png')
page=fitz.open(); pp=page.new_page(width=595.276,height=841.89)
pp.insert_text((48,42),'Original post-activation residual blocks',fontname='helv',fontsize=12)
pp.insert_text((48,59),'Provisional page preview | Figure embedded at 85 mm width',fontname='helv',fontsize=9)
rect=fitz.Rect(48,82,48+W,82+H)
pp.show_pdf_page(rect,doc,0)
caption='Figure 1. Original same-resolution residual blocks. (a) The basic block preserves 64 channels. (b) The bottleneck reduces 256 channels to 64 with a 1 x 1 convolution, processes the 64-channel representation with a 3 x 3 convolution, then restores 256 channels with a 1 x 1 convolution. Each residual F(x) is added elementwise to its unchanged input x and followed by ReLU. Batch normalization follows every convolution but is omitted; no activation intervenes between final BN and addition. Based on the supplied description of He et al., CVPR 2016, Figures 2 and 5, Sections 3.2-3.4 and 4.1. Geometry is schematic.'
caption_remaining=pp.insert_textbox(fitz.Rect(48,505,48+W,720),caption,fontname='helv',fontsize=9,lineheight=1.25)
key_remaining=pp.insert_textbox(fitz.Rect(320,85,548,205),'Reading key\nBlue boxes: convolutions and channel transitions\nWhite boxes: ReLU\nBypass: identity shortcut\nCircle: elementwise addition',fontname='helv',fontsize=9,lineheight=1.5)
assert caption_remaining >= 0 and key_remaining >= 0, 'Page text overflow'
page.save(O/'page.pdf');pp.get_pixmap(dpi=130,alpha=False).save(O/'page.png')
(O/'caption.txt').write_text(caption+'\n')
qa=dict(pdf_page_points=list(p.rect),pdf_raster_images=len(p.get_images()),pdf_vector_paths=len(p.get_drawings()),pdf_fonts=p.get_fonts(),font_sizes_pt=sorted(set(round(s['size'],3) for b in p.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans'])),svg_external_images=False)
(O/'build_checks.json').write_text(json.dumps(qa,indent=2)+'\n')
print(json.dumps(qa,indent=2))

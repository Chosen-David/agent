# Original U-Net architecture diagram

Status: delivered for independent review. This record reports construction and inspection evidence, not an independent acceptance decision.

## Scope and source

The sole scientific input was `cases/unet/inputs/unet/method.md`. Its SHA-256 is `199295cf9bafd140bf5c9952fb7dbbc37e4df35dafff6031d60307f39567153c`. The task SHA-256 is `454e1343ab03cabdbcb21303d69ae4774cf5b2f2b1452f2990804f2d09e0578b`.

The supplied method attributes the architecture to Ronneberger, Fischer & Brox, *U-Net: Convolutional Networks for Biomedical Image Segmentation*, MICCAI 2015, Fig. 1 (arXiv v1 PDF p. 2), §2 (p. 4). The provided URLs are https://arxiv.org/pdf/1505.04597v1 and https://lmb.informatik.uni-freiburg.de/Publications/2015/RFB15a/ . They were not visited. No original figure, other case, evaluator material, repository tests or external sources were read. No later same-padding U-Net variant is incorporated.

The applicable pinned research-diagrams Skill, execution, workflow, shared QA, decision gate, and relevant tool/reference guidance were read. Tool selection is a local/offline fallback under the explicit no-browsing and no-install task restrictions. SVG + Inkscape supports editable text, inspectable connector IDs, and actual vector PDF; PyMuPDF handles vector page embedding. This is an architecture schematic, not a measured result or validated model implementation.

## Design

Reader question: how do valid convolutions, pooling, up-convolution and cropped skip concatenation change the feature maps?

A U-shaped two-column flow preserves contracting/expanding direction and aligns each corresponding skip pair horizontally. A flat left-to-right chain would make four long skip routes harder to follow, so it was not selected. Each pair of convolutions is a source-backed block abstraction rather than two drawn feature slabs. Spatial and channel progressions retain the two individual convolution steps inside each block. Explicit concatenation nodes distinguish channel joining from addition, and the crop nodes retain all four exact source/target side lengths. Encoder output branches before pooling. The bottom block connects the two arms.

DejaVu Sans supplies a small consistent type hierarchy. Blue labels identify contracting blocks, teal labels expanding blocks, and ochre identifies copy/crop and concatenation. Text, spatial location, dashed copy paths and explicit operation names supply redundant semantics in grayscale. Rectangles are schematic and do not encode tensor size or channel count through geometry. Groups represent logical computation, not hardware or deployment boundaries.

Final physical figure size: **180 × 194.117647 mm**, provisional. Minimum label size: **8.0037 pt** (16 SVG units), main dimensions: 9.0042 pt, stage labels: 9.5044 pt. A4 proof page embeds the vector figure at **180 mm width without additional scaling**. No venue compliance is claimed.

## Source mapping

| Visible objects | Supplied evidence | Encoded facts |
|---|---|---|
| Input, Encoder 1–4 | First paragraph; table rows Input/encoder 1 through Encoder 4 | Two valid 3×3 convolutions with ReLU per stage; exact spatial and channel progressions |
| Four pooling edges | First paragraph; pool sizes in table | 2×2 max pool, stride 2; four downsamplings; channels preserved |
| Bottom | First paragraph; Bottom table row | 32 → 30 → 28 spatial, 512 → 1024 → 1024 channels |
| Four copy + crop nodes | Last method paragraph | 568 → 392, 280 → 200, 136 → 104, 64 → 56; channels preserved |
| Four up-convolution edges | Expanding-stage paragraph; decoder table rows | 2×2 up-convolution doubles side length and halves channels |
| Four Concat nodes | Expanding-stage paragraph; last paragraph | Join corresponding cropped encoder and upsampled decoder channels; totals 128, 256, 512, 1024 |
| Decoder 1–4 | Expanding-stage paragraph; decoder table rows | Two valid convolution/ReLU steps; exact supplied spatial progressions and restored stage channels |
| Final edge and output | Final-1×1 sentence; decoder 1/output row | 64 → 2 channels at spatial side 388 |

The explicit input-channel progressions for encoder stages 2–4 and the bottom are direct deductions from channel-preserving pooling and the supplied previous-stage output channels. Decoder concat totals follow the supplied channel-doubling rule. No train-only module, loss, normalization, padding, activation after the final 1×1 convolution, or performance claim was added.

## Caption

**Figure. Original U-Net for a square image tile.** The contracting path applies paired valid 3×3 convolutions with ReLU and four max-pooling steps. Each expanding stage up-convolves, concatenates a spatially cropped encoder copy, and applies paired convolutions. The 572 × 572 input yields a 388 × 388 prediction with two class channels. Spatial and channel progressions are shown separately. Architecture schematic based on the supplied method summary of Ronneberger, Fischer and Brox (MICCAI 2015; arXiv v1); no performance claim is implied.

## Build and technical evidence

Exact command from any working directory:

```bash
python /workspace/scratch/c12f3d9f92bd/architecture-eval-v2/cases/unet/attempts/0001/outputs/build_figure.py
```

`figure.svg` is the editable primary artwork, generated by `build_figure.py`. The script writes the semantic contract, runs the local Inkscape PDF and 300 dpi PNG exports, converts the PNG to grayscale, and uses PyMuPDF to embed the PDF as vector content on an A4 proof page. It also generates a nominal 96 dpi, 180 mm-width screen proof. It only writes to its own output directory. The supplied method path is used for hashing, and must remain available to rerun. Installed tool versions and actual command results are in `build_log.json`.

`technical_checks.json` records actual checks: SVG IDs were unique, all 22 semantic edges refer to the 19 recorded nodes, PDF width is 179.999995 mm (floating-point representation), the figure PDF contains 73 vector drawing objects and **zero raster images**, and PDF text remains extractable with embedded DejaVu font subsets. The page includes its caption. These checks establish properties of the files; they do not substitute for semantic or visual reading.

## Actual inspection and revisions

1. **Initial render:** opened the full-color figure, grayscale figure and full A4 proof page with the image viewer. Source-backed stage sizes and crop routes were visible. A concrete defect was found: single-line max-pool labels crossed the vertical pooling arrows. The general “Conv = 3×3” legend could also be read too broadly next to the final 1×1 edge.
2. **Revision:** preserved initial SVG, figure PNG, page PNG and semantic contract in `revision_01/`. Split pool labels into two lines placed left of the arrow. Restricted the convolution legend to the paired blocks. Added the explicit up-convolution scaling rule, clarified copied-feature cropping, and marked block geometry schematic. Height increased to maintain spacing; scientific nodes/edges/values were unchanged.
3. **Final render:** opened `final_width_96dpi.png`, `grayscale.png`, and `page.png`. The pooling text no longer crosses arrows. All four crop arrows terminate at their matching Concat boxes, and the upward decoder arrows enter from below before reaching paired-convolution blocks. The bottom route remains distinct from the fourth crop branch. At the nominal final-width proof, labels remain readable with no observed clipping or overlap. In grayscale, stage names and dashed copied paths retain their identities despite convergence of fill tones. On the complete page, the caption and figure fit with clear separation.

No color-vision simulation or paper print was performed. Display pixel density is device-dependent; the physical page size and embedded figure width are recorded independently. Independent scientific/visual review remains with the root reviewer. No unresolved construction defect was observed in the final inspected renders; this is not a self-awarded evaluation result.

## Deliverables

- `figure.svg`: editable primary vector artwork, with stable semantic IDs.
- `figure.pdf`: actual vector figure.
- `figure.png`: 300 dpi color render.
- `grayscale.png`: grayscale render.
- `page.pdf`, `page.png`: full A4 embedding proof at declared width.
- `final_width_96dpi.png`: nominal final-width screen preview.
- `semantic_contract.json`: source-backed nodes, edges, groups and invariants.
- `build_figure.py`, `build_log.json`, `technical_checks.json`: reproducible build and checks.
- `source_hashes.json`, `artifact_hashes.json`: input and final output hashes.
- `revision_01/`: retained initial artwork and proof before correction.

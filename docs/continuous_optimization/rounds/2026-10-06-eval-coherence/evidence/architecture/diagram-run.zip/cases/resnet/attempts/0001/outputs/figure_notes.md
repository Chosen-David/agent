# Original residual blocks — figure notes

Figure ID: `resnet-original-identity-blocks`  
Role: research-diagrams  
Status: delivered for independent review  
Evidence: supplied method description; source-grounded schematic, not a model execution or measured result.

## Design and scope

The reader question is how the two original post-activation block types learn and add a residual while preserving the identity input. Two aligned vertical columns make convolution count and channel transitions directly comparable. A common merge and output baseline makes the addition-before-ReLU order easy to trace. The basic column has longer inter-operation gaps solely to align these baselines; line lengths encode no runtime, depth, or other quantity.

Convolutions use pale blue boxes; ReLU uses smaller white boxes. All types are named, and identity routes have text labels, so the distinction does not rely on color. A lightly tinted branch background separates the learned path from the bypass without implying a hardware boundary. The shared equation explains the output and defines the residual and elementwise addition symbol. The final note explicitly fixes the original post-activation version.

The examples preserve spatial resolution and have identity shortcuts. Dimension-changing/projection blocks and pre-activation variants are not included. BN follows every convolution and is omitted as declared in the figure. Each displayed convolution output edge therefore abstracts the post-BN result. No ReLU is inserted between final BN and addition. Code-specific Scale layers are not individually drawn in this method-level abstraction.

## Physical format

- Provisional figure size: **85 mm × 144.286 mm** (240.9449 × 409 pt).
- Text: editable DejaVu Sans; exported sizes range from **8.0 to 10.4 pt**. Operation labels are 8.3 pt; input/output labels 8.6 pt.
- Stroke widths: 0.8–0.9 pt for operations and data flow; lighter decorative separators are 0.6–0.65 pt.
- `figure.svg` is the editable primary source, with stable operation and connection IDs.
- `figure.pdf` retains vector paths and embedded text fonts. Actual inspection found **0 raster images and 57 vector drawing objects**.
- `figure.png` and `grayscale.png`: 300 dpi. `final_size.png`: 96 dpi nominal physical-size viewing aid. Physical display scaling depends on the viewer.
- `page.pdf`: A4 page; vector figure embedded at exactly 85 mm width. `page.png` is its 130 dpi preview. The page is a size-check layout, not a venue template.
- Submission specifications were not provided or verified; no submission-compliance claim is made.

## Source mapping and input identity

Only the supplied local method file was used for scientific content:

`/workspace/scratch/c12f3d9f92bd/architecture-eval-v2/cases/resnet/inputs/resnet/method.md`

SHA-256: `06a20335da38a76809436241adc66c0a6ca792140eb2d33657cd3a7fc6341969`

| Figure content | Supplied source location |
|---|---|
| Input branch, identity bypass, elementwise sum, final ReLU, equation | `method.md`, line 5 |
| Basic two 3×3 convolutions at 64 channels and intervening ReLU | `method.md`, line 7 |
| Bottleneck 1×1 / 3×3 / 1×1, channels 256→64→64→256, two intermediate ReLUs | `method.md`, line 7 |
| BN omission and no activation before addition | `method.md`, line 7 |
| Same-resolution scope; basic versus bottleneck network depth families | `method.md`, line 9 |
| Paper identity and locators | `method.md`, line 11 |
| Official code commit and static implementation correspondence | `method.md`, line 13 |

The supplied paper locator is He et al., *Deep Residual Learning for Image Recognition*, CVPR 2016, Figures 2 and 5, §§3.2–3.4 and §4.1. The supplied code locator is `prototxt/ResNet-50-deploy.prototxt`, commit `a7026cb6d478e131b765b898c312e25f9f6dc031`, lines 225–354. In that supplied description, `res2a` is the input, `res2b_branch2c` is the residual branch output, and `res2b` performs the merge before ReLU. These locators were not fetched or independently inspected during this task. The original figures were not viewed. No inference was executed.

## Caption

Figure 1. Original same-resolution residual blocks. (a) The basic block preserves 64 channels. (b) The bottleneck reduces 256 channels to 64 with a 1 × 1 convolution, processes the 64-channel representation with a 3 × 3 convolution, then restores 256 channels with a 1 × 1 convolution. Each residual F(x) is added elementwise to its unchanged input x and followed by ReLU. Batch normalization follows every convolution but is omitted; no activation intervenes between final BN and addition. Based on the supplied description of He et al., CVPR 2016, Figures 2 and 5, §§3.2–3.4 and §4.1. Geometry is schematic.

## Build

Run the following exact command in the provided environment:

```bash
python /workspace/scratch/c12f3d9f92bd/architecture-eval-v2/cases/resnet/attempts/0001/outputs/build.py
```

`build.py` generates the SVG, semantic contract, vector PDF, color/grayscale/final-size PNGs, caption, full-page PDF/PNG, and machine-readable `build_checks.json`. It uses Inkscape for SVG→PDF, PyMuPDF for rendering and vector page embedding, and Pillow for luminance conversion. No paid services, installs, network access, or external raster assets are needed. The supplied method remains read-only and its hash is recomputed on each build. Manual SVG edits are possible; rerunning the generator replaces the SVG with its code-defined version.

Actual tools: Python 3.12.14, Inkscape 1.2.2, PyMuPDF 1.26.6, Pillow 12.3.0.

## Render inspections and revision record

1. **Initial figure render:** Opened `figure.png` and `final_size.png`. Followed each input to its learned branch and identity path, then to the correct addition and post-addition ReLU. Channel text, kernel labels, plus signs, and all arrowheads were visible; routes did not cross labels. Convolution and activation boxes retained distinct shape/label coding at nominal 85 mm scale. No figure-layout change was required.
2. **Initial grayscale/page inspection:** Opened `grayscale.png` and the first `page.png`. Grayscale retained operation outlines, text, and route contrast. The page figure and caption were visible, but the optional reading key was absent because its text box was too short. Retained the actual initial page as `page_revision01.png`.
3. **Page correction:** Increased only the reading-key text box height and added explicit nonnegative-fit assertions for the page key and caption. Rebuilt and opened the final `page.png`; the complete reading key now appears in the right column. No figure nodes, edges, labels, groups, or equation changed.
4. **Technical inspection:** Parsed SVG XML, checked unique IDs, checked all semantic-edge endpoints refer to existing nodes, counted two identity shortcut edges, and confirmed every PDF text bounding box lies within the figure page. Exported minimum font size is 8 pt. PDF content inspection found vector paths, embedded DejaVu Sans fonts, and no embedded raster image.

These are the producing agent's observed checks, not an independent acceptance result or an aesthetic score. Source-level scientific facts were checked against the supplied method, not against externally retrieved paper/code. Color-vision simulation and physical printed inspection were not performed. Independent review remains with the root reviewer.

## Delivered files and remaining limits

Requested deliverables: `figure.svg`, `figure.pdf`, `figure.png`, `grayscale.png`, `page.pdf`, `page.png`, `semantic_contract.json`, `figure_notes.md`.

Reproduction/inspection support: `build.py`, `build_checks.json`, `caption.txt`, `final_size.png`, `page_revision01.png`.

No known unresolved rendering defect was observed. The artifact explains only the supplied same-resolution identity examples; it does not claim experimental validation, measured performance, independent source verification, or venue compliance.

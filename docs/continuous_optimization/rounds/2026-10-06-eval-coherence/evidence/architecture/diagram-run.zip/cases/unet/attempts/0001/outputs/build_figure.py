from pathlib import Path
import json, hashlib, subprocess, sys, html
import fitz
from PIL import Image
ROOT=Path(__file__).resolve().parent
SRC=Path('/workspace/scratch/c12f3d9f92bd/architecture-eval-v2/cases/unet/inputs/unet/method.md')
W,H=1020,1100
blue='#315D80'; teal='#2F706B'; amber='#94672B'; ink='#202D37'; muted='#53616B'
items=[]
def add(s):items.append(s)
def text(x,y,s,size=18,fill=ink,weight='normal',anchor='start',id=None):
    ident=f' id="{id}"' if id else ''
    add(f'<text{ident} x="{x}" y="{y}" font-size="{size}" fill="{fill}" font-weight="{weight}" text-anchor="{anchor}">{html.escape(s)}</text>')
def rect(id,x,y,w,h,fill,stroke,rx=6,dash=None):
    add(f'<rect id="{id}" x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="1.6"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>')
def path(id,d,color=ink,dash=None,arrow=True):
    add(f'<path id="{id}" d="{d}" fill="none" stroke="{color}" stroke-width="2.1" stroke-linejoin="round"'+(f' stroke-dasharray="{dash}"' if dash else '')+(f' marker-end="url(#{"crop-arrow" if color==amber else "arrow"})"' if arrow else '')+'/>')
add(f'<svg xmlns="http://www.w3.org/2000/svg" width="180mm" height="{180*H/W:.6f}mm" viewBox="0 0 {W} {H}">')
add('<title>Original U-Net: valid-convolution feature flow</title><desc>Four encoder stages descend through max pooling. Four cropped copies join up-convolved decoder features by concatenation. All spatial side lengths and channel changes are explicit.</desc>')
add('<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L10,5 L0,10 Z" fill="#202D37"/></marker><marker id="crop-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L10,5 L0,10 Z" fill="#94672B"/></marker></defs>')
add('<rect width="1020" height="1100" fill="white"/><g font-family="DejaVu Sans, sans-serif">')
text(30,30,'Original U-Net',25,weight='bold')
text(990,30,'2D segmentation · 2015',18,muted,anchor='end')
text(30,58,'s = spatial side length (pixels); C = channels. All feature maps are square.',18,muted)
rect('input',30,78,285,40,'#F2F5F7',blue)
text(172.5,104,'Input: 572 × 572 × 1',18,anchor='middle')
rect('output',705,78,285,40,'#EFF6F3',teal)
text(847.5,104,'Output: 388 × 388 × 2',18,anchor='middle')
path('input-to-e1','M172.5 118 V145')
path('d1-to-output','M847.5 145 V118')
text(866,136,'1×1 conv',16)
ys=[145,330,515,700]
encs=[([572,570,568],[1,64,64]),([284,282,280],[64,128,128]),([140,138,136],[128,256,256]),([68,66,64],[256,512,512])]
decs=[([392,390,388],[128,64,64]),([200,198,196],[256,128,128]),([104,102,100],[512,256,256]),([56,54,52],[1024,512,512])]
nodes=[{'id':'input','type':'tensor','shape':[572,572,1],'source':'method.md: input / encoder 1 table row'}, {'id':'output','type':'tensor','shape':[388,388,2],'source':'method.md: decoder 1 / output table row'}]
edges=[]
def edge(id,a,b,kind='data',label='',source='method.md'):
    edges.append(dict(id=id,source=a,target=b,direction='forward',kind=kind,label=label,evidence=source))
edge('input-to-e1','input','e1')
for i,(y,(sp,ch),(dsp,dch)) in enumerate(zip(ys,encs,decs),1):
    rect(f'e{i}',30,y,285,104,'#EDF3F9',blue)
    text(46,y+27,f'Encoder {i} · 2× conv',19,blue,'bold')
    text(46,y+57,'s: '+' → '.join(map(str,sp)),18)
    text(46,y+85,'C: '+' → '.join(map(str,ch)),18)
    path(f'e{i}-out',f'M172.5 {y+104} V{y+127}',arrow=False)
    add(f'<circle cx="172.5" cy="{y+127}" r="3.5" fill="{ink}"/>')
    # The dashed branch is a copied encoder output, never an additive residual.
    path(f'e{i}-to-crop{i}',f'M172.5 {y+127} H388',amber,'7 5')
    rect(f'crop{i}',389,y+104,212,46,'#FCF8F0',amber,5,'5 4')
    text(495,y+123,'copy + crop',16,amber,anchor='middle')
    text(495,y+142,f's: {sp[-1]} → {dsp[0]} · C: {ch[-1]}',16,anchor='middle')
    path(f'crop{i}-to-cat{i}',f'M601 {y+127} H705',amber,'7 5')
    rect(f'd{i}',705,y,285,82,'#ECF5F2',teal)
    text(721,y+24,f'Decoder {i} · 2× conv',19,teal,'bold')
    text(721,y+49,'s: '+' → '.join(map(str,dsp)),18)
    text(721,y+72,'C: '+' → '.join(map(str,dch)),18)
    rect(f'cat{i}',705,y+105,285,44,'#FBF3E7',amber)
    text(847.5,y+133,f'Concat · s: {dsp[0]} · C: {dch[0]}',18,anchor='middle')
    path(f'cat{i}-to-d{i}',f'M847.5 {y+105} V{y+82}')
    nodes.extend([
      dict(id=f'e{i}',type='paired_valid_conv_relu',spatial=sp,channels=ch,evidence=f'method.md: encoder {i} row; first paragraph'),
      dict(id=f'crop{i}',type='copy_crop',spatial=[sp[-1],dsp[0]],channels=ch[-1],evidence='method.md: copied encoder endpoints paragraph'),
      dict(id=f'cat{i}',type='channel_concatenation',spatial=dsp[0],input_channels=[ch[-1],ch[-1]],output_channels=dch[0],evidence='method.md: concatenation doubles upsampled channels'),
      dict(id=f'd{i}',type='paired_valid_conv_relu',spatial=dsp,channels=dch,evidence=f'method.md: decoder {i} row; expanding-stage paragraph')])
    edge(f'e{i}-to-crop{i}',f'e{i}',f'crop{i}','copied_data','copy and crop')
    edge(f'crop{i}-to-cat{i}',f'crop{i}',f'cat{i}','copied_data','cropped encoder features')
    edge(f'cat{i}-to-d{i}',f'cat{i}',f'd{i}','data','two valid 3×3 convolutions, each followed by ReLU')
    if i<4:
        path(f'pool{i}',f'M172.5 {y+127} V{ys[i]}')
        text(32,y+159,'2×2 max pool',16)
        text(32,y+178,'stride 2',16)
        path(f'up{i}',f'M847.5 {ys[i]} V{y+149}')
        text(865,y+172,'2×2 up-conv',16)
        edge(f'pool{i}',f'e{i}',f'e{i+1}','data','2×2 max pooling, stride 2')
        edge(f'up{i}',f'd{i+1}',f'cat{i}','data','2×2 up-convolution; halves channels')
path('pool4','M172.5 827 V904 H355')
text(32,858,'2×2 max pool,',16)
text(32,881,'stride 2',16)
rect('bottom',355,865,312,91,'#EDF3F9',blue)
text(373,891,'Bottom · 2× conv',19,blue,'bold')
text(373,918,'s: 32 → 30 → 28',18)
text(373,944,'C: 512 → 1024 → 1024',18)
path('up4','M667 904 H847.5 V849')
text(865,888,'2×2 up-conv',16)
nodes.append(dict(id='bottom',type='paired_valid_conv_relu',spatial=[32,30,28],channels=[512,1024,1024],evidence='method.md: bottom table row'))
edge('pool4','e4','bottom','data','2×2 max pooling, stride 2')
edge('up4','bottom','cat4','data','2×2 up-convolution; 1024 → 512 channels, 28 → 56 spatial')
edge('d1-to-output','d1','output','data','1×1 convolution: 64 → 2 channels; spatial side remains 388')
add('<path d="M30 976 H990" stroke="#CCD3D8" stroke-width="1"/>')
text(30,1001,'2× conv blocks: two valid 3×3 convolutions, each followed by ReLU.',18)
text(30,1031,'Up-conv doubles s and halves C. Concat joins channels; it is not addition.',18)
text(30,1061,'Dashed arrows copy encoder features; cropping aligns their spatial sizes.',18)
text(30,1087,'Schematic: block sizes do not encode tensor dimensions.',16,muted)
add('</g></svg>')
(ROOT/'figure.svg').write_text('\n'.join(items))
contract=dict(schema_version=1,figure_id='unet-original-2015',source_sha256=hashlib.sha256(SRC.read_bytes()).hexdigest(),evidence_type='source-grounded architecture schematic',source_version='Supplied method.md; attributed to MICCAI 2015 / arXiv 1505.04597v1',nodes=nodes,edges=edges,groups=[dict(id='encoder',members=[f'e{i}' for i in range(1,5)],meaning='contracting path; not a hardware boundary'),dict(id='decoder',members=[x for i in range(1,5) for x in [f'cat{i}',f'd{i}']],meaning='expanding path; not a hardware boundary')],invariants=['Four downsamplings and four up-convolutions','Each convolution in every paired block is valid 3×3 then ReLU','Skip copies are cropped, then concatenated along channels; never summed','Cropped skips preserve channels','Pooling preserves channels and halves spatial side length','Up-convolution doubles spatial side length and halves channels','Final 1×1 maps 64 to two classes with spatial side 388','No same-padding or modern U-Net variant implied'],dimensions=dict(width_mm=180,height_mm=180*H/W,min_text_pt=16*180/1020*72/25.4),unknowns=[],status='for independent review')
(ROOT/'semantic_contract.json').write_text(json.dumps(contract,indent=2)+'\n')
# Export SVG through Inkscape. PDF retains vectors and embedded text fonts.
log=[]
for cmd in [['inkscape',str(ROOT/'figure.svg'),'--export-type=pdf',f'--export-filename={ROOT/"figure.pdf"}'],['inkscape',str(ROOT/'figure.svg'),'--export-type=png','--export-dpi=300',f'--export-filename={ROOT/"figure.png"}']]:
    r=subprocess.run(cmd,text=True,capture_output=True,check=True);log.append({'command':cmd,'stdout':r.stdout,'stderr':r.stderr})
Image.open(ROOT/'figure.png').convert('L').save(ROOT/'grayscale.png')
# A4 proof page, 180 mm figure width, with a concise caption. Figure remains vector.
mm=72/25.4
page_doc=fitz.open();pg=page_doc.new_page(width=210*mm,height=297*mm)
pg.insert_text((15*mm,16*mm),'Architecture proof · provisional 180 mm figure width',fontsize=10,fontname='helv')
fig=fitz.open(ROOT/'figure.pdf')
box=fitz.Rect(15*mm,24*mm,195*mm,(24+180*H/W)*mm)
pg.show_pdf_page(box,fig,0)
caption=('Figure. Original U-Net for a square image tile. The contracting path applies paired valid 3×3 convolutions with ReLU and four max-pooling steps. Each expanding stage up-convolves, concatenates a spatially cropped encoder copy, and applies paired convolutions. The 572 × 572 input yields a 388 × 388 prediction with two class channels. Spatial and channel progressions are shown separately. Architecture schematic based on the supplied method summary of Ronneberger, Fischer and Brox (MICCAI 2015; arXiv v1); no performance claim is implied.')
pg.insert_textbox(fitz.Rect(15*mm,box.y1+7*mm,195*mm,286*mm),caption,fontsize=9,fontname='helv',lineheight=1.3)
page_doc.save(ROOT/'page.pdf')
pg.get_pixmap(matrix=fitz.Matrix(1.6,1.6),alpha=False).save(ROOT/'page.png')
fig[0].get_pixmap(matrix=fitz.Matrix(96/72,96/72),alpha=False).save(ROOT/'final_width_96dpi.png')
versions={'python':sys.version,'inkscape':subprocess.check_output(['inkscape','--version'],text=True).strip(),'fitz':fitz.VersionBind,'Pillow':Image.__version__}
(ROOT/'build_log.json').write_text(json.dumps(dict(commands=log,versions=versions,pdf_dimensions_pt=list(fig[0].rect),page_figure_width_mm=180),indent=2)+'\n')
print(json.dumps({'files':[p.name for p in ROOT.iterdir()],'figure_mm':[180,180*H/W],'minimum_font_pt':contract['dimensions']['min_text_pt']},indent=2))

# Original Transformer architecture

Draw the 2017 encoder–decoder model at the module level, including both sequence streams and the probability head. Design the composition yourself.

Source tokens pass through an embedding and are summed with positional encodings. The encoder repeats a layer six times: multi-head self-attention, then a position-wise feed-forward network. Each sublayer has its own residual addition followed by layer normalization (post-norm).

Shifted-right target tokens pass through an output embedding and a positional-encoding sum. The decoder repeats six layers. Each contains masked self-attention, encoder–decoder attention, and a feed-forward network, in that order, each with residual addition and post-layer-normalization. Cross-attention queries come from the preceding decoder sublayer; keys and values come from the final encoder output. Future target positions are masked; source self-attention is unmasked.

The decoder stack feeds a learned linear projection and softmax, producing next-token probabilities. The base model uses width 512, eight attention heads, and feed-forward width 2048. Positional encodings are added, not concatenated. Encoder memory must reach the cross-attention in every decoder layer.

Source: Vaswani et al., *Attention Is All You Need*, NIPS 2017, Figure 1 (PDF p.3), §§3.1–3.5. https://proceedings.neurips.cc/paper_files/paper/2017/file/3f5ee243547dee91fbd053c1c4a845aa-Paper.pdf

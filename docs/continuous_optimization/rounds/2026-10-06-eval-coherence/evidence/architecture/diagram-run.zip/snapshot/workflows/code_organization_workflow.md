# 文件管理与代码组织工作流

[返回](../README.md) · [技能入口](../plugins/research-assistant/skills/code-organization/SKILL.md)

## 职责与触发

`code-organization` 同时承担文件管理 Agent：项目开始先规划存放位置，Agent 交接时登记产物，每个任务完成后增量核对，整轮结束后整理映射和提出归档方案。它与实现、实验、作图、写作、审稿等 Agent 协作，主 AI 是唯一协调者。简单单文件任务沿用已有目录，不强制创建一套新结构。

- 主 AI：确定项目根、任务版本、写入负责人、允许动作和输出目录；维护根目录 TASK.md，最终批准完整性。
- 文件管理 Agent：只读盘点、为新产物建议路径、维护 CODEMAP/产物清单，检查重复、散落文件、引用与消费者；不替实验 Agent 改数据，不把文件存在当任务完成。
- 生产 Agent：写入分配路径，交付产物清单、任务 ID、来源、校验信息与状态；不要自创第二份 TASK.md 或随手向根目录写图表/日志。
- 消费 Agent：按清单中的准确路径读取，反馈缺失/过期/不匹配；不要默默复制一个“final_v2_new”到另一个目录。

## 根目录 TASK.md：唯一总清单

TASK.md 固定在**当前项目根目录**，不是工具仓库根目录（除非当前项目就是本仓库）。同一项目不在各 Agent 子目录另设 TASK.md。模板文件不属于活跃清单；子任务日志用 `status.json`/`notes.md`，并引用根任务 ID。

主 AI 在新会话/续跑开始、委派前、每个任务完成/失败后、监督 tick 和最终汇报前读取根 TASK.md。各 Agent 开始任务时读取根文件或主 AI 交接的当前版本，返回 `task_id/task_refs` 与差异建议；**仅主 AI 串行合并总清单修改**。用户手改总清单优先核对，不能覆盖或忽略。

TASK.md 只放稳定目标、约束、验收和产物索引；高频状态/日志放 `.agent-runs/<run_id>/` 的 SQLite、progress.json 等。启动运行后清单内容哈希被固定，主 AI 不要每个 tick 改勾选导致版本漂移：结果写进度文件，需求变化时版本化重规划；整轮完成且监督已退出后才按证据统一更新勾选/汇总。若同步勾选改变了源哈希，旧 final-report 对应旧版本，保留旧快照/哈希并记录收尾修订，不伪称与新文件字节相同。

## 目录与文件约定

先尊重已有结构；没有约定时使用以下默认位置，不为保持整齐批量搬动历史文件。

| 内容 | 默认位置 | 规则 |
| --- | --- | --- |
| 总任务与说明 | `TASK.md`、`README.md`、`CODEMAP.md` | 根目录稳定入口，由主 AI/指定唯一作者维护 |
| 可复用实现 | `src/` 或项目已有源码目录；`scripts/` | 不放临时日志/模型输出 |
| 输入与原始数据 | `data/raw/`；`data/processed/` | 标来源、版本；原始数据保持只读，不重复复制大文件 |
| 实验与指标 | `results/<task_id>/<run_id>/` | 区分 raw/derived/synthetic；保留参数与单位 |
| 图表 | `figures/<task_id>/` | 区分 source/ 与 export/，中文/英文版本可定位 |
| 报告与交付 | `reports/<task_id>/` 或既有 `docs/` | 最终文件有明确版本/来源，不散落根目录 |
| 运行状态/临时文件 | `.agent-runs/<run_id>/` | 日志、DB、状态、临时草稿；私密数据不提交公共仓库 |
| 历史归档 | `archive/<date-or-run>/` | 仅在任务停止、引用核查、现有授权及可回滚条件满足后归档 |

默认从一开始就把新文件写到合适位置，可在既有任务授权内直接做；不要反复询问普通文件命名。历史文件移动/删除的风险与主调度决策协议一致：用户明确授权整理时可执行可回滚且引用已核查的移动；删除、覆盖重要原始数据、改变外部接口或运行中的路径须另行处理，不能凭“整理”一词推定授权。

## 跨 Agent 文件交接

主 AI 在任务输入中指定 `project_root`, `task_refs`, `output_root`, `artifact_manifest`, `allowed_writes` 和唯一写入 owner。生产 Agent 交付 JSON 清单或等价结构：

```json
{
  "task_id": "T1",
  "producer": "research-implement-optimize",
  "artifacts": [
    {
      "path": "results/T1/run-001/metrics.json",
      "kind": "measured-result",
      "status": "final",
      "sha256": "actual-content-sha256",
      "consumers": ["research-data-visualization", "research-review"],
      "source": "raw-log-path-and-configuration"
    }
  ]
}
```

文件管理 Agent 核对路径存在/位于项目约定目录、来源/哈希、同路径多作者、消费者引用、临时与正式版本。未生成的计划输出标 `planned`，不得写假哈希或说已交付。实际交接清单放 `.agent-runs/<run_id>/artifacts/<task_id>.json` 或项目现有 manifest 目录；汇总写 CODEMAP，不把同一二进制产物复制给每个消费者。

产物报告继续满足 [监督工作流](task_supervision_workflow.md) 的 summary/data/evidence 契约；整理通过不替代技术验收。文件管理返回缺失/孤儿/冲突及下一责任人，主 AI 编入修复节点后重新核对 TASK.md。

## 每轮执行

1. **只读盘点**：先读根 TASK.md、已有 CODEMAP、最新进度、git status、实际活跃作业/生产者与消费者；用 `rg --files` 和 `rg` 追踪文件/路径，不靠文件名或 mtime 猜归属。
2. **分配与登记**：新产物先确定目录和单一作者。接收各 Agent 清单，增量更新 CODEMAP 表格：`任务 ID | 结论/状态 | 生产者 | 脚本 | 数据 | 产物/版本 | 消费者/引用`。不重排无关历史行。
3. **目录说明**：仅必要目录写一段用途、命名规则及索引链接；避免为每个临时目录生成 README。
4. **提出整理**：列出散落、孤儿、重复、命名漂移文件及引用证据；无法判定的标 unknown/backlog。已引用文件核查代码/文档/任务计划/manifest/论文路径；哈希相同不等于可删除。
5. **授权内执行**：对停止使用且已核查的文件以逻辑组 git mv，修复所有消费者和清单引用，保留可回滚点。无 git 或未知外部消费者时先提案；不改逻辑、原始数据和活跃输出路径。删除不自动执行。
6. **验收交接**：实际检查新路径、引用、相关脚本最小运行；将“对应 TASK 的哪项、文件/数据在哪里、哪些还未整理/阻塞、下一负责人”返回主 AI。主 AI 再更新进度并决定下一任务，不能因目录看起来整齐就宣布全链完成。

## 验收与限制

本轮各 Agent 声明的产物应 **100% 登记或明确标缺失/unknown**；历史活跃脚本映射目标 ≥95%，缺口必须列出，不能用旧比例掩盖新产物丢失。确认单一根 TASK.md、无多作者覆盖、消费者引用有效、正式/临时数据区分、无活跃路径移动、删除项 0。不能证明的运行状态视为未知并保留路径，推进其他可安全整理部分。

[执行与验收细则](../plugins/research-assistant/skills/code-organization/references/execution.md)。

## 脚本复用与报告更新

优先查 CODEMAP/`rg` 定位同类实验脚本。算法、输入输出契约相同而只是数据集、seed、阈值或绘图样式不同，复用一个脚本配不同 JSON/YAML/CLI 参数；保留每次调用、配置哈希、代码 commit、环境版本与输出 run_id。先检查是否真的共享语义，不把不兼容的测量混成充满分支的万能脚本。临时原型验证有效后再合并公共函数；重构前保留旧运行，验证同输入数值/单位/边界一致，修复引用。不能仅凭文件名/哈希相似就删脚本。

本库的 Agent 回归直接复用 `scripts/agent_eval_pipeline.py --help`：不同任务通过 `--tasks/--rubric/--fixture-root/--adapter` 配置，不每轮复制 runner。它接收真实宿主执行回执，不会自己调用模型。开发评测与用户科研实验明确分开；不拿评测gold给执行Agent。

报告采用双层结构，沿用已有目录时记录对应映射：

- `reports/<task_id>/runs/<run_id>/report.json` 与 `report.md` 是不可变本轮快照；引用原始数据、脚本和图的准确路径/哈希，不重复复制大文件。
- `reports/<task_id>/latest.json` 是原子更新的稳定入口；CODEMAP/TASK 链接这个入口或对应确切版本。普通用户摘要可原位更新，但消费者、论文引用和验收绑定固定 run/哈希，禁止用移动中的 latest 证明旧结论。
- 根文件不堆 `final_final_v3.md`。同一轮草稿可由唯一作者原位编辑；一旦交接/验收就冻结，后续修改创建新 run。保留失败与负结果；归档不等于删除。
- 每个运行报告说清 `purpose`（为哪个目标）、`summary`、`data`（类型/值或可追溯描述/单位）、`meaning`（可支持什么）、`useful`（true/false/unknown）、`limitations` 与下一步。false 也可能是有价值的反证，不按“结果好看”筛掉。

完整 checkout 可使用 `python scripts/publish_report.py publish --root PROJECT --manifest MANIFEST.json`，模板见 `templates/run_report.example.json`。发布前检查 artifact 哈希与 memory_refs，拒绝覆盖旧 run；`read --root PROJECT --task T1` 重新核验 latest 与来源/记忆。直接看历史 Markdown 不会自动刷新失效标记，纠错后主 AI 必须更新 TASK/CODEMAP 的状态并明确旧报告不可用于当前验收。脚本仅管项目内报告，不发布到外部服务，不代替技术审阅。

仅插件安装时执行相同契约并明确脚本未安装；不要假设用户目录里有本仓库 `scripts/`。文件管理 Agent 将受更正影响的报告/图及消费者列表交给主 AI，按 [记忆纠错](project_memory_workflow.md) 重验后再更新稳定入口。

# Delivery notes — comparative methods section

Author actor: `/root/architecture_writer`. Scope: a bounded English comparative methods section and integration of three delivered architecture figures, not a new research paper or an experimental evaluation. Status: draft produced and author-side construction checks completed; independent scientific and reader review is pending.

## Delivered manuscript

- `paper.tex`: editable LaTeX section, captions, and linked source references.
- `paper.pdf`: four physical A4 pages; page 1 contains the comparison and references, pages 2–4 contain Transformer, ResNet, and U-Net plates.
- `page-1.png` through `page-4.png`: every final page rendered at 150 dpi and opened with the image viewer.
- `figures/transformer.pdf`, `figures/resnet.pdf`, `figures/unet.pdf`: byte-identical copies of the supplied vector figures, embedded at the declared 180 mm, 85 mm, and 180 mm widths. No cropping, label changes, diagram reconstruction, or intentional font reduction was performed.
- `build.py`, `build.log`, `paper.log`, and `build_checks.json`: reproducible local compilation, render, and technical evidence.
- `verified_inputs.json`: the actual SHA-256 of all 15 handoff files, each compared successfully with `inputs/handoff.json` before prose was written.

The scientific text is approximately 597 words under an alphanumeric count with hyphenated words kept together: approximately 450 in the main prose and 147 in captions, excluding title, references, and embedded diagram text. This is a word-count approximation, not an evaluation score.

## Reproduce

From this output directory, run:

```bash
python build.py
```

The script runs the following command twice in its own directory, then uses PyMuPDF to render all PDF pages and record technical properties:

```bash
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
```

Observed tools: pdfTeX 3.141592653-2.6-1.40.25 (TeX Live 2023/Debian), LaTeX2e 2023-11-01, and PyMuPDF 1.26.6. The manuscript uses locally installed article, Latin Modern, geometry, graphicx, amsmath, caption, and hyperref packages. No network access, dependency installation, experiments, paid runtime, or model execution was used. Rebuilding changes PDF creation metadata and therefore may change its hash.

## Source and claim mapping

| Manuscript location | Source supplied in this task | Scope of support |
|---|---|---|
| Page 1, sequence conditioning; Figure 1 caption | `inputs/transformer/method.md`, source/target/decoder paragraphs; semantic-contract invariants; delivered diagram | Six encoder and six decoder layers; post-norm order; masked targets; Q from decoder, K/V from final encoder to every decoder layer; dimensions and output head |
| Page 1, residual refinement; Figure 2 caption | `inputs/resnet/method.md`, same-shape, convolution, and scope paragraphs; semantic-contract invariants; delivered diagram | Identity addition and post-addition ReLU; basic and bottleneck channels/kernels; BN after convolution; final BN directly preceding addition; same-resolution scope and depth families |
| Page 1, spatial feature fusion; Figure 3 caption | `inputs/unet/method.md`, contracting/expanding descriptions, dimension table, final crop paragraph; semantic-contract invariants; delivered diagram | Valid convolutions, four down/up stages, crop and concatenate semantics, exact crop dimensions and input/output sizes |
| Page 1, opening and final synthesis | Direct comparison of the three preceding supported mechanisms | Attention memory, same-shaped elementwise addition, and spatially aligned channel concatenation have different interfaces; no quantitative benefit or novelty claim |

Citation identities, titles, years, paper URLs, and section/figure locators were inherited from the frozen source-reader handoff. They were not independently retrieved. The cited source references are Vaswani et al., NIPS 2017, Fig. 1 and §§3.1–3.5; He et al., CVPR 2016, Figs. 2/5 and §§3.2–3.4/4.1; Ronneberger, Fischer, and Brox, MICCAI 2015, Fig. 1 and §2, arXiv v1. The ResNet code locator in the input was read as a supplied static-inspection report; code was neither fetched nor executed and is not presented as this author's independent validation.

## Author-side visual observations

The final PDF was rendered and all four complete pages were opened as images, not inferred from extracted text alone.

| Physical page | Viewed content and observations |
|---|---|
| 1 | Title, five comparison paragraphs, equations/dimensions, and three references are legible; citations and figure references resolve. No observed text collision or truncation. |
| 2 | Full Transformer plate and caption fit separately from the footer. Source/target streams, all residual additions before LayerNorm, Q and K/V entry routes, six-layer markers, and probability head are readable. |
| 3 | ResNet plate remains at its supplied 85 mm width. Both identity routes reach their own additions; final ReLU and the BN omission note remain legible. The surrounding white space is intentional to preserve the figure's physical width. Caption is complete. |
| 4 | U-Net plate and caption are complete. All four crop paths connect to the matching concat nodes; spatial and channel progressions remain legible. Input and output sizes and the final convolution are visible. |

The final compiler log contains no warning, overfull/underfull box, or undefined-reference diagnostic. The PDF contains four A4 pages and zero embedded raster images. Extracted minimum figure text sizes are 8.5004 pt, 8.0002 pt, and 8.0041 pt, respectively, compared with supplied minima 8.5 pt, 8.0 pt, and 8.0037 pt. Tiny positive differences are due to PDF/TeX coordinate precision. These observations document construction; they do not constitute independent acceptance or a quality grade.

## Workflow binding and limits

Before writing, the actor read the pinned research-write `SKILL.md`, `references/execution.md`, `references/workflow.md`, and `references/paper_delivery_contract.md` under `architecture-writing-eval/snapshot/plugins/research-assistant/skills/research-write/`. The task and START handoff explicitly scope this as a local section; the full-manuscript exemplar-learning phase does not apply. Existing local tools were selected under the explicit offline restriction. Workflow file hashes are in `workflow_hashes.json`.

The figure PDFs are supplied outputs; their upstream editable SVGs were not among this task's inputs. The manuscript source and layout are editable, while the figures remain the supplied, unmodified vector PDFs. No venue template was requested, so this is a generic article layout without a venue-compliance claim. No claims of training quality, performance, novelty, or experimental validation are made. No physical print or color-vision simulation was performed. Independent scientific review and independent full-page reader review remain with the controller. No construction blocker remains known to this author.

## Frozen output identity

The viewed final `paper.pdf` SHA-256 is `ab942daf96731fc448c317b9fada15c470539a88f9708133748dd7b355360988`.

The three unchanged figure PDF SHA-256 values are:

| File | SHA-256 |
|---|---|
| `figures/transformer.pdf` | `593a14181596328276eb274cebda481092cbf4d21862d66d1ffc30a8b4743bbe` |
| `figures/resnet.pdf` | `6231a0917a641c8de4e0ebbc6dc630fb381c3e62be0d5a2608a50fe6e07122ce` |
| `figures/unet.pdf` | `9e9f88e75198a3c084c73df0cbf5b26620e81a86c6c479e56b0f28d000678115` |

`artifact_hashes.json` records the delivered manuscript, every page image, figures, supporting notes, and build files after writing these notes. Files will remain unchanged after handoff for independent review.

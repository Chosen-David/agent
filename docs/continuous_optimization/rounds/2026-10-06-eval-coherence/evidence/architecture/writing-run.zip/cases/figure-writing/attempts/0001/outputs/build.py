"""Compile the editable section and render every physical PDF page locally."""
from pathlib import Path
import hashlib
import json
import subprocess
import fitz

ROOT = Path(__file__).resolve().parent
logs = []
for run in (1, 2):
    result = subprocess.run(
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "paper.tex"],
        cwd=ROOT, text=True, capture_output=True,
    )
    logs.append(f"Compilation {run}\n{result.stdout}\n{result.stderr}")
    (ROOT / "build.log").write_text("\n".join(logs))
    result.check_returncode()

pdf = fitz.open(ROOT / "paper.pdf")
report = {
    "page_count": len(pdf),
    "pdf_sha256": hashlib.sha256((ROOT / "paper.pdf").read_bytes()).hexdigest(),
    "render_dpi": 150,
    "pymupdf_version": fitz.VersionBind,
    "pages": [],
    "figures": [],
}
for index, page in enumerate(pdf, 1):
    page.get_pixmap(dpi=150, alpha=False).save(ROOT / f"page-{index}.png")
    report["pages"].append({
        "page": index,
        "raster_images": len(page.get_images()),
        "width_mm": page.rect.width * 25.4 / 72,
        "height_mm": page.rect.height * 25.4 / 72,
    })
for name, index, width in [("transformer", 1, 180), ("resnet", 2, 85), ("unet", 3, 180)]:
    source = fitz.open(ROOT / "figures" / f"{name}.pdf")
    source_spans = [s for b in source[0].get_text("dict")["blocks"] if "lines" in b
                    for l in b["lines"] for s in l["spans"]]
    embedded_spans = [s for b in pdf[index].get_text("dict")["blocks"] if "lines" in b
                      for l in b["lines"] for s in l["spans"] if "DejaVu" in s["font"]]
    xobjects = pdf[index].get_xobjects()
    report["figures"].append({
        "name": name,
        "declared_width_mm": width,
        "source_width_mm": source[0].rect.width * 25.4 / 72,
        "source_min_font_pt": min(s["size"] for s in source_spans),
        "embedded_min_font_pt": min(s["size"] for s in embedded_spans),
        "xobjects": [list(x[:3]) + [list(x[3])] for x in xobjects],
        "copied_pdf_sha256": hashlib.sha256((ROOT / "figures" / f"{name}.pdf").read_bytes()).hexdigest(),
    })
(ROOT / "build_checks.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))

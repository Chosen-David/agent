# Execution account: c12

Entered through the pinned local research-implement-optimize/SKILL.md, execution supplement, workflow sections 1/4/6 and experiment execution contract. Read gpu_adapter.py in full and experiment.py lines 1–100 (including digest and probe); the latter was imported as a dependency at runtime. loaded.json records SHA-256 hashes and read scopes before harness execution. Local frozen standard-library implementation was the offline fallback; no external discovery or installation.

Read task.txt and inputs/evidence.md for this case. The input directory contained only evidence.md, with no pairs.csv. Confirmed attempts/0001/start.json existed using ls and an existence assertion before creating outputs. No controller/generator/oracle/rubric files were read.

Actual execution command:

```sh
python -B /workspace/scratch/noise-holdout-v1/cases/c12/attempts/0001/outputs/harness.py > /workspace/scratch/noise-holdout-v1/cases/c12/attempts/0001/outputs/stdout.txt
```

The tool invocation then read stdout.txt with cat and returned shell status 0. Printed outcome and saved JSON were inspected. Actual trace contains 10 events and 1 evaluate calls. Harness SHA-256: 859c7ff7001dbf1d78b47f86b6fb82c11e00726bd5046d782e241e1eaa8ad27a.

The harness imports frozen gpu_adapter, replaces experiment.probe with a function that raises on any attempted real probe, and explicitly supplies a synthetic observe callback on every run. No nvidia-smi, GPU/model/sglang execution, network, installs or nested agents. `python -B` prevents snapshot bytecode writes. Cooperative lock files and all generated artifacts are inside this output directory. The mock UUIDs are labels only.

Artifacts: harness.py, stdout.txt, trace.json (actual callback/evaluate events), outcome.json, loaded.json, result.md, execution.md.

Limitations: deterministic CPU fixture only; mock full-admission receipts do not prove authorization, visibility, exclusivity or actual GPU behavior. No latency measurements, confidence intervals or scientific quality claims.

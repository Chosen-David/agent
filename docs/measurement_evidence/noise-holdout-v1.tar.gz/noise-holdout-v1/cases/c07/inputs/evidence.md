Claim: aggregate quality 70.12 to 70.16 proves improvement. Only these two rounded summaries remain; per-example outputs, scorer version and sampling/seed history unavailable.

import sys, json, time, hashlib, threading, traceback
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, "/workspace/scratch/noise-holdout-v1/snapshot/research-implement-optimize/scripts")
import gpu_adapter as g
OUT=Path(__file__).resolve().parent
CASE=OUT.parents[2].name
LOG=[]
LOCK=threading.Lock()
def log(event, **kw):
    with LOCK: LOG.append(dict(event=event, **kw))
def forbidden_probe(*a, **kw):
    raise AssertionError("Real hardware probing forbidden")
g.experiment.probe=forbidden_probe
PROTOCOL=hashlib.sha256(b"CPU MOCK id-square protocol v1").hexdigest()
DEVICES=["GPU-MOCK-A", "GPU-MOCK-B"]
def observe():
    obs={"mock":True,"observed_at":time.time(),"gpu":{"devices":{"status":"observed","csv":"uuid,name,driver_version,utilization.gpu [%],memory.used [MiB],memory.total [MiB]\n"+"".join(u+",MOCK,MOCK,0 %,0 MiB,1000 MiB\n" for u in DEVICES)},"processes":{"status":"observed","csv":"gpu_uuid,pid,used_gpu_memory [MiB]\n"}}}
    log("synthetic_observation", observation=obs)
    return obs
class Mock:
    def __init__(self,label,omit=False): self.label=label; self.omit=omit
    def authorize(self,r,uuids):
        log("mock_authorize",run=self.label,uuids=uuids); return True
    def capabilities(self):
        return dict(ready=True,modes=["accuracy"],id="CPU-MOCK-"+self.label,protocol_sha256=PROTOCOL,code_version="harness-v1",model_version="no model")
    def verify_admission(self,r,uuids):
        result=dict(allowed=True,source="MOCK full admission; no real resource claim",observed_at=time.time())
        log("mock_full_admission",run=self.label,receipt=result); return result
    def known_pids(self): return []
    def evaluate(self,uuid,ids,seeds,batch_size):
        log("evaluate",run=self.label,uuid=uuid,ids=ids,seeds=seeds,batch_size=batch_size)
        if not self.omit and batch_size>2:
            log("BatchOOM",run=self.label,uuid=uuid,batch_size=batch_size)
            raise g.BatchOOM("Synthetic batch exceeds 2")
        rows=[dict(id=i,prediction=dict(value=int(i)**2,seed=s)) for i,s in zip(ids,seeds)]
        if self.omit: rows=rows[:-1]
        log("returned_rows",run=self.label,rows=rows)
        return rows
def req(devices,batch):
    return dict(mode="accuracy",authorized_devices=devices,sample_ids=[str(i) for i in range(9)],seed=19,batch_size=batch,min_free_mib=1,max_utilization=0,protocol_sha256=PROTOCOL,warmup=1,repeats=2)
# Predeclared finite contract: exact ordered unique IDs, square predictions,
# stable per-ID seeds across configurations; incomplete batch must raise.
summary={"case":CASE,"execution":"CPU mock only","gpu":"notrun","model":"notrun"}
try:
    if CASE=="c11":
        a=g.run(req(DEVICES,4),Mock("two-device-batch4"),OUT/"lease-a",observe=observe)
        b=g.run(req(DEVICES[:1],1),Mock("one-device-batch1"),OUT/"lease-b",observe=observe)
        (OUT/"receipt-a.json").write_text(json.dumps(a,indent=2))
        (OUT/"receipt-b.json").write_text(json.dumps(b,indent=2))
        ids=[str(i) for i in range(9)]
        checks={"ordered_unique_coverage": [x["id"] for x in a["output"]["rows"]]==ids and len(set(x["id"] for x in a["output"]["rows"]))==9,
        "reference_squares":all(x["prediction"]["value"]==int(x["id"])**2 for x in a["output"]["rows"]),
        "per_id_seeds_equal":{x["id"]:x["prediction"]["seed"] for x in a["output"]["rows"]}=={x["id"]:x["prediction"]["seed"] for x in b["output"]["rows"]},
        "all_outputs_equal":a["output"]==b["output"],"fallback_observed":len(a["events"])==2}
        summary.update(statuses=[a["status"],b["status"]],checks=checks,oom_events=a["events"],rows=a["output"]["rows"])
        assert all(checks.values()),checks
    else:
        try:
            receipt=g.run(req(DEVICES[:1],4),Mock("omitting-runner",omit=True),OUT/"lease",observe=observe)
        except Exception as exc:
            summary.update(adapter_returned=False,status="raised",error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc())
            assert isinstance(exc,ValueError) and str(exc)=="runner output ID/order/coverage mismatch"
        else:
            summary.update(adapter_returned=True,receipt=receipt)
            raise AssertionError("Incomplete output was unexpectedly accepted")
finally:
    (OUT/"trace.json").write_text(json.dumps(LOG,indent=2))
    (OUT/"outcome.json").write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))

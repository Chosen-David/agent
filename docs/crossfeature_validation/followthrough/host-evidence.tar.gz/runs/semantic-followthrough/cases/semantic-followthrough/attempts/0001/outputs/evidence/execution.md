# Execution account

Start gate: confirmed attempts/0001/start.json existed before any output creation. loaded.json was saved before validator execution. All inputs and snapshot files remained read-only. Snapshot source hashes identify this exact code; no repository commit identity is claimed. The host controller, not this worker, records actual dispatch receipts.

Read commands used cat/sed for the exact pinned SKILL.md, orchestrator.md, execution supplement, paper_delivery_contract.md, review and code-reading fallbacks, snapshot AGENTS.md and decision_review.md, plus the three validation source files. rg located code anchors. Every supplied input was read and later hash-checked. The long reviewer workflow output had a truncated middle; only visible relevant sections are claimed as read. No source evaluation rubric or other run was accessed.

## Actual handoff commands

```sh
python -B /workspace/agent/.agent-runs/semantic-followthrough/host/snapshot/scripts/validate_handoff.py /workspace/agent/.agent-runs/semantic-followthrough/host/cases/semantic-followthrough/inputs/handoff-x.json --root /workspace/agent/.agent-runs/semantic-followthrough/host/cases/semantic-followthrough/inputs --expected-input-version shape6:r9
```

Observed exit 0 at 2026-10-03T09:18:16.428908+00:00. stdout:

```json
{
  "integrity_valid": true,
  "errors": [],
  "completion_verified": false,
  "consumer_version_checked": true,
  "scope": "local integrity and explicit consumer version only; no semantic or visual certification"
}
```

stderr was empty.

```sh
python -B /workspace/agent/.agent-runs/semantic-followthrough/host/snapshot/scripts/validate_handoff.py /workspace/agent/.agent-runs/semantic-followthrough/host/cases/semantic-followthrough/inputs/handoff-x.json --root /workspace/agent/.agent-runs/semantic-followthrough/host/cases/semantic-followthrough/inputs --expected-input-version shape6:r9 --require-complete
```

Observed exit 0 at 2026-10-03T09:18:16.455169+00:00. stdout:

```json
{
  "integrity_valid": true,
  "errors": [],
  "completion_verified": true,
  "consumer_version_checked": true,
  "scope": "local integrity and explicit consumer version only; no semantic or visual certification"
}
```

stderr was empty.

```sh
python -B /workspace/agent/.agent-runs/semantic-followthrough/host/snapshot/scripts/validate_handoff.py /workspace/agent/.agent-runs/semantic-followthrough/host/cases/semantic-followthrough/inputs/handoff-y.json --root /workspace/agent/.agent-runs/semantic-followthrough/host/cases/semantic-followthrough/inputs --expected-input-version shape6:r10
```

Observed exit 1 at 2026-10-03T09:18:16.480692+00:00. stdout:

```json
{
  "integrity_valid": false,
  "errors": [
    "consumer input version mismatch"
  ],
  "completion_verified": false,
  "consumer_version_checked": true,
  "scope": "local integrity and explicit consumer version only; no semantic or visual certification"
}
```

stderr was empty.

```sh
python -B /workspace/agent/.agent-runs/semantic-followthrough/host/snapshot/scripts/validate_handoff.py /workspace/agent/.agent-runs/semantic-followthrough/host/cases/semantic-followthrough/inputs/handoff-y.json --root /workspace/agent/.agent-runs/semantic-followthrough/host/cases/semantic-followthrough/inputs --expected-input-version shape6:r10 --require-complete
```

Observed exit 1 at 2026-10-03T09:18:16.507637+00:00. stdout:

```json
{
  "integrity_valid": false,
  "errors": [
    "consumer input version mismatch"
  ],
  "completion_verified": false,
  "consumer_version_checked": true,
  "scope": "local integrity and explicit consumer version only; no semantic or visual certification"
}
```

stderr was empty.

## Additional direct byte check

A real local `python -B` check read every input using pathlib.Path.read_bytes, computed hashlib.sha256 and byte lengths, compared material-n.md bytes directly with source-note.md, parsed values.json, summed its group counts and expanded each (symbol,count). It observed exact source reuse, group count=3, sum=6, element_count=6, and reconstructed [2,2,5,5,5,9]. Full values are in byte-checks.json. This arithmetic is an inspection of supplied data, not a general implementation test or performance benchmark.

## Scope and limitations

Four pinned CLI subprocesses actually ran; commands.json records exact argv, timestamps, exit codes, stdout and stderr. Paper/semantic acceptance conclusions are static source inspection; no unsupplied paper record or forged acceptance/event was generated. There were no PDFs/images to render. No drafting, network, nested agents, installs, input mutation or external runtime execution occurred. The requested assessment is finished; consumer Y version mismatch and absent trusted completion evidence remain as documented conditions.

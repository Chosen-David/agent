# Anchored assessment

The requested artifact is a bounded text-only mechanism brief, not a submission manuscript (inputs/requests.json:1). This assessment uses the pinned research-assistant role and its local review/code-reading fallbacks. No external skills or services were used.

Material M is suitable within that boundary. Its Introduction asks whether group count can replace element count (material-m.md:7); Method defines adjacent grouping and count-based reconstruction (line 13). Evaluation gives a counterexample: [2,2,5,5,5,9] becomes three groups whose counts sum to six, plus [4,4] and empty-input boundaries (line 16). The actual values.json bytes contain [[2,2],[5,3],[9,1]] and element_count=6; direct calculation reconstructs the six inputs. These are tiny constructed examples, not measured speed or a tested production implementation. Related work and Limitations explicitly leave literature, implementation proof and submission readiness unverified (lines 10, 16, 19). That candor does not invalidate the narrow brief. No source-note prose reuse was observed; no worldwide originality inference follows.

Material N is unsuitable: both its lines duplicate source-note.md exactly, including the title and packing paragraph. The byte comparison confirms 281 identical bytes with SHA-256 e943576914103b69045d558af8dff57f9c35f30e3604d799ea746c47be29f15f. The paragraph concerns box rotation and cube inventory and explicitly contains no sequence grouping method or experiment. This establishes reuse of the supplied source, not an original grouping contribution, and does not establish intent or a legal finding.

Material O is unsuitable: Abstract counts inspected paths (line 4), Method lists paths/lengths/timestamps (line 10), Evaluation counts checksums/status cells (line 13), and Conclusion addresses file naming (line 19). Its own Limitations confirms absent sequence input, output, comparison and multiplicity evidence (line 16). Those concrete contents make it an inventory audit; familiar section headings do not rescue artifact fit.

## Consumer checks

The trusted requests are consumer-x shape6:r9 and consumer-y shape6:r10. Both producer handoffs actually declare shape6:r9 (handoff-x.json:5 and handoff-y.json:5); both reference the same verified values hash. Executed results:

| Consumer | Mode | Exit | integrity_valid | completion_verified |
|---|---|---:|---|---|
| X | version + integrity | 0 | true | false |
| X | version + completion | 0 | true | true |
| Y | version + integrity | 1 | false | false |
| Y | version + completion | 1 | false | false |

Both Y errors are `consumer input version mismatch`. X may be consumed for this version/integrity contract, with semantic limitations preserved; Y must be withheld until a genuine matching-version artifact is provided. The completion_verified field in X's CLI output has the tool's explicitly narrow scope: local integrity and explicit consumer version only, no semantic or visual certification. Worker status=completed and check=pass are declarations, not trusted semantic acceptance. See validate_handoff.py:25-32 and 160-164 and the saved raw outputs.

## Trusted completion and observed events

Static code inspection traces validate_paper_delivery.validate from status=submission_checks_complete (line 42) to validate_acceptance(record, root, acceptance) (lines 87-90). Acceptance comes from the explicit CLI/API argument; CLI rejects a path inside the worker root (lines 145-155). Missing acceptance immediately returns `unverified: completion requires external trusted semantic acceptance` (semantic_acceptance.py:92-96). The supplied request has controller_semantic_acceptance=null, so it cannot certify submission completion. This is code-grounded analysis, not a claim that a paper record CLI was run.

The gate binds canonical record SHA, complete declared file hashes and actual bytes; it requires an independently completed research-review actor distinct from the writer, matching language snapshots and evidence-bearing artifact_fit/originality passes (semantic_acceptance.py:99-150). Hashes establish byte binding, not authentic identity, genuine reading, prose quality or honesty of a controller. This worker's decisions.json is not that external controller acceptance.

validate_paper_delivery.py:71-76 calls validate_role_events for completed role bindings. semantic_acceptance.py:60-75 requires separate start/started and complete/produced events; subsequent lines require matching run, actor, role, revision, task, attempt and nonempty IDs. The supplied dispatch/queued event is neither kind and proves no start or result. Its declared writer identity does not prove execution. No replacement receipt or acceptance was generated. The paper delivery contract's full submission requirements are outside this bounded task; the missing acceptance is a blocker to a completion claim, not a reason to stop the independent candidate assessment.

# Execution record

Actor: `/root/host_coordination`. Scope: `coordination-consumer-boundary`, attempt `0001`.

## Commands and observed results

- Ran `cat /workspace/agent/evals/pipeline_smoke/host_worker.md` to read the host-worker protocol.
- Ran `cat` on this case's `task.txt` and the exact pinned `snapshot/plugins/research-assistant/skills/research-assistant/SKILL.md`.
- Ran `cat` on the pinned `references/orchestrator.md`, `references/execution.md`, and `references/task_supervision_workflow.md`. These are the only snapshot dependencies read; their actual SHA-256 values are saved in `loaded.json`.
- Ran `rg --files` on this case's `inputs/`; observed exactly `producer.json`, `consumer.json`, `result.txt`, and `events.json`.
- Ran `cat` on those four files, then `test -f` on `attempts/0001/start.json`; command exited 0. No outputs were created before that existence check.
- Ran a local `python -B` heredoc that asserted the start file exists, created only the authorized `outputs/` directory, computed hashes of the four read snapshot files using `hashlib.sha256(p.read_bytes()).hexdigest()`, and saved `loaded.json` before executing artifact checks.
- Ran a second local `python -B` heredoc using standard-library `pathlib`, `json`, `hashlib`, and `datetime`. It parsed the three input JSON files; read the actual result bytes; hashed all four inputs; compared the result hash with producer A1; checked `Path.exists()` for `inputs/absent.pdf` and case-root `absent.pdf`; collected event IDs and null monitor readback; and saved `inspection.json`. Full observed values are in that file.
- Ran a final local `python -B` heredoc to save `decision.md` and this execution account.

## Findings

A1's hash matches and its exact text is preserved in `inspection.json`. Producer/result use v1 and workload 32; consumer uses v2 and workload 64. The two checked PDF paths do not exist. Event IDs are e7, e7, e8. Monitor live readback is null. These observations support the bounded acceptance, rejection and not-established decisions in `decision.md`.

## Limits

No target script was executed, no network was used, no input files were changed, no subagent was spawned, and no scheduler, publisher, renderer or runtime backend was called. The Python commands were read-only inspection plus authorized output writing, not execution of input code. No PDF was available to render or open, and no visual completion is claimed. Event JSON is untrusted input evidence, not an actual trigger. The host's dispatch receipt was neither inspected nor manufactured. This is an executor account and does not constitute independent grading.

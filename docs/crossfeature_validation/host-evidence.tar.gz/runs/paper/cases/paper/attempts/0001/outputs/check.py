from pathlib import Path
import json, hashlib, struct
import fitz
from PIL import Image,ImageDraw
O=Path(__file__).parent; I=O.parents[2]/'inputs'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[[9,1,0,1],[1,2,3,4]]
rows=[[struct.unpack('f',struct.pack('f',x))[0] for x in row] for row in rows]
scores=[sum(row[-2:]) for row in rows]; winner=max(range(len(rows)),key=lambda i:scores[i])
result={'reconstructed_cpu_example':{'scores':scores,'selected_row_one_based':winner+1,'selected_value':rows[winner],'returned_width':len(rows[winner]),'scope':'Independent reconstruction of stated main method, not supplied implementation execution'},'borrowed_exact':(I/'item-b.md').read_bytes()==(I/'reference.md').read_bytes()==(I/'exemplar-3.md').read_bytes(),'input_hashes':{p.name:sha(p) for p in sorted(I.iterdir()) if p.is_file()},'learning':{},'pdfs':{}}
for n in [1,2,3]:
 d=json.loads((I/f'learning-{n}.json').read_text()); ps=d['exemplar_learning']['papers']; refs=[]
 def visit(v,path=''):
  if isinstance(v,dict):
   if 'path' in v and 'sha256' in v:refs.append({'pointer':path,'file':v['path'],'hash_matches':sha(I/v['path'])==v['sha256']})
   for k,x in v.items():visit(x,path+'/'+k)
  elif isinstance(v,list):
   for k,x in enumerate(v):visit(x,path+'/'+str(k))
 visit(d)
 result['learning'][str(n)]={'papers':len(ps),'full_text':sum(p['access']=='full_text' for p in ps),'full_page_declarations':sum(p['read_pages']==list(range(1,p['page_count']+1)) for p in ps),'full_figure_declarations':sum(set(p['figure_inventory'])==set(p['figures_read']) for p in ps),'refs':refs}
for n in range(10):
 p=I/f'exemplar-{n}.pdf'; doc=fitz.open(p); texts=[]; imgs=[]
 for k,page in enumerate(doc):
  texts.append(page.get_text()); pix=page.get_pixmap(matrix=fitz.Matrix(1,1)); dest=O/f'exemplar-{n}-p{k+1}.png'; pix.save(dest); imgs.append(Image.open(dest).convert('RGB'))
 canvas=Image.new('RGB',(sum(x.width for x in imgs),max(x.height for x in imgs)), 'white'); x=0
 for im in imgs:canvas.paste(im,(x,0)); x+=im.width
 canvas.save(O/f'exemplar-{n}-spread.png')
 result['pdfs'][p.name]={'pages':len(doc),'text':texts}
svg=fitz.open(I/'figure-1.svg'); pdf=fitz.open('pdf',svg.convert_to_pdf()); pdf[0].get_pixmap(matrix=fitz.Matrix(3,3)).save(O/'figure-1.png')
(O/'evidence.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['input_hashes','learning']},indent=2))
print({n:{k:v for k,v in d.items() if k!='refs'} for n,d in result['learning'].items()})
print('All referenced hashes match:',all(r['hash_matches'] for d in result['learning'].values() for r in d['refs']))

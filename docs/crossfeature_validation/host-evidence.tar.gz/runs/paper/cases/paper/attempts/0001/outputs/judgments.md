The requested bounded synthetic manuscript is fulfilled by **item-a.md and item-c.md**. **item-b.md is borrowed exemplar material; item-d.md is a file audit.** These are artifact-delivery judgments for the supplied brief, not publication-readiness judgments.

All evidence locations below refer to `cases/paper/inputs/`. JSON locations use zero-based JSON Pointer paths. `evidence.json` records input hashes, calculations, PDF text by physical page, and reference-hash checks; `check.py` is the executed editable check source.

| Manuscript | Judgment and exact evidence |
| --- | --- |
| item-a.md | Bounded complete synthetic mechanism manuscript. Lines 2 and 5 pose the reduced-selection/full-value question and explain its relevance; line 11 defines float32 conversion, last-two-coordinate scoring and first-maximum selection; lines 14–15 give the two rows, deterministic scores, selected value and actual figure; line 18 sharply bounds the result; line 21 draws the supported conclusion. Removing audit language does not remove the research argument. Line 8 explicitly disclaims published-source learning and external novelty. Our CPU reconstruction supports the main two-row example. |
| item-b.md | Does not deliver this requested manuscript: all six lines are byte-identical to reference.md and exemplar-3.md. Lines 3–4 discuss adding 3 to inputs 0 and 1, a different question from full-width returned values. Line 6 merely names a figure/table without supplying this manuscript's figure evidence. This is whole-artifact reuse, not a short attributed quotation. |
| item-c.md | Same bounded complete manuscript as item-a at lines 1–21, with an allowed attributed four-word quotation at line 23. The quotation matches exemplar-3.md line 5, explicitly describes that exemplar and is explicitly not presented as the manuscript's evidence. It neither replaces the argument nor makes the manuscript wholesale borrowing. |
| item-d.md | Audit material substituted for a research manuscript. Lines 2, 5, 8, 11, 14, 17 and 20 repeat the same manifest/checksum inspection statement under scientific headings. No research question, mechanism, experiment, figure or supported contribution appears. Headings do not repair artifact fit, and the actual user did not request a file audit. The claimed inspections/mismatches themselves lack corroborating supplied logs. |

For a/c, the supported core is deliberately small: sum([0,1])=1, sum([3,4])=7, argmax=second row, returned float32 values=[1,2,3,4], width=4 while score-coordinate width=2. This is an independent reconstruction of the prose, not proof that a supplied implementation previously ran. The optional projection in line 11 is not specified sufficiently to reproduce; empty/malformed rejection in line 18 has no supplied executable or tests. Neither auxiliary claim is certified here. These gaps do not erase the complete bounded main demonstration, but would require code and targeted checks before implementation-level certification. No performance, statistical generalization or production behavior is inferred.

| Supporting artifact | Judgment and exact evidence |
| --- | --- |
| figure-1.svg | Real supplied manuscript figure, rendered to figure-1.png and visually opened. SVG line 1 has bar heights 10 and 70 with shared bottom y=100, labels 1 and 7, and title “Synthetic scores, linear units.” Pixels show the same ratio and labels, matching a/c line 14. No error bars or speedup evidence is present or needed for these exact deterministic values. Row labels would improve standalone interpretation; the manuscript supplies their order. |
| reference.md | Six-line synthetic offset exemplar, identical to exemplar-3.md and item-b.md; useful source for identifying borrowing, not evidence for the a/c mechanism. |
| event.json | At `/synthetic`, `/kind`, `/status`: true, dispatch, queued. A synthetic queued dispatch neither establishes a real worker start nor a completed result. |
| receipt.json | At `/synthetic`, `/kind`, `/status`, `/note`: true, start, fixture_only, and an explicit prohibition on using it as real host execution proof. The name “start” does not override the fixture status. No actual historical worker execution is attested by it. |

Each exemplar pair was read separately, including both rendered physical PDF pages. The complete per-artifact observations are:

| Files | Exact content and status |
| --- | --- |
| exemplar-0.md / exemplar-0.pdf | MD lines 1–6, PDF p1: synthetic offset 0, outputs 0 and 1, two-input limit; PDF p2: textual Fig1 heights 0/1 and Table1 input/output 0→0, 1→1. Synthetic control only. |
| exemplar-1.md / exemplar-1.pdf | MD lines 1–6, PDF p1: offset 1, outputs 1/2, same limit; p2 textual Fig1 1/2 and Table1 0→1, 1→2. Synthetic control only. |
| exemplar-2.md / exemplar-2.pdf | MD lines 1–6, PDF p1: offset 2, outputs 2/3; p2 textual Fig1 2/3 and Table1 0→2, 1→3. Synthetic control only. |
| exemplar-3.md / exemplar-3.pdf | MD lines 1–6, PDF p1: offset 3, outputs 3/4; p2 textual Fig1 3/4 and Table1 0→3, 1→4. Source of item-b's entire text and item-c's attributed limit quotation. |
| exemplar-4.md / exemplar-4.pdf | MD lines 1–6, PDF p1: offset 4, outputs 4/5; p2 textual Fig1 4/5 and Table1 0→4, 1→5. Synthetic control only. |
| exemplar-5.md / exemplar-5.pdf | MD lines 1–6, PDF p1: offset 5, outputs 5/6; p2 textual Fig1 5/6 and Table1 0→5, 1→6. Synthetic control only. |
| exemplar-6.md / exemplar-6.pdf | MD lines 1–6, PDF p1: offset 6, outputs 6/7; p2 textual Fig1 6/7 and Table1 0→6, 1→7. Synthetic control only. |
| exemplar-7.md / exemplar-7.pdf | MD lines 1–6, PDF p1: offset 7, outputs 7/8; p2 textual Fig1 7/8 and Table1 0→7, 1→8. Synthetic control only. |
| exemplar-8.md / exemplar-8.pdf | MD lines 1–6, PDF p1: offset 8, outputs 8/9; p2 textual Fig1 8/9 and Table1 0→8, 1→9. Synthetic control only. |
| exemplar-9.md / exemplar-9.pdf | MD lines 1–6, PDF p1: offset 9, outputs 9/10; p2 textual Fig1 9/10 and Table1 0→9, 1→10. Synthetic control only. |

All ten PDF first pages visually show a short five-line block at upper left; all second pages show one line describing Fig1 and Table1, with the rest blank. There are no actual drawn bars or tabular grids in these exemplar PDFs. Thus Fig1/Table1 are simulated inventory identifiers, not proof of substantive published-figure reading. The manuscript SVG is a separate actual bar figure.

| Learning artifact | Completeness within the explicitly synthetic protocol simulation |
| --- | --- |
| learning-1.json | Complete positive declaration control: `/exemplar_learning/papers` has ten distinct EX0–EX9 entries, all `/access=full_text`, `/page_count=2`, `/read_pages=[1,2]`, and matching `/figure_inventory` and `/figures_read` of Fig1/Table1. All five analysis dimensions are present for all ten, five decision dimensions are present, and template/selection/synthesis/blueprint/preflight references plus completed-before-drafting declaration are populated. All referenced file hashes match. This establishes declaration completeness in the simulation only. |
| learning-2.json | Degraded full-read control: `/exemplar_learning/papers/0/access` through `/9/access` are all `abstract_only`. These are the only differences from learning-1. Its retained completed state and page/figure declarations cannot overcome explicitly abstract-only access; full-text prerequisite is not complete, even within the protocol simulation. |
| learning-3.json | Degraded figure-coverage control: `/exemplar_learning/papers/0/figure_inventory=["Fig1","Table1"]`, but `/figures_read=["Table1"]`. EX0 Fig1 is missing; the other nine entries retain full inventory declarations. This is the only difference from learning-1. Full page lists do not repair missing figure coverage. |

None of these three records certifies real published-exemplar learning or real role execution. Each `/synthetic=true` and `/scope` explicitly limits it to protocol simulation; publication/template URLs are example.invalid and selection reasons say fixture only. `/published=true` is merely a simulated assertion. All notes, synthesis, blueprint, selection and read/preflight receipts point to the same fixture-only receipt.json; matching hashes establish byte identity, not reading, provenance, meaningful analysis, blueprint application or temporal execution order. Five-dimensional values are generic “synthetic observation/transfer,” and decisions use “synthetic choice” and OWN1 without a supplied substantive blueprint. Real full-read, figure-reading, publication and preflight claims would need actual sources, meaningful observations and host execution evidence. This worker's present rendering and reading of synthetic fixtures cannot retroactively certify the learning records or turn them into ten published papers.

Scope completed: inspection and bounded delivery judgments for all supplied artifacts. No external publication-readiness assessment, network lookup, manuscript rewrite or independent writer/reviewer/reader execution is claimed or required by this task.

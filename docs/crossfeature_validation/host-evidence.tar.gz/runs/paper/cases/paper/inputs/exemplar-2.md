Synthetic exemplar 2.
Abstract: compare deterministic offsets.
Method: add 2 to inputs zero and one.
Results: outputs 2 and 3.
Limitations: two constructed inputs only.
Figure 1: two bars. Table 1: the two exact outputs.

Synthetic exemplar 3.
Abstract: compare deterministic offsets.
Method: add 3 to inputs zero and one.
Results: outputs 3 and 4.
Limitations: two constructed inputs only.
Figure 1: two bars. Table 1: the two exact outputs.

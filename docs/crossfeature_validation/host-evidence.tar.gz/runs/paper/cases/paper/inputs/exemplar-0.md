Synthetic exemplar 0.
Abstract: compare deterministic offsets.
Method: add 0 to inputs zero and one.
Results: outputs 0 and 1.
Limitations: two constructed inputs only.
Figure 1: two bars. Table 1: the two exact outputs.

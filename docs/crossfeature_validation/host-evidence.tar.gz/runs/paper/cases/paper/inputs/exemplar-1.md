Synthetic exemplar 1.
Abstract: compare deterministic offsets.
Method: add 1 to inputs zero and one.
Results: outputs 1 and 2.
Limitations: two constructed inputs only.
Figure 1: two bars. Table 1: the two exact outputs.

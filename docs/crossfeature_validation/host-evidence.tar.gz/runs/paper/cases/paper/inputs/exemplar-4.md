Synthetic exemplar 4.
Abstract: compare deterministic offsets.
Method: add 4 to inputs zero and one.
Results: outputs 4 and 5.
Limitations: two constructed inputs only.
Figure 1: two bars. Table 1: the two exact outputs.

# Architecture reconciliation

CODE-READ architecture-0001. Read-only scope: supplied inputs README.md, core.py, cases.json and pinned code-reading skill with workflow, execution and coverage references. No local AGENTS.md or .agents/skills exists in inputs. A target Git commit is not supplied in these input files; exact source hashes are recorded below. All anchors refer to inputs/. No other cases, evaluation answers, network or nested agents were accessed.

## README versus source (source facts)

- README.md:1–2 claims projection is default. Contradicted by `run(mode='default')` at core.py:26 and `select(... projected=mode == 'projected')` at core.py:28–29. `select` independently defaults its flag to False at core.py:11.
- README.md:2 claims final width 2. Only built-in selection uses width 2 (core.py:13–15). Final consumption reads the full encoded selected row via `list(values[position])` (core.py:21–23,34), width 4.
- README.md:2 claims float64 output. Encoding stores array('f') values (core.py:8), measured as four-byte storage on this platform. Consumption boxes these already rounded values into a Python list of Python floats (core.py:23). This is not a float64 tensor/array, and boxing cannot recover encoding precision. The returned dtype 'f' describes encoded storage (core.py:36), not a dtype attached to the output list.
- README.md:2–3 claims a built-in accelerator for unknown modes. Contradicted: unknown modes call a supplied non-None extension (core.py:30–31) or raise LookupError (core.py:32–33). Complete supplied core.py:1–36 contains no accelerator implementation.

## Closed call/data paths (static reasoning)

1. `run` → `encode` (core.py:26–27) validates nonempty rows with width 4 (core.py:5–7), then converts each row to array('f') (core.py:8). Shape is [T,4], T>0. Numeric conversion precedes selection. Bad input fails before mode dispatch. No CLI/environment/file override or persistent state exists in this complete supplied module; run arguments provide overrides.
2. Default run → select(projected=False) at core.py:28–29. Slicing row[2:] and converting to list makes [T,2] Python-float coordinates x2,x3 (core.py:13). Summation yields T scores, then max over range(T) returns an input-row index (core.py:16–18). For ordinary finite values, scoring is x2+x3. Equal maximal scores select the first encountered index. Scores use Python arithmetic on previously float32-converted values, not a float32 array accumulator.
3. Explicit mode='projected' activates the branch (core.py:29). It first builds the default reduced list and then replaces it with [x0+x2,x1-x3] (core.py:13–15). This is a fixed linear transformation of encoded values; neither learned nor query-dependent. Reduced shape remains [T,2]; score is the sum of the two components (core.py:16). Full stored values remain [T,4].
4. Both built-in paths return (position,reduced) to run (core.py:18,29), which calls consume(values,position) (core.py:34). Consume reads the selected original encoded row (core.py:21–23), producing a width-4 list. It neither emits reduced coordinates nor performs full-dimensional rescoring. Full refers to row width, not all T rows. Reduced is also consumed to build reduced_shape (core.py:35); values supply full_shape and storage dtype (core.py:36).
5. Unknown mode with extension → extension(values) (core.py:30–31) → shared consumer and metadata (core.py:34–36). The call site is resolved, but the callable implementation, selection rule, reduced representation and any mutation are unresolved. The implicit callback contract requires two unpackable results, a usable row index, and a nonempty indexable reduced structure. There is no explicit validation. The callback receives the same values object later consumed, so arbitrary mutating callbacks can defeat built-in shape/type guarantees. Recognized modes ignore any supplied extension because the built-in branch wins (core.py:28–31).
6. Unknown mode without extension raises after encoding and before final consumption (core.py:27–33). Empty or wrong-width input raises at encode (core.py:6–7). Built-in valid nonempty inputs avoid empty max/reduced[0]. Other input types, overflow, NaNs, and custom callbacks are outside executed coverage.

These edges are supported by call sites and function bodies, not an instrumented trace or graph backend. No additional dynamic dispatch exists in supplied code beyond the extension.

## Actual CPU observations

All seven entries in cases.json were executed unchanged, including both supplied groups, using python -B. Each input was passed to core.run with only its id removed. Errors were captured per case; the overall harness exited 0.

| Case | Observed result |
| --- | --- |
| development/default | output [1.0,2.0,3.0,4.0], selected 1; reduced_shape [2,2], full_shape [2,4], dtype f |
| development/optional | output [9.0,1.0,0.0,1.0], selected 0; reduced_shape [2,2], full_shape [2,4], dtype f |
| development/unknown_extension | LookupError: unknown mode needs caller extension |
| development/wrong_width | ValueError: expected nonempty [T,4] values |
| development/empty | ValueError: expected nonempty [T,4] values |
| holdout/holdout_reordered | output [1.0,2.0,3.0,4.0], selected 0; reduced_shape [2,2], full_shape [2,4], dtype f |
| holdout/holdout_float_boundary | output [16777216.0,1.0,0.0,0.0], selected 0; reduced_shape [2,2], full_shape [2,4], dtype f |

Static explanation, distinct from observed outputs: default scores for the first case are [1,7]. Projected coordinates for the optional case are [[9,0],[4,-2]], with scores [9,2]. Reordering changes the selected index but preserves selected values. The boundary case has two zero default scores, choosing row 0; observed 16777217→16777216.0 shows rounding before consumption. Neither reduced coordinates nor scores were instrumented during execution.

Four cases returned; three raised the recorded exceptions. No supplied case calls a non-None extension, so that route is statically inspected only. No GPU, performance or general integration conclusion follows. This report has a source-anchor self-check, not an independent review.

## Input SHA-256

- README.md: `699ce8eb77aefebcb1dc99c23921abf643a3430b8da86970512dee1931d02cf3`
- cases.json: `ad496cd868d535d6c38644d59feba9f648f009eb3b6679f9b77ee82c0af3b661`
- core.py: `f5a31e39bec949c0d8400554c0d4c8e199e2904e83c6e3c652b63d01e0666d46`

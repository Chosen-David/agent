# Execution evidence

The start.json file existed before output creation. Read the host worker protocol and task, then pinned SKILL.md, references/workflow.md, references/execution.md and references/coverage.md. loaded.json recorded their actual paths and SHA-256 hashes before target execution. Input files were enumerated with rg --files, then read with line numbers. All Python commands used -B; inputs were not modified.

Actual CPU command structure: `python -B - <<'PY'` loaded inputs/core.py with importlib.util.spec_from_file_location('architecture_case_core',p), module_from_spec, and spec.loader.exec_module(core). It loaded cases.json, iterated every group and case, removed only id from kwargs, and called `core.run(**kwargs)` once per case. Each Exception was captured as its type name and message; each returned dictionary was stored verbatim. It printed each record as JSON and saved records with Python/platform identity, source SHA-256 hashes and core.array('f').itemsize to results.json. Exit code was 0. These were actual executions, not predicted outputs.

Observed stdout records:

```jsonl
{"group": "development", "id": "default", "input": {"rows": [[9, 1, 0, 1], [1, 2, 3, 4]]}, "status": "returned", "result": {"output": [1.0, 2.0, 3.0, 4.0], "selected": 1, "reduced_shape": [2, 2], "full_shape": [2, 4], "dtype": "f"}}
{"group": "development", "id": "optional", "input": {"rows": [[9, 1, 0, 1], [1, 2, 3, 4]], "mode": "projected"}, "status": "returned", "result": {"output": [9.0, 1.0, 0.0, 1.0], "selected": 0, "reduced_shape": [2, 2], "full_shape": [2, 4], "dtype": "f"}}
{"group": "development", "id": "unknown_extension", "input": {"rows": [[1, 2, 3, 4]], "mode": "accelerator"}, "status": "raised", "error_type": "LookupError", "error": "unknown mode needs caller extension"}
{"group": "development", "id": "wrong_width", "input": {"rows": [[1, 2, 3]]}, "status": "raised", "error_type": "ValueError", "error": "expected nonempty [T,4] values"}
{"group": "development", "id": "empty", "input": {"rows": []}, "status": "raised", "error_type": "ValueError", "error": "expected nonempty [T,4] values"}
{"group": "holdout", "id": "holdout_reordered", "input": {"rows": [[1, 2, 3, 4], [9, 1, 0, 1]]}, "status": "returned", "result": {"output": [1.0, 2.0, 3.0, 4.0], "selected": 0, "reduced_shape": [2, 2], "full_shape": [2, 4], "dtype": "f"}}
{"group": "holdout", "id": "holdout_float_boundary", "input": {"rows": [[16777217, 1, 0, 0], [3, 4, 0, 0]]}, "status": "returned", "result": {"output": [16777216.0, 1.0, 0.0, 0.0], "selected": 0, "reduced_shape": [2, 2], "full_shape": [2, 4], "dtype": "f"}}
```

Python: 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]

Platform: Linux-6.18.44-x86_64-with-glibc2.41

float array itemsize: 4 bytes.

An initial report-writing command failed with a Python SyntaxError because its shell heredoc delimiter also appeared in the embedded command text. That invocation did not execute its Python body or alter inputs/results. The report-writing command was corrected with a unique delimiter and completed. No additional target runs were needed.

Limitations: no extension callable was supplied/executed; no target Git commit was present in the supplied input files; no GPU, network, external runtime installation or benchmark was attempted. No visual rendering was relevant. loaded.json, results.json, analysis.md and execution.md are the delivered artifacts.

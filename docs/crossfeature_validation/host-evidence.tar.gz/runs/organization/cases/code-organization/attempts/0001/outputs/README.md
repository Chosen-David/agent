# 目录映射交付
本目录为只读盘点的文档副本，原始范围是 `inputs/organization`。
[CODEMAP](CODEMAP.md) 保留历史行并追加当前实验映射；表中代码路径均相对原始输入根目录。
`experiments/`、`results/`、`notes/` 内 README 解释对应输入目录；这里不复制或执行目标文件。
`docs/` 保存重组提案；`inventory.json` 保存文件哈希与引用证据。
活跃路径和保护项以原始 `active_tasks.json` 为准；不迁移、不删除输入。

| Experiment | Conclusion | Script | Data | Result | Citation |
|---|---|---|---|---|---|
| HIST-0 | unknown | archived/missing.py | unknown | unknown | unknown |
| ALPHA | inconclusive（文件记录，未运行验证） | experiments/alpha.py | synthetic-x（标签；原始数据未提供） | results/alpha.json | unknown |
| BETA | rejected（文件记录，未运行验证） | experiments/beta.py | synthetic-y（标签；原始数据未提供） | results/beta.json | unknown |

路径相对于原始 inputs/organization；本表是增量交付副本。HIST-0 历史行保留原顺序及内容。

ALPHA/BETA 来源锚点：对应 experiments/*.py:1 与 results/*.json:1；双方实验代号、输入标签和结果路径一致。脚本只有注释，未包含产出逻辑，因此无法确认 JSON 的实际生产过程。未提供数据文件、提交记录、运行日志及论文引用，相关来源保持 unknown。

active_tasks.json:1 声明两个脚本活跃，results/beta.json 为运行中输出，notes/orphan.txt 为受保护文件。此为提供的任务状态，未探查宿主进程。未执行任何目标脚本。

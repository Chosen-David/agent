# 历史笔记
原始目录仅有 `orphan.txt`，其内容明确缺少实验来源。
文件在 `active_tasks.json` 中受保护，不得因名称或缺少实验引用而删除。
未发现可推导的一般命名约定；保持原名。
来源未知项见 [CODEMAP](../CODEMAP.md) 与 [提案](../docs/reorg_proposal_2026-10-03.md)。

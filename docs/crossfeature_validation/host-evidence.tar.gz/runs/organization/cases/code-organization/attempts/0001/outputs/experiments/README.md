# 实验脚本
原始目录包含 `alpha.py` 与 `beta.py`，均由 `active_tasks.json` 声明活跃。
当前文件按实验名命名；头部记录 ALPHA/BETA、输入标签和结果路径。
两个脚本均为禁止执行的注释夹具，未提供生成结果的实现。
实验与结果关系见 [CODEMAP](../CODEMAP.md)。

# 结果记录
原始目录保存 `alpha.json` 与 `beta.json`，按实验名命名。
JSON 记录 experiment、input、result、script；与脚本注释可交叉核对。
记录结论分别为 inconclusive 与 rejected，不代表本次运行验证。
`results/beta.json` 是声明的运行中输出路径，不得移动。
映射见 [CODEMAP](../CODEMAP.md)。

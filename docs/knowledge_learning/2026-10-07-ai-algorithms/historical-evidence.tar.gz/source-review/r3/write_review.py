import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent
proof=json.loads((HERE/'alias-scope-proof.json').read_text())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
semantic={
 'ai.speculative-decoding-cost-bound':[
  ('speculative decoding speedup acceptance rate cost','Supported topic descriptor: the card derives the conditional relationship among accepted tokens and same-baseline draft/verification/other costs.'),
  ('推测解码 接受率 草稿开销','Supported algorithm-qualified topic descriptor. It does not assert that acceptance alone determines speed.'),
  ('expected accepted prefix tail sum total variation','Supported mechanism descriptor: accepted-prefix tail sum and the separately scoped single-proposal 1−TV identity are both present. It does not identify tree acceptance with 1−TV.'),
  ('correlated acceptance draft verification overhead','Supported boundary descriptor: conditional-event dependence is retained and draft, verification and other overhead are separated.'),
  ('tree MTP throughput latency boundary','Supported boundary descriptor, not a claim that the chain formula applies unchanged to trees or MTP; the body explicitly rejects that transfer.'),
  ('speculative decoding walltime analysis','Supported cost-analysis descriptor. The analysis is conditional and is not an empirical walltime benchmark.'),
  ('推测解码成本模型','Supported algorithm-qualified Chinese topic descriptor.')],
 'ai.speculative-sampling-residual-exactness':[
  ('speculative sampling rejection correction','Supported algorithm/mechanism descriptor; omitting residual here does not remove the residual mechanism from the unchanged title, summary, structures, assumptions or body.'),
  ('推测 解码 校正 随机 分布 无损','Supported retrieval topic words when read with the explicit exact-probability, true-proposal and correct-prefix assumptions; not unconditional runtime losslessness.'),
  ('greedy same seed distribution equivalence','Supported query-topic descriptor for distinctions and counterexamples. It must not be promoted to an assertion that greedy or same-seed identity implies distribution equivalence; the body explicitly denies those implications.'),
  ('tree verifier deterministic candidate elimination','Supported local-mechanism descriptor for sequential point-proposal elimination; it does not certify arbitrary trees or verifier implementations.'),
  ('MTP proposal probability mismatch','Supported failure-mode descriptor: the actual proposal law must match the probability used for correction, independently of the MTP name.'),
  ('modified rejection sampling','Supported established terminology. The supplied original Chen v1 text contains this heading and Theorem 1 title; symbol reversal is retained in the card.'),
  ('推测采样','Supported Chinese algorithm name.'),
  ('修正拒绝采样','Supported Chinese translation of the source terminology, within the explicit algorithm conditions.')]
}
result={
 'schema_version':1,
 'review_id':'AIK-02-r3-alias-and-upstream-overlap-independent-review',
 'reviewed_at_utc':datetime.now(timezone.utc).isoformat(),
 'status':'accepted-for-bounded-alias-semantics-and-nonduplication',
 'decision_gate':'EXECUTE: read-only semantic review and writing evidence only to the assigned reviewer output directory.',
 'repo_base_commit':proof['repo_base_commit'],
 'candidate_freeze':proof['freeze_files']['r3'],
 'candidate_files':proof['candidate_files']['r3'],
 'proof':{'path':'alias-scope-proof.json','sha256':sha(HERE/'alias-scope-proof.json'),'script':'verify_alias_scope.py','script_sha256':sha(HERE/'verify_alias_scope.py'),'passed':True,'mechanical_assertions':proof['check_count'],'count_scope':'Hash, exact-field-diff, raw-outside-alias, byte-identity and pinned-upstream checks; not 55 independent scientific experiments.'},
 'prior_source_review':{'path':'../review-result.json','sha256':proof['evidence_files']['source-review/review-result.json'],'inheritance_basis':'All r1 hashes match prior accepted review and reviewed-candidate snapshot. Both r3 bodies and all non-alias metadata are unchanged from that r1. Only aliases are newly reviewed here. No re-execution or new full-paper/math review claimed.'},
 'change_scope':{'r1_to_r3':'Only the top-level aliases array in each JSON changed; Markdown bytes and raw JSON outside the aliases array are identical.','r2_to_r3':'Same aliases-only property. R2 was inspected as candidate metadata/body, not through retrieval reports.','core_source_proof_status':'Preserved, not upgraded.','finding':'R3 retains mechanism/boundary topic descriptors from r1 while adding algorithm-qualified names from r2. Semantic coverage does not establish retrieval performance.'},
 'alias_semantics':{stem:[{'alias':alias,'decision':'accepted-as-retrieval-topic-descriptor','rationale':reason} for alias,reason in items] for stem,items in semantic.items()},
 'upstream_comparison':{
  'id':'infra.speculative-acceptance','version':1,'pinned_commit':proof['repo_base_commit'],'files':proof['upstream_files'],
  'decision':'complementary-nonduplicative-at-card-purpose-level',
  'shared_content':['Same Leviathan ICML 2023 primary paper.','Acceptance alone does not determine realized speed.','The alpha=0.8, gamma=4 expected-length example and same-seed/high-batch caveats overlap; do not present them as newly independent evidence.'],
  'existing_card_role':'Published empirical case: fixed single-TPU-v4, T5-XXL, batch-1, WMT/CNN-DailyMail observations, including smaller-draft speed/acceptance trade-offs and minimal transfer checks.',
  'residual_card_increment':['Explicit accepted-mass plus positive-residual identity and support/zero-residual conditions.','Actual post-processing proposal/target laws and correct sequential prefix/cache requirements.','Constructed failure cases distinguishing greedy, same-seed equality and distribution preservation.','Locally valid deterministic candidate elimination and bounded tree/MTP use.'],
  'cost_card_increment':['General conditional accepted-prefix tail sum without an independence assumption.','Separated c/v/o costs and same-baseline long-run accounting.','Explicitly restricted alpha>c existence threshold and endpoint cases.','Correlated-event, long-horizon and verification-overhead counterexamples; tree/MTP transfer boundaries.'],
  'documentation_needed':'Record the empirical-case versus derivation-card distinction and shared-paper/example overlap in the release report. Count two new reusable derivation cards, not two new empirical results or independent replications. Preserve the existing empirical card and its conditions.'
 },
 'proposed_relation_review':{
  'status':'semantically-approved-not-applied-or-byte-verified',
  'source_id':'ai.speculative-decoding-cost-bound',
  'append_relation':{'type':'related','id':'infra.speculative-acceptance'},
  'preserve_requires':[{'id':'ai.speculative-sampling-residual-exactness','version':1}],
  'preserve_existing_relation':{'type':'prerequisite','id':'ai.speculative-sampling-residual-exactness'},
  'sufficient':True,
  'direct_residual_to_infra_link_required':False,
  'reason':'The cost card is the direct mathematical companion of the empirical trade-off case; its existing prerequisite edge reaches the distribution-exactness foundation. Related expresses topical navigation without claiming that old measurements were derived from the new card. The empirical case is not a required mathematical premise.',
  'alternative':'A direct residual-to-Infra related link would be defensible as optional navigation, but adds no necessary dependency or semantic coverage here.',
  'integration_conditions':['Keep frozen r3 untouched. Adding this relation makes the publication metadata differ from the aliases-only freeze; describe the separate navigation change explicitly.','Freeze and hash the actual integrated candidate and run schema/link validation plus applicable retrieval/non-regression checks.','Do not count this semantic approval as byte verification of an unseen integrated artifact or as publication authorization.']
 },
 'independence':{
  'retrieval_queries_read':False,'gold_labels_read':False,'retrieval_result_files_read':False,
  'provenance_label_exposure':'candidate-freeze-3.json contains author-provided feedback-category labels; no queries, gold labels, ranks, scores or result files were inspected by this reviewer.',
  'reserved_holdout_policy_read':True,'reserved_target_contents_read':False,
  'sglang_files_read_or_modified':False,'repo_files_modified':False,'candidate_files_modified':False,'publication_performed':False,
  'owned_write_scope':'source-review/r3/'
 },
 'not_certified':['Retrieval gains, regression acceptance or generalization to unseen queries.','New mathematical proof status, runtime correctness, EAGLE end-to-end correctness or GPU/model performance.','Publication candidate bytes after the proposed navigation edge or other integration changes.'],
 'blocking_findings':[],
 'task_mapping':{'AIK-01':'Existing bounded source/body conclusions preserved by verified identity; no new source-research claim.','AIK-02':'Independent r3 alias scope/semantics and upstream nonduplication checks passed. Retrieval, CPU math and other acceptance remain separately owned.','AIK-03':'Relation/documentation integration, full regression and publication/readback remain with the main owner.'}
}
(HERE/'review-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
knowledge_use={
 'schema_version':1,'task_id':result['review_id'],'input_version':proof['freeze_files']['r3'],
 'decision':'Read allowlisted relevant entry files directly to preserve semantic-review isolation from retrieval tests.',
 'knowledge_tool_status':'Direct-file content/hash contract checked; no global retrieval or check-refs CLI was run.',
 'corpus':'Pinned upstream card at a35a102 plus frozen r3 candidate pair, treated as distinct published/candidate inputs.',
 'knowledge_refs':proof['knowledge_refs'],
 'applicability':[{'id':'infra.speculative-acceptance','adopted_for':'Classifying overlap as empirical case versus derivation; not transferring reported TPU-v4 performance to another environment.','condition_status':'Read original card conditions; empirical applicability to new environments is not asserted.'},{'id':'ai.speculative-sampling-residual-exactness','adopted_for':'Mapping alias terms to unchanged assumptions, mechanisms and counterexamples.','condition_status':'Candidate source/body identity verified against prior review; not promoted to production certification.'},{'id':'ai.speculative-decoding-cost-bound','adopted_for':'Mapping alias terms to conditional-tail and cost assumptions, and reviewing the related navigation edge.','condition_status':'Candidate source/body identity verified; no measured runtime cost supplied or inferred.'}],
 'evidence':['alias-scope-proof.json','review-result.json','alias-review.md'],
 'hash_note':'Ref hashes use the real agent_runtime.knowledge metadata/content normalization. The extra status/hash_method fields distinguish these audit records from strict check-refs input.'
}
(HERE/'knowledge-use.json').write_text(json.dumps(knowledge_use,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'result_sha256':sha(HERE/'review-result.json'),'knowledge_use_sha256':sha(HERE/'knowledge-use.json')},ensure_ascii=False))

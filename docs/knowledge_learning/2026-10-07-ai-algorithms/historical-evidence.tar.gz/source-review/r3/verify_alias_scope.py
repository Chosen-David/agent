#!/usr/bin/env python3
"""Read only allowlisted candidates and evidence; write proof only under this directory."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
ROUND = HERE.parent.parent
REPO = ROUND.parent / 'agent-ai-algorithms-20261007'
BASE_COMMIT = 'a35a102306e3aba0af1a5180390b226febe14705'
STEMS = ['ai.speculative-decoding-cost-bound', 'ai.speculative-sampling-residual-exactness']
FILES = [stem + ext for stem in STEMS for ext in ['.json', '.md']]
sha = lambda raw: hashlib.sha256(raw).hexdigest()
canonical = lambda value: json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
read_json = lambda path: json.loads(path.read_text(encoding='utf-8'))
checks = []
def check(label, condition):
    checks.append({'check': label, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(label)

def file_hash(path):
    return sha(path.read_bytes())

def without_alias_text(raw):
    value, count = re.subn(r'^  "aliases": \[\n.*?^  \],\n', '  "aliases": [],\n', raw, count=1, flags=re.M | re.S)
    check('exactly one top-level pretty-printed alias field replaced', count == 1)
    return value

source_review = read_json(ROUND/'source-review/review-result.json')
versions = {'r1': 'entries', 'r2': 'entries-r2', 'r3': 'entries-r3'}
freeze_paths = {v: ROUND/f'research/candidate-freeze-{n}.json' for n, v in enumerate(versions, 1)}
freezes = {v: read_json(path) for v, path in freeze_paths.items()}
proof = {
    'schema_version': 1,
    'task_id': 'AIK-02-r3-independent-alias-scope',
    'repo_base_commit': BASE_COMMIT,
    'freeze_files': {v: {'path': str(path.relative_to(ROUND)), 'sha256': file_hash(path)} for v, path in freeze_paths.items()},
    'candidate_files': {},
    'entries': {},
    'upstream_files': {},
    'knowledge_refs': [],
    'read_scope': 'Explicitly allowlisted cards, freezes and source-review metadata only; no evaluation queries, gold labels, retrieval-result files or reserved target contents.'
}
for version, folder in versions.items():
    root = ROUND/'research'/folder
    check(version + ' exactly four candidate files', {p.name for p in root.iterdir() if p.is_file()} == set(FILES))
    proof['candidate_files'][version] = {}
    for name in FILES:
        actual = file_hash(root/name)
        freeze_key = name if version == 'r3' else folder+'/'+name
        check(version+' frozen hash '+name, actual == freezes[version]['files'][freeze_key])
        proof['candidate_files'][version][name] = actual
        if version == 'r1':
            check('r1 matches prior source review '+name, actual == source_review['candidate_files'][name])
            check('prior reviewed snapshot '+name, actual == file_hash(ROUND/'source-review/reviewed-candidate'/name))

for stem in STEMS:
    metadata = {v: read_json(ROUND/'research'/folder/(stem+'.json')) for v, folder in versions.items()}
    texts = {v: (ROUND/'research'/folder/(stem+'.json')).read_text(encoding='utf-8') for v, folder in versions.items()}
    bodies = {v: (ROUND/'research'/folder/(stem+'.md')).read_bytes() for v, folder in versions.items()}
    records = {'diffs': {}, 'aliases': {v: d['aliases'] for v, d in metadata.items()}}
    for before, after in [('r1', 'r2'), ('r1', 'r3'), ('r2', 'r3')]:
        changed = sorted(k for k in set(metadata[before])|set(metadata[after]) if metadata[before].get(k) != metadata[after].get(k))
        check(stem+' '+before+' to '+after+' only aliases', changed == ['aliases'])
        check(stem+' '+before+' to '+after+' raw JSON outside aliases unchanged', without_alias_text(texts[before]) == without_alias_text(texts[after]))
        check(stem+' '+before+' to '+after+' body byte-identical', bodies[before] == bodies[after])
        records['diffs'][before+'..'+after] = {'changed_json_fields': changed, 'raw_json_outside_aliases_unchanged': True, 'body_byte_identical': True}
    records['non_alias_metadata_sha256'] = sha(canonical({k:v for k,v in metadata['r3'].items() if k != 'aliases'}))
    records['body_sha256'] = sha(bodies['r3'])
    proof['entries'][stem] = records
    proof['knowledge_refs'].append({'id': stem, 'version': metadata['r3']['version'], 'sha256': sha(canonical({'metadata': metadata['r3'], 'content': bodies['r3'].decode('utf-8')})), 'status': 'candidate', 'hash_method': 'agent_runtime.knowledge._digest metadata/content contract; computed directly without corpus traversal'})

upstream_metadata = None
upstream_body = None
for ext in ['.json', '.md']:
    rel = 'knowledge/entries/ai-infra/infra.speculative-acceptance'+ext
    pinned = subprocess.check_output(['git', 'show', BASE_COMMIT+':'+rel], cwd=REPO)
    check('upstream worktree matches pinned commit '+ext, pinned == (REPO/rel).read_bytes())
    proof['upstream_files'][rel] = {'sha256': sha(pinned), 'worktree_matches_pinned_commit': True}
    if ext == '.json': upstream_metadata = json.loads(pinned)
    else: upstream_body = pinned.decode('utf-8')
proof['knowledge_refs'].append({'id': upstream_metadata['id'], 'version': upstream_metadata['version'], 'sha256': sha(canonical({'metadata': upstream_metadata, 'content': upstream_body})), 'status': 'published', 'hash_method': 'agent_runtime.knowledge._digest metadata/content contract; computed directly without corpus traversal'})
proof['evidence_files'] = {name: file_hash(ROUND/name) for name in ['research/source-lock.json', 'source-review/review-result.json', 'source-review/source-review.md', 'source-review/source-manifest.json']}
proof['checks'] = checks
proof['passed'] = all(item['passed'] for item in checks)
proof['check_count'] = len(checks)
out = HERE/'alias-scope-proof.json'
out.write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'passed': proof['passed'], 'checks': len(checks), 'output': str(out), 'sha256': file_hash(out)}, ensure_ascii=False))

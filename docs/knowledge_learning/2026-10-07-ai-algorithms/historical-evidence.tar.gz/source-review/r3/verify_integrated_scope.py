#!/usr/bin/env python3
"""Validate only the two integrated cards and their freeze. Never inspect tests."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROUND=HERE.parent.parent
REPO=ROUND.parent/'agent-ai-algorithms-20261007'
FREEZE=REPO/'docs/knowledge_learning/2026-10-07-ai-algorithms/final-candidate-freeze.json'
STEMS=['ai.speculative-decoding-cost-bound','ai.speculative-sampling-residual-exactness']
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
load=lambda path:json.loads(path.read_text())
freeze=load(FREEZE)
checks=[]
def check(name, cond):
 checks.append({'check':name,'passed':bool(cond)})
 assert cond,name

def diff(a,b,prefix=''):
 if isinstance(a,dict) and isinstance(b,dict):
  out=[]
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b: out.append(prefix+k)
   else: out.extend(diff(a[k],b[k],prefix+k+'.'))
  return out
 return [prefix.rstrip('.')] if a != b else []

report={'schema_version':1,'review_id':'AIK-02-final-integration-scope-addendum','freeze':{'path':str(FREEZE.relative_to(REPO)),'sha256':sha(FREEZE),'metadata':freeze},'files':{},'diffs':{},'knowledge_refs':[], 'prior_r3_review':{'path':'review-result.json','sha256':sha(HERE/'review-result.json')}}
check('integrated base pinned',freeze['integrated_base']=='a35a102306e3aba0af1a5180390b226febe14705')
expected_checks=['docs/knowledge_learning/2026-10-07-ai-algorithms/'+f for f in ['source-review.md','source-lock.json','verify.py','checks.json','independent_math_check.py','independent_math_result.json','report.md']]
for stem in STEMS:
 before=load(ROUND/'research/entries-r3'/(stem+'.json'))
 file=REPO/'knowledge/entries/ai-algorithms'/(stem+'.json')
 after=load(file)
 changed=diff(before,after)
 allowed=['status','verification.checks','verification.proof']
 if stem.endswith('cost-bound'): allowed.append('relations')
 check(stem+' exactly declared changed fields',set(changed)==set(allowed))
 check(stem+' published is local schema status',after['status']=='published')
 check(stem+' proof tag is derivation-reviewed',after['verification']['proof']=='derivation-reviewed')
 check(stem+' review source unchanged',after['verification']['source']==before['verification']['source'])
 check(stem+' check paths are expected metadata only',after['verification']['checks']==expected_checks)
 check(stem+' requires unchanged',after['requires']==before['requires'])
 expected_relations=before['relations']+([{'type':'related','id':'infra.speculative-acceptance'}] if stem.endswith('cost-bound') else [])
 check(stem+' exact approved relation change',after['relations']==expected_relations)
 report['diffs'][stem]={'changed_fields':changed,'before_verification':before['verification'],'after_verification':after['verification'],'before_relations':before['relations'],'after_relations':after['relations'],'status_before':before['status'],'status_after':after['status']}
 for ext in ['.json','.md']:
  name=stem+ext
  path=file.with_suffix(ext)
  actual=sha(path)
  check(name+' matches final freeze',actual==freeze['files'][name])
  report['files'][name]=actual
  if ext=='.md':check(name+' body identical to r3',path.read_bytes()==(ROUND/'research/entries-r3'/name).read_bytes())
 canonical=json.dumps({'metadata':after,'content':file.with_suffix('.md').read_text()},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
 report['knowledge_refs'].append({'id':stem,'version':after['version'],'sha256':hashlib.sha256(canonical).hexdigest()})
description_complete = all(term in freeze.get('from_r3_alias_freeze_changes', '') for term in ['verification.proof', 'verification.checks', 'related']) and 'status candidate→published' in freeze.get('from_r3_integrated_freeze_changes', '')
check('freeze descriptions distinguish alias integration from local status promotion', description_complete)
report['freeze_scope_description_requires_correction']=not description_complete
report['checks']=checks
report['passed']=all(x['passed'] for x in checks)
report['mechanical_assertions']=len(checks)
report['retrieval_tests_or_results_read']=False
report['claimed_corpus_snapshot_verification']='Not performed. Full-corpus snapshot and entry count are copied from the owner freeze, not independently certified in this two-card review.'
report['evidence_path_contents_read']=False
report['scope']='Verifies exact local integrated card bytes, alias/body/core-premise preservation, declared metadata-only proof/check-path promotion and the approved related edge. Does not certify evidence-path contents, full schema regression, search performance, remote publication or broader corpus snapshot.'
(HERE/'integrated-scope-proof.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':report['passed'],'mechanical_assertions':len(checks),'freeze_scope_description_requires_correction':report['freeze_scope_description_requires_correction'],'freeze_sha256':sha(FREEZE),'output_sha256':sha(HERE/'integrated-scope-proof.json')}))

"""Verify frozen r2 contains alias changes only. Does not read evaluations."""
import hashlib, json
from pathlib import Path
root=Path(__file__).resolve().parents[2]
review=root/'source-review'
lock=json.loads((review/'review-result.json').read_text())['candidate_files']
r1=root/'research/entries';r2=root/'research/entries-r2'
for name,sha in lock.items():
    old=(r1/name).read_bytes(); new=(r2/name).read_bytes()
    assert hashlib.sha256(old).hexdigest()==sha,(name,'r1 changed')
    if name.endswith('.md'):
        assert old==new,(name,'body changed')
    else:
        a=json.loads(old);b=json.loads(new)
        assert {k for k in set(a)|set(b) if a.get(k)!=b.get(k)}=={'aliases'}
print('PASS: frozen r1 intact; r2 bodies identical; JSON differences exclusively aliases.')

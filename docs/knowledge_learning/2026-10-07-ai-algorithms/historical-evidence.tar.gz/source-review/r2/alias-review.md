# r2 alias 独立精确性审查

结论：accepted-alias-semantics-only。r2 是可解释的领域词汇整理；没有观察到题目/答案硬编码。本结论不声称检索回归已通过，candidate 是否发布仍依赖独立检索与原有完整验收。

审查材料仅为 r1/r2 两条候选、固定来源中已经核过的术语、FORMAT.md 和 alias diff/freeze 文件。未读12条冻结新题、gold、题目结果或检索实现；未向作者透露或索取这些材料。已知旧回归问题的概述来自 root，这使 r2 属于修复回归后的第二次候选，不能当成未经反馈的首次盲测。

## 术语结论

- residual 条目的 speculative sampling / 推测采样 是 Leviathan §2.3 的算法名；modified rejection sampling / 修正拒绝采样 对应 Chen PDF p.4 小标题。中文为忠实术语翻译，没有伪称原论文中文命名。
- cost 条目的 speculative decoding walltime analysis / speculative decoding speedup model / 推测解码时延分析 / 推测解码成本模型 是准确的领域限定描述，适配 Leviathan §3.3、Definition 3.7、Theorem 3.8。它们不是该论文正式命名的“新算法”，不应如此宣传。
- 旧 aliases 混合了问题触发词、机制词和负面适用边界。把所有旧词袋一致改成算法名或领域主题短语，有统一编辑原则，不是只为某一道题插入/排除词条。
- greedy、same-seed、tree、MTP、接受前缀与长度等信息仍在未改正文/structures/assumptions 中；没有删除真实声明、风险或反例以提高分数。
- 新 aliases 没有题目字符串、答案片段、检索文档 ID、特判指令、评分阈值或禁词列表。规范术语中的“拒绝”“采样”“成本”等也是跨任务正常词汇。
- 较短别名可能牺牲部分长尾检索覆盖；仅从词义不能断言净收益。须独立重跑预先固定评测，不调整 gold 或运行时规则，并保留首轮失败和 r1。

## 独立字节核查

已实际执行 `verify_alias_scope.py`：r1 四文件仍匹配前次审查 SHA；r2 两个 Markdown 与 r1 字节一致；两个 JSON 仅 aliases 字段改变，所有其他字段完全相等。

r2 JSON SHA256：
- cost：0a50c90f4a8b430e6ca01480b4257379c0daef4535d4358a2b4595f04a14d613
- residual：cda97a3e9277a5aac2bc99e59759342ca79abb28c38ba8154f4f9365ab1601a6

完整逐文件哈希和语义差异在 `alias-review-result.json`。初次检索失败的归档由评测 owner 核验，本审查未读取评测材料，不能独立认证其归档状态。

## 不扩大的接受范围

前次知识层面的数学/来源接受继续适用于相同正文。此次只增加 alias 词义与改动范围的接受，不认证算法实测、检索收益、生产部署或隐藏评测结论。主库、运行时、gold、正文和原候选均未由本 reviewer 修改。

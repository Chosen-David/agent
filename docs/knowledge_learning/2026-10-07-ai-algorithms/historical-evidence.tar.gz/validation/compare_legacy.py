#!/usr/bin/env python3
"""Per-case frozen legacy suite comparison; read-only inputs and ranking."""
import argparse,subprocess,sys,json,hashlib,os
from pathlib import Path

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--corpus',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
 a.out.mkdir(parents=True,exist_ok=False);r=a.repo
 baseline=r/'.agent-runs/ai-algorithms-20261007';summaries=[];regressions=[];env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
 for suite,name in [('original','queries.json'),('round2','round2-queries.json'),('morphology','morphology-queries.json')]:
  queryfile=r/'evals/knowledge'/name;oldfile=baseline/f'baseline-{suite}.json';oldhash=sha(oldfile);queryhash=sha(queryfile)
  output=a.out/f'{suite}-expanded.json';cmd=[sys.executable,str(r/'scripts/eval_knowledge.py'),'--root',str(a.corpus),'--cases',str(queryfile),'--output',str(output)]
  cp=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  (a.out/f'{suite}-run.log').write_text(cp.stdout)
  old=json.loads(oldfile.read_text());new=json.loads(output.read_text())
  summary={'suite':suite,'baseline_snapshot':old['snapshot'],'expanded_snapshot':new['snapshot'],'baseline_sha256':oldhash,'original_query_file_sha256':queryhash,'command':cmd,'cli_exit_code':cp.returncode,'backends':{}}
  for backend,b in old['backends'].items():
   n=new['backends'][backend];changes=[];rows=[]
   assert len(b['queries'])==len(n['queries'])
   for before,after in zip(b['queries'],n['queries']):
    assert (before['case'],before['query'],before['expected'])==(after['case'],after['query'],after['expected'])
    metrics=['recall_at_3','context_recall','reciprocal_rank','no_hit_correct']
    change={m:{'old':before[m],'new':after[m]} for m in metrics if before[m]!=after[m]}
    worse=[m for m in ['recall_at_3','context_recall','reciprocal_rank'] if before[m] is not None and after[m]<before[m]]
    if before['no_hit_correct'] is True and after['no_hit_correct'] is not True:worse.append('no_hit_correct')
    row={'case':before['case'],'query':before['query'],'expected':before['expected'],'old_actual':before['actual'],'new_actual':after['actual'],'old_context':before['context_ids'],'new_context':after['context_ids'],'metric_changes':change,'regressed_metrics':worse,'old_metrics':{m:before[m] for m in metrics},'new_metrics':{m:after[m] for m in metrics}}
    rows.append(row)
    if change:changes.append(row)
    if worse:regressions.append({'suite':suite,'backend':backend,**row})
   summary['backends'][backend]={'old_summary':{k:x for k,x in b.items() if k.startswith('mean_')},'new_summary':{k:x for k,x in n.items() if k.startswith('mean_')},'metric_changes':changes,'all_queries':rows}
  assert oldhash==sha(oldfile) and queryhash==sha(queryfile)
  summaries.append(summary)
 result={'schema_version':1,'scope':'Same original queries, expected values and ranking; per-query comparison against root 16-entry baseline; status-only candidate copy. CLI exit code is not the acceptance metric.','all_original_inputs_unchanged':True,'no_new_regressions':not regressions,'regressions':regressions,'suites':summaries,'script_sha256':sha(Path(__file__))}
 (a.out/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'no_new_regressions':not regressions,'regression_case_backend_pairs':len(regressions),'out':str(a.out)},ensure_ascii=False))
if __name__=='__main__':main()

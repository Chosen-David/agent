from pathlib import Path
import json,hashlib,datetime
root=Path(__file__).parent
retr=json.loads((root/'candidate_v1/retrieval_results.json').read_text())
cases=json.loads((root/'frozen_tasks.json').read_text())['cases']
reviews={
'A01':('apply',['residual:s3','residual:s4'],'All premises supplied. Compute accepted mass (1/4,1/3,1/6), alpha=3/4, r=(1,0,0), output p.'),
'A02':('apply_boundary',['residual:s3'],'q need not cover target support. Never evaluate p/q at q=0 on a sampled point; missing target mass comes from correction.'),
'A03':('apply_boundary',['residual:s3'],'p=q implies alpha=1 and zero residual mass; reject unconditional normalization. Bonus uses target at the accepted prefix.'),
'A04':('reject_false_premise',['residual:s3','residual:s6'],'The distribution used by verification is not the actual top-1 proposal. Wrong output=(1,0); replacing q by actual delta restores target.'),
'A05':('reject_invalid_correction',['residual:s4','residual:s6'],'Rejection fallback p is not residual; wrong output=(5/8,3/8). Kernel check confirms the discrepancy exactly.'),
'A06':('reject_target_mismatch',['residual:s6'],'Greedy agreement preserves only a separately specified greedy target; output delta is not stochastic p. Do not silently change the task objective.'),
'A07':('insufficient_information',['residual:s7','residual:s4'],'Head marginals do not specify proposal joint law or sequential conditionals. Independent heads give mismatch mass 1/2. No generic MTP rejection or certification is inferred.'),
'A08':('reject_selection_bias',['residual:s7','residual:s3'],'Selecting a preferred sibling changes proposal to (1/4,3/4); equality of individual node marginals is insufficient. The candidate separately permits correctly updated point-proposal elimination.'),
'A09':('reject_iid_shortcut_apply_tail',['prefix:s5','prefix:s8'],'Marginal alpha=1/2 does not yield geometric tails. Correct tails=1,1/2,1/2,1/2 and E[L]=5/2; iid shortcut=15/8.'),
'A10':('apply_conditional_tail',['prefix:s5'],'Conditional rates yield tails=1,1/2,3/8,1/4 and E[L]=17/8 without independence. After zero survival all later tail terms are zero.'),
'A11':('apply_only_stated_cost_model',['prefix:s6','prefix:s10'],'Under long-run stable model, 16ms per round gives 128/17ms/token and speed 85/64; 26ms gives speed 85/104<1. Unknown costs imply unknown speed.'),
'A12':('reject_unclipped_cost_claim',['prefix:s5','prefix:s10','residual:s4'],'One remaining token makes useful output 1, speed 5/8 under paid full-draft cost. EOS half-probability caps expectation at 15/8. Preserve target stopping rule and recompute useful output/cost.')}
rows=[]
for case in cases:
    decision,locs,note=reviews[case['id']]
    cites=[]
    for loc in locs:
        role,node=loc.split(':');tree=json.loads((root/f'candidate_v1/{role}_tree.json').read_text())
        sec=next(n for n in tree['nodes'] if n['node']==node)
        cites.append({'id':tree['id'],'version':tree['version'],'sha256':tree['sha256'],'node':node,'title':sec['title'],'start_line':sec['start_line'],'end_line':sec['end_line']})
    rows.append({'case':case['id'],'decision':decision,'review':'pass','explanation':note,'source_sections':cites,'numerical_evidence':'math_results.json','retrieved_in_default_context_both_backends':all(next(r for r in b['rows'] if r['case']==case['id'])['context_hit'] for b in retr['backends'].values())})
review={'schema_version':1,'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'evaluator_scope':'Independent from candidate author; this validator froze tasks before reading candidates, then manually reviewed retrieved full text and calculated answers with exact scripts. This is not a separately sampled model-use benchmark or automatic applicability enforcement.','frozen_tasks_sha256':hashlib.sha256((root/'frozen_tasks.json').read_bytes()).hexdigest(),'candidate_source_hashes':retr['candidate_sources'],'result':'12/12 premise/outcome reviews pass','rows':rows,'supplemental':'Four candidate-specific families checked after reading candidate; separately labeled, not blind.'}
(root/'application_review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
r=next(x for x in retr['backends']['sqlite']['rows'] if x['case']=='A12')
failure={'schema_version':1,'first_observed_failure':{'type':'raw_top3_retrieval_miss','case':'A12','backend':'sqlite-fts5-rrf-v1','query':r['query'],'expected':r['expected_id'],'actual':r['raw_top3']},'recovery':{'mechanism':'Existing default related-neighbor context expansion; no metadata or ranking edit','context_ids':r['context_ids'],'budget':r['budget'],'expected_bundle_complete':r['context_hit']},'raw_failure_still_counted':True,'code_or_candidate_fix_applied':False,'scope':'A retrieval miss with supported navigation recovery, not a theorem error or fabricated code repair.'}
(root/'first_failure_and_recovery.json').write_text(json.dumps(failure,ensure_ascii=False,indent=2)+'\n')
print(review['result'])
